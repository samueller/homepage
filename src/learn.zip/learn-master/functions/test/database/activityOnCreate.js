import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const activityOnCreate =
  proxyquire(
    '../../database/activityOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CACHE BY LESSON

test('cacheByLesson creates the correct cache', async t => {
  await activityOnCreate._test.cacheByLesson(
    { lessonId: 'lesson-1', id: 'activity-1' }
  )
  t.deepEqual(
    mockdatabase.getData().activityLessons,
    { 'activity-1': 'lesson-1' }
  )
})

// CACHE EXERCISE SET BY ACTIVITY

test('cacheExerciseSetByActivity creates the correct cache', async t => {
  await activityOnCreate._test.cacheExerciseSetByActivity(
    { id: 'activity-1' },
    { activityId: 'exercise-set-1', activityType: 'exercises' }
  )
  t.deepEqual(
    mockdatabase.getData().exerciseSetActivities,
    { 'exercise-set-1': 'activity-1' }
  )
})

// CACHE PROJECT STEP BY ACTIVITY

test('cacheByProjectStepByActivity creates the correct cache', async t => {
  await activityOnCreate._test.cacheByProjectStepByActivity(
    { id: 'activity-1' },
    { activityId: 'project-step-1', activityType: 'project_step' }
  )
  t.deepEqual(
    mockdatabase.getData().projectStepActivities,
    { 'project-step-1': 'activity-1' }
  )
})
