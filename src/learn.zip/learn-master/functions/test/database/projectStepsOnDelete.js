import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const projectStepsOnDelete =
  proxyquire(
    '../../database/projectStepsOnDelete',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// DELETE CACHE BY ACTIVITY

test('deleteCacheByActivity removes the related cache', async t => {
  mockdatabase.set({
    projectStepActivities: { 'project-step-1': 'activity-1' }
  })
  await projectStepsOnDelete._test.deleteCacheByActivity(
    { projectStepId: 'project-step-1' }
  )
  t.falsy(mockdatabase.getData())
})
