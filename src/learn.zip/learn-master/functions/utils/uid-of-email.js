const db = require('./db')

module.exports = email =>
  db.valueOf(db.ref('users').orderByChild('email').equalTo(email))
    .then(users => users && Object.keys(users)[0])
