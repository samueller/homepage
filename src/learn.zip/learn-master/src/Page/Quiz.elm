module Page.Quiz exposing (main)

import Dict
import Dict.Extra as Dict
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Firebase.Errors
import Html exposing (..)
import Html.Attributes exposing (..)
import Json.Decode as Decode
import Json.Encode as Encode
import List
import Material.Grid as Grid
import Random.Pcg as Random
import RemoteData
import Task
import Types.Activity as Activity
import Types.Chapter as Chapter
import Types.Instruction as Instruction
import Types.Instructor as Instructor
import Types.Lesson as Lesson
import Types.Milestone as Milestone
import Types.MultResp as MultResp
import Types.Quiz as Quiz
import UCode.Browser as Browser
import UCode.Data as Data
import UCode.Firebase
import UCode.Model
import UCode.Msg
import UCode.Users as Users
import UCode.View as View
import Util.Heading as Heading


main : Program UCode.Model.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUserAndCmd SharedMsg initialModel initialCmd
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialCmd : UCode.Model.SharedModelFirebaseUser -> Cmd Msg
initialCmd sharedModel =
    Random.generate RandomInt <|
        Random.int Random.minInt Random.maxInt


type alias RemoteData a =
    RemoteData.RemoteData String a


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , lessonId : Data.Id
    , lessonResult : Maybe Lesson.Result
    , activityId : Data.Id
    , activity : Maybe Activity.Activity
    , nextActivityId : Maybe Data.Id
    , nextActivity : Maybe Activity.Activity
    , nextLessonId : Maybe Data.Id
    , nextLesson : Maybe Lesson.Lesson
    , nextLessonActivityId : Maybe Data.Id
    , nextLessonActivity : Maybe Activity.Activity
    , id : Data.Id
    , studentQuestions : Dict.Dict Int ( Data.Id, Quiz.Question )
    , allQuestions : Dict.Dict Int (List ( Data.Id, Quiz.Question ))
    , currentQuestionNumber : Int
    , multRespQuestions : Dict.Dict Data.Id MultResp.Question
    , multRespOptions : Dict.Dict Data.Id (List ( Data.Id, MultResp.OptionNoId ))
    , multRespSelections : Dict.Dict Data.Id (List ( Data.Id, Bool ))
    , oldScore : Maybe Activity.Result
    , score : Maybe Activity.Result
    , isInstructor : RemoteData Bool
    , showAnswers : Bool
    , sharedModel : UCode.Model.SharedModelFirebaseUser
    }


initialModel : UCode.Model.SharedModelFirebaseUser -> Model
initialModel sharedModel =
    { milestone = Nothing
    , chapter = Nothing
    , lesson = Nothing
    , lessonId = Browser.queryParam "lesson"
    , lessonResult = Nothing
    , activityId = Browser.queryParam "activity"
    , activity = Nothing
    , nextActivityId = Nothing
    , nextActivity = Nothing
    , nextLessonId = Nothing
    , nextLesson = Nothing
    , nextLessonActivityId = Nothing
    , nextLessonActivity = Nothing
    , id = Browser.queryId
    , studentQuestions = Dict.empty
    , allQuestions = Dict.empty
    , currentQuestionNumber = 1
    , multRespQuestions = Dict.empty
    , multRespOptions = Dict.empty
    , multRespSelections = Dict.empty
    , oldScore = Nothing
    , score = Nothing
    , isInstructor = RemoteData.Loading
    , showAnswers = False
    , sharedModel = sharedModel
    }


type Msg
    = SharedMsg UCode.Msg.Msg
    | ChangedIsInstructor (Result String Bool)
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | ChangedLessonResult Types.Snapshot
    | ChangedActivity Types.Snapshot
    | ChangedNextActivity Types.Snapshot
    | ChangedNextLesson Types.Snapshot
    | ChangedNextLessonActivity Types.Snapshot
    | RandomInt Int
    | GotQuestions Int (Result Firebase.Errors.Error Types.Snapshot)
    | ChangedMultResp Types.Snapshot
    | AddedMultRespOption Bool Data.Id Types.Snapshot
    | ChangedMultRespOption Data.Id Types.Snapshot
    | RemovedMultRespOption Data.Id Types.Snapshot
    | Scored Types.Snapshot
    | CheckOption Data.Id Data.Id String Bool
    | PrevQuestion
    | NextQuestion
    | ToggleAnswers
    | Submitted (Result Firebase.Errors.Error ())


questionsByNumber : Int -> List ( Data.Id, Quiz.Question ) -> Dict.Dict Int ( Data.Id, Quiz.Question )
questionsByNumber randomInt =
    Dict.map (\_ -> Data.randomListElementWithDefault randomInt ( "", Quiz.emptyQuestion ))
        << Dict.groupBy (.number << Tuple.second)


submitAnswers : Model -> UCode.Firebase.FirebaseApp -> Cmd Msg
submitAnswers model firebase =
    let
        questionResponseKeyAndTask =
            UCode.Firebase.keyAndTaskFromPush
                firebase.db
                ("questionResponses/" ++ model.sharedModel.user.uid ++ "/" ++ model.id)
                (MultResp.valueFromResponses model.multRespSelections)
    in
    Task.attempt Submitted <|
        Task.andThen
            (\_ ->
                UCode.Firebase.saveTrueTask
                    ("activityQuestionResponses/" ++ model.sharedModel.user.uid ++ "/" ++ model.activityId ++ "/" ++ model.id ++ "/" ++ questionResponseKeyAndTask.key)
                    firebase.db
            )
            questionResponseKeyAndTask.task


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedIsInstructor result ->
            { model | isInstructor = RemoteData.fromResult result } ! []

        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedLessonResult snapshot ->
            Lesson.recordMaybeLessonResultSnapshot model snapshot ! []

        ChangedActivity snapshot ->
            case Decode.decodeValue Activity.decoder (Snapshot.value snapshot) of
                Ok activity ->
                    { model | activity = Just activity } ! []

                Err _ ->
                    { model | activity = Nothing } ! []

        ChangedNextActivity snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Activity.decoder) (Snapshot.value snapshot) of
                Ok (( activityId, activity ) :: _) ->
                    { model
                        | nextActivityId = Just activityId
                        , nextActivity = Just activity
                    }
                        ! []

                _ ->
                    { model
                        | nextActivityId = Nothing
                        , nextActivity = Nothing
                    }
                        ! []

        ChangedNextLesson snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Decode.int) (Snapshot.value snapshot) of
                Ok (( lessonId, number ) :: _) ->
                    { model | nextLessonId = Just lessonId } ! []

                _ ->
                    { model | nextLessonId = Nothing } ! []

        ChangedNextLessonActivity snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Activity.decoder) (Snapshot.value snapshot) of
                Ok (( activityId, activity ) :: _) ->
                    { model
                        | nextLessonActivityId = Just activityId
                        , nextLessonActivity = Just activity
                    }
                        ! []

                _ ->
                    { model
                        | nextLessonActivityId = Nothing
                        , nextLessonActivity = Nothing
                    }
                        ! []

        RandomInt int ->
            ( model
            , UCode.Firebase.onceMaybe
                (GotQuestions int)
                ("quizzes/" ++ model.id ++ "/questions")
                model.sharedModel.firebaseApp
            )

        GotQuestions randomInt (Ok snapshot) ->
            case Decode.decodeValue (Decode.keyValuePairs Quiz.questionDecoder) (Snapshot.value snapshot) of
                Ok questions ->
                    { model
                        | studentQuestions = questionsByNumber randomInt questions
                        , allQuestions = Dict.groupBy (.number << Tuple.second) questions
                    }
                        ! []

                _ ->
                    model ! []

        GotQuestions _ (Err _) ->
            model ! []

        ChangedMultResp snapshot ->
            case ( Snapshot.key snapshot, Decode.decodeValue MultResp.questionDecoder (Snapshot.value snapshot) ) of
                ( Just id, Ok question ) ->
                    { model | multRespQuestions = Dict.insert id question model.multRespQuestions } ! []

                _ ->
                    model ! []

        AddedMultRespOption isStudentQuestion multRespId snapshot ->
            case ( Snapshot.key snapshot, Decode.decodeValue MultResp.optionNoIdDecoder (Snapshot.value snapshot) ) of
                ( Just id, Ok option ) ->
                    { model
                        | multRespOptions =
                            Data.dictWithAddedListElement multRespId ( id, option ) model.multRespOptions
                        , multRespSelections =
                            if isStudentQuestion then
                                Data.dictWithAddedListElement multRespId ( id, False ) model.multRespSelections

                            else
                                model.multRespSelections
                    }
                        ! []

                _ ->
                    model ! []

        ChangedMultRespOption multRespId snapshot ->
            case ( Snapshot.key snapshot, Decode.decodeValue MultResp.optionNoIdDecoder (Snapshot.value snapshot) ) of
                ( Just id, Ok option ) ->
                    { model | multRespOptions = Data.dictWithChangedIdListElement multRespId ( id, option ) model.multRespOptions } ! []

                _ ->
                    model ! []

        RemovedMultRespOption multRespId snapshot ->
            case Snapshot.key snapshot of
                Just id ->
                    { model
                        | multRespOptions = Data.dictWithRemovedIdListElement multRespId id model.multRespOptions
                        , multRespSelections = Data.dictWithRemovedIdListElement multRespId id model.multRespSelections
                    }
                        ! []

                _ ->
                    model ! []

        Scored snapshot ->
            case Decode.decodeValue Activity.resultDecoder (Snapshot.value snapshot) of
                Ok result ->
                    if model.currentQuestionNumber == 0 then
                        { model | score = Just result } ! []

                    else
                        { model | oldScore = Just result } ! []

                Err _ ->
                    model ! []

        CheckOption multRespId multRespOptionId content checked ->
            { model
                | multRespSelections =
                    Data.dictWithChangedIdListElement multRespId ( multRespOptionId, checked ) model.multRespSelections
            }
                ! []

        PrevQuestion ->
            let
                questionNumber =
                    model.currentQuestionNumber - 1

                maybeQuestion =
                    Dict.get questionNumber model.studentQuestions
            in
            case maybeQuestion of
                Just ( questionId, question ) ->
                    ( { model | currentQuestionNumber = questionNumber }
                    , View.scrollToElement ("question_" ++ questionId)
                    )

                Nothing ->
                    model ! []

        NextQuestion ->
            let
                questionNumber =
                    model.currentQuestionNumber + 1

                maybeQuestion =
                    Dict.get questionNumber model.studentQuestions
            in
            case maybeQuestion of
                Just ( questionId, question ) ->
                    ( { model | currentQuestionNumber = questionNumber }
                    , View.scrollToElement ("question_" ++ questionId)
                    )

                Nothing ->
                    ( { model | currentQuestionNumber = 0 }
                    , Data.foldMaybe Cmd.none (submitAnswers model) model.sharedModel.firebaseApp
                    )

        ToggleAnswers ->
            { model | showAnswers = not model.showAnswers } ! []

        Submitted _ ->
            model ! []

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model


nextLink : Model -> Maybe String
nextLink model =
    case ( model.nextActivityId, model.nextActivity, model.nextLessonId, model.nextLessonActivityId, model.nextLessonActivity ) of
        ( Just nextActivityId, Just nextActivity, _, _, _ ) ->
            Just (Activity.href nextActivity nextActivityId model.lessonId)

        ( _, _, Just nextLessonId, Just nextActivityId, Just nextActivity ) ->
            Just (Activity.href nextActivity nextActivityId nextLessonId)

        _ ->
            Nothing


viewMultRespOption : Model -> Data.Id -> Int -> Int -> ( Data.Id, MultResp.OptionNoId ) -> Html Msg
viewMultRespOption model multRespId questionIndex optionIndex ( optionId, option ) =
    li [ class "quiz__option", id ("option_" ++ optionId) ]
        [ View.checkbox model
            SharedMsg
            (CheckOption multRespId optionId option.content)
            False
            [ 0, optionIndex, questionIndex ]
            (Data.idListElementWithDefault False optionId (Dict.get multRespId model.multRespSelections))
            [ Instruction.div option.content ]
        ]


viewMultRespOptions : Model -> Data.Id -> Int -> List ( Data.Id, MultResp.OptionNoId ) -> Html Msg
viewMultRespOptions model multRespId index =
    ol [ class "quiz__options" ]
        << List.indexedMap (viewMultRespOption model multRespId index)


viewQuestion : Model -> Int -> Quiz.Question -> List (Html Msg)
viewQuestion model index question =
    [ Data.foldDict View.spinner (Instruction.div << .question) question.questionId model.multRespQuestions
    , Data.foldDict View.spinner (viewMultRespOptions model question.questionId index) question.questionId model.multRespOptions
    ]
        ++ (if model.currentQuestionNumber == question.number then
                [ div [ class "actions" ]
                    [ View.buttonWithText model SharedMsg PrevQuestion (model.currentQuestionNumber <= 1) [ 0, index ] "Previous"
                    , text " "
                    , View.buttonWithText model SharedMsg NextQuestion False [ 1, index ] "Next"
                    ]
                ]

            else
                []
           )


viewQuizQuestion : Model -> Int -> ( Int, ( Data.Id, Quiz.Question ) ) -> Html Msg
viewQuizQuestion model index ( number, ( quizQuestionId, question ) ) =
    li
        [ classList
            [ ( "question", True )
            , ( "current"
              , number == model.currentQuestionNumber || model.currentQuestionNumber == 0
              )
            ]
        , value (toString number)
        , id ("question_" ++ quizQuestionId)
        ]
        (viewQuestion model index question)


viewMultRespOptionsAnswers : Model -> Data.Id -> List ( Data.Id, MultResp.OptionNoId ) -> Html Msg
viewMultRespOptionsAnswers model questionId options =
    let
        viewOption ( id, option ) =
            li [ class "quiz__option" ]
                [ View.checkbox
                    model
                    SharedMsg
                    (CheckOption "" "" "")
                    True
                    [ 0 ]
                    option.correct
                    [ Instruction.div option.content ]
                ]
    in
    ol [ class "quiz__options" ] (List.map viewOption options)


viewQuestionAnswer : Model -> ( Data.Id, Quiz.Question ) -> Html Msg
viewQuestionAnswer model ( id, question ) =
    li [ value (toString question.number) ]
        [ Data.foldDict
            View.spinner
            (Instruction.div << .question)
            question.questionId
            model.multRespQuestions
        , Data.foldDict
            View.spinner
            (viewMultRespOptionsAnswers model question.questionId)
            question.questionId
            model.multRespOptions
        ]


viewScore : Model -> Html Msg
viewScore model =
    case model.score of
        Just result ->
            h1 [ class "result" ] [ text ("Score: " ++ toString (round result.score) ++ "%") ]

        Nothing ->
            if model.currentQuestionNumber == 0 then
                View.spinner

            else
                hr [] []


viewAnswersButton : Model -> Html Msg
viewAnswersButton model =
    View.buttonWithText
        model
        SharedMsg
        ToggleAnswers
        False
        [ 0 ]
        (if model.showAnswers then
            "Hide Answers"

         else
            "Show Answers"
        )


viewAnswersButtonIfInstructor : Model -> Html Msg
viewAnswersButtonIfInstructor model =
    case model.isInstructor of
        RemoteData.NotAsked ->
            text ""

        RemoteData.Loading ->
            text ""

        RemoteData.Failure error ->
            div [] [ text <| "An error occured while checking your permissions: " ++ error ]

        RemoteData.Success True ->
            viewAnswersButton model

        RemoteData.Success False ->
            text ""


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        (if Dict.isEmpty model.studentQuestions then
            [ View.fullWidthCell [ View.spinner ] ]

         else
            [ Heading.viewActivityHeading model "Quiz"
            , View.fullWidthCell [ viewAnswersButtonIfInstructor model ]
            , View.fullWidthCell
                [ ol [ class "quiz container" ] <|
                    if model.showAnswers then
                        Dict.values model.allQuestions
                            |> List.concat
                            |> List.map (viewQuestionAnswer model)

                    else
                        List.indexedMap (viewQuizQuestion model) (Dict.toList model.studentQuestions)
                , viewScore model
                , View.activityActions
                    [ View.buttonLink model
                        SharedMsg
                        (if model.currentQuestionNumber == 0 && Data.isJust model.score then
                            nextLink model

                         else
                            Nothing
                        )
                        [ 0 ]
                        [ text "Next Activity" ]
                    ]
                ]
            ]
        )
    ]


activitySubs : Model -> UCode.Firebase.FirebaseApp -> Activity.Activity -> Sub Msg
activitySubs model firebase activity =
    UCode.Firebase.valuesByChildSubscription ChangedNextActivity ("activities/" ++ model.lessonId) "number" firebase (Encode.int (activity.number + 1))


nextLessonActivitySubs : Model -> UCode.Firebase.FirebaseApp -> Data.Id -> Sub Msg
nextLessonActivitySubs model firebase nextLessonId =
    UCode.Firebase.valuesByChildSubscription ChangedNextLessonActivity ("activities/" ++ nextLessonId) "number" firebase (Encode.int 1)


nextLessonSubs : Model -> UCode.Firebase.FirebaseApp -> Lesson.Result -> Lesson.Lesson -> Sub Msg
nextLessonSubs model firebase lessonResult lesson =
    UCode.Firebase.valuesByChildValueSubscription ChangedNextLesson ("lessonNumbers/" ++ lesson.chapterId) firebase (Encode.int (lesson.number + 1))


isStudentQuestion : Data.Id -> Dict.Dict comparable ( Data.Id, a ) -> Bool
isStudentQuestion id =
    Dict.find (\_ ( id_, _ ) -> id_ == id) >> (/=) Nothing


questionSubs : UCode.Firebase.FirebaseApp -> Dict.Dict Int ( Data.Id, Quiz.Question ) -> ( Data.Id, Quiz.Question ) -> Sub Msg
questionSubs firebase studentQuestions ( id, question ) =
    Sub.batch
        [ UCode.Firebase.idSubscription
            "questions/multResp"
            firebase
            ChangedMultResp
            question.questionId
        , UCode.Firebase.objectsSubscriptions
            ("multRespOptions/" ++ question.questionId)
            firebase.db
            (AddedMultRespOption (isStudentQuestion id studentQuestions) question.questionId)
            (ChangedMultRespOption question.questionId)
            (RemovedMultRespOption question.questionId)
        ]


firebaseSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ UCode.Firebase.idSubscription ("lessonResults/" ++ model.sharedModel.user.uid) firebase ChangedLessonResult model.lessonId
        , UCode.Firebase.idSubscription ("activities/" ++ model.lessonId) firebase ChangedActivity model.activityId
        , UCode.Firebase.idSubscription ("activityResults/" ++ model.sharedModel.user.uid) firebase Scored model.activityId
        , Data.foldMaybe Sub.none (activitySubs model firebase) model.activity
        , Data.foldMaybe Sub.none (nextLessonActivitySubs model firebase) model.nextLessonId
        , Data.fold2Maybes Sub.none (nextLessonSubs model firebase) model.lessonResult model.lesson
        , Sub.batch <|
            List.map
                (questionSubs
                    firebase
                    model.studentQuestions
                )
            <|
                List.concat <|
                    Dict.values model.allQuestions
        , Instructor.subIsInstructor model.sharedModel.user.uid ChangedIsInstructor firebase
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        , Data.foldMaybe Sub.none (firebaseSubs model) model.sharedModel.firebaseApp
        ]
