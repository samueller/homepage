import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const facebookEventSharesOnCreate =
  proxyquire(
    '../../database/facebookEventSharesOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CREATE FACEBOOK EVENT SHARE TRANSACTION

test('createFacebookEventShareTransaction creates a valid transaction', async t => {
  await facebookEventSharesOnCreate._test.createFacebookEventShareTransaction(
    { userId: 'testUserId', eventId: 'event-12345' }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'facebookEventShares',
          reasonId: 'event-12345',
          change: 50,
          timestamp:
            ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})
