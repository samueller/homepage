module Page.ManageCenter exposing (main)

import Set exposing (Set)
import Html exposing (Html, nav, h1, h2, h3, h4, fieldset, legend, p, strong, text, ul, li, span, br, div, a, img)
import Html.Attributes exposing (class, classList, href, src, style)
import Task
import Dict exposing (Dict)
import List.Extra
import RemoteData
import Material.Options as Options
import Material.Tabs as Tabs
import Material.Grid as Grid
import Material.Typography as Typography
import UCode.View as View
import UCode.Users as Users
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import UCode.Model
import UCode.Msg
import UCode.Sub
import UCode.Browser
import Types.Student as Student exposing (Student)
import Types.Invite as Invite exposing (Invite)
import Types.Instructor as Instructor exposing (Instructor, InstructorTeamupId)
import Types.Center as Center exposing (Center)
import Types.Manager as Manager
import Types.Completion as Completion exposing (CachedMilestone)
import Types.Curricula as Curricula exposing (Curricula)
import Util.Form exposing (Form)
import Util.Form.View
import Util.Form.Value as Value exposing (Value)
import View.Loading
import View.Dropdown
import View.Button
import View.Dialog
import View.Table


main : Program UCode.Model.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.init SharedMsg init
        , view = View.viewWithDialog SharedMsg view
        , update = update
        , subscriptions = subscriptions
        }



-- MODEL


type alias RemoteData a =
    RemoteData.RemoteData String a


type alias InviteFormValues =
    { email : Value String
    , name : Value String
    , birthDate : Value String
    , permission : Value String
    }


type alias InviteForm =
    Util.Form.View.Model InviteFormValues


type Tab
    = Students
    | Instructors
    | InviteTab


tabs : List Tab
tabs =
    [ Students, Instructors, InviteTab ]


type alias Model =
    { sharedModel : UCode.Model.SharedModelFirebaseUser
    , isManager : RemoteData Bool
    , centerId : Id
    , center : RemoteData Center
    , students : RemoteData (Dict Id Student)
    , instructors : RemoteData (Dict Id Instructor)
    , invites : RemoteData (Dict Id Invite)
    , milestoneCompletions : RemoteData (List ( String, Dict Int (List CachedMilestone) ))
    , curricula : RemoteData Curricula
    , instructorTeamupIds : RemoteData (Dict Int InstructorTeamupId)
    , tab : Tab
    , selectedStudentDropdown : String
    , selectedInstructorDropdown : String
    , inviteForm : InviteForm
    , expandedMilstoneMonths : Set String
    }


init : UCode.Model.SharedModelFirebaseUser -> ( Model, Cmd Msg )
init sharedModel =
    { sharedModel = sharedModel
    , isManager = RemoteData.Loading
    , centerId = UCode.Browser.queryId
    , center = RemoteData.NotAsked
    , students = RemoteData.NotAsked
    , instructors = RemoteData.NotAsked
    , invites = RemoteData.NotAsked
    , milestoneCompletions = RemoteData.NotAsked
    , curricula = RemoteData.NotAsked
    , instructorTeamupIds = RemoteData.NotAsked
    , tab = Students
    , selectedStudentDropdown = "active"
    , selectedInstructorDropdown = "active"
    , inviteForm = emptyInviteForm
    , expandedMilstoneMonths = Set.empty
    }
        ! []


emptyInviteForm : InviteForm
emptyInviteForm =
    Util.Form.View.idle
        { email = Value.blank
        , name = Value.blank
        , birthDate = Value.blank
        , permission = Value.blank
        }



-- UPDATE


type
    Msg
    -- UI
    = SharedMsg UCode.Msg.Msg
    | SelectTab Int
    | SetStudentDropdown String
    | SetInstructorDropdown String
    | InviteFormChanged (Util.Form.View.Model InviteFormValues)
    | SubmitInviteForm String String String Invite.Permission
    | ToggleMilestoneDetails String
    | DeleteInvite Invite
      -- Loading data
    | GotIsManager (Result String Bool)
    | GotCenter (Result String Center)
    | GotInstructors (Result String (Dict Id Instructor))
    | GotStudents (Result String (Dict Id Student))
    | GotInvites (Result String (Dict Id Invite))
    | GotMilestoneCompletions (Result String (List ( String, Dict Int (List CachedMilestone) )))
    | GotCurricula (Result String Curricula)
    | GotInstructorTeamupIds (Result String (Dict Int InstructorTeamupId))
    | FinishCreateInvite (Result String ())
    | DeletedInvite Invite (Result String ())


remoteDataStartLoading : RemoteData a -> Cmd msg -> ( RemoteData a, Cmd msg )
remoteDataStartLoading data cmd =
    if RemoteData.isNotAsked data then
        ( RemoteData.Loading, cmd )
    else
        ( data, Cmd.none )


type alias DataLoader a msg =
    ( Model -> RemoteData a, RemoteData a -> Model -> Model, FirebaseApp -> Cmd msg )


modelStartLoading : DataLoader a msg -> Model -> ( Model, Cmd msg )
modelStartLoading ( get, set, cmd ) model =
    case model.sharedModel.firebaseApp of
        Just firebaseApp ->
            remoteDataStartLoading (get model) (cmd firebaseApp)
                |> Tuple.mapFirst (\data -> set data model)

        Nothing ->
            ( model, Cmd.none )


andThenLoad : DataLoader a msg -> ( Model, Cmd msg ) -> ( Model, Cmd msg )
andThenLoad loader ( model, cmds ) =
    modelStartLoading loader model
        |> Tuple.mapSecond (\cmd -> Cmd.batch [ cmds, cmd ])


fetchDataForTab : Model -> ( Model, Cmd Msg )
fetchDataForTab ({ centerId } as model) =
    let
        center =
            ( .center
            , \d m -> { m | center = d }
            , Center.get centerId >> Task.attempt GotCenter
            )

        instructors =
            ( .instructors
            , \d m -> { m | instructors = d }
            , Instructor.getAllForCenter centerId >> Task.attempt GotInstructors
            )

        students =
            ( .students
            , \d m -> { m | students = d }
            , Student.getAllForCenter centerId >> Task.attempt GotStudents
            )

        invites =
            ( .invites
            , \d m -> { m | invites = d }
            , Invite.getInvitesForCenter centerId
                >> Task.attempt GotInvites
            )

        milestoneCompletions =
            ( .milestoneCompletions
            , \d m -> { m | milestoneCompletions = d }
            , Completion.getMilestonesForCenterByMonth centerId
                >> Task.attempt GotMilestoneCompletions
            )

        curricula =
            ( .curricula
            , \d m -> { m | curricula = d }
            , .db >> Curricula.getTask >> Task.attempt GotCurricula
            )

        instructorTeamupIds =
            ( .instructorTeamupIds
            , \d m -> { m | instructorTeamupIds = d }
            , \_ ->
                Instructor.getIndexByTeamupId ()
                    |> Task.attempt GotInstructorTeamupIds
            )
    in
        case model.tab of
            Students ->
                modelStartLoading center model
                    |> andThenLoad students

            Instructors ->
                modelStartLoading center model
                    |> andThenLoad instructors

            InviteTab ->
                modelStartLoading center model
                    |> andThenLoad invites


mapInviteForm :
    (Util.Form.View.Model InviteFormValues
     -> ( Util.Form.View.Model InviteFormValues, Cmd Msg )
    )
    -> Model
    -> ( Model, Cmd Msg )
mapInviteForm fn model =
    fn model.inviteForm
        |> Tuple.mapFirst
            (\inviteForm -> { model | inviteForm = inviteForm })


setToggle : comparable -> Set comparable -> Set comparable
setToggle candidate set =
    if Set.member candidate set then
        Set.remove candidate set
    else
        Set.insert candidate set


tabFromIndex : Int -> Maybe Tab
tabFromIndex index =
    List.indexedMap (,) tabs
        |> List.Extra.find (Tuple.first >> (==) index)
        |> Maybe.map Tuple.second


indexFromTab : Tab -> Int
indexFromTab tab =
    List.Extra.findIndex ((==) tab) tabs |> Maybe.withDefault 0


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model

        SelectTab index ->
            { model
                | tab = tabFromIndex index |> Maybe.withDefault model.tab
            }
                |> fetchDataForTab

        SetStudentDropdown id ->
            { model | selectedStudentDropdown = id } ! []

        SetInstructorDropdown id ->
            { model | selectedInstructorDropdown = id } ! []

        InviteFormChanged values ->
            { model | inviteForm = values } ! []

        SubmitInviteForm email name birthDate permission ->
            mapInviteForm
                (\form ->
                    let
                        createFn =
                            case permission of
                                Invite.Student ->
                                    Invite.createStudent

                                Invite.Instructor ->
                                    Invite.createInstructor

                        inviteData =
                            { email = email
                            , name = name
                            , birthDate = birthDate
                            , centerId = model.centerId
                            , inviter = model.sharedModel.user.displayName
                            , inviterId = model.sharedModel.user.uid
                            }
                    in
                        { form | state = Util.Form.View.Loading }
                            ! [ Data.foldMaybe
                                    Cmd.none
                                    (createFn inviteData
                                        >> Task.attempt FinishCreateInvite
                                    )
                                    model.sharedModel.firebaseApp
                              ]
                )
                model

        ToggleMilestoneDetails month ->
            { model
                | expandedMilstoneMonths =
                    setToggle month model.expandedMilstoneMonths
            }
                ! []

        DeleteInvite invite ->
            model
                ! [ Task.attempt (DeletedInvite invite) (Invite.delete invite)
                  ]

        DeletedInvite invite result ->
            case result of
                Ok () ->
                    View.notify "Invite deleted"
                        SharedMsg
                        { model
                            | invites =
                                RemoteData.map
                                    (Dict.remove invite.id)
                                    model.invites
                        }

                Err error ->
                    let
                        _ =
                            Debug.log "Failed to delete invite" error
                    in
                        View.notify "Failed to delete invite" SharedMsg model

        GotIsManager result ->
            let
                updatedModel =
                    { model | isManager = RemoteData.fromResult result }

                isManager =
                    updatedModel.isManager
                        |> RemoteData.withDefault False
            in
                if isManager then
                    updatedModel |> fetchDataForTab
                else
                    updatedModel ! []

        GotCenter result ->
            { model | center = RemoteData.fromResult result } ! []

        GotInstructors result ->
            { model | instructors = RemoteData.fromResult result } ! []

        GotStudents result ->
            { model | students = RemoteData.fromResult result } ! []

        GotInvites result ->
            { model | invites = RemoteData.fromResult result } ! []

        GotMilestoneCompletions result ->
            { model | milestoneCompletions = RemoteData.fromResult result } ! []

        GotCurricula result ->
            { model | curricula = RemoteData.fromResult result } ! []

        GotInstructorTeamupIds result ->
            { model | instructorTeamupIds = RemoteData.fromResult result } ! []

        FinishCreateInvite (Ok ()) ->
            { model | inviteForm = emptyInviteForm }
                |> View.notify "Invite created" SharedMsg

        FinishCreateInvite (Err error) ->
            mapInviteForm
                (\form -> { form | state = Util.Form.View.Error error } ! [])
                model



-- SUBS


firebaseSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    let
        uid =
            model.sharedModel.user.uid
    in
        Manager.subIsManager uid GotIsManager firebase


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , UCode.Sub.firebaseSubs model firebaseSubs
        ]



-- VIEW


viewError : String -> String -> Html Msg
viewError action error =
    div []
        [ h1 [] [ text <| "Something went wrong while " ++ action ]
        , h3 [] [ text error ]
        ]


viewCenterTitle : Center -> Html Msg
viewCenterTitle center =
    Options.styled h1 [ Options.center ] [ text center.name ]


viewDictAsNamesBlock : Dict String String -> Html Msg
viewDictAsNamesBlock =
    Dict.map
        (\id name ->
            Grid.cell
                [ Grid.size Grid.All 3 ]
                [ a [ href ("profile.html?id=" ++ id) ] [ text name ] ]
        )
        >> Dict.values
        >> Grid.grid []


viewInvites : Model -> (Invite -> Msg) -> RemoteData (Dict Id Invite) -> Html Msg
viewInvites model deleteMsg remoteInvites =
    case remoteInvites of
        RemoteData.NotAsked ->
            View.Loading.large

        RemoteData.Loading ->
            View.Loading.large

        RemoteData.Failure error ->
            viewError "loading invites" error

        RemoteData.Success invites ->
            View.Table.basic
                [ Options.css "width" "100%"
                , Options.css "margin-top" "10px"
                ]
                [ View.Table.column "Type"
                    (\inv ->
                        Invite.permissionToString inv.permission
                    )
                , View.Table.column "Email" .email
                , View.Table.column "Name" .name
                , View.Table.column "Birth Date" .birthDate
                , View.Table.column "Invited at" (.timestamp >> Data.formatDateTime)
                , View.Table.columnIndexed
                    "Action"
                    (\index invite ->
                        View.Button.icon
                            SharedMsg
                            [ 2, index ]
                            model
                            []
                            (deleteMsg invite)
                            "delete"
                    )
                    False
                ]
                (Dict.values invites)


viewStudents : Model -> (Student -> Bool) -> Html Msg
viewStudents model filter =
    case model.students of
        RemoteData.NotAsked ->
            View.Loading.large

        RemoteData.Loading ->
            View.Loading.large

        RemoteData.Failure error ->
            viewError "loading students" error

        RemoteData.Success students ->
            students
                |> Dict.filter (\_ -> filter)
                |> Dict.map (always .name)
                |> viewDictAsNamesBlock


viewInviteForm : Model -> Bool -> InviteForm -> Html Msg
viewInviteForm model showTeamupInstructorIdNote values =
    let
        emailField =
            Util.Form.emailField
                { parser =
                    (\input ->
                        let
                            email =
                                String.trim input
                        in
                            if Users.invalidEmail email then
                                Err "Not a valid email"
                            else
                                Ok email
                    )
                , value = .email
                , update = \v r -> { r | email = v }
                , attributes =
                    { label = "Email"
                    , placeholder = ""
                    }
                }

        nameField =
            Util.Form.textField
                { parser = Ok
                , value = .name
                , update = \v r -> { r | name = v }
                , attributes =
                    { label = "Name"
                    , placeholder = ""
                    }
                }

        birthDateField =
            Util.Form.textField
                { parser =
                    \inputDate ->
                        if Users.invalidBirthDate inputDate then
                            Err "Invalid birthdate, must be yyyy-mm-dd"
                        else
                            Ok inputDate
                , value = .birthDate
                , update = \v r -> { r | birthDate = v }
                , attributes =
                    { label = "Birth Date"
                    , placeholder = "2007-01-25"
                    }
                }

        permissionField =
            Util.Form.selectField
                { parser =
                    Ok << Invite.stringToPermission
                , value = .permission
                , update = \v r -> { r | permission = v }
                , options =
                    [ ( "Student", "Student" )
                    , ( "Instructor", "Instructor" )
                    ]
                , attributes =
                    { label = ""
                    , placeholder = ""
                    }
                }

        inviteForm =
            Util.Form.empty SubmitInviteForm
                |> Util.Form.append emailField
                |> Util.Form.append nameField
                |> Util.Form.append birthDateField
                |> Util.Form.append permissionField
    in
        Util.Form.View.basic
            { onChange = InviteFormChanged
            , action = "Invite"
            , loadingMessage = "Saving..."
            , validation = Util.Form.View.ValidateOnSubmit
            }
            model.sharedModel.mdl
            (UCode.Msg.Mdl >> SharedMsg)
            inviteForm
            values


viewStudentsTab : Model -> List (Html Msg)
viewStudentsTab model =
    [ Options.div
        [ Options.css "display" "flex"
        , Options.css "justify-content" "space-between"
        ]
        [ View.Dropdown.render
            { placeholder = ""
            , onSelect = SetStudentDropdown
            , selected = Just model.selectedStudentDropdown
            , disabled = False
            , options =
                [ View.Dropdown.Option
                    { text = "Active", id = "active", disabled = False }
                , View.Dropdown.Option
                    { text = "Inactive", id = "inactive", disabled = False }
                ]
            }
        ]
    , case model.selectedStudentDropdown of
        "active" ->
            viewStudents model .active

        "inactive" ->
            viewStudents model (not << .active)

        _ ->
            viewStudents model .active
    ]


viewInstructors : Model -> Html Msg
viewInstructors model =
    case model.instructors of
        RemoteData.NotAsked ->
            View.Loading.large

        RemoteData.Loading ->
            View.Loading.large

        RemoteData.Failure error ->
            viewError "loading instructors" error

        RemoteData.Success instructors ->
            instructors
                |> Dict.map (always .name)
                |> viewDictAsNamesBlock


viewInstructorsTab : Model -> List (Html Msg)
viewInstructorsTab model =
    [ viewInstructors model
    ]


viewInviteTab : Model -> List (Html Msg)
viewInviteTab model =
    [ viewInviteForm model False model.inviteForm
    , viewInvites model DeleteInvite model.invites
    ]


viewMonthDetails :
    Dict Id Student
    -> ( String, Dict Int (List CachedMilestone) )
    -> List (Html Msg)
viewMonthDetails students ( month, milestones ) =
    milestones
        |> Dict.toList
        |> List.map
            (\( milestoneNumber, completions ) ->
                div []
                    [ Options.styled h1
                        [ Typography.left
                        , Typography.display1
                        ]
                        [ text <| "Milestone " ++ toString milestoneNumber ]
                    , View.Table.basic [ Options.css "width" "100%" ]
                        [ View.Table.columnCustom
                            "Student"
                            (\{ userId } ->
                                Dict.get userId students
                                    |> Maybe.map .name
                                    |> Maybe.withDefault "Unknown student"
                                    |> text
                                    |> List.singleton
                                    |> a [ href <| "/profile.html?id=" ++ userId ]
                            )
                            False
                        , View.Table.column
                            "Completed"
                            (.completedAt >> Data.formatDateTime)
                        ]
                        completions
                    ]
            )


viewInstructorLinked : Int -> Dict Int InstructorTeamupId -> Html Msg
viewInstructorLinked instructorTeamupId instructors =
    (Dict.get instructorTeamupId instructors)
        |> Maybe.map
            (\{ id, name } ->
                a [ href ("/profile.html?id=" ++ id) ] [ text name ]
            )
        |> Maybe.withDefault (text ("Unknown (" ++ (toString instructorTeamupId) ++ ")"))


viewTabs : Model -> Html Msg
viewTabs model =
    let
        tabLabel tabText =
            Tabs.label [ Options.center ] [ text tabText ]

        container attributes =
            Options.div
                ([ Options.css "max-width" "800px"
                 , Options.css "margin" "10px auto 0"
                 ]
                    ++ attributes
                )
    in
        Tabs.render (UCode.Msg.Mdl >> SharedMsg)
            [ 0 ]
            model.sharedModel.mdl
            [ Tabs.ripple
            , Tabs.onSelectTab SelectTab
            , Tabs.activeTab (indexFromTab model.tab)
            ]
            [ tabLabel "Students"
            , tabLabel "Instructors"
            , tabLabel "Invites"
            ]
            [ container [] <|
                case model.tab of
                    Students ->
                        viewStudentsTab model

                    Instructors ->
                        viewInstructorsTab model

                    InviteTab ->
                        viewInviteTab model
            ]


viewManageCenter : Model -> Html Msg
viewManageCenter model =
    case model.center of
        RemoteData.NotAsked ->
            View.Loading.large

        RemoteData.Loading ->
            View.Loading.large

        RemoteData.Failure error ->
            viewError "loading center info" error

        RemoteData.Success center ->
            div []
                [ viewCenterTitle center
                , viewTabs model
                ]


viewMain : Model -> Html Msg
viewMain model =
    case model.isManager of
        RemoteData.NotAsked ->
            View.Loading.large

        RemoteData.Loading ->
            View.Loading.large

        RemoteData.Failure error ->
            viewError "checking auth" error

        RemoteData.Success isManager ->
            if isManager then
                viewManageCenter model
            else
                div []
                    [ h3 [] [ text "Access denied" ]
                    , p [] [ text "You must be an Academic Director to view this page" ]
                    ]


viewContainer : List (Html Msg) -> Html Msg
viewContainer page =
    div
        [ style
            [ ( "max-width", "1500px" )
            , ( "margin", "0 auto 100px" )
            ]
        ]
        [ div [ style [ ( "margin", "0 20px" ) ] ]
            page
        ]


viewDialog : Model -> Html Msg
viewDialog model =
    View.Dialog.empty


view : Model -> ( List (Html Msg), Html Msg )
view model =
    ( [ viewContainer <| List.singleton <| viewMain model ]
    , viewDialog model
    )
