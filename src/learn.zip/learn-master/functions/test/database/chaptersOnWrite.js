import test from 'ava'
import proxyquire from 'proxyquire'
import testData from '../_data'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const chaptersOnWrite =
  proxyquire(
    '../../database/chaptersOnWrite',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

test.beforeEach(t => {
  mockdatabase.set(testData)
})

test.serial('cacheByMilestone creates a cache entry for new chapters', async t => {
  mockdatabase.child('chapters/chapter-4')
    .set({ name: 'Chapter 4', number: 3, milestoneId: 'milestone-1' })
  await chaptersOnWrite._test.cacheByMilestone(
    'chapter-4',
    null,
    { name: 'Chapter 4', number: 3, milestoneId: 'milestone-1' }
  )
  const { chapterNumbers } = mockdatabase.getData()
  t.deepEqual(
    chapterNumbers['milestone-1'],
    {
      'chapter-1': 1,
      'chapter-2': 2,
      'chapter-4': 3
    }
  )
})

test.serial('cacheByMilestone updates cache entries for modified chapters', async t => {
  mockdatabase.child('chapters/chapter-4')
    .set({ name: 'Chapter 4', number: 4, milestoneId: 'milestone-1' })
  await chaptersOnWrite._test.cacheByMilestone(
    'chapter-4',
    { name: 'Chapter 4', number: 3, milestoneId: 'milestone-1' },
    { name: 'Chapter 4', number: 4, milestoneId: 'milestone-1' }
  )
  const { chapterNumbers } = mockdatabase.getData()
  t.deepEqual(
    chapterNumbers['milestone-1'],
    {
      'chapter-1': 1,
      'chapter-2': 2,
      'chapter-4': 4
    }
  )
})

test.serial('cacheByMilestone removes cache entries for deleted chapters', async t => {
  mockdatabase.child('chapters/chapter-4').remove()
  await chaptersOnWrite._test.cacheByMilestone(
    'chapter-4',
    { name: 'Chapter 4', number: 4, milestoneId: 'milestone-1' },
    null
  )
  const { chapterNumbers } = mockdatabase.getData()
  t.deepEqual(
    chapterNumbers['milestone-1'],
    {
      'chapter-1': 1,
      'chapter-2': 2
    }
  )
})
