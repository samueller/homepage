const functions = require('firebase-functions')
const createTransaction = require('../utils/createTransaction')
const constants = require('../constants')

const createParentTestimonialsTransaction = ({ userId, testimonialId }) =>
  createTransaction(
    userId,
    'parentTestimonials',
    testimonialId,
    false,
    constants.UCOIN_VALUES.STUDENT_TESTIMONIAL,
    `parentTestimonials/${userId}/${testimonialId}/ucoins`
  )

module.exports =
  functions.database.ref('parentTestimonials/{userId}/{testimonialId}')
    .onCreate((snap, context) =>
      createParentTestimonialsTransaction(context.params)
    )

module.exports._test = { createParentTestimonialsTransaction }
