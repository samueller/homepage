import test from 'ava'
import proxyquire from 'proxyquire'
import sinon from 'sinon'

const requestStub = sinon.fake.returns(Promise.resolve())

const teamup =
  proxyquire('../../utils/teamup', { 'request-promise': requestStub })

// GET SESSION ATTENDANCES

test('getSessionAttendances preforms a valid request', t => {
  teamup.getSessionAttendances('token-1', 'customer-1', new Date(100))
  t.deepEqual(
    requestStub.lastArg,
    {
      uri: 'https://goteamup.com/api/v1/sessionattendances',
      qs: {
        customer: 'customer-1',
        session_start_datetime_after: '1969-12-31'
      },
      headers: {
        Authorization: 'Bearer token-1'
      },
      json: true
    }
  )
})
