module Types.ParentTestimonial exposing (create)

import Task exposing (Task)
import Json.Encode as Encode exposing (Value)
import UCode.Model exposing (FirebaseUser)
import UCode.User as User
import Util.Firebase.Database as Db


encoder : FirebaseUser -> Value
encoder manager =
    Encode.object
        [ ( "recordedAt", Db.serverTime )
        , ( "recordedByUserId", Encode.string manager.uid )
        , ( "recordedByUserName", Encode.string manager.displayName )
        ]


create : String -> FirebaseUser -> Task String ()
create userEmail manager =
    User.validateEmailNoDb userEmail
        |> Task.andThen
            (\user ->
                Db.push [ "parentTestimonials", user.id ] (encoder manager)
                    |> Tuple.second
            )
