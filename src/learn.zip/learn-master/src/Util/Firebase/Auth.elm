module Util.Firebase.Auth exposing (User, auth, logout, onAuthStateChanged)

import Task exposing (Task)
import UCode.Ports as Ports
import Firebase.Authentication as Auth
import Firebase.Authentication.Types
import Util.Firebase.App as App


type alias User =
    { uid : String
    , displayName : String
    , email : String
    , photoURL : String
    }


auth : Firebase.Authentication.Types.Auth
auth =
    Auth.init App.app


logout : msg -> Cmd msg
logout onFinish =
    Task.perform (always onFinish) (Auth.signOut auth)


onAuthStateChanged : (Maybe User -> msg) -> Sub msg
onAuthStateChanged tagger =
    Ports.onAuthStateChanged tagger
