const functions = require('firebase-functions')
const db = require('../utils/db')
const currentSession = require('../utils/current-teamup-session')
const getInstructorByTeamupId = require('../utils/instructor-uid-of-teamup-id')

const currentInstructor = (studentTeamupId, centerId, userId) =>
  currentSession(studentTeamupId, centerId)
    .then(
      session => {
        if (!session) {
          console.log(`Student ${userId} completed a lesson but they are not in a session`)
          return null
        }

        const teamupInstructor = session.instructors[0]
        if (!teamupInstructor) {
          console.log(`Student ${userId} completed a lesson but their session ${session.id} doesn't have an instructor`)
          return null
        }

        return getInstructorByTeamupId(teamupInstructor.id)
          .then(instructorId => {
            if (!instructorId) {
              console.log(`Student ${userId} completed a lesson during session ${session.id} with instructor ${teamupInstructor.id}, but there is no instructor with that Teamup ID`)
            }
            return instructorId
          })
      },
      error => {
        console.error(`Error getting current session for user ${userId} with Teamup ID ${studentTeamupId}`, error)
        return null
      }
    )

const setLessonPassed = (userId, lessonId) =>
  db.value('students', userId)
    .then(({ teamupId, centerId }) => {
      if (!teamupId) {
        return null
      }
      return currentInstructor(teamupId, centerId, userId)
    })
    .then(instructorId =>
      db.ref('lessonResults', userId, lessonId)
        .set({
          timestamp: db.ServerValue.TIMESTAMP,
          instructor: instructorId
        })
    )

const activityResultPassed = userId => activityId =>
  db.value('activityResults', userId, activityId)
    .then(result => result && result.score)

const getHasPassedActivitesOfLesson = userId => lessonActivites =>
  Promise.all(
    Object.keys(lessonActivites).map(activityResultPassed(userId))
  )
    .then(scores => scores.every(score => score >= 95))

const checkLessonProgress = ({ userId, activityId }) =>
  db.valueOrReject('activityLessons', activityId)
    .then(lessonId =>
      db.value('lessonResults', userId, lessonId)
        .then(hasPassedLesson => {
          if (!hasPassedLesson) {
            return db.valueOrReject('activities', lessonId)
              .then(getHasPassedActivitesOfLesson(userId))
              .then(hasPassedActivitesOfLesson => {
                if (hasPassedActivitesOfLesson) {
                  return setLessonPassed(userId, lessonId)
                }
              })
          }
        })
    )

module.exports =
  functions.database.ref('activityResults/{userId}/{activityId}')
    .onWrite((change, context) => checkLessonProgress(context.params))

module.exports._test = {
  checkLessonProgress
}
