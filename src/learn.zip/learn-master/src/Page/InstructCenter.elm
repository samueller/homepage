module Page.InstructCenter exposing (main)

import Dict exposing (Dict)
import Firebase.Database.Types as Types exposing (Snapshot)
import Html exposing (..)
import Html.Attributes exposing (..)
import List
import Material.Grid as Grid
import Material.List as Lists
import Material.Table as Table
import Material.Options as Options
import RemoteData exposing (RemoteData)
import Set exposing (Set)
import Types.Activity as Activity
import Types.Center as Center exposing (Center)
import Types.Chapter as Chapter exposing (ChapterNoId)
import Types.Instructor as Instructor
import Types.Lesson as Lesson exposing (Lesson)
import Types.Milestone as Milestone exposing (MilestoneNoId)
import Types.Project as Project exposing (Submission)
import Types.Student as Student exposing (Student)
import UCode.Browser as Browser
import UCode.Data as Data exposing (Id)
import UCode.Firebase as UFirebase
import UCode.Model as UModel
import UCode.Msg as UMsg
import UCode.Sub as USub
import UCode.Users as Users
import UCode.View as View


main : Program UModel.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUser SharedMsg initialModel
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


type alias Model =
    { centerId : Data.Id
    , center : RemoteData String Center
    , validInstructor : RemoteData String Bool
    , students : List ( Data.Id, Student )
    , lessons : Dict Data.Id Lesson.Lesson
    , chapters : Dict Data.Id Chapter.ChapterNoId
    , milestones : Dict Data.Id Milestone.MilestoneNoId
    , submissions : Dict Id (Dict Id (Submission Id Id String))
    , projectStepActivities : Dict Id Id
    , activityLessons : Dict Id Id
    , revealSubmissions : Set Id
    , sharedModel : UModel.SharedModelFirebaseUser
    }


initialModel : UModel.SharedModelFirebaseUser -> Model
initialModel sharedModel =
    { centerId = Browser.queryId
    , center = RemoteData.Loading
    , validInstructor = RemoteData.Loading
    , students = []
    , lessons = Dict.empty
    , chapters = Dict.empty
    , milestones = Dict.empty
    , submissions = Dict.empty
    , projectStepActivities = Dict.empty
    , activityLessons = Dict.empty
    , revealSubmissions = Set.empty
    , sharedModel = sharedModel
    }


type Msg
    = SharedMsg UMsg.Msg
    | ChangedCenter (Result String Center)
    | ChangedValidInstructor Types.Snapshot
    | StudentAdded Types.Snapshot
    | StudentChanged Types.Snapshot
    | StudentRemoved Types.Snapshot
    | LessonChanged Types.Snapshot
    | LessonRemoved Types.Snapshot
    | ChapterChanged Types.Snapshot
    | ChapterRemoved Types.Snapshot
    | MilestoneChanged Types.Snapshot
    | MilestoneRemoved Types.Snapshot
    | SubmissionAdded (Result String (Submission Id Id String))
    | SubmissionChanged (Result String (Submission Id Id String))
    | SubmissionRemoved (Result String (Submission Id Id String))
    | ToggleShowSubmissions Id
    | ProjectStepActivityIdReceived Id (Result String Id) -- projectStepId (Result error activityId)
    | LessonIdForActivityIdReceived Id (Result String Id) -- activityId (Result error lessonId)


addedStudent : Model -> Data.Id -> Student -> Model
addedStudent model id student =
    { model | students = ( id, student ) :: model.students }


changedStudent : Model -> Data.Id -> Student -> Model
changedStudent model id student =
    { model | students = Data.idListReplaced id student model.students }


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedCenter result ->
            { model | center = RemoteData.fromResult result } ! []

        ChangedValidInstructor snapshot ->
            { model | validInstructor = RemoteData.Success (Instructor.existsFromSnapshot snapshot) } ! []

        StudentAdded snapshot ->
            Data.recordUpdatedFromSnapshot model addedStudent Student.decoder snapshot
                ! []

        StudentChanged snapshot ->
            Data.recordUpdatedFromSnapshot model changedStudent Student.decoder snapshot
                ! []

        StudentRemoved snapshot ->
            { model | students = Data.idListRemovedSnapshot model.students snapshot }
                ! []

        LessonChanged snapshot ->
            Data.recordUpdatedFromSnapshot model Lesson.recordWithChangedDictEntry Lesson.decoder snapshot
                ! []

        LessonRemoved snapshot ->
            Lesson.recordWithRemovedDictEntry model snapshot
                ! []

        ChapterChanged snapshot ->
            Data.recordUpdatedFromSnapshot model Chapter.recordWithChangedDictEntry Chapter.noIdDecoder snapshot
                ! []

        ChapterRemoved snapshot ->
            Chapter.recordWithRemovedDictEntry model snapshot
                ! []

        MilestoneChanged snapshot ->
            Data.recordUpdatedFromSnapshot model Milestone.recordWithChangedDictEntry Milestone.noIdDecoder snapshot
                ! []

        MilestoneRemoved snapshot ->
            Milestone.recordWithRemovedDictEntry model snapshot
                ! []

        SharedMsg msg_ ->
            UModel.update SharedMsg msg_ model

        SubmissionAdded (Err error) ->
            --TODO handle errors
            Debug.log "Failed to decode submission" error
                |> always (model ! [])

        SubmissionChanged (Err error) ->
            --TODO handle errors
            Debug.log "Failed to decode submission" error
                |> always (model ! [])

        SubmissionRemoved (Err error) ->
            --TODO handle errors
            Debug.log "Failed to decode submission" error
                |> always (model ! [])

        SubmissionAdded (Ok submission) ->
            { model
                | submissions =
                    Dict.update
                        submission.student
                        (\maybeStudentSubmissions ->
                            Just <|
                                Dict.insert
                                    submission.projectStep
                                    submission
                                    (Maybe.withDefault Dict.empty maybeStudentSubmissions)
                        )
                        model.submissions
            }
                ! [ Project.activityIdForProjectStep
                        submission.projectStep
                        (ProjectStepActivityIdReceived submission.projectStep)
                        model.sharedModel.firebaseApp
                  ]

        SubmissionChanged (Ok submission) ->
            { model
                | submissions =
                    Dict.update
                        submission.student
                        (\maybeStudentSubmissions ->
                            Just <|
                                Dict.insert
                                    submission.projectStep
                                    submission
                                    (Maybe.withDefault Dict.empty maybeStudentSubmissions)
                        )
                        model.submissions
            }
                ! []

        SubmissionRemoved (Ok submission) ->
            { model
                | submissions =
                    Dict.update
                        submission.student
                        (\maybeStudentSubmissions ->
                            Just <|
                                Dict.remove
                                    submission.projectStep
                                    (Maybe.withDefault Dict.empty maybeStudentSubmissions)
                        )
                        model.submissions
            }
                ! []

        ToggleShowSubmissions studentId ->
            { model
                | revealSubmissions =
                    if Set.member studentId model.revealSubmissions then
                        Set.remove studentId model.revealSubmissions
                    else
                        Set.insert studentId model.revealSubmissions
            }
                ! []

        ProjectStepActivityIdReceived projectStepId result ->
            case result of
                Err error ->
                    --TODO handle errors
                    Debug.log ("Failed to fetch activityId for " ++ projectStepId) error
                        |> always (model ! [])

                Ok activityId ->
                    { model
                        | projectStepActivities =
                            Dict.insert projectStepId activityId model.projectStepActivities
                    }
                        ! [ Activity.lessonIdForActivityId
                                activityId
                                (LessonIdForActivityIdReceived activityId)
                                model.sharedModel.firebaseApp
                          ]

        LessonIdForActivityIdReceived activityId result ->
            case result of
                Err error ->
                    --TODO handle errors
                    Debug.log ("Failed to fetch lessonId for " ++ activityId) error
                        |> always (model ! [])

                Ok lessonId ->
                    { model
                        | activityLessons =
                            Dict.insert activityId lessonId model.activityLessons
                    }
                        ! []


maybeLoading : Maybe String -> String
maybeLoading =
    Maybe.withDefault "loading..."


name : Data.WithName (Data.WithNumber r) -> String
name r =
    toString r.number ++ ": " ++ r.name


nameOrLoading : Maybe (Data.WithName (Data.WithNumber r)) -> String
nameOrLoading =
    maybeLoading
        << Maybe.map name


maybeLink : String -> String -> Maybe Data.Id -> Maybe (Data.WithName (Data.WithNumber r)) -> Html Msg
maybeLink url urlEnd maybeId maybeLink =
    case maybeId of
        Just id ->
            a [ href (url ++ id ++ urlEnd) ] [ text (nameOrLoading maybeLink) ]

        Nothing ->
            text (nameOrLoading maybeLink)


viewStudent : Model -> Int -> ( Data.Id, Student ) -> List (Html Msg)
viewStudent model index ( id, student ) =
    let
        maybeLesson =
            Dict.get student.currentLessonId model.lessons

        maybeChapterId =
            Maybe.map .chapterId maybeLesson

        maybeChapter =
            Maybe.andThen (flip Dict.get model.chapters) maybeChapterId

        maybeMilestoneId =
            Maybe.map .milestoneId maybeChapter

        maybeMilestone =
            Maybe.andThen (flip Dict.get model.milestones) maybeMilestoneId
    in
        [ Table.tr []
            [ Table.td []
                [ a [ href ("/profile.html?id=" ++ id) ]
                    [ Options.span
                        (if student.active then
                            []
                         else
                            [ Options.css "text-decoration" "line-through"
                            , Options.css "color" "gray"
                            ]
                        )
                        [ text student.name ]
                    ]
                ]
            , Table.td [] [ maybeLink "/milestone.html?id=" "" maybeMilestoneId maybeMilestone ]
            , Table.td [] [ maybeLink "/chapter.html?id=" "" maybeChapterId maybeChapter ]
            , Table.td [] [ maybeLink "/chapter.html?id=" ("#lesson_" ++ student.currentLessonId) maybeChapterId maybeLesson ]
            , Table.td []
                [ text
                    (if student.active then
                        "Yes"
                     else
                        "No"
                    )
                ]
            , Table.td [] [ viewStudentSubmissionButton model index id ]
            ]
        ]
            ++ case ( Set.member id model.revealSubmissions, Dict.get id model.submissions ) of
                ( True, submissions ) ->
                    [ Table.tr []
                        [ Table.td
                            [ colspan 6 |> Options.attribute
                            , Options.css "text-align" "left"
                            ]
                            [ viewStudentSubmissions
                                model
                                index
                                ( id, Maybe.withDefault Dict.empty submissions )
                            ]
                        ]
                    ]

                _ ->
                    []


viewStudents : Model -> Html Msg
viewStudents model =
    Table.table []
        [ Table.thead []
            [ Table.tr []
                [ Table.th [] [ text "Name" ]
                , Table.th [] [ text "Milestone" ]
                , Table.th [] [ text "Chapter" ]
                , Table.th [] [ text "Lesson" ]
                , Table.th [] [ text "Active?" ]
                , Table.th [] [ text "Project Submissions" ]
                ]
            ]
        , Table.tbody [] <|
            (List.indexedMap (viewStudent model) model.students |> List.concat)
        ]


viewSubmissionFields : Dict Id String -> List (Html Msg)
viewSubmissionFields =
    Dict.toList
        >> List.map (\( id, content ) -> div [] [ text <| id ++ ": " ++ content ])


lessonChapterMilestoneForProjectStep : Id -> Model -> Maybe ( MilestoneNoId, ChapterNoId, Lesson )
lessonChapterMilestoneForProjectStep projectStepId model =
    Dict.get projectStepId model.projectStepActivities
        |> Maybe.andThen (\activityId -> Dict.get activityId model.activityLessons)
        |> Maybe.andThen (\lessonId -> Dict.get lessonId model.lessons)
        |> Maybe.andThen
            (\lesson ->
                Dict.get lesson.chapterId model.chapters
                    |> Maybe.map (\chapter -> ( chapter, lesson ))
            )
        |> Maybe.andThen
            (\( chapter, lesson ) ->
                Dict.get chapter.milestoneId model.milestones
                    |> Maybe.map (\milestone -> ( milestone, chapter, lesson ))
            )


viewStudentSubmission : Model -> Id -> Int -> Int -> ( a, Submission Id Id String ) -> Html Msg
viewStudentSubmission model studentId index1 index2 ( _, submission ) =
    let
        title =
            case lessonChapterMilestoneForProjectStep submission.projectStep model of
                Just ( milestone, chapter, lesson ) ->
                    "Project step for "
                        ++ toString milestone.number
                        ++ "."
                        ++ toString chapter.number
                        ++ "."
                        ++ toString lesson.number

                Nothing ->
                    "Project step " ++ submission.projectStep
    in
        Lists.li [ Lists.withSubtitle ]
            [ Lists.content []
                [ text title
                , Lists.subtitle []
                    [ text <| "Submitted at " ++ Data.formatDateTime submission.timestamp ]
                ]
            , View.buttonLink
                model
                SharedMsg
                (Just <|
                    "/grade_submission.html?student="
                        ++ studentId
                        ++ "&project_step="
                        ++ submission.projectStep
                )
                [ 11, index1, index2 ]
                [ text "Grade" ]
            ]


viewStudentSubmissions : Model -> Int -> ( Id, Dict Id (Submission Id Id String) ) -> Html Msg
viewStudentSubmissions model index ( studentId, submissions ) =
    if Dict.size submissions == 0 then
        div [] [ text "No submissions" ]
    else
        Dict.toList submissions
            |> List.sortBy (Tuple.second >> .timestamp)
            |> List.indexedMap (viewStudentSubmission model studentId index)
            |> Lists.ul [ Options.css "width" "100%" ]


viewStudentSubmissionButton : Model -> Int -> Id -> Html Msg
viewStudentSubmissionButton model index studentId =
    let
        submissionCount =
            Dict.get studentId model.submissions
                |> Maybe.map Dict.size
                |> Maybe.withDefault 0
    in
        if Set.member studentId model.revealSubmissions then
            View.buttonWithText model SharedMsg (ToggleShowSubmissions studentId) False [ 10, index ] "Hide"
        else
            View.buttonWithText model SharedMsg (ToggleShowSubmissions studentId) False [ 10, index ] "Show"


viewTitle : RemoteData String Center.Center -> Html Msg
viewTitle remoteCenter =
    h1 []
        [ text
            (case remoteCenter of
                RemoteData.NotAsked ->
                    "Instruct"

                RemoteData.Loading ->
                    "Instruct"

                RemoteData.Failure error ->
                    "Instruct"

                RemoteData.Success { name } ->
                    "Instruct " ++ name
            )
        ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        [ View.fullWidthCell
            (case model.validInstructor of
                RemoteData.Success True ->
                    [ viewTitle model.center
                    , h2 [] [ text "Students" ]
                    , viewStudents model
                    ]

                RemoteData.Success False ->
                    [ h1 [] [ text "Not Instructor" ]
                    , p [] [ text "Please contact your center's administrator" ]
                    ]

                RemoteData.Failure message ->
                    [ h1 [] [ text "Error" ]
                    , p [] [ text message ]
                    ]

                RemoteData.Loading ->
                    [ h1 [] [ text "Loading" ]
                    , View.spinner
                    ]

                RemoteData.NotAsked ->
                    [ h1 [] [ text "Starting" ]
                    , View.spinner
                    ]
            )
        ]
    ]


validInstructorSub : Model -> UFirebase.FirebaseApp -> Sub Msg
validInstructorSub model firebase =
    UFirebase.idSubscription ("centerInstructors/" ++ model.centerId) firebase ChangedValidInstructor model.sharedModel.user.uid


firebaseSubs : Model -> UFirebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        ([ UFirebase.objectsByIdSubscriptions "students" "centerId" firebase StudentAdded StudentChanged StudentRemoved model.centerId
         , UFirebase.objectsSubscriptions "lessons" firebase.db LessonChanged LessonChanged LessonRemoved
         , UFirebase.objectsSubscriptions "chapters" firebase.db ChapterChanged ChapterChanged ChapterRemoved
         , UFirebase.objectsSubscriptions "milestones" firebase.db MilestoneChanged MilestoneChanged MilestoneRemoved
         , Center.sub model.centerId ChangedCenter firebase
         ]
            ++ (Set.toList model.revealSubmissions
                    |> List.map
                        (\studentId ->
                            Project.onSubmissionChanged
                                studentId
                                firebase.db
                                SubmissionAdded
                                SubmissionChanged
                                SubmissionRemoved
                        )
               )
        )


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , USub.firebaseSubs model validInstructorSub
        , USub.firebaseSubsIfRemoteData model model.validInstructor firebaseSubs
        ]
