module UCode.Firebase exposing (..)

import Json.Decode as Decode exposing (Decoder, Value)
import Json.Encode as Encode
import Task exposing (Task)
import Firebase
import Firebase.Errors
import Firebase.Authentication as Authentication
import Firebase.Database
import Firebase.Database.Reference as Reference
import Firebase.Database.Query as Query
import Firebase.Database.Types as Types
import Firebase.Database.Snapshot as Snapshot
import UCode.Data as Data exposing (Id)


type alias FirebaseApp =
    { app : Firebase.App
    , db : Types.Database
    }


type alias WithFirebase model =
    { model | firebaseApp : Maybe FirebaseApp }


type alias WithSharedModelFirebase model r =
    { model | sharedModel : WithFirebase r }


initFirebase : Firebase.App -> FirebaseApp
initFirebase app =
    FirebaseApp app (Firebase.Database.init app)


maybeFirebaseApp : Maybe FirebaseApp
maybeFirebaseApp =
    Maybe.map initFirebase (Firebase.app ())


mapDatabaseTask :
    (FirebaseApp -> Task String a)
    -> Maybe FirebaseApp
    -> Task String a
mapDatabaseTask fn =
    Maybe.map fn >> Maybe.withDefault (Task.fail "Failed to initialize Firebase")


ref : String -> Types.Database -> Types.Reference
ref =
    Firebase.Database.ref << Just


foldFirebaseDb : (Types.Database -> Cmd msg) -> Maybe FirebaseApp -> Cmd msg
foldFirebaseDb f =
    Data.foldMaybe Cmd.none (f << .db)


withDb : (Types.Database -> Cmd msg) -> WithSharedModelFirebase model r -> Cmd msg
withDb cmdFunction =
    Data.foldMaybe Cmd.none
        (cmdFunction << .db)
        << .firebaseApp
        << .sharedModel


withModelDb : (WithSharedModelFirebase model r -> Types.Database -> Cmd msg) -> WithSharedModelFirebase model r -> Cmd msg
withModelDb cmdFunction model =
    Data.foldMaybe Cmd.none
        (cmdFunction model << .db)
        model.sharedModel.firebaseApp


firebaseDbTask : Maybe FirebaseApp -> (Types.Database -> Cmd msg) -> Cmd msg
firebaseDbTask =
    flip foldFirebaseDb


logout : WithFirebase model -> (() -> msg) -> ( WithFirebase model, Cmd msg )
logout model loggedOut =
    Data.foldMaybe
        (model ! [])
        (\firebase ->
            ( model, Task.perform loggedOut (Authentication.signOut (Authentication.init firebase.app)) )
        )
        model.firebaseApp


idSubscription : String -> FirebaseApp -> (Types.Snapshot -> msg) -> String -> Sub msg
idSubscription path firebase msg id =
    Reference.on "value" (ref (path ++ "/" ++ id) firebase.db) msg


objectsSubscription : String -> Types.Database -> (Types.Snapshot -> msg) -> Sub msg
objectsSubscription path db =
    Reference.on "child_added" <|
        ref path db


objectsChangedSubscription : String -> Types.Database -> (Types.Snapshot -> msg) -> Sub msg
objectsChangedSubscription path db =
    Reference.on "child_changed" <|
        ref path db


objectsRemovedSubscription : String -> Types.Database -> (Types.Snapshot -> msg) -> Sub msg
objectsRemovedSubscription path db =
    Reference.on "child_removed" <|
        ref path db


objectsSubscriptions : String -> Types.Database -> (Types.Snapshot -> msg) -> (Types.Snapshot -> msg) -> (Types.Snapshot -> msg) -> Sub msg
objectsSubscriptions path db addedMsg changedMsg removedMsg =
    Sub.batch
        [ objectsSubscription path db addedMsg
        , objectsChangedSubscription path db changedMsg
        , objectsRemovedSubscription path db removedMsg
        ]


objectsByIdSubscription : String -> String -> FirebaseApp -> (Types.Snapshot -> msg) -> String -> Sub msg
objectsByIdSubscription path idField firebase msg id =
    Query.on "child_added" (Query.equalTo (Encode.string id) Nothing (Reference.orderByChild idField (ref path firebase.db))) msg


objectsByIdChangedSubscription : String -> String -> FirebaseApp -> (Types.Snapshot -> msg) -> String -> Sub msg
objectsByIdChangedSubscription path idField firebase msg id =
    Query.on "child_changed" (Query.equalTo (Encode.string id) Nothing (Reference.orderByChild idField (ref path firebase.db))) msg


objectsByIdRemovedSubscription : String -> String -> FirebaseApp -> (Types.Snapshot -> msg) -> String -> Sub msg
objectsByIdRemovedSubscription path idField firebase msg id =
    Query.on "child_removed" (Query.equalTo (Encode.string id) Nothing (Reference.orderByChild idField (ref path firebase.db))) msg


objectsByIdSubscriptions : String -> String -> FirebaseApp -> (Types.Snapshot -> msg) -> (Types.Snapshot -> msg) -> (Types.Snapshot -> msg) -> String -> Sub msg
objectsByIdSubscriptions path idField firebase addedMsg changedMsg removedMsg id =
    Sub.batch
        [ objectsByIdSubscription path idField firebase addedMsg id
        , objectsByIdChangedSubscription path idField firebase changedMsg id
        , objectsByIdRemovedSubscription path idField firebase removedMsg id
        ]


valuesByChildSubscription : (Types.Snapshot -> msg) -> String -> String -> FirebaseApp -> Encode.Value -> Sub msg
valuesByChildSubscription msg path childField firebase value =
    Query.on "value"
        (Query.equalTo value Nothing <|
            Reference.orderByChild childField <|
                ref path <|
                    firebase.db
        )
        msg


valuesByChildValueSubscription : (Types.Snapshot -> msg) -> String -> FirebaseApp -> Encode.Value -> Sub msg
valuesByChildValueSubscription msg path firebase value =
    Query.on "value"
        (Query.equalTo value Nothing <|
            Reference.orderByValue <|
                ref path <|
                    firebase.db
        )
        msg


saveInt : String -> (Result Firebase.Errors.Error () -> msg) -> Int -> Types.Database -> Cmd msg
saveInt path savedMsg value =
    Task.attempt savedMsg
        << Reference.set (Encode.int value)
        << ref path


saveString : String -> (Result Firebase.Errors.Error () -> msg) -> String -> Types.Database -> Cmd msg
saveString path savedMsg value =
    Task.attempt savedMsg
        << Reference.set (Encode.string value)
        << ref path


saveTrueTask : String -> Types.Database -> Task Firebase.Errors.Error ()
saveTrueTask path =
    Reference.set (Encode.bool True)
        << ref path


saveTrue : String -> (Result Firebase.Errors.Error () -> msg) -> Types.Database -> Cmd msg
saveTrue path savedMsg =
    Task.attempt savedMsg
        << saveTrueTask path


saveFalseTask : String -> Types.Database -> Task Firebase.Errors.Error ()
saveFalseTask path =
    Reference.set (Encode.bool False)
        << ref path


saveFalse : String -> (Result Firebase.Errors.Error () -> msg) -> Types.Database -> Cmd msg
saveFalse path savedMsg =
    Task.attempt savedMsg
        << saveFalseTask path


pushValueTask : String -> Encode.Value -> Types.Database -> Task Firebase.Errors.Error ()
pushValueTask path value =
    Reference.set value
        << Reference.push
        << ref path


pushValue : String -> (Result Firebase.Errors.Error () -> msg) -> Encode.Value -> Types.Database -> Cmd msg
pushValue path pushedMsg value =
    Task.attempt pushedMsg
        << pushValueTask path value


pushPushValueTask : String -> String -> Encode.Value -> Types.Database -> Task Firebase.Errors.Error ()
pushPushValueTask path path2 value =
    Reference.set value
        << Reference.push
        << Reference.child path2
        << Reference.push
        << ref path


keyAndTaskFromPush : Types.Database -> String -> Encode.Value -> { key : String, task : Task Firebase.Errors.Error () }
keyAndTaskFromPush db path value =
    let
        pushRef =
            Reference.push <|
                ref path db
    in
        { key = Reference.key pushRef
        , task = Reference.set value pushRef
        }


keysAndTaskFromPushPush : Types.Database -> String -> String -> Encode.Value -> { keys : ( String, String ), task : Task Firebase.Errors.Error () }
keysAndTaskFromPushPush db path path2 value =
    let
        pushRef =
            Reference.push <|
                ref path db

        pushRef2 =
            Reference.push <|
                Reference.child path2 pushRef
    in
        { keys = ( Reference.key pushRef, Reference.key pushRef2 )
        , task = Reference.set value pushRef2
        }


keyAndCmdFromPush : String -> (Result Firebase.Errors.Error () -> msg) -> Encode.Value -> Types.Database -> { key : String, cmd : Cmd msg }
keyAndCmdFromPush path pushedMsg value db =
    let
        pushRef =
            Reference.push <|
                ref path db
    in
        { key = Reference.key pushRef
        , cmd =
            Task.attempt pushedMsg <|
                Reference.set value pushRef
        }


cmdWithKeyFromPush : String -> (String -> Result Firebase.Errors.Error () -> msg) -> Encode.Value -> Types.Database -> Cmd msg
cmdWithKeyFromPush path pushedMsg value db =
    let
        pushRef =
            Reference.push <|
                ref path db
    in
        Task.attempt (pushedMsg (Reference.key pushRef)) <|
            Reference.set value pushRef


updateValueTask : String -> Encode.Value -> Types.Database -> Task Firebase.Errors.Error ()
updateValueTask path value =
    Reference.update value
        << ref path


updateValue : String -> Encode.Value -> (Result Firebase.Errors.Error () -> msg) -> Types.Database -> Cmd msg
updateValue path value updatedMsg =
    Task.attempt updatedMsg
        << updateValueTask path value


updateValueMaybe : (Result Firebase.Errors.Error () -> msg) -> String -> Encode.Value -> Maybe FirebaseApp -> Cmd msg
updateValueMaybe updatedMsg path value =
    Data.foldMaybe
        Cmd.none
        (updateValue path value updatedMsg << .db)


setValue : String -> Encode.Value -> (Result Firebase.Errors.Error () -> msg) -> Types.Database -> Cmd msg
setValue path value updatedMsg =
    Task.attempt updatedMsg
        << Reference.set value
        << ref path


setValueMaybe : (Result Firebase.Errors.Error () -> msg) -> String -> Encode.Value -> Maybe FirebaseApp -> Cmd msg
setValueMaybe updatedMsg path value =
    Data.foldMaybe
        Cmd.none
        (setValue path value updatedMsg << .db)


removeNodeTask : String -> Types.Database -> Task Firebase.Errors.Error ()
removeNodeTask path =
    Reference.remove << ref path


removeNode : String -> (Result Firebase.Errors.Error () -> msg) -> Types.Database -> Cmd msg
removeNode path removedMsg =
    Task.attempt removedMsg
        << removeNodeTask path


removeNodeMaybe : String -> (Result Firebase.Errors.Error () -> msg) -> Maybe FirebaseApp -> Cmd msg
removeNodeMaybe path removedMsg =
    foldFirebaseDb <|
        removeNode path removedMsg


remove2Nodes : String -> String -> (Result Firebase.Errors.Error () -> msg) -> Types.Database -> Cmd msg
remove2Nodes path1 path2 removedMsg db =
    Task.attempt removedMsg <|
        Task.andThen (\_ -> removeNodeTask path2 db) <|
            removeNodeTask path1 db


remove2NodesMaybe : String -> String -> (Result Firebase.Errors.Error () -> msg) -> Maybe FirebaseApp -> Cmd msg
remove2NodesMaybe path1 path2 removedMsg =
    Data.foldMaybe
        Cmd.none
        (remove2Nodes path1 path2 removedMsg << .db)


listToRef : List String -> Types.Database -> Types.Reference
listToRef pathList db =
    List.foldl Reference.child (Firebase.Database.ref (Just "/") db) pathList


valueTask : List String -> Decoder v -> FirebaseApp -> Task String v
valueTask pathList decoder { db } =
    listToRef pathList db
        |> Reference.once "value"
        |> Task.andThen
            (Snapshot.value >> Decode.decodeValue decoder >> Data.taskFromResult)


subValue : List String -> Decoder v -> (Result String v -> msg) -> FirebaseApp -> Sub msg
subValue pathList decoder onChange { db } =
    Reference.on
        "value"
        (listToRef pathList db)
        (Snapshot.value >> Decode.decodeValue decoder >> onChange)


{-| Listens for child_added, child_changed, and child_removed events at the given path.
The callback message receives an `Err` if the decoder failed, or a tuple of
(decoded, removed). The "removed" flag indicates it was triggered by a child_removed event.
-}
subChildren : List String -> (Id -> Decoder v) -> (Result String ( v, Bool ) -> msg) -> FirebaseApp -> Sub msg
subChildren pathList decoder callback { db } =
    let
        decodeSnapshot removed snapshot =
            Decode.decodeValue
                (Snapshot.key snapshot |> Maybe.withDefault "" |> decoder)
                (Snapshot.value snapshot)
                |> Result.map (\v -> ( v, removed ))
    in
        objectsSubscriptions
            (String.join "/" pathList)
            db
            (decodeSnapshot False >> callback)
            (decodeSnapshot False >> callback)
            (decodeSnapshot True >> callback)


firstByChild : List String -> (Id -> Decoder a) -> String -> String -> FirebaseApp -> Task String (Maybe a)
firstByChild pathList decoder child equalTo { db } =
    listToRef pathList db
        |> Reference.orderByChild child
        |> Query.equalTo (Encode.string equalTo) Nothing
        |> Query.limitToFirst 1
        |> Query.once "value"
        |> Task.andThen
            (Snapshot.value
                >> Decode.decodeValue
                    (Decode.nullable
                        (Data.indexedKeyValueDecoder decoder)
                    )
                >> Result.map (Maybe.andThen List.head)
                >> Data.taskFromResult
            )


setTask : List String -> Encode.Value -> FirebaseApp -> Task String ()
setTask pathList value { db } =
    listToRef pathList db |> Reference.set value |> Task.mapError toString


updateMulti : List String -> List ( List String, Value ) -> FirebaseApp -> Task String ()
updateMulti pathList updates { db } =
    listToRef pathList db
        |> Reference.updateMulti
            (List.map
                (Tuple.mapFirst (String.join "/"))
                updates
            )
        |> Task.mapError toString


pushTask : List String -> Encode.Value -> FirebaseApp -> Task String ()
pushTask pathList value { db } =
    listToRef pathList db |> Reference.push |> Reference.set value |> Task.mapError toString


once : String -> (Result Firebase.Errors.Error Types.Snapshot -> msg) -> Types.Database -> Cmd msg
once path gotMsg =
    Task.attempt gotMsg
        << Reference.once "value"
        << ref path


onceTask : String -> Types.Database -> Task String Types.Snapshot
onceTask path =
    ref path >> Reference.once "value"


onceOrNone : (Result Firebase.Errors.Error Types.Snapshot -> msg) -> String -> Cmd msg
onceOrNone gotMsg path =
    Data.foldMaybe
        Cmd.none
        (once path gotMsg << .db)
        maybeFirebaseApp


onceMaybe : (Result Firebase.Errors.Error Types.Snapshot -> msg) -> String -> Maybe FirebaseApp -> Cmd msg
onceMaybe gotMsg path =
    Data.foldMaybe
        Cmd.none
        (once path gotMsg << .db)


onceByChildTask : List String -> String -> Encode.Value -> Decoder a -> FirebaseApp -> Task String a
onceByChildTask pathList childField value decoder { db } =
    listToRef pathList db
        |> Reference.orderByChild childField
        |> Query.equalTo value Nothing
        |> Query.once "value"
        |> Task.andThen
            (Snapshot.value >> Decode.decodeValue decoder >> Data.taskFromResult)


onceByChild : (Result Firebase.Errors.Error Types.Snapshot -> msg) -> String -> String -> Encode.Value -> FirebaseApp -> Cmd msg
onceByChild gotMsg path childField value =
    Task.attempt gotMsg
        << Query.once "value"
        << Query.equalTo value Nothing
        << Reference.orderByChild childField
        << ref path
        << .db


onceByChildMaybe : (Result Firebase.Errors.Error Types.Snapshot -> msg) -> String -> String -> Encode.Value -> Maybe FirebaseApp -> Cmd msg
onceByChildMaybe gotMsg path childField value =
    Data.foldMaybe
        Cmd.none
        (onceByChild gotMsg path childField value)


serverTime : Encode.Value
serverTime =
    Encode.object [ ( ".sv", Encode.string "timestamp" ) ]
