const functions = require('firebase-functions')
const db = require('../utils/db')
const createTransaction = require('../utils/createTransaction')

const validatePurchase = ({ userId, purchaseId }, val) =>
  Promise.all([
    db.valueOrReject('prizes', val.prizeId),
    db.valueOrReject('users', userId),
    db.value('students', userId)
  ])
    .then(([ prize, user, student ]) => {
      if (user.ucoins < prize.price) {
        console.error(`User ${user.id} does not have enough ucoins to purchase ${val.prizeId}`)
        return
      }

      if (!student || !student.active) {
        console.error(`User ${user.id} is not an active student`)
        return
      }

      return Promise.all([
        db.ref('prizePurchases', userId, purchaseId)
          .update({ cost: prize.price, validated: true }),
        student
          && db.ref('pendingCenterPurchases', student.centerId, purchaseId)
            .set({ userName: user.name, userId, prizeName: prize.name }),
        createTransaction(
          userId,
          'prizePurchases',
          purchaseId,
          false,
          -prize.price,
          false
        )
      ])
    })

module.exports =
  functions.database.ref('prizePurchases/{userId}/{purchaseId}')
    .onCreate((snap, context) =>
      validatePurchase(context.params, snap.val())
    )

module.exports._test = { validatePurchase }
