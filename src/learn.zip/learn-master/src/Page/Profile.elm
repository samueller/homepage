module Page.Profile exposing (main)

import Task
import Dict exposing (Dict)
import List.Extra
import Html exposing (..)
import Html.Attributes exposing (..)
import Html.Events exposing (onInput)
import RemoteData
import Material.Options as Options
import Material.Typography as Typography
import Material.Tabs as Tabs
import Material.Icon as Icon
import Material.Dialog as Dialog
import Types.Curricula as Curricula exposing (Curricula)
import Types.Lesson as Lesson exposing (LessonWithId)
import Types.Student as Student exposing (Student)
import Types.Manager as Manager
import Types.Instructor as Instructor
import Types.Completion as Completion exposing (MilestoneCompletion)
import Types.LessonResult as LessonResult exposing (InstructorCache)
import Types.SurveyCompletion as SurveyCompletion exposing (SurveyCompletion)
import Types.Instructor as Instructor exposing (InstructorTeamupId)
import Types.Center as Center exposing (Center)
import UCode.Browser as Browser
import UCode.Data as Data exposing (Id, foldMaybe)
import UCode.Firebase
import UCode.Model
import UCode.Msg
import UCode.Sub
import UCode.User as User
import UCode.Users as Users
import UCode.View as View
import View.Dropdown
import View.Dialog
import View.Loading
import View.Button
import View.Textfield
import View.Table
import Time exposing (Time)


main : Program UCode.Model.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.init SharedMsg init
        , view = View.viewWithDialog SharedMsg view
        , update = update
        , subscriptions = subscriptions
        }



-- MODEL


type alias RemoteData a =
    RemoteData.RemoteData String a


type alias User =
    User.UserWithId


type alias GroupedInstructorResults =
    Dict Id (List ( String, Dict Int (List InstructorCache) ))


type Tab
    = General
    | CompletedMilestones
    | InstructorLessons
    | ExitSurveySubmissions


tabs : Model -> List Tab
tabs model =
    let
        isManager =
            RemoteData.withDefault False model.isManager

        isInstructorProfile =
            RemoteData.withDefault False model.isInstructorProfile

        isOwner =
            model.sharedModel.user.uid == model.id
    in
        List.concat
            [ [ General
              , CompletedMilestones
              ]
            , if isInstructorProfile && (isManager || isOwner) then
                [ InstructorLessons ]
              else
                []
            , if isManager then
                [ ExitSurveySubmissions ]
              else
                []
            ]


indexToTab : Int -> Model -> Tab
indexToTab int model =
    List.Extra.getAt int (tabs model) |> Maybe.withDefault General


tabIndex : Tab -> List Tab -> Int
tabIndex tab tabs =
    List.Extra.findIndex ((==) tab) tabs |> Maybe.withDefault 0


tabToString : Tab -> String
tabToString tab =
    case tab of
        General ->
            "General"

        CompletedMilestones ->
            "Completed Milestones"

        InstructorLessons ->
            "Instructor Lessons"

        ExitSurveySubmissions ->
            "Exit Survey Submissions"


type Dialog
    = SurveyCompletionDetails SurveyCompletion


type alias Model =
    { sharedModel : UCode.Model.SharedModelFirebaseUser
    , id : Id
    , isManager : RemoteData Bool
    , isInstructor : RemoteData Bool
    , isInstructorProfile : RemoteData Bool
    , user : RemoteData User
    , student : RemoteData Student
    , currentLesson : RemoteData LessonWithId
    , curricula : RemoteData Curricula
    , completedMilestones : RemoteData (List MilestoneCompletion)
    , instructorLessons : RemoteData GroupedInstructorResults
    , surveyResults : RemoteData (List SurveyCompletion)
    , instructors : RemoteData (Dict Int InstructorTeamupId)
    , centers : RemoteData (Dict Id Center)
    , selectedInstructorCenter : Maybe Id
    , showEditStatus : Bool
    , showChangeLesson : Bool
    , showEditTeamupId : Bool
    , showEditNotes : Bool
    , selectedTab : Tab
    , notesInput : String
    , currentTime : Maybe Time
    , dialog : Maybe Dialog
    }


init : UCode.Model.SharedModelFirebaseUser -> ( Model, Cmd Msg )
init sharedModel =
    let
        userId =
            Browser.queryIdMaybe
                |> Maybe.withDefault sharedModel.user.uid
    in
        { sharedModel = sharedModel
        , id = userId
        , isManager = RemoteData.Loading
        , isInstructor = RemoteData.Loading
        , isInstructorProfile = RemoteData.Loading
        , user = RemoteData.Loading
        , student = RemoteData.Loading
        , currentLesson = RemoteData.NotAsked
        , curricula = RemoteData.Loading
        , completedMilestones = RemoteData.NotAsked
        , instructorLessons = RemoteData.NotAsked
        , surveyResults = RemoteData.NotAsked
        , instructors = RemoteData.NotAsked
        , centers = RemoteData.NotAsked
        , selectedInstructorCenter = Nothing
        , showEditStatus = False
        , showChangeLesson = False
        , showEditTeamupId = False
        , showEditNotes = False
        , selectedTab = General
        , notesInput = ""
        , currentTime = Nothing
        , dialog = Nothing
        }
            ! [ Data.batchWithMaybe
                    sharedModel.firebaseApp
                    [ .db >> Curricula.get GotCurricula
                    , User.getWithId userId GotUser
                    , Just >> Student.get userId GotStudent
                    , Instructor.getIsInstructor userId
                        >> Task.attempt GotIsInstructorProfile
                    ]
              , Task.perform OnTime Time.now
              ]



-- UPDATE


type
    Msg
    -- UI
    = SharedMsg UCode.Msg.Msg
    | SelectTab Int
    | ShowEditStatus
    | ShowChangeLesson
    | ShowEditTeamupId
    | ShowEditNotes
    | SetActive String
    | SetMilestone Id
    | SetChapter Id
    | SetLesson Id
    | SaveLesson
    | SetTeamupId String
    | SetNotes String
    | SaveStatus
    | SaveNotes
    | SaveTeamupId
    | ShowSurvey SurveyCompletion
    | SetSelectedInstructorCenter Id
    | CloseDialog
      -- Receiving data / Saving data
    | GotIsManager (Result String Bool)
    | GotIsInstructor (Result String Bool)
    | GotIsInstructorProfile (Result String Bool)
    | GotUser (Result String User)
    | GotStudent (Result String Student)
    | GotCurricula (Result String Curricula)
    | GotMilestoneCompletions (Result String (Dict Id MilestoneCompletion))
    | GotInstructorLessons (Result String GroupedInstructorResults)
    | GotSurveyResults (Result String (List SurveyCompletion))
    | GotInstructors (Result String (Dict Int InstructorTeamupId))
    | GotCenters (Result String (Dict Id Center))
    | FinishSetLesson (Result String ())
    | FinishSetTeamupId (Result String ())
    | FinishSetActive (Result String ())
    | FinishSetNotes (Result String ())
    | OnTime Time


fetchDataForTab : Model -> ( Model, Cmd Msg )
fetchDataForTab model =
    case model.selectedTab of
        General ->
            model ! []

        CompletedMilestones ->
            if RemoteData.isNotAsked model.completedMilestones then
                { model | completedMilestones = RemoteData.Loading }
                    ! [ Data.foldMaybe
                            Cmd.none
                            (Completion.getMilestonesForUser model.id
                                >> Task.attempt GotMilestoneCompletions
                            )
                            model.sharedModel.firebaseApp
                      ]
            else
                model ! []

        InstructorLessons ->
            if
                RemoteData.isNotAsked model.instructorLessons
                    || RemoteData.isNotAsked model.centers
            then
                { model | instructorLessons = RemoteData.Loading }
                    ! [ LessonResult.getByMonthMilestone
                            model.id
                            model.sharedModel.firebaseApp
                            |> Task.attempt GotInstructorLessons
                      , Center.getAll () |> Task.attempt GotCenters
                      ]
            else
                model ! []

        ExitSurveySubmissions ->
            if
                RemoteData.isNotAsked model.surveyResults
                    || RemoteData.isNotAsked model.instructors
            then
                { model
                    | surveyResults = RemoteData.Loading
                    , instructors = RemoteData.Loading
                }
                    ! [ SurveyCompletion.getByUser model.id
                            |> Task.attempt GotSurveyResults
                      , Instructor.getIndexByTeamupId ()
                            |> Task.attempt GotInstructors
                      ]
            else
                model ! []


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model

        SelectTab tab ->
            { model | selectedTab = indexToTab tab model } |> fetchDataForTab

        ShowEditStatus ->
            { model | showEditStatus = True } ! []

        ShowChangeLesson ->
            { model | showChangeLesson = True } ! []

        ShowEditTeamupId ->
            { model | showEditTeamupId = True } ! []

        ShowEditNotes ->
            { model | showEditNotes = True } ! []

        SetActive activeString ->
            let
                active =
                    case activeString of
                        "True" ->
                            True

                        _ ->
                            False

                student =
                    RemoteData.map
                        (\student -> { student | active = active })
                        model.student
            in
                { model | student = student } ! []

        SetMilestone id ->
            let
                firstLesson =
                    model.curricula
                        |> RemoteData.toMaybe
                        |> Maybe.andThen (Curricula.firstLessonOfMilestone id)
                        |> Maybe.map (\( _, _, lesson ) -> lesson)

                student =
                    case firstLesson of
                        Just lesson ->
                            RemoteData.map
                                (\student ->
                                    { student | currentLessonId = lesson.id }
                                )
                                model.student

                        Nothing ->
                            model.student
            in
                { model | student = student } ! []

        SetChapter id ->
            let
                firstLesson =
                    model.curricula
                        |> RemoteData.toMaybe
                        |> Maybe.andThen (Curricula.firstLessonOfChapter id)
                        |> Maybe.map (\( _, _, lesson ) -> lesson)

                student =
                    case firstLesson of
                        Just lesson ->
                            RemoteData.map
                                (\student ->
                                    { student | currentLessonId = lesson.id }
                                )
                                model.student

                        Nothing ->
                            model.student
            in
                { model | student = student } ! []

        SetLesson id ->
            { model
                | student =
                    RemoteData.map
                        (\student -> { student | currentLessonId = id })
                        model.student
            }
                ! []

        SaveLesson ->
            let
                currentLessonId =
                    model.student
                        |> RemoteData.toMaybe
                        |> Maybe.map .currentLessonId
            in
                { model | showChangeLesson = False }
                    ! [ Data.fold2Maybes
                            Cmd.none
                            (\{ db } lessonId ->
                                Student.setCurrentLessonId
                                    model.id
                                    lessonId
                                    FinishSetLesson
                                    db
                            )
                            model.sharedModel.firebaseApp
                            currentLessonId
                      ]

        SetTeamupId input ->
            { model
                | student =
                    RemoteData.map
                        (\student -> { student | teamupId = Just input })
                        model.student
            }
                ! []

        SetNotes input ->
            { model
                | student =
                    RemoteData.map
                        (\student -> { student | notes = input })
                        model.student
            }
                ! []

        SaveStatus ->
            { model | showEditStatus = False }
                ! [ model.student
                        |> RemoteData.toMaybe
                        |> Maybe.map
                            (\{ active } ->
                                Data.batchWithMaybe
                                    model.sharedModel.firebaseApp
                                    [ Student.setActive model.id active
                                        >> Task.attempt FinishSetActive
                                    ]
                            )
                        |> Maybe.withDefault Cmd.none
                  ]

        SaveNotes ->
            { model | showEditNotes = False }
                ! [ model.student
                        |> RemoteData.toMaybe
                        |> Maybe.map
                            (\{ notes } ->
                                Student.setNotes model.id notes
                                    |> Task.attempt FinishSetNotes
                            )
                        |> Maybe.withDefault Cmd.none
                  ]

        SaveTeamupId ->
            case RemoteData.toMaybe model.student of
                Just student ->
                    case student.teamupId of
                        Just "" ->
                            View.notify "Teamup ID can't be empty" SharedMsg model

                        Nothing ->
                            View.notify "Teamup ID can't be empty" SharedMsg model

                        Just teamupId ->
                            { model | showEditTeamupId = False }
                                ! [ Student.setTeamupId model.id teamupId FinishSetTeamupId model ]

                Nothing ->
                    model ! []

        ShowSurvey survey ->
            { model | dialog = Just (SurveyCompletionDetails survey) } ! []

        SetSelectedInstructorCenter id ->
            { model | selectedInstructorCenter = Just id } ! []

        CloseDialog ->
            { model | dialog = Nothing } ! []

        GotIsManager result ->
            { model | isManager = RemoteData.fromResult result } ! []

        GotIsInstructor result ->
            { model | isInstructor = RemoteData.fromResult result } ! []

        GotIsInstructorProfile result ->
            { model | isInstructorProfile = RemoteData.fromResult result } ! []

        GotUser result ->
            { model | user = RemoteData.fromResult result } ! []

        GotStudent result ->
            { model | student = RemoteData.fromResult result } ! []

        GotCurricula result ->
            { model | curricula = RemoteData.fromResult result } ! []

        GotMilestoneCompletions result ->
            { model
                | completedMilestones =
                    result
                        |> RemoteData.fromResult
                        |> RemoteData.map
                            (Dict.values >> List.sortBy .completedAt)
            }
                ! []

        GotInstructorLessons result ->
            { model | instructorLessons = RemoteData.fromResult result } ! []

        GotSurveyResults result ->
            { model | surveyResults = RemoteData.fromResult result } ! []

        GotInstructors result ->
            { model | instructors = RemoteData.fromResult result } ! []

        GotCenters result ->
            { model | centers = RemoteData.fromResult result } ! []

        FinishSetLesson result ->
            View.notifyWhenError "saving lesson" SharedMsg model result

        FinishSetTeamupId result ->
            View.notifyWhenError "saving Teamup ID" SharedMsg model result

        FinishSetActive result ->
            View.notifyWhenError "saving status" SharedMsg model result

        FinishSetNotes result ->
            View.notifyWhenError "saving notes" SharedMsg model result

        OnTime time ->
            { model | currentTime = Just time } ! []



-- SUBSCRIPTIONS


accessControlSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
accessControlSubs model app =
    let
        uid =
            model.sharedModel.user.uid
    in
        Sub.batch
            [ Manager.subIsManager uid (GotIsManager) app
            , Instructor.subIsInstructor uid (GotIsInstructor) app
            ]


firebaseSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ accessControlSubs model firebase
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch <|
        [ View.materialSub model SharedMsg
        , UCode.Sub.firebaseSubs model firebaseSubs
        ]



-- VIEW


viewError : String -> String -> Html Msg
viewError action error =
    div []
        [ h1 [] [ text <| "Something went wrong while " ++ action ]
        , h3 [] [ text error ]
        ]


viewTitle : User -> Html Msg
viewTitle user =
    Options.styled header
        [ Options.css "text-align" "center" ]
        [ h1 [] [ text user.name ]
        , Options.styled h2 [ Typography.subhead ] [ text user.email ]
        ]



-- Field Definitions


type alias ViewerPermissions =
    { employee : Bool
    , ownProfile : Bool
    }


type alias EditProfileField =
    { editMsg : ViewerPermissions -> Maybe ( Msg, Msg )
    , viewEditing : Model -> List Int -> List (Html Msg)
    }


type alias ProfileField =
    { label : String
    , view : ViewerPermissions -> Maybe (List (Html Msg))
    , edit : Maybe EditProfileField
    }


statusField : Bool -> ProfileField
statusField status =
    { label = "Active"
    , view =
        \{ employee } ->
            if employee then
                Just
                    [ text <|
                        if status then
                            "Yes"
                        else
                            "No"
                    ]
            else
                Nothing
    , edit =
        Just
            { editMsg = \_ -> Just ( ShowEditStatus, SaveStatus )
            , viewEditing =
                \model index ->
                    [ View.Dropdown.render
                        { placeholder = ""
                        , options =
                            [ View.Dropdown.Option
                                { text = "Yes", id = "True", disabled = False }
                            , View.Dropdown.Option
                                { text = "No", id = "False", disabled = False }
                            ]
                        , onSelect = SetActive
                        , selected = Just <| toString status
                        , disabled = False
                        }
                    ]
            }
    }


viewLessonLocation : Curricula -> Id -> Html msg
viewLessonLocation curricula id =
    case Curricula.findLesson id curricula of
        Just ( milestone, chapter, lesson ) ->
            span
                [ title <|
                    toString milestone.number
                        ++ ": "
                        ++ milestone.name
                        ++ "\n"
                        ++ toString chapter.number
                        ++ ": "
                        ++ chapter.name
                        ++ "\n"
                        ++ toString lesson.number
                        ++ ": "
                        ++ lesson.name
                ]
                [ text <|
                    ([ ( "M", milestone.number )
                     , ( "C", chapter.number )
                     , ( "L", lesson.number )
                     ]
                        |> List.map (\( letter, number ) -> letter ++ toString number)
                        |> String.join " "
                    )
                ]

        Nothing ->
            Options.span [ Options.css "font-style" "italic" ]
                [ text "Unknown Lesson" ]


currentLessonField : Curricula -> Id -> ProfileField
currentLessonField curricula id =
    { label = "Current Lesson"
    , view =
        \_ -> Just [ viewLessonLocation curricula id ]
    , edit =
        Just
            { editMsg =
                \{ employee } ->
                    if employee then
                        Just ( ShowChangeLesson, SaveLesson )
                    else
                        Nothing
            , viewEditing =
                \model index ->
                    let
                        currentLesson =
                            Curricula.findLesson id curricula

                        milestone =
                            currentLesson
                                |> Maybe.andThen
                                    (\( milestone, _, _ ) ->
                                        Curricula.milestone milestone.id curricula
                                    )

                        chapter =
                            Maybe.andThen
                                (\( milestone, chapters ) ->
                                    Data.firstSuccess
                                        (\( chapter, lessons ) ->
                                            Maybe.andThen
                                                (\( _, currentChapter, _ ) ->
                                                    if currentChapter.id == chapter.id then
                                                        Just ( chapter, lessons )
                                                    else
                                                        Nothing
                                                )
                                                currentLesson
                                        )
                                        chapters
                                )
                                milestone
                    in
                        [ View.Dropdown.render
                            { placeholder = "Choose a milestone"
                            , options =
                                List.map
                                    (\( milestone, chapters ) ->
                                        View.Dropdown.Option
                                            { text = toString milestone.number ++ " - " ++ milestone.name
                                            , id = milestone.id
                                            , disabled = List.length chapters == 0
                                            }
                                    )
                                    curricula
                            , onSelect = SetMilestone
                            , selected =
                                currentLesson
                                    |> Maybe.map (\( milestone, _, _ ) -> milestone.id)
                            , disabled = False
                            }
                        , br [] []
                        , View.Dropdown.render
                            { placeholder = "Choose a chapter"
                            , options =
                                milestone
                                    |> Maybe.map
                                        (\( _, chapters ) ->
                                            List.map
                                                (\( chapter, _ ) ->
                                                    View.Dropdown.Option
                                                        { text = toString chapter.number ++ " - " ++ chapter.name
                                                        , id = chapter.id
                                                        , disabled = List.length chapters == 0
                                                        }
                                                )
                                                chapters
                                        )
                                    |> Maybe.withDefault []
                            , onSelect = SetChapter
                            , selected =
                                currentLesson
                                    |> Maybe.map (\( _, chapter, _ ) -> chapter.id)
                            , disabled = False
                            }
                        , br [] []
                        , View.Dropdown.render
                            { placeholder = "Choose a lesson"
                            , options =
                                chapter
                                    |> Maybe.map
                                        (\( chapter, lessons ) ->
                                            List.map
                                                (\lesson ->
                                                    View.Dropdown.Option
                                                        { text = toString lesson.number ++ " - " ++ lesson.name
                                                        , id = lesson.id
                                                        , disabled = List.length lessons == 0
                                                        }
                                                )
                                                lessons
                                        )
                                    |> Maybe.withDefault []
                            , onSelect = SetLesson
                            , selected =
                                currentLesson
                                    |> Maybe.map (\( _, _, lesson ) -> lesson.id)
                            , disabled = False
                            }
                        , br [] []
                        ]
            }
    }


ageField : Maybe Int -> ProfileField
ageField age =
    { label = "Age"
    , view =
        \_ ->
            case age of
                Just age ->
                    Just
                        [ Options.styled pre
                            [ Options.css "margin" "0"
                            , Options.css "font-family" "inherit"
                            ]
                            [ text (toString age)
                            ]
                        ]

                Nothing ->
                    Nothing
    , edit =
        Nothing
    }


notesField : String -> ProfileField
notesField note =
    { label = "Notes"
    , view =
        \{ employee } ->
            if employee then
                Just
                    [ Options.styled pre
                        [ Options.css "margin" "0"
                        , Options.css "font-family" "inherit"
                        ]
                        [ text note ]
                    ]
            else
                Nothing
    , edit =
        Just
            { editMsg = \_ -> Just ( ShowEditNotes, SaveNotes )
            , viewEditing =
                \model index ->
                    [ textarea [ onInput SetNotes, value note ] []
                    ]
            }
    }


teamupIdField : Maybe String -> ProfileField
teamupIdField maybeTeamupId =
    { label = "Teamup ID"
    , view =
        \{ employee } ->
            if employee then
                Just
                    [ case maybeTeamupId of
                        Just id ->
                            text id

                        Nothing ->
                            Options.span [ Options.css "font-style" "italic" ]
                                [ text "Not set" ]
                    ]
            else
                Nothing
    , edit =
        Just
            { editMsg = \_ -> Just ( ShowEditTeamupId, SaveTeamupId )
            , viewEditing =
                \model index ->
                    [ View.Textfield.basic
                        SharedMsg
                        index
                        model
                        []
                        ""
                        (Maybe.withDefault "" maybeTeamupId)
                        SetTeamupId
                    ]
            }
    }


ucoinsField : Id -> Int -> ProfileField
ucoinsField userId ucoins =
    { label = "UCoins"
    , view =
        \{ ownProfile, employee } ->
            Just
                [ if ownProfile || employee then
                    a [ href <| "/ucoins.html?user=" ++ userId ]
                        [ text <| toString ucoins ]
                  else
                    span [] [ text <| toString ucoins ]
                ]
    , edit = Nothing
    }



-- Display fields


viewProfileField : Model -> List Int -> ProfileField -> ViewerPermissions -> Bool -> Html Msg
viewProfileField model index field permissions editing =
    case field.view permissions of
        Just fieldHtml ->
            Options.div
                [ Options.css "font-size" "18px"
                , Options.css "margin-bottom" "10px"
                ]
                [ Options.div
                    [ Options.css "width" "49%"
                    , Options.css "text-align" "right"
                    , Options.css "font-weight" "bold"
                    , Options.css "display" "inline-block"
                    , Options.css "margin-right" "1%"
                    , Options.css "vertical-align" "top"
                    ]
                    [ text field.label ]
                , Options.div
                    [ Options.css "width" "49%"
                    , Options.css "display" "inline-block"
                    , Options.css "margin-left" "1%"
                    ]
                    (case field.edit of
                        Just { editMsg, viewEditing } ->
                            case editMsg permissions of
                                Just ( starEditing, stopEditing ) ->
                                    if editing then
                                        viewEditing model (index ++ [ 0 ])
                                            ++ [ View.Button.raised
                                                    SharedMsg
                                                    (index ++ [ 1 ])
                                                    model
                                                    []
                                                    stopEditing
                                                    "Save"
                                               ]
                                    else
                                        fieldHtml
                                            ++ [ View.Button.icon
                                                    SharedMsg
                                                    index
                                                    model
                                                    []
                                                    starEditing
                                                    "edit"
                                               ]

                                Nothing ->
                                    fieldHtml

                        Nothing ->
                            fieldHtml
                    )
                ]

        Nothing ->
            text ""


viewProfileFields :
    Model
    -> List Int
    -> ViewerPermissions
    -> List ( ProfileField, Model -> Bool )
    -> List (Html Msg)
viewProfileFields model index permissions =
    List.indexedMap
        (\subIndex ( field, editing ) ->
            viewProfileField model (index ++ [ subIndex ]) field permissions (editing model)
        )


viewGeneralHelp : Model -> Bool -> User -> Student -> Curricula -> Html Msg
viewGeneralHelp model isManagerOrInstructor user student curricula =
    let
        viewingOwnProfile =
            model.sharedModel.user.uid == model.id

        permissions =
            { employee = isManagerOrInstructor
            , ownProfile = viewingOwnProfile
            }
    in
        div [] <|
            viewProfileFields
                model
                [ 0 ]
                permissions
                [ ( statusField student.active, .showEditStatus )
                , ( currentLessonField curricula student.currentLessonId, .showChangeLesson )
                , ( ucoinsField user.id user.ucoins, always False )
                , ( teamupIdField student.teamupId, .showEditTeamupId )
                , ( ageField (Maybe.andThen (User.age user) model.currentTime), always False )
                , ( notesField student.notes, .showEditNotes )
                ]


viewGeneral : Model -> Html Msg
viewGeneral model =
    RemoteData.map
        (viewGeneralHelp model)
        (RemoteData.map2 (||) model.isManager model.isInstructor)
        |> RemoteData.andMap model.user
        |> RemoteData.andMap model.student
        |> RemoteData.andMap model.curricula
        |> View.Loading.remoteData
            Nothing
            View.Loading.large
            (viewError "loading the page")
            identity


viewMilestonesHelp : List MilestoneCompletion -> Html Msg
viewMilestonesHelp milestones =
    Options.div [ Options.center ]
        [ if List.length milestones == 0 then
            span [] [ text "No completed milestones yet" ]
          else
            View.Table.basic []
                [ View.Table.column "Milestone" .numberAndName
                , View.Table.column "Completed" (.completedAt >> Data.formatDateTime)
                ]
                milestones
        ]


viewCompletedMilestones : Model -> Html Msg
viewCompletedMilestones model =
    View.Loading.remoteData
        Nothing
        View.Loading.large
        (viewError "loading completed milestones")
        viewMilestonesHelp
        model.completedMilestones


viewInstructorLessonsTable : List ( String, Dict Int (List InstructorCache) ) -> Html Msg
viewInstructorLessonsTable results =
    Options.div [ Options.center ]
        [ View.Table.basic []
            ([ View.Table.column "Month" Tuple.first ]
                ++ List.map
                    (\number ->
                        View.Table.columnNumeric
                            ("Milestone " ++ toString number)
                            (Tuple.second
                                >> Dict.get number
                                >> Maybe.map List.length
                                >> Maybe.withDefault 0
                            )
                    )
                    (List.range 1 6)
            )
            results
        ]


viewInstructorLessonsHelp : Maybe Id -> Dict Id Center -> GroupedInstructorResults -> Html Msg
viewInstructorLessonsHelp selectedCenterId centers resultsByCenter =
    let
        selectedCenterResults =
            Maybe.andThen (\id -> Dict.get id resultsByCenter) selectedCenterId
    in
        Options.div [ Options.css "text-align" "center" ]
            [ if Dict.size resultsByCenter == 0 then
                span [] [ text "No completed lessons yet" ]
              else
                Options.div [ Options.css "margin-bottom" "10px" ]
                    [ View.Dropdown.render
                        { placeholder = "Select center"
                        , options =
                            Dict.keys resultsByCenter
                                |> List.map
                                    (\id ->
                                        View.Dropdown.Option
                                            { text =
                                                case Dict.get id centers of
                                                    Just center ->
                                                        center.name

                                                    Nothing ->
                                                        "Unknown center (" ++ id ++ ")"
                                            , disabled = False
                                            , id = id
                                            }
                                    )
                        , onSelect = SetSelectedInstructorCenter
                        , selected = selectedCenterId
                        , disabled = False
                        }
                    ]
            , case selectedCenterResults of
                Just results ->
                    viewInstructorLessonsTable results

                Nothing ->
                    text ""
            ]


viewInstructorLessons : Model -> Html Msg
viewInstructorLessons model =
    RemoteData.succeed (viewInstructorLessonsHelp model.selectedInstructorCenter)
        |> RemoteData.andMap model.centers
        |> RemoteData.andMap model.instructorLessons
        |> View.Loading.andFork
            Nothing
            View.Loading.large
            (viewError "loading instructor lessons")


viewInstructorLinked : Dict Int InstructorTeamupId -> Int -> Html Msg
viewInstructorLinked instructors instructorTeamupId =
    (Dict.get instructorTeamupId instructors)
        |> Maybe.map
            (\{ id, name } ->
                a [ href ("/profile.html?id=" ++ id) ] [ text name ]
            )
        |> Maybe.withDefault (text ("Unknown (" ++ (toString instructorTeamupId) ++ ")"))


viewSurveySubmissions :
    List SurveyCompletion
    -> Curricula
    -> Dict Int InstructorTeamupId
    -> Html Msg
viewSurveySubmissions submissions curricula instructors =
    View.Table.dialog [ Options.css "margin" "auto" ]
        [ View.Table.column "Submitted at" (.timestamp >> Data.formatDateTime)
        , View.Table.columnCustom
            "Instructor"
            (.instructorTeamupId >> viewInstructorLinked instructors)
            False
        , View.Table.columnCustom
            "Lesson"
            (.currentLessonId >> viewLessonLocation curricula)
            False
        ]
        ShowSurvey
        submissions


viewSurveySubmissionsTab : Model -> Html Msg
viewSurveySubmissionsTab model =
    RemoteData.succeed viewSurveySubmissions
        |> RemoteData.andMap model.surveyResults
        |> RemoteData.andMap model.curricula
        |> RemoteData.andMap model.instructors
        |> View.Loading.andFork
            Nothing
            View.Loading.large
            (viewError "loading exit survey submissions")


viewTabBody : Model -> Html Msg
viewTabBody model =
    case model.selectedTab of
        General ->
            viewGeneral model

        CompletedMilestones ->
            viewCompletedMilestones model

        InstructorLessons ->
            viewInstructorLessons model

        ExitSurveySubmissions ->
            viewSurveySubmissionsTab model


viewTabs : Model -> Html Msg
viewTabs model =
    let
        tabLabel tabText =
            Tabs.label [ Options.center ] [ text tabText ]

        filteredTabs =
            tabs model
    in
        Tabs.render (UCode.Msg.Mdl >> SharedMsg)
            [ 0 ]
            model.sharedModel.mdl
            [ Tabs.ripple
            , Tabs.onSelectTab SelectTab
            , Tabs.activeTab (tabIndex model.selectedTab filteredTabs)
            ]
            (List.map (tabToString >> tabLabel) filteredTabs)
            [ Options.div [ Options.css "margin-top" "20px" ]
                [ viewTabBody model ]
            ]


viewMain : Model -> Html Msg
viewMain model =
    View.Loading.remoteData
        Nothing
        View.Loading.large
        (viewError "loading user")
        (\user -> div [] [ viewTitle user, viewTabs model ])
        model.user


viewContainer : List (Html Msg) -> Html Msg
viewContainer page =
    div [ style [ ( "max-width", "1500px" ), ( "margin", "0 auto 100px" ) ] ]
        [ div [ style [ ( "margin", "0 20px" ) ] ] page ]


viewSurveyCompletionDetails : SurveyCompletion -> Html Msg
viewSurveyCompletionDetails survey =
    View.Dialog.custom
        [ Options.div
            [ Options.css "display" "flex"
            , Options.css "justify-content" "space-between"
            ]
            [ Options.div [ Options.css "margin-right" "20px" ]
                [ Options.styled h1
                    [ Typography.headline
                    , Options.css "margin" "0"
                    ]
                    [ text "Survey Details" ]
                , Options.styled p
                    [ Typography.body1
                    , Options.css "margin" "10px 0 0"
                    ]
                    [ text ("Submitted " ++ Data.formatDateTime survey.timestamp)
                    ]
                ]
            , Icon.view "close"
                [ Dialog.closeOn "click"
                , Options.onClick CloseDialog
                , Options.css "cursor" "pointer"
                ]
            ]
        , View.Table.basic []
            [ View.Table.column "Question" SurveyCompletion.question
            , View.Table.column "Response" SurveyCompletion.response
            ]
            (Dict.values survey.responses)
        ]


viewDialog : Model -> Html Msg
viewDialog model =
    case model.dialog of
        Just (SurveyCompletionDetails survey) ->
            viewSurveyCompletionDetails survey

        Nothing ->
            View.Dialog.empty


view : Model -> ( List (Html Msg), Html Msg )
view model =
    ( [ viewContainer <| List.singleton <| viewMain model ]
    , viewDialog model
    )
