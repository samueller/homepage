const admin = require('firebase-admin')
const { database } = admin

/**
 * Wrapper for firebase-admin that provides shortcuts for common actions
 */

/**
 * Create a Firebase database reference
 * @param  {string...} path Any number of path segements which are joined with slashes
 * @return {admin.database.Reference}
 */
const ref = (...path) =>
  database().ref(path.length ? path.join('/') : '/')

/**
 * Check if there is a value at the given path in the database
 * @param  {string...} path
 * @return {Promise<Bool>}
 */
const exists = (...path) =>
  ref(...path).once('value').then(snap => snap.exists())

/**
 * Fetch the value at the given path and extract the value from the snapshot
 * @param  {string...} path
 * @return {Promise<*>}
 */
const value = (...path) =>
  ref(...path)
    .once('value')
    .then(snap => snap.val())

/**
 * Fetch the value at the given path, rejecting when the value is null
 * @param  {string...} path
 * @return {Promise<*>}
 */
const valueOrReject = (...path) =>
  value(...path)
    .then(val =>
      val !== null
        ? val
        : Promise.reject(new Error('Expected value at ' + path.join('/') + ' but got null'))
    )

/**
 * Shortcut to request the value from the given ref and extract the value from
 * the snapshot
 * @param  {admin.database.Reference} ref
 * @return {Promise<*>} Promise resolves to the value referenced by `ref`
 */
const valueOf = ref =>
  ref.once('value').then(snap => snap.val())

module.exports = {
  ref,
  exists,
  value,
  valueOrReject,
  valueOf,
  ServerValue: database.ServerValue
}
