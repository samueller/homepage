module View.Button exposing (flat, icon, raised)

import Html exposing (Html)
import Material.Button as Button
import Material.Icon as Icon
import Material.Options as Options
import UCode.Model exposing (WithSharedModel)
import UCode.Msg


base :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> List (Button.Property msg)
    -> List (Html msg)
    -> Html msg
base sharedMsg index model =
    Button.render (sharedMsg << UCode.Msg.Mdl) index model.sharedModel.mdl


flat :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> List (Button.Property msg)
    -> msg
    -> String
    -> Html msg
flat sharedMsg index model properties onClick text =
    (base sharedMsg index model)
        ([ Button.ripple, Options.onClick onClick ] ++ properties)
        [ Html.text text ]


icon :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> List (Button.Property msg)
    -> msg
    -> String
    -> Html msg
icon sharedMsg index model properties onClick icon =
    (base sharedMsg index model)
        ([ Button.icon, Options.onClick onClick ] ++ properties)
        [ Icon.i icon ]


raised :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> List (Button.Property msg)
    -> msg
    -> String
    -> Html msg
raised sharedMsg index model properties onClick text =
    (base sharedMsg index model)
        ([ Button.raised
         , Button.primary
         , Button.ripple
         , Options.onClick onClick
         ]
            ++ properties
        )
        [ Html.text text ]
