class RequestError extends Error {
  constructor(statusCode, statusText) {
    super(statusText)
    this.statusCode = statusCode
    this.statusText = statusText
  }
}

module.exports = RequestError
