module.exports = promises =>
  Promise.all(
    promises.map(promise =>
      Promise.resolve(promise)
        .catch(e => {
          console.error(e)
          return null
        })
    )
  )
