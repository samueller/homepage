module Page.Prizes exposing (main)

import Task
import Html exposing (..)
import Html.Attributes exposing (..)
import List.Extra
import Material.Grid as Grid
import Material.Options as Options
import RemoteData
import UCode.Model exposing (FirebaseUser, SharedModelMaybeFirebaseUser)
import UCode.Firebase exposing (FirebaseApp)
import UCode.Msg
import UCode.Sub
import UCode.Users as Users
import UCode.User as User exposing (UserWithId)
import UCode.View as View
import UCode.Data as Data exposing (Id)
import Types.Prize as Prize exposing (Prize)
import Types.PrizePurchase as PrizePurchase
import Types.Student as Student exposing (Student)
import View.Dialog


main : Program (Maybe FirebaseUser) Model Msg
main =
    Html.programWithFlags
        { init = Users.initMaybeUser SharedMsg init
        , view = View.viewMaybeUserUcoins SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


init : SharedModelMaybeFirebaseUser -> ( Model, Cmd Msg )
init sharedModel =
    { sharedModel = sharedModel
    , user = Nothing
    , activeStudent = RemoteData.Loading
    , prizes = RemoteData.Loading
    , dialog = Closed
    }
        ! [ Data.batchWithMaybe
                sharedModel.firebaseApp
                [ Prize.getAll ReceivedPrizes
                ]
          , case sharedModel.user of
                Just { uid } ->
                    Student.isActive uid |> Task.attempt ReceivedIsActive

                Nothing ->
                    Cmd.none
          ]



-- MODEL


type alias RemoteData a =
    RemoteData.RemoteData String a


type Dialog
    = Closed
    | ConfirmPurchaseDialog Prize
    | FinishedPurchaseDialog (Result String ())


type alias Model =
    { sharedModel : SharedModelMaybeFirebaseUser
    , user : Maybe UserWithId
    , activeStudent : RemoteData Bool
    , prizes : RemoteData (List Prize)
    , dialog : Dialog
    }



-- UPDATE


type Msg
    = SharedMsg UCode.Msg.Msg
    | ReceivedUser (Result String UserWithId)
    | ReceivedPrizes (Result String (List Prize))
    | ReceivedIsActive (Result String Bool)
    | Purchase Id
    | ConfirmPurchase Prize
    | CloseDialog
    | FinishedPurchase (Result String ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model

        ReceivedUser (Ok user) ->
            { model | user = Just user } ! []

        ReceivedUser (Err error) ->
            let
                _ =
                    Debug.log error
            in
                View.notify "Error fetching user" SharedMsg model

        ReceivedPrizes result ->
            { model | prizes = RemoteData.fromResult result } ! []

        ReceivedIsActive result ->
            { model | activeStudent = RemoteData.fromResult result } ! []

        Purchase id ->
            { model
                | dialog =
                    RemoteData.toMaybe model.prizes
                        |> Maybe.andThen (List.Extra.find (.id >> (==) id))
                        |> Maybe.map ConfirmPurchaseDialog
                        |> Maybe.withDefault Closed
            }
                ! []

        ConfirmPurchase prize ->
            case model.user of
                Just user ->
                    if user.ucoins >= prize.price then
                        { model | dialog = Closed }
                            ! [ Data.batchWithMaybe
                                    model.sharedModel.firebaseApp
                                    [ PrizePurchase.create user.id prize FinishedPurchase ]
                              ]
                    else
                        { model | dialog = Closed }
                            |> View.notify ("You don't have enough UCoins to purchase " ++ prize.name) SharedMsg

                Nothing ->
                    -- We should never be here
                    model ! []

        CloseDialog ->
            { model | dialog = Closed } ! []

        FinishedPurchase result ->
            { model | dialog = FinishedPurchaseDialog result } ! []



-- SUBSCRIPTIONS


firebaseSubs : Model -> FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    model.sharedModel.user
        |> Maybe.map
            (\{ uid } -> User.sub uid ReceivedUser firebase)
        |> Maybe.withDefault Sub.none


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , UCode.Sub.firebaseSubs model firebaseSubs
        ]



-- VIEW


viewPrize : Model -> Int -> Prize -> Grid.Cell Msg
viewPrize model index prize =
    let
        textWrapper string =
            span [ style [ ( "flex-shrink", "0" ) ] ] [ text string ]
    in
        Grid.cell [ Grid.size Grid.All 4, Options.attribute <| id prize.id, Options.css "margin-bottom" "100px" ]
            [ img
                [ style [ ( "width", "100%" ), ( "height", "300px" ), ( "object-fit", "cover" ) ]
                , src prize.imageUrl
                ]
                []
            , h4 [] [ text prize.name ]
            , p [] [ text <| toString prize.price ++ " UCoins" ]
            , View.markdown prize.description
            , case ( model.user, model.activeStudent ) of
                ( Just user, RemoteData.Success isActiveStudent ) ->
                    div [ style [ ( "text-align", "center" ) ] ]
                        [ View.button
                            model
                            SharedMsg
                            (Purchase prize.id)
                            (user.ucoins < prize.price || not isActiveStudent)
                            True
                            [ 0, index ]
                            [ if isActiveStudent then
                                text "Purchase"
                              else
                                text "Must be active student to purchase"
                            ]
                        ]

                _ ->
                    text ""
            ]


viewLoading : Grid.Cell Msg
viewLoading =
    Grid.cell [ Grid.stretch ] [ text "Loading...", View.spinner ]


viewError : String -> String -> Grid.Cell Msg
viewError action error =
    Grid.cell [ Grid.stretch ]
        [ h4 [] [ text <| "Error while " ++ action ]
        , p [] [ text error ]
        ]


viewDialog : Model -> Html Msg
viewDialog model =
    case model.dialog of
        ConfirmPurchaseDialog prize ->
            View.Dialog.confirm
                model
                SharedMsg
                [ 1 ]
                "Confirm Purchase"
                [ p [] [ text <| "Are you sure you want to purchase this prize?" ]
                , h4 [] [ text prize.name ]
                , p [] [ text <| toString prize.price ++ " UCoins" ]
                ]
                "Purchase"
                "Cancel"
                (ConfirmPurchase prize)
                CloseDialog

        FinishedPurchaseDialog (Ok ()) ->
            View.Dialog.info
                model
                SharedMsg
                [ 1 ]
                "Purchase Successful"
                [ p [] [ text <| "Congratulations!" ] ]
                CloseDialog

        FinishedPurchaseDialog (Err error) ->
            View.Dialog.info
                model
                SharedMsg
                [ 1 ]
                "Purchased Failed"
                [ p [] [ text "Something went wrong while saving your purchase. You haven't been charged any UCoins. Please try again or ask an instructor for help." ]
                , p [] [ text "Here's technical details of the error:" ]
                , p [] [ text error ]
                ]
                CloseDialog

        Closed ->
            View.Dialog.empty


viewBody : Model -> ( Maybe UserWithId, List (Html Msg) )
viewBody model =
    ( model.user
    , [ Grid.grid [ Grid.maxWidth "1500px" ]
            (case model.prizes of
                RemoteData.NotAsked ->
                    [ viewLoading ]

                RemoteData.Loading ->
                    [ viewLoading ]

                RemoteData.Failure error ->
                    [ viewError "loading prizes" error ]

                RemoteData.Success prizes ->
                    prizes
                        |> List.sortBy .price
                        |> List.indexedMap (viewPrize model)
            )
      , viewDialog model
      ]
    )
