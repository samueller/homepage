module.exports = numbers =>
  numbers.reduce((total, number) => total + number, 0) / numbers.length
