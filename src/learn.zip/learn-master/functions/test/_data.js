// Data used in tests

export default {
  lessons: {
    'lesson-1': {
      name: 'a',
      number: 1,
      chapterId: 'chapter-1'
    },
    'lesson-2': {
      name: 'b',
      number: 2,
      chapterId: 'chapter-1'
    },
    'lesson-3': {
      name: 'c',
      number: 1,
      chapterId: 'chapter-2'
    },
    'lesson-4': {
      name: 'd',
      number: 2,
      chapterId: 'chapter-2'
    },
    'lesson-5': {
      name: 'e',
      number: 1,
      chapterId: 'chapter-3'
    },
    'lesson-6': {
      name: 'f',
      number: 2,
      chapterId: 'chapter-3'
    }
  },
  chapters: {
    'chapter-1': {
      name: 'g',
      number: 1,
      milestoneId: 'milestone-1'
    },
    'chapter-2': {
      name: 'h',
      number: 2,
      milestoneId: 'milestone-1'
    },
    'chapter-3': {
      name: 'i',
      number: 1,
      milestoneId: 'milestone-2'
    }
  },
  milestones: {
    'milestone-1': {
      name: 'j',
      number: 1
    },
    'milestone-2': {
      name: 'k',
      number: 2
    }
  },
  lessonNumbers: {
    'chapter-1': {
      'lesson-1': 1,
      'lesson-2': 2
    },
    'chapter-2': {
      'lesson-3': 1,
      'lesson-4': 2
    },
    'chapter-3': {
      'lesson-5': 1,
      'lesson-6': 2
    }
  },
  chapterNumbers: {
    'milestone-1': {
      'chapter-1': 1,
      'chapter-2': 2
    },
    'milestone-2': {
      'chapter-3': 1
    }
  }
}
