const functions = require('firebase-functions')
const db = require('../utils/db')
const uidOfEmail = require('../utils/uid-of-email')
const constants = require('../constants')

module.exports =
  functions.https.onRequest((req, res) => {
    if (req.method !== 'POST') {
      return res.status(405).send('This route only accepts POST requests')
    }
    if (typeof req.body.email !== 'string') {
      return res.status(400).send('Expected `req.body.email` to be a string')
    }
    if (req.headers['x-utype-webhook-secret'] !== functions.config().utype.webhook_secret) {
      return res.status(400).send('Bad secret')
    }
    res.status(204).end()
    return uidOfEmail(req.body.email)
      .then(uid => {
        console.log(`email: ${req.body.email}, userId: ${uid}`)
        if (uid) {
          return db.ref('utypeCompletions', uid)
            .set({
              ucoins: constants.UCOIN_VALUES.UTYPE_COMPLETION,
              completedAt: db.ServerValue.TIMESTAMP
            })
        }
      })
  })
