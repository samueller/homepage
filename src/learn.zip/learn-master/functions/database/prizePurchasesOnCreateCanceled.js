const functions = require('firebase-functions')
const db = require('../utils/db')
const createTransaction = require('../utils/createTransaction')

const cancelPurchase = ({ userId, purchaseId }) =>
  Promise.all([
    db.valueOrReject('prizePurchases', userId, purchaseId),
    db.value('students', userId, 'centerId')
  ])
    .then(([ purchase, centerId ]) => {
      console.log(`Refunding purchase ${purchaseId} for user ${userId} (center ID: ${centerId})`)
      return Promise.all([
        createTransaction(
          userId,
          'prizeRefund',
          purchaseId,
          false,
          purchase.cost,
          false
        ),
        centerId
          && db.ref('pendingCenterPurchases', centerId, purchaseId).set(null)
      ])
    })

module.exports =
  functions.database.ref('prizePurchases/{userId}/{purchaseId}/canceled')
    .onCreate((snap, context) =>
      cancelPurchase(context.params)
    )

module.exports._test = { cancelPurchase }
