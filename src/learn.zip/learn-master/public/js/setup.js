/* eslint-env browser */
/* global firebase */

const database = firebase.database()

const firstAuthStateChange = () =>
  new Promise(resolve => {
    const unsubscribe = firebase.auth().onAuthStateChanged(user => {
      unsubscribe()
      resolve(user)
    })
  })

const firstChildSnapshot = snapshot => {
  let first = null
  snapshot.forEach(child => {
    first = child
    return true // cancel loop so we only handle the first snapshot
  })
  return first
}

const createUser = (firebaseUser, invite) =>
  database
    .ref('users')
    .child(firebaseUser.uid)
    .set({
      name: invite.name,
      email: invite.email,
      birthDate: invite.birthDate
    })

const createStudent = (firebaseUser, invite) =>
  database
    .ref('students')
    .child(firebaseUser.uid)
    .set({
      centerId: invite.centerId,
      name: invite.name,
      currentLessonId: '-KvSDUL7trWSRH_d9xiQ',
      active: true
    })

const createInstructor = (firebaseUser, invite) =>
  database
    .ref('centerInstructors')
    .child(invite.centerId)
    .child(firebaseUser.uid)
    .set(invite.name)

const setupStudent = (firebaseUser, invite) =>
  Promise.all([
    createUser(firebaseUser, invite),
    createStudent(firebaseUser, invite)
  ])

const setupInstructor = (firebaseUser, invite) =>
  Promise.all([
    createUser(firebaseUser, invite),
    createStudent(firebaseUser, invite),
    createInstructor(firebaseUser, invite)
  ])

const viewParagraphs = paragraphs =>
  paragraphs.map(text => {
    const p = document.createElement('p')
    p.innerHTML = text
    return p
  })

const viewMessage = (heading, ...paragraphs) => {
  const h1 = document.createElement('h1')
  h1.innerHTML = heading

  const elements = [ h1, ...viewParagraphs(paragraphs) ]
  elements.forEach(element => document.body.appendChild(element))
}

const main = async () => {
  const user = await firstAuthStateChange()

  if (!user) {
    return firebase.auth().signInWithRedirect(
      (new firebase.auth.GoogleAuthProvider())
        .setCustomParameters({ prompt: 'select_account' })
    )
  }

  const studentInvitesSnapshot = await database
    .ref('studentInvites')
    .orderByChild('email')
    .equalTo(user.email)
    .once('value')

  const instructorInvitesSnapshot = await database
    .ref('instructorInvites')
    .orderByChild('email')
    .equalTo(user.email)
    .once('value')

  if (studentInvitesSnapshot.exists()) {
    const studentInvite = firstChildSnapshot(studentInvitesSnapshot)
    await Promise.all([
      setupStudent(user, studentInvite.val()),
      studentInvite.ref.remove()
    ])
    viewMessage(
      'Success!',
      `You've been setup as a student for your email address ${user.email}`,
      '<a href="/">Click here to go to your dashboard</a>'
    )
  } else if (instructorInvitesSnapshot.exists()) {
    const instructorInvite = firstChildSnapshot(instructorInvitesSnapshot)
    await Promise.all([
      setupStudent(user, instructorInvite.val()),
      setupInstructor(user, instructorInvite.val()),
      instructorInvite.ref.remove()
    ])
    viewMessage(
      'Success!',
      `You've been setup as an instructor for your email address ${user.email}`,
      '<a href="/">Click here to go to your dashboard</a>'
    )
  } else {
    viewMessage(
      'No invite',
      `There is no invite for your email address ${user.email}`
    )
  }
}

main()
  .catch(error => {
    console.error(error)
    viewMessage(
      'Oops',
      `Something went wrong while setting up your account, please try again. Ask your instructor for help if this keeps happening.`,
      'Details in the console.'
    )
  })
