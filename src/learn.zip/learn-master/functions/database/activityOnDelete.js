const functions = require('firebase-functions')
const db = require('../utils/db')
const promiseAllIgnoreReject = require('../utils/promise-all-ignore-reject')

const activityPaths = {
  video: 'videos',
  instruction: 'instructions',
  quiz: 'quizzes',
  lti: 'lti',
  exercises: 'exerciseSets',
  exams: 'exams',
  project_step: 'projectSteps',
  submission_instruction: 'submissionInstr'
}

const deleteCacheByLesson = ({ id }) =>
  db.ref('activityLessons', id).remove()

// In this context, an 'activity' is a project step, exercise, video, etc
const deleteActivity = activity =>
  db.ref(activityPaths[activity.activityType], activity.activityId).remove()

module.exports =
  functions.database.ref('activities/{lessonId}/{id}')
    .onDelete((before, context) =>
      promiseAllIgnoreReject([
        deleteCacheByLesson(context.params),
        deleteActivity(before.val())
      ])
    )

module.exports._test = {
  deleteCacheByLesson,
  deleteActivity
}
