module UCode.Model
    exposing
        ( SharedModelUser
        , SharedModelFirebaseUser
        , SharedModelMaybeFirebaseUser
        , WithSharedModel
        , WithSharedModelUser
        , WithSharedModelFirebaseUser
        , WithSharedModelUserFields
        , WithSharedModelMaybeUser
        , updateSnackbar
        , update
        , openHomepage
        , User
        , FirebaseUser
        )

import Navigation
import Material
import Material.Snackbar as Snackbar
import UCode.Firebase exposing (WithFirebase, FirebaseApp, logout)
import UCode.Msg exposing (Msg(..))
import UCode.Ports as Ports


type alias User =
    { id : String
    , name : String
    , email : String
    , birthDate : String
    }


type alias FirebaseUser =
    { uid : String
    , displayName : String
    , email : String
    , photoURL : String
    }


type alias WithMaterialModel model =
    { model
        | mdl : Material.Model
        , snackbar : Snackbar.Model ()
    }


type alias WithUser model =
    { model | user : User }


type alias WithSharedModelFields model =
    WithMaterialModel (WithFirebase model)


type alias WithSharedModelUserFields model =
    WithMaterialModel (WithFirebase (WithUser model))


type alias WithSharedModel model a =
    { model | sharedModel : WithSharedModelFields a }


type alias WithSharedModelUser model a =
    { model | sharedModel : WithSharedModelUserFields a }


type alias WithSharedModelFirebaseUser model =
    { model | sharedModel : SharedModelFirebaseUser }


type alias SharedModelUser =
    { mdl : Material.Model
    , firebaseApp : Maybe FirebaseApp
    , user : User
    , snackbar : Snackbar.Model ()
    }


type alias SharedModelFirebaseUser =
    { mdl : Material.Model
    , firebaseApp : Maybe FirebaseApp
    , user : FirebaseUser
    , snackbar : Snackbar.Model ()
    }


type alias SharedModelMaybeFirebaseUser =
    { mdl : Material.Model
    , firebaseApp : Maybe FirebaseApp
    , user : Maybe FirebaseUser
    , snackbar : Snackbar.Model ()
    }


type alias WithSharedModelMaybeUser model =
    { model | sharedModel : SharedModelMaybeFirebaseUser }


liftSharedModel : WithSharedModel model a -> WithSharedModelFields a -> WithSharedModel model a
liftSharedModel model sharedModel =
    { model | sharedModel = sharedModel }


liftSharedModelAndCmd : (Msg -> msg) -> WithSharedModel model a -> ( WithSharedModelFields a, Cmd Msg ) -> ( WithSharedModel model a, Cmd msg )
liftSharedModelAndCmd liftMsg model =
    Tuple.mapFirst (liftSharedModel model)
        << Tuple.mapSecond (Cmd.map liftMsg)


updateSnackbar :
    (Msg -> msg)
    -> (Snackbar.Model () -> ( Snackbar.Model (), Cmd (Snackbar.Msg ()) ))
    -> { model | sharedModel : { a | snackbar : Snackbar.Model () } }
    -> ( { model | sharedModel : { a | snackbar : Snackbar.Model () } }, Cmd msg )
updateSnackbar liftMsg updater model =
    let
        sharedModel =
            model.sharedModel

        snackbar =
            sharedModel.snackbar

        ( newSnackbarModel, snackbarCmd ) =
            updater snackbar
    in
        { model
            | sharedModel =
                { sharedModel | snackbar = newSnackbarModel }
        }
            ! [ Cmd.map (Snackbar >> liftMsg) snackbarCmd ]


openHomepage : model -> ( model, Cmd msg )
openHomepage model =
    ( model, Navigation.load "/" )


update : (Msg -> msg) -> Msg -> WithSharedModel model a -> ( WithSharedModel model a, Cmd msg )
update liftMsg msg model =
    let
        logoutThen msg =
            liftSharedModelAndCmd liftMsg model <|
                logout model.sharedModel (always msg)
    in
        case msg of
            Mdl msg_ ->
                liftSharedModelAndCmd liftMsg model <|
                    Material.update Mdl msg_ model.sharedModel

            Snackbar msg_ ->
                updateSnackbar liftMsg (Snackbar.update msg_) model

            LogoutAndLoadHome ->
                logoutThen LoadHome

            LoadHome ->
                model ! [ Navigation.load "/" ]

            SignIn ->
                model ! [ Ports.signIn () ]

            LogoutAndReload ->
                logoutThen Reload

            Reload ->
                model ! [ Navigation.reload ]
