const request = require('request-promise')

const dateToTeamupDate = date =>
  `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`

const teampupRequest = (token, route, qs) =>
  request({
    uri: 'https://goteamup.com/api/v1/' + route,
    qs,
    headers: {
      Authorization: 'Bearer ' + token
    },
    json: true
  })
    .catch(e => {
      const error = new Error('Failed to call Teamup API: ' + e.message)
      error.cause = e
      return Promise.reject(error)
    })

const getSessionAttendances = (token, customerId, after) =>
  teampupRequest(
    token,
    'sessionattendances',
    {
      customer: customerId,
      session_start_datetime_after: dateToTeamupDate(after)
    }
  )

module.exports = {
  getSessionAttendances
}
