module Page.NewProjectStep exposing (main)

import Html exposing (..)
import Material.Grid as Grid
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.View as View
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Model as UModel
import UCode.Msg
import UCode.Firebase as UFirebase
import UCode.Data as Data
import Types.Lesson as Lesson
import Types.Chapter as Chapter
import Types.Milestone as Milestone
import Types.Instruction as Instruction
import Types.Project as Project
import Util.Heading as Heading


main : Program UModel.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUser SharedMsg initialModel
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialModel : UModel.SharedModelFirebaseUser -> Model
initialModel =
    Model Nothing Nothing Nothing Browser.queryId (Browser.intQueryParam "number") Project.emptyStep


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , lessonId : Data.Id
    , number : Int
    , projectStep : Project.Step
    , sharedModel : UModel.SharedModelFirebaseUser
    }


type Msg
    = SharedMsg UCode.Msg.Msg
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | InputInstruction String
    | InputRubric String
    | Create
    | Created Data.Id (Result Firebase.Errors.Error ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        InputInstruction instruction ->
            Project.recordWithStepInstruction instruction model ! []

        InputRubric rubric ->
            Project.recordWithStepRubric rubric model ! []

        Create ->
            ( model, UFirebase.withDb (Project.createStep Created model.lessonId model.number model.projectStep) model )

        Created projectStepId _ ->
            ( model, Project.openEditStepUrlWithLesson model.lessonId projectStepId )

        SharedMsg msg_ ->
            UModel.update SharedMsg msg_ model


viewFields : Model -> List (Grid.Cell Msg)
viewFields model =
    [ View.halfWidthDesktopTabletCell
        [ View.fieldsetH3 "📜 Instruction"
            [ View.textarea model SharedMsg InputInstruction 10 "GitHub-Flavored Markdown" True False [ 0 ] model.projectStep.instruction ]
        ]
    , View.halfWidthDesktopTabletWideCell
        [ View.fieldsetH3 "👁 Preview"
            [ Instruction.div model.projectStep.instruction ]
        ]
    , View.halfWidthDesktopTabletCell
        [ View.fieldsetH3 "💯 Rubric"
            [ View.textarea model SharedMsg InputRubric 10 "GitHub-Flavored Markdown" False False [ 1 ] model.projectStep.rubric ]
        ]
    , View.halfWidthDesktopTabletWideCell
        [ View.fieldsetH3 "👁 Preview"
            [ Instruction.div model.projectStep.rubric ]
        ]
    , View.fullWidthCell
        [ View.buttonWithText model SharedMsg Create (Project.invalidStep model.projectStep) [ 2 ] "Create" ]
    ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid [] <|
        Heading.viewActivityEditHeading model "New Project Step"
            :: viewFields model
    ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch <|
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        ]
