module View.Loading exposing (large, remoteData, andFork)

import Html exposing (Html)
import RemoteData exposing (RemoteData(..))
import Material.Options as Options
import UCode.View


large : Html msg
large =
    Options.div
        [ Options.css "text-align" "center" ]
        [ Html.h1 [] [ Html.text "Loading", UCode.View.spinner ] ]


{-| Similar to a (non-existant) "RemoteData.fork". Handles each possible state
of a RemoteData. `NotAsked` is either loading, or displays custom HTML. `Loading`
displays a static loading indicator. `Failure` calls the given "onFailure"
function, and `Success` calls the "onSuccess" function.
-}
remoteData : Maybe b -> b -> (x -> b) -> (a -> b) -> RemoteData x a -> b
remoteData onNotAsked onLoading onError onSuccess data =
    case data of
        NotAsked ->
            Maybe.withDefault onLoading onNotAsked

        Loading ->
            onLoading

        Failure x ->
            onError x

        Success a ->
            onSuccess a


{-| Pipeline-friendly version of `remoteData`

    RemoteData.succeed viewSurveySubmissions
        |> RemoteData.andMap model.surveyResults
        |> RemoteData.andMap model.curricula
        |> View.Loading.andFork
            Nothing
            View.Loading.large
            (viewError "loading exit survey submissions")

-}
andFork : Maybe a -> a -> (x -> a) -> RemoteData x a -> a
andFork onNotAsked onLoading onError data =
    case data of
        NotAsked ->
            Maybe.withDefault onLoading onNotAsked

        Loading ->
            onLoading

        Failure x ->
            onError x

        Success html ->
            html
