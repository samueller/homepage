import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const studentTestimonialsOnCreate =
  proxyquire(
    '../../database/studentTestimonialsOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CREATE STUDENT TESTIMONIALS TRANSACTION

test('createStudentTestimonialsTransaction creates a valid transaction', async t => {
  await studentTestimonialsOnCreate._test.createStudentTestimonialsTransaction(
    { userId: 'testUserId', testimonialId: 'testimonial-12345' }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'studentTestimonials',
          reasonId: 'testimonial-12345',
          change: 500,
          timestamp:
            ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})
