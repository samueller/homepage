module Page.NewQuiz exposing (main)

import Html exposing (Html, nav, header, h1, h2, h3, h4, h5, h6, p, strong, text, ol, ul, li, span, br, div, a, img, select, option)
import Material.Grid as Grid
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.View as View
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Model exposing (User, SharedModelUser)
import UCode.Msg
import Types.Lesson as Lesson
import Types.Chapter as Chapter
import Types.Milestone as Milestone
import Types.Quiz as Quiz
import Types.Question as Question
import Types.Instruction as Instruction
import Util.Heading as Heading


main : Program User Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithUser SharedMsg initialModel
        , view = View.viewWithUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialModel : SharedModelUser -> Model
initialModel =
    Model Nothing Nothing Nothing Browser.queryId (Browser.intQueryParam "number") ""


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , lessonId : String
    , number : Int
    , question : String
    , sharedModel : SharedModelUser
    }


type Msg
    = SharedMsg UCode.Msg.Msg
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | InputQuestion String
    | Create
    | Created String (Result Firebase.Errors.Error ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        InputQuestion question ->
            { model | question = question } ! []

        Create ->
            ( model, Quiz.createWithMultRespQuestionMaybe model Created model.question model.lessonId model.number )

        Created quizId _ ->
            ( model, Quiz.openEditUrlWithLesson model.lessonId quizId )

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model


viewFields : Model -> List (Grid.Cell Msg)
viewFields model =
    [ View.fullWidthCell
        [ View.buttonWithText model SharedMsg Create (Question.invalidFields model) [ 1 ] "Create First Question" ]
    , View.halfWidthDesktopTabletCell
        [ View.fieldsetH3 "📋 First Question"
            [ View.textarea model SharedMsg InputQuestion 6 "GitHub-Flavored Markdown" True False [ 0 ] model.question ]
        ]
    , View.halfWidthDesktopTabletWideCell
        [ View.fieldsetH3 "👁 Preview"
            [ Instruction.divQuestion model.question ]
        ]
    ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        (Heading.viewActivityEditHeading model "New Quiz with First Question"
            :: viewFields model
        )
    ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch <|
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        ]
