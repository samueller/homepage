import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const utypeCompletionsOnCreate =
proxyquire(
  '../../database/utypeCompletionsOnCreate',
  { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
)

test.serial('createUtypeCompletionTransaction creates a valid transaction', async t => {
  await utypeCompletionsOnCreate._test.createUtypeCompletionTransaction(
    { userId: 'user-1' },
    { ucoins: 200 }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory['user-1'],
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'utypeCompletions',
          change: 200,
          timestamp:
            ucoinTransactionHistory['user-1'].transactions[0].timestamp
        }
      ]
    }
  )
})
