module View.Dialog exposing (empty, info, confirm, custom)

import Html exposing (Html, text)
import Html.Attributes as Attribute
import Material.Dialog as Dialog
import Material.Button as Button
import Material.Options as Options
import UCode.Msg
import UCode.Model exposing (WithSharedModel)


{-| If the page doesn't have anything to display in a dialog at a given time,
this should be output somewhere in the view function, because a dialog should
always be rendered in the DOM
-}
empty : Html msg
empty =
    Dialog.view [] []


{-| A dialog for presenting information. The user dismisses it when they're
done reading.
-}
info :
    WithSharedModel model a
    -> (UCode.Msg.Msg -> msg)
    -> List Int
    -> String
    -> List (Html msg)
    -> msg
    -> Html msg
info model liftMsg index title content onClose =
    Dialog.view
        [ Options.css "width" "fit-content"
        , Options.css "max-width" "700px"
        , Attribute.attribute "open" "true"
            |> Options.attribute
        ]
        [ Dialog.title [] [ text title ]
        , Dialog.content [] content
        , Dialog.actions []
            [ Button.render (liftMsg << UCode.Msg.Mdl)
                index
                model.sharedModel.mdl
                [ Button.ripple
                , Dialog.closeOn "click"
                , Options.onClick onClose
                ]
                [ text "Close" ]
            ]
        ]


{-| A dialog for asking the user to accept or decline an action or message
-}
confirm :
    WithSharedModel model a
    -> (UCode.Msg.Msg -> msg)
    -> List Int
    -> String
    -> List (Html msg)
    -> String
    -> String
    -> msg
    -> msg
    -> Html msg
confirm model liftMsg index title content confirmMessage cancelMessage onConfirm onCancel =
    Dialog.view
        [ Options.css "width" "fit-content"
        , Options.css "max-width" "700px"
        ]
        [ Dialog.title [] [ text title ]
        , Dialog.content [] content
        , Dialog.actions []
            [ Button.render (liftMsg << UCode.Msg.Mdl)
                (index ++ [ 0 ])
                model.sharedModel.mdl
                [ Button.ripple
                , Button.colored
                , Dialog.closeOn "click"
                , Options.onClick onConfirm
                ]
                [ text confirmMessage ]
            , Button.render (liftMsg << UCode.Msg.Mdl)
                (index ++ [ 1 ])
                model.sharedModel.mdl
                [ Button.ripple
                , Dialog.closeOn "click"
                , Options.onClick onCancel
                ]
                [ text cancelMessage ]
            ]
        ]


{-| Gives you complete control over the children of the dialog element
-}
custom : List (Html msg) -> Html msg
custom children =
    Dialog.view
        [ Options.css "width" "fit-content" ]
        [ Dialog.content [ Options.css "padding" "0" ] children ]
