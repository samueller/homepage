module Types.Student exposing (..)

import Firebase.Database.Reference as Reference
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Json.Decode as Decode exposing (Decoder)
import Json.Encode as Encode
import Task exposing (Task)
import Dict exposing (Dict)
import Types.Lesson as Lesson
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Util.Firebase.Database as Db


type alias Student =
    { name : String
    , centerId : String
    , currentLessonId : String
    , active : Bool
    , teamupId : Maybe String
    , notes : String
    }


type alias WithMaybeStudent r =
    { r | student : Maybe Student }


decoder : Decoder Student
decoder =
    Decode.map6 Student
        (Decode.field "name" Decode.string)
        (Decode.field "centerId" Decode.string)
        (Decode.field "currentLessonId" Decode.string)
        (Decode.field "active" Decode.bool)
        (Decode.maybe (Decode.field "teamupId" Decode.string))
        (Decode.oneOf
            [ Decode.field "notes" Decode.string
            , Decode.succeed ""
            ]
        )


recordWithJustStudent : WithMaybeStudent a -> Student -> WithMaybeStudent a
recordWithJustStudent record student =
    { record | student = Just student }


recordWithJustStudentSnapshot : WithMaybeStudent a -> Types.Snapshot -> WithMaybeStudent a
recordWithJustStudentSnapshot record =
    Data.recordWithSnapshotValue record (recordWithJustStudent record) decoder


fromSnapshot : Types.Snapshot -> Maybe Student
fromSnapshot =
    Data.maybeFromSnapshot decoder


lessonLocked : Student -> Maybe Lesson.Lesson -> Lesson.Lesson -> Bool
lessonLocked student studentLesson lesson =
    Data.foldMaybe
        True
        (\studentLesson ->
            studentLesson.chapterId == lesson.chapterId && studentLesson.number < lesson.number
        )
        studentLesson


getTask : Id -> Task String Student
getTask id =
    Db.value [ "students", id ] decoder


getTaskMaybe : Id -> Task String (Maybe Student)
getTaskMaybe id =
    Db.value [ "students", id ] (Decode.oneOf [ Decode.map Just decoder, Decode.null Nothing ])


get : Id -> (Result String Student -> msg) -> Maybe UCode.Firebase.FirebaseApp -> Cmd msg
get studentId onFinish =
    UCode.Firebase.onceMaybe
        (Result.mapError toString
            >> Result.andThen (Snapshot.value >> Decode.decodeValue decoder)
            >> onFinish
        )
        ("students/" ++ studentId)


getAllForCenter : Id -> FirebaseApp -> Task String (Dict String Student)
getAllForCenter centerId =
    UCode.Firebase.onceByChildTask
        [ "students" ]
        "centerId"
        (Encode.string centerId)
        (Decode.keyValuePairs decoder
            |> Decode.map Dict.fromList
        )


sub : UCode.Firebase.FirebaseApp -> (Types.Snapshot -> msg) -> String -> Sub msg
sub =
    UCode.Firebase.idSubscription "students"


setCurrentLessonId : String -> String -> (Result String () -> msg) -> Types.Database -> Cmd msg
setCurrentLessonId studentId lessonId onFinish =
    UCode.Firebase.ref ("/students/" ++ studentId ++ "/currentLessonId")
        >> Reference.set (Encode.string lessonId)
        >> Task.mapError toString
        >> Task.attempt onFinish


setTeamupId :
    Id
    -> String
    -> (Result String () -> msg)
    -> { model | sharedModel : { sharedModel | firebaseApp : Maybe FirebaseApp } }
    -> Cmd msg
setTeamupId studentId teamupId onFinish { sharedModel } =
    case sharedModel.firebaseApp of
        Just app ->
            UCode.Firebase.setTask
                [ "students", studentId, "teamupId" ]
                (Encode.string teamupId)
                app
                |> Task.attempt onFinish

        Nothing ->
            Cmd.none


setNotes : Id -> String -> Task String ()
setNotes studentId note =
    Db.set
        [ "students", studentId, "notes" ]
        (Encode.string note)


setActive : Id -> Bool -> FirebaseApp -> Task String ()
setActive studentId active =
    UCode.Firebase.setTask
        [ "students", studentId, "active" ]
        (Encode.bool active)


isActive : Id -> Task String Bool
isActive id =
    Db.value [ "students", id, "active" ] Decode.bool
