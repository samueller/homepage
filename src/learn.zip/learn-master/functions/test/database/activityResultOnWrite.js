import test from 'ava'
import sinon from 'sinon'
import proxyquire from 'proxyquire'
import testData from '../_data'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const currentTeamupSessionStub = sinon.stub()
const instructorUidOfTeamupIdStub = sinon.stub()

const activityResultOnWrite =
  proxyquire(
    '../../database/activityResultOnWrite',
    {
      'firebase-admin': Object.assign({ '@global': true }, adminMock),
      '../utils/current-teamup-session': currentTeamupSessionStub,
      '../utils/instructor-uid-of-teamup-id': instructorUidOfTeamupIdStub
    }
  )

// CHECK LESSON PROGRESS

test('checkLessonProgress marks lessons passed', async t => {
  mockdatabase.set({
    ...testData,
    activityLessons: {
      'activity-3': 'lesson-1'
    },
    activities: {
      'lesson-1': {
        'activity-1': true,
        'activity-2': true,
        'activity-3': true
      }
    },
    activityResults: {
      'user-1': {
        'activity-1': { score: 100 },
        'activity-2': { score: 100 },
        'activity-3': { score: 100 }
      }
    }
  })
  await activityResultOnWrite._test.checkLessonProgress(
    { userId: 'user-1', activityId: 'activity-3' }
  )
  const { lessonResults } = mockdatabase.getData()
  t.truthy(lessonResults['user-1']['lesson-1'])
})

test('checkLessonProgress records instructor when possible', async t => {
  mockdatabase.set({
    ...testData,
    students: {
      'user-1': {
        teamupId: '1234',
        centerId: 'center-1'
      }
    },
    activityLessons: {
      'activity-3': 'lesson-1'
    },
    activities: {
      'lesson-1': {
        'activity-1': true,
        'activity-2': true,
        'activity-3': true
      }
    },
    activityResults: {
      'user-1': {
        'activity-1': { score: 100 },
        'activity-2': { score: 100 },
        'activity-3': { score: 100 }
      }
    }
  })
  currentTeamupSessionStub
    .callsFake((teamupId, centerId) => {
      t.is(teamupId, '1234')
      t.is(centerId, 'center-1')
      return Promise.resolve({ instructors: [ { id: 'instructor-1' } ] })
    })
  instructorUidOfTeamupIdStub
    .withArgs('instructor-1')
    .resolves('user-2')
  await activityResultOnWrite._test.checkLessonProgress(
    { userId: 'user-1', activityId: 'activity-3' }
  )
  const { lessonResults } = mockdatabase.getData()
  t.is(lessonResults['user-1']['lesson-1'].instructor, 'user-2')
})
