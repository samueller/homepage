module Types.UcoinAdjustments
    exposing
        ( UcoinAdjustment
        , ucoinAdjustmentDecoder
        , get
        , create
        )

import Task
import Json.Decode as Decode exposing (Decoder, Value)
import Json.Encode as Encode
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import UCode.Model exposing (FirebaseUser)
import UCode.User as User exposing (UserWithId)


type alias UcoinAdjustment =
    { userId : Id
    , id : Id
    , reason : String
    , adjustedById : Id
    , adjustedByName : String
    , adjustedAt : Int
    , ucoins : Int
    }


ucoinAdjustmentDecoder : Id -> Id -> Decoder UcoinAdjustment
ucoinAdjustmentDecoder userId adjustmentId =
    Decode.map5 (UcoinAdjustment userId adjustmentId)
        (Decode.field "reason" Decode.string)
        (Decode.at [ "adjustedBy", "userId" ] Decode.string)
        (Decode.at [ "adjustedBy", "userName" ] Decode.string)
        (Decode.field "adjustedAt" Decode.int)
        (Decode.field "ucoins" Decode.int)


ucoinAdjustmentEncoder : UserWithId -> String -> Int -> FirebaseUser -> Value
ucoinAdjustmentEncoder student reason ucoins manager =
    Encode.object
        [ ( "reason", Encode.string reason )
        , ( "ucoins", Encode.int ucoins )
        , ( "adjustedBy"
          , Encode.object
                [ ( "userId", Encode.string manager.uid )
                , ( "userName", Encode.string manager.displayName )
                ]
          )
        , ( "adjustedAt", UCode.Firebase.serverTime )
        ]


get : Id -> Id -> (Result String UcoinAdjustment -> msg) -> FirebaseApp -> Cmd msg
get userId adjustmentId onFinish =
    UCode.Firebase.valueTask
        [ "ucoinAdjustments", userId, adjustmentId ]
        (ucoinAdjustmentDecoder userId adjustmentId)
        >> Task.attempt onFinish


create : String -> String -> Int -> FirebaseUser -> (Result String () -> msg) -> FirebaseApp -> Cmd msg
create email reason ucoins manager onFinish app =
    User.validateEmail email app
        |> Task.andThen
            (\user ->
                UCode.Firebase.pushTask
                    [ "ucoinAdjustments", user.id ]
                    (ucoinAdjustmentEncoder user reason ucoins manager)
                    app
            )
        |> Task.attempt onFinish
