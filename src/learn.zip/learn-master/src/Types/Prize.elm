module Types.Prize exposing (..)

import Task
import Json.Decode as Decode exposing (Decoder)
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)


type alias Prize =
    { id : Id
    , name : String
    , imageUrl : String
    , description : String
    , price : Int
    }


prizeDecoder : Id -> Decoder Prize
prizeDecoder id =
    Decode.map4 (Prize id)
        (Decode.field "name" Decode.string)
        (Decode.field "imageUrl" Decode.string)
        (Decode.field "description" Decode.string)
        (Decode.field "price" Decode.int)


getAll : (Result String (List Prize) -> msg) -> FirebaseApp -> Cmd msg
getAll onFinish =
    UCode.Firebase.valueTask
        [ "prizes" ]
        (Data.indexedKeyValueDecoder prizeDecoder)
        >> Task.attempt onFinish
