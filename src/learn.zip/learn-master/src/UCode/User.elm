module UCode.User exposing (..)

import Task exposing (Task)
import Json.Decode as Decode
import Json.Decode.Extra as Decode
import Json.Encode as Encode
import Firebase.Database.Types exposing (Snapshot)
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Util.Firebase.Database as Db
import Date exposing (Date)
import Time exposing (Time)
import DateFormat


type alias User =
    { name : String
    , email : String
    , birthDate : String
    , ucoins : Int
    }


type alias UserWithId =
    { id : Id
    , name : String
    , email : String
    , birthDate : String
    , ucoins : Int
    }


age : UserWithId -> Time -> Maybe Int
age user time =
    Date.fromString user.birthDate
        |> Result.toMaybe
        |> Maybe.andThen
            (\date ->
                Date.fromTime (time - Date.toTime date)
                    |> DateFormat.format [ DateFormat.yearNumber ]
                    |> String.toInt
                    |> Result.toMaybe
            )
        |> Maybe.map (\date -> date - 1970)


decoder : Decode.Decoder User
decoder =
    Decode.map4 User
        (Decode.field "name" Decode.string)
        (Decode.field "email" Decode.string)
        (Decode.field "birthDate" Decode.string)
        (Decode.optionalField "ucoins" Decode.int
            |> Decode.map (Maybe.withDefault 0)
        )


decoderWithId : Id -> Decode.Decoder UserWithId
decoderWithId id =
    Decode.map4 (UserWithId id)
        (Decode.field "name" Decode.string)
        (Decode.field "email" Decode.string)
        (Decode.field "birthDate" Decode.string)
        (Decode.optionalField "ucoins" Decode.int
            |> Decode.map (Maybe.withDefault 0)
        )


type alias WithUser record user =
    { record | user : user }


updateRecordUser : WithUser a user -> user -> WithUser a user
updateRecordUser record user =
    { record | user = user }


updateRecordDecodedUser : WithUser a user -> Decode.Decoder user -> Snapshot -> WithUser a user
updateRecordDecodedUser record decoder snapshot =
    Data.recordWithSnapshotValue record (updateRecordUser record) decoder snapshot


getAll : Task String (List UserWithId)
getAll =
    Db.getIndexed [ "users" ] decoderWithId


get : Id -> Task String UserWithId
get uid =
    Db.value [ "users", uid ] (decoderWithId uid)


getWithId : Id -> (Result String UserWithId -> msg) -> FirebaseApp -> Cmd msg
getWithId userId onFinish =
    UCode.Firebase.valueTask
        [ "users", userId ]
        (decoderWithId userId)
        >> Task.attempt onFinish


sub : Id -> (Result String UserWithId -> msg) -> FirebaseApp -> Sub msg
sub userId =
    UCode.Firebase.subValue [ "users", userId ] (decoderWithId userId)


getByEmailTask : String -> FirebaseApp -> Task String (Maybe UserWithId)
getByEmailTask =
    UCode.Firebase.firstByChild [ "users" ] decoderWithId "email"


validateEmail : String -> FirebaseApp -> Task String UserWithId
validateEmail email app =
    getByEmailTask email app
        |> Task.mapError (\error -> "Failed to validate email \"" ++ email ++ "\": " ++ error)
        |> Task.andThen
            (\maybeUser ->
                case maybeUser of
                    Just user ->
                        Task.succeed user

                    Nothing ->
                        Task.fail <| "There isn't a user with the email \"" ++ email ++ "\""
            )


validateEmailNoDb : String -> Task String UserWithId
validateEmailNoDb email =
    Db.queryByChildFirst [ "users" ] "email" (Encode.string email) decoderWithId
        |> Task.mapError (\error -> "Failed to validate email \"" ++ email ++ "\": " ++ error)
        |> Task.andThen
            (\maybeUser ->
                case maybeUser of
                    Just user ->
                        Task.succeed user

                    Nothing ->
                        Task.fail <| "There isn't a user with the email \"" ++ email ++ "\""
            )
