import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const lti =
  proxyquire(
    '../../http/lti',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

test.cb('records the user\'s result', t => {
  t.plan(2)
  const req = {
    body: `
      <sourcedId>exercise activity-1 user-1 lti-1</sourcedId>
      <textString>1</textString>
    `
  }
  const res = {
    status: code => {
      t.is(code, 204)
      return {
        end: () => {
          const { exerciseSetResults } = mockdatabase.getData()
          const { timestamp } = exerciseSetResults['user-1']['activity-1']['lti-1']
          t.deepEqual(
            exerciseSetResults,
            {
              'user-1': {
                'activity-1': {
                  'lti-1': {
                    score: 100,
                    attempts: 1,
                    timestamp
                  }
                }
              }
            }
          )
          t.end()
        }
      }
    }
  }
  lti(req, res)
})
