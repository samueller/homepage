const functions = require('firebase-functions')
const db = require('../utils/db')

const deleteCacheByActivity = ({ exerciseSetId }) =>
  db.ref('exerciseSetActivities', exerciseSetId).remove()

module.exports =
  functions.database.ref('exerciseSets/{exerciseSetId}')
    .onDelete((before, context) => deleteCacheByActivity(context.params))

module.exports._test = { deleteCacheByActivity }
