module Types.FacebookLike exposing (..)

import Task exposing (Task)
import Json.Decode as Decode exposing (Decoder, Value)
import Json.Encode as Encode
import UCode.Data as Data exposing (Id)
import UCode.Model exposing (FirebaseUser)
import UCode.Firebase exposing (FirebaseApp)
import UCode.User as User exposing (UserWithId)


type alias FacebookLike =
    { userId : Id
    , likedBy : String
    , recordedAt : Int
    , recordedById : Id
    , recordedByName : String
    , ucoins : Int
    }


facebookLikeDecoder : Id -> Decoder FacebookLike
facebookLikeDecoder userId =
    Decode.map5 (FacebookLike userId)
        (Decode.field "likedBy" Decode.string)
        (Decode.field "recordedAt" Decode.int)
        (Decode.at [ "recordedBy", "userId" ] Decode.string)
        (Decode.at [ "recordedBy", "userName" ] Decode.string)
        (Decode.field "ucoins" Decode.int)


facebookLikeEncoder : String -> FirebaseUser -> Value
facebookLikeEncoder profileId manager =
    Encode.object
        [ ( "likedBy", Encode.string profileId )
        , ( "recordedAt", UCode.Firebase.serverTime )
        , ( "recordedBy"
          , Encode.object
                [ ( "userId", Encode.string manager.uid )
                , ( "userName", Encode.string manager.displayName )
                ]
          )
        ]


hasLikedTask : Id -> FirebaseApp -> Task String Bool
hasLikedTask id =
    UCode.Firebase.valueTask
        [ "facebookLikes", id ]
        (Decode.oneOf [ Decode.null False, Decode.succeed True ])


get : Id -> (Result String FacebookLike -> msg) -> FirebaseApp -> Cmd msg
get userId onFinish =
    UCode.Firebase.valueTask
        [ "facebookLikes", userId ]
        (facebookLikeDecoder userId)
        >> Task.attempt onFinish


create : String -> String -> FirebaseUser -> (Result String () -> msg) -> FirebaseApp -> Cmd msg
create userEmail profileId manager onFinish app =
    User.validateEmail userEmail app
        |> Task.andThen
            (\user ->
                hasLikedTask user.id app
                    |> Task.mapError (\error -> "Failed to check if \"" ++ userEmail ++ "\" has liked us: " ++ error)
                    |> Task.andThen
                        (\hasLikedUcode ->
                            if hasLikedUcode then
                                Task.fail <| "\"" ++ userEmail ++ "\" has already liked us"
                            else
                                Task.succeed user
                        )
            )
        |> Task.andThen
            (\user ->
                UCode.Firebase.setTask
                    [ "facebookLikes", user.id ]
                    (facebookLikeEncoder profileId manager)
                    app
            )
        |> Task.attempt onFinish
