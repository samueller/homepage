import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

mockdatabase.set({
  a: {
    b: {
      c: 'test1'
    }
  }
})

const db = proxyquire('../../utils/db', { 'firebase-admin': adminMock })

// ServerValue

test('exposes server values', t => {
  t.truthy(db.ServerValue)
})

// ref

test('ref returns a database reference', t => {
  const ref = db.ref('a', 'b', 'c')
  t.is(ref.constructor.name, 'MockFirebase')
  t.is(ref.path, 'Mock://a/b/c')
})

// exists

test('exists checks if there is a value at the given path', async t => {
  const result1 = await db.exists('a', 'b', 'c')
  t.true(result1)
  const result2 = await db.exists('doesnotexist')
  t.false(result2)
})

// value

test('value fetchs an existing value', async t => {
  t.is(await db.value('a', 'b', 'c'), 'test1')
})

// valueOrReject

test('valueOrReject fetches an existing value', async t => {
  const result = await db.valueOrReject('a', 'b', 'c')
  t.is(result, 'test1')
})

test('valueOrReject rejects for null values', t => {
  return t.throws(
    db.valueOrReject('doesnotexist'),
    { message: 'Expected value at doesnotexist but got null' }
  )
})

// valueOf

test('valueOf fetches the value from the given reference', async t => {
  const result = await db.valueOf(db.ref('a', 'b', 'c'))
  t.is(result, 'test1')
})
