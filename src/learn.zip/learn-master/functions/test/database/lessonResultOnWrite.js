import test from 'ava'
import proxyquire from 'proxyquire'
import testData from '../_data.js'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const lessonResultOnWrite =
  proxyquire(
    '../../database/lessonResultOnWrite',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

test.beforeEach(t => {
  mockdatabase.set(
    Object.assign(
      {
        students: {
          testUserId: {
            currentLessonId: 'lesson-1',
            centerId: 'center-1'
          }
        },
        lessonResults: {
          testUserId: {
            'lesson-1': {
              timestamp: 1234,
              instructor: 'testUserId'
            },
            'lesson-2': {
              timestamp: 1235,
              instructor: 'testUserId'
            }
          }
        }
      },
      testData
    )
  )
})

// CHECK CHAPTER COMPLETION

test('checkChapterCompletion caches chapter completions', async t => {
  await lessonResultOnWrite._test.checkChapterCompletion(
    { userId: 'testUserId', lessonId: 'lesson-2' },
    { timestamp: 1235, instructor: 'testUserId' }
  )
  const completion = mockdatabase.getData().chapterCompletions.testUserId['chapter-1']
  t.deepEqual(
    completion,
    {
      milestoneId: 'milestone-1',
      completedAt: completion.completedAt,
      numberAndName: '1.1 g',
      ucoins: 100
    }
  )
})

test('checkChapterCompletion does not override previous completions', async t => {
  mockdatabase.child('chapterCompletions/testUserId/chapter-1')
    .set({
      milestoneId: 'milestone-1',
      completedAt: 1,
      numberAndName: '1.1 g',
      ucoins: 100
    })
  await lessonResultOnWrite._test.checkChapterCompletion(
    { userId: 'testUserId', lessonId: 'lesson-2' },
    { timestamp: 1235, instructor: 'testUserId' }
  )
  t.deepEqual(
    mockdatabase.getData().chapterCompletions.testUserId['chapter-1'],
    {
      milestoneId: 'milestone-1',
      completedAt: 1,
      numberAndName: '1.1 g',
      ucoins: 100
    }
  )
})

test('checkChapterCompletion does nothing when the full chapter was not completed', async t => {
  await lessonResultOnWrite._test.checkChapterCompletion(
    { userId: 'testUserId', lessonId: 'lesson-3' },
    { timestamp: 1235, instructor: 'testUserId' }
  )
  t.falsy(mockdatabase.getData().chapterCompletions.testUserId['chapter-2'])
})

// CHECK CURRENT LESSON

// TODO checkCurrentLesson uses .orderBy* methods but firebase-mock does not support them
test.todo('checkCurrentLesson increments to the next lesson')

// CACHE BY INSTRUCTOR

test('cacheByInstructor inserts a copy into instructorLessonResults', async t => {
  await lessonResultOnWrite._test.cacheByInstructor(
    { userId: 'testUserId', lessonId: 'lesson-1' },
    { timestamp: 1234, instructor: 'testUserId' }
  )
  const results = mockdatabase.getData().instructorLessonResults.testUserId
  t.is(Object.keys(results).length, 1)
  const id = Object.keys(results)[0]
  t.deepEqual(
    results[id],
    {
      studentId: 'testUserId',
      lessonId: 'lesson-1',
      centerId: 'center-1',
      timestamp: 1234
    }
  )
})
