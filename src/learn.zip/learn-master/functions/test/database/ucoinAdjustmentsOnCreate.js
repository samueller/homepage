import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const ucoinAdjustmentsOnCreate =
  proxyquire(
    '../../database/ucoinAdjustmentsOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CREATE CHAPTER COMPLETION TRANSACTION

test('createUcoinAdjustmentTransaction creates a valid transaction', async t => {
  await ucoinAdjustmentsOnCreate._test.createUcoinAdjustmentTransaction(
    { userId: 'testUserId', adjustmentId: 'adjustment-1' },
    {
      reason: 'test',
      adjustedBy: {
        userId: 'user-1',
        userName: 'User 1'
      },
      adjustedAt: 0,
      ucoins: 1234
    }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'ucoinAdjustments',
          reasonId: 'adjustment-1',
          change: 1234,
          timestamp:
            ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})
