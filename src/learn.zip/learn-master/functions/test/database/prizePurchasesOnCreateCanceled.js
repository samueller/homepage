import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const prizePurchasesOnCreateCanceled =
  proxyquire(
    '../../database/prizePurchasesOnCreateCanceled',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

test.serial('cancelPurchase creates refund transaction', async t => {
  mockdatabase.set({
    prizePurchases: {
      'user-1': {
        'purchase-1': {
          cost: 100
        }
      }
    }
  })
  await prizePurchasesOnCreateCanceled._test.cancelPurchase(
    { userId: 'user-1', purchaseId: 'purchase-1' }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory,
    {
      'user-1': {
        nextTransactionId: 1,
        transactions: [{
          reason: 'prizeRefund',
          reasonId: 'purchase-1',
          change: 100,
          timestamp: ucoinTransactionHistory['user-1'].transactions[0].timestamp
        }]
      }
    }
  )
})

test.serial('cancelPurchase deletes pending purchase', async t => {
  mockdatabase.set({
    prizePurchases: {
      'user-1': {
        'purchase-1': {
          cost: 100
        }
      }
    },
    students: {
      'user-1': {
        centerId: 'center-1'
      }
    },
    pendingCenterPurchases: {
      'center-1': {
        'purchase-1': {
          userName: 'User 1',
          userId: 'user-1',
          prizeName: 'Prize 1'
        }
      }
    }
  })
  await prizePurchasesOnCreateCanceled._test.cancelPurchase(
    { userId: 'user-1', purchaseId: 'purchase-1' }
  )
  const { ucoinTransactionHistory, pendingCenterPurchases } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory,
    {
      'user-1': {
        nextTransactionId: 1,
        transactions: [{
          reason: 'prizeRefund',
          reasonId: 'purchase-1',
          change: 100,
          timestamp: ucoinTransactionHistory['user-1'].transactions[0].timestamp
        }]
      }
    }
  )
  t.falsy(pendingCenterPurchases)
})
