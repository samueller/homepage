module Page.Video exposing (main)

import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Html exposing (..)
import Html.Attributes exposing (..)
import Json.Decode as Decode
import Json.Encode as Encode
import Material.Grid as Grid
import Task
import Types.Activity as Activity
import Types.Chapter as Chapter
import Types.Instruction as Instruction
import Types.Lesson as Lesson
import Types.Milestone as Milestone
import Types.Video as Video
import UCode.Browser as Browser
import UCode.Data as Data
import UCode.Firebase
import UCode.Model
import UCode.Msg
import UCode.Users as Users
import UCode.View as View
import Util.Heading as Heading


main : Program UCode.Model.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUserAndCmd SharedMsg initialModel initialCmds
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialCmds : UCode.Model.SharedModelFirebaseUser -> Cmd Msg
initialCmds sharedModel =
    Data.foldMaybe
        Cmd.none
        (Activity.setScore sharedModel.user.uid (Browser.queryParam "activity") 100.0
            >> Task.attempt Scored
        )
        sharedModel.firebaseApp


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , lessonId : Data.Id
    , lessonResult : Maybe Lesson.Result
    , activityId : Data.Id
    , activity : Maybe Activity.Activity
    , nextActivityId : Maybe Data.Id
    , nextActivity : Maybe Activity.Activity
    , nextLessonId : Maybe Data.Id
    , nextLesson : Maybe Lesson.Lesson
    , nextLessonActivityId : Maybe Data.Id
    , nextLessonActivity : Maybe Activity.Activity
    , id : Data.Id
    , video : Maybe Video.Video
    , sharedModel : UCode.Model.SharedModelFirebaseUser
    }


initialModel : UCode.Model.SharedModelFirebaseUser -> Model
initialModel =
    Model
        Nothing
        Nothing
        Nothing
        (Browser.queryParam "lesson")
        Nothing
        (Browser.queryParam "activity")
        Nothing
        Nothing
        Nothing
        Nothing
        Nothing
        Nothing
        Nothing
        Browser.queryId
        Nothing


type Msg
    = SharedMsg UCode.Msg.Msg
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | ChangedLessonResult Types.Snapshot
    | ChangedVideo Types.Snapshot
    | Scored (Result String ())
    | ChangedActivity Types.Snapshot
    | ChangedNextActivity Types.Snapshot
    | ChangedNextLesson Types.Snapshot
    | ChangedNextLessonActivity Types.Snapshot


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedLessonResult snapshot ->
            Lesson.recordMaybeLessonResultSnapshot model snapshot ! []

        ChangedVideo snapshot ->
            Video.recordUpdatedFromSnapshotValue model snapshot ! []

        Scored _ ->
            model ! []

        ChangedActivity snapshot ->
            case Decode.decodeValue Activity.decoder (Snapshot.value snapshot) of
                Ok activity ->
                    { model | activity = Just activity } ! []

                Err _ ->
                    { model | activity = Nothing } ! []

        ChangedNextActivity snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Activity.decoder) (Snapshot.value snapshot) of
                Ok (( activityId, activity ) :: _) ->
                    { model
                        | nextActivityId = Just activityId
                        , nextActivity = Just activity
                    }
                        ! []

                _ ->
                    { model
                        | nextActivityId = Nothing
                        , nextActivity = Nothing
                    }
                        ! []

        ChangedNextLesson snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Decode.int) (Snapshot.value snapshot) of
                Ok (( lessonId, number ) :: _) ->
                    { model | nextLessonId = Just lessonId } ! []

                _ ->
                    { model | nextLessonId = Nothing } ! []

        ChangedNextLessonActivity snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Activity.decoder) (Snapshot.value snapshot) of
                Ok (( activityId, activity ) :: _) ->
                    { model
                        | nextLessonActivityId = Just activityId
                        , nextLessonActivity = Just activity
                    }
                        ! []

                _ ->
                    { model
                        | nextLessonActivityId = Nothing
                        , nextLessonActivity = Nothing
                    }
                        ! []

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model


nextLink : Model -> Maybe String
nextLink model =
    case ( model.nextActivityId, model.nextActivity, model.nextLessonId, model.nextLessonActivityId, model.nextLessonActivity ) of
        ( Just nextActivityId, Just nextActivity, _, _, _ ) ->
            Just (Activity.href nextActivity nextActivityId model.lessonId)

        ( _, _, Just nextLessonId, Just nextActivityId, Just nextActivity ) ->
            Just (Activity.href nextActivity nextActivityId nextLessonId)

        _ ->
            Nothing


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        (case model.video of
            Nothing ->
                [ View.fullWidthCell [ View.spinner ] ]

            Just video ->
                [ View.fullWidthCell
                    [ div [ class "video__header" ]
                        [ Heading.viewActivityHeadingHtml model ""
                        , View.activityActions
                            [ View.buttonLink model SharedMsg (nextLink model) [ 0 ] [ text "Next" ] ]
                        ]
                    ]
                , View.fullWidthCell
                    [ View.youtubeEmbed video.videoId
                    , Instruction.div video.content
                    ]
                ]
        )
    ]


activitySubs : Model -> UCode.Firebase.FirebaseApp -> Activity.Activity -> Sub Msg
activitySubs model firebase activity =
    UCode.Firebase.valuesByChildSubscription ChangedNextActivity ("activities/" ++ model.lessonId) "number" firebase (Encode.int (activity.number + 1))


nextLessonActivitySubs : Model -> UCode.Firebase.FirebaseApp -> Data.Id -> Sub Msg
nextLessonActivitySubs model firebase nextLessonId =
    UCode.Firebase.valuesByChildSubscription ChangedNextLessonActivity ("activities/" ++ nextLessonId) "number" firebase (Encode.int 1)


nextLessonSubs : Model -> UCode.Firebase.FirebaseApp -> Lesson.Result -> Lesson.Lesson -> Sub Msg
nextLessonSubs model firebase lessonResult lesson =
    UCode.Firebase.valuesByChildValueSubscription ChangedNextLesson ("lessonNumbers/" ++ lesson.chapterId) firebase (Encode.int (lesson.number + 1))


firebaseSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ UCode.Firebase.idSubscription "videos" firebase ChangedVideo model.id
        , UCode.Firebase.idSubscription ("lessonResults/" ++ model.sharedModel.user.uid) firebase ChangedLessonResult model.lessonId
        , UCode.Firebase.idSubscription ("activities/" ++ model.lessonId) firebase ChangedActivity model.activityId
        , Data.foldMaybe Sub.none (activitySubs model firebase) model.activity
        , Data.foldMaybe Sub.none (nextLessonActivitySubs model firebase) model.nextLessonId
        , Data.fold2Maybes Sub.none (nextLessonSubs model firebase) model.lessonResult model.lesson
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        , Data.foldMaybe Sub.none (firebaseSubs model) model.sharedModel.firebaseApp
        ]
