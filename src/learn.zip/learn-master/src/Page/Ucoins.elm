module Page.Ucoins exposing (main)

import Html exposing (..)
import Html.Attributes exposing (..)
import Dict exposing (Dict)
import List.Extra
import Material.Options as Options exposing (css)
import Material.Dialog as Dialog
import Material.Button as Button
import Material.Icon as Icon
import RemoteData
import Types.Manager as Manager
import Types.UcoinTransaction as UcoinTransaction exposing (TransactionType(..))
import Types.Instructor as Instructor
import Types.Student as Student exposing (Student)
import UCode.Browser as Browser
import UCode.Data as Data exposing (Id)
import UCode.Firebase as UFirebase
import UCode.Model as UModel
import UCode.Msg as UMsg
import UCode.Sub as USub
import UCode.Users as Users
import UCode.User as User exposing (UserWithId)
import UCode.View as View
import Util.Firebase.Auth as Auth
import View.Card
import View.Dialog
import View.Table


main : Program UModel.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.init SharedMsg init
        , view = View.viewWithDialog SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }



-- MODEL


type alias RemoteData a =
    RemoteData.RemoteData String a


type alias Model =
    { sharedModel : UModel.SharedModelFirebaseUser
    , paramUserId : Maybe Id
    , user : RemoteData UserWithId
    , isManager : RemoteData Bool
    , isInstructor : RemoteData Bool
    , transactions : RemoteData UcoinTransaction.History
    , transactionDetails : Dict Int (RemoteData UcoinTransaction.TransactionType)
    , showingDetails : Maybe Int
    , student : RemoteData Student
    }


init : UModel.SharedModelFirebaseUser -> ( Model, Cmd Msg )
init sharedModel =
    let
        model =
            { sharedModel = sharedModel
            , paramUserId = Browser.queryParamMaybe "user"
            , user = RemoteData.NotAsked
            , isManager = RemoteData.Loading
            , isInstructor = RemoteData.Loading
            , transactions = RemoteData.NotAsked
            , transactionDetails = Dict.empty
            , showingDetails = Nothing
            , student = RemoteData.NotAsked
            }
    in
        fetchDataIfCanView model



-- UPDATE


viewingSelf : Model -> Bool
viewingSelf model =
    model.paramUserId
        == Nothing
        || Just model.sharedModel.user.uid
        == model.paramUserId


canView : Model -> Bool
canView model =
    viewingSelf model
        || RemoteData.withDefault False model.isInstructor
        || RemoteData.withDefault False model.isManager


fetchDataIfCanView : Model -> ( Model, Cmd Msg )
fetchDataIfCanView model =
    if canView model then
        let
            userId =
                Maybe.withDefault
                    model.sharedModel.user.uid
                    model.paramUserId
        in
            ( { model
                | user = RemoteData.Loading
                , transactions = RemoteData.Loading
              }
            , Data.batchWithMaybe
                model.sharedModel.firebaseApp
                [ User.getWithId userId GotUser
                , UcoinTransaction.getHistory userId GotHistory
                ]
            )
    else
        model ! []


fetchDetails : Int -> Model -> ( Model, Cmd Msg )
fetchDetails transactionId model =
    let
        userId =
            Maybe.withDefault
                model.sharedModel.user.uid
                model.paramUserId

        maybeTransaction =
            RemoteData.toMaybe model.transactions
                |> Maybe.andThen
                    (.transactions
                        >> List.Extra.find (\{ id } -> id == transactionId)
                    )
    in
        case maybeTransaction of
            Just transaction ->
                ( { model
                    | transactionDetails =
                        Dict.insert transactionId RemoteData.Loading model.transactionDetails
                  }
                , Data.batchWithMaybe
                    model.sharedModel.firebaseApp
                    [ UcoinTransaction.getDetailsByReason
                        userId
                        transaction.reason
                        (GotTransactionDetails transactionId)
                    ]
                )

            Nothing ->
                model ! []


type Msg
    = SharedMsg UMsg.Msg
    | ChangedIsManager (Result String Bool)
    | ChangedIsInstructor (Result String Bool)
    | GotUser (Result String UserWithId)
    | GotHistory (Result String UcoinTransaction.History)
    | GotTransactionDetails Int (Result String UcoinTransaction.TransactionType)
    | ShowDetails Int
    | CloseShowDetails
    | AuthStateChanged (Maybe UModel.FirebaseUser)
    | GotStudent (Result String Student)


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        SharedMsg msg_ ->
            UModel.update SharedMsg msg_ model

        ChangedIsManager result ->
            { model | isManager = RemoteData.fromResult result }
                |> fetchDataIfCanView

        ChangedIsInstructor result ->
            { model | isInstructor = RemoteData.fromResult result }
                |> fetchDataIfCanView

        GotUser result ->
            { model | user = RemoteData.fromResult result } ! []

        GotHistory result ->
            let
                _ =
                    case result of
                        Ok _ ->
                            ""

                        Err error ->
                            Debug.log "Error loading history" error
            in
                { model
                    | transactions =
                        result
                            |> Result.map
                                (\history ->
                                    { history
                                        | transactions = List.reverse history.transactions
                                    }
                                )
                            |> RemoteData.fromResult
                }
                    ! []

        GotTransactionDetails transactionId result ->
            { model
                | transactionDetails =
                    Dict.insert
                        transactionId
                        (RemoteData.fromResult result)
                        model.transactionDetails
            }
                ! []

        ShowDetails transactionId ->
            { model | showingDetails = Just transactionId }
                |> fetchDetails transactionId

        CloseShowDetails ->
            { model | showingDetails = Nothing } ! []

        AuthStateChanged maybeUser ->
            let
                sharedModel =
                    model.sharedModel

                ( student, cmd ) =
                    case maybeUser of
                        Just user ->
                            ( RemoteData.Loading
                            , Student.get
                                user.uid
                                GotStudent
                                model.sharedModel.firebaseApp
                            )

                        Nothing ->
                            ( model.student, Cmd.none )
            in
                { model
                    | student = student
                }
                    ! [ cmd ]

        GotStudent result ->
            { model | student = RemoteData.fromResult result } ! []



-- SUBSCRIPTIONS


firebaseSubs : Model -> UFirebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    let
        uid =
            model.sharedModel.user.uid
    in
        Sub.batch
            (if viewingSelf model then
                []
             else
                [ Manager.subIsManager uid ChangedIsManager firebase
                , Instructor.subIsInstructor uid ChangedIsInstructor firebase
                ]
            )


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , USub.firebaseSubs model firebaseSubs
        , Auth.onAuthStateChanged AuthStateChanged
        ]



-- VIEW


viewLoading : Html Msg
viewLoading =
    div [] [ h1 [] [ text "Loading...", View.spinner ] ]


viewError : String -> String -> Html Msg
viewError action error =
    div []
        [ h1 [] [ text <| "Something went wrong while " ++ action ]
        , h3 [] [ text error ]
        ]


viewMissingPermission : String -> Html Msg
viewMissingPermission action =
    div []
        [ h1 [] [ text "Access Denied" ]
        , h3 [] [ text <| "You don't have permission to " ++ action ]
        ]


viewUcoinCount : Bool -> UserWithId -> Html Msg
viewUcoinCount isViewingSelf user =
    div []
        [ h3 [ style [ ( "margin-bottom", "10px" ) ] ]
            [ text <|
                if isViewingSelf then
                    "You have "
                else
                    user.name ++ " has "
            ]
        , h1 [ style [ ( "margin", "0 0 10px" ) ] ] [ text <| toString user.ucoins ]
        , h3 [ style [ ( "margin-bottom", "40px" ) ] ]
            [ text <|
                " UCoin"
                    ++ (if user.ucoins == 1 then
                            ""
                        else
                            "s"
                       )
            ]
        ]


viewTransactionAmount : Int -> Html Msg
viewTransactionAmount amount =
    if amount > 0 then
        text <| "+" ++ toString amount
    else
        text <| toString amount


viewTransaction : UcoinTransaction.Transaction -> Html Msg
viewTransaction transaction =
    Options.div
        [ Options.cs "--interactive"
        , css "display" "flex"
        , css "justify-content" "space-between"
        , Options.onClick (ShowDetails transaction.id)
        , Dialog.openOn "click"
        ]
        [ span [] [ text <| Data.formatDateTime transaction.timestamp ]
        , span [] [ viewTransactionAmount transaction.change ]
        ]


viewTransactions : Bool -> RemoteData UcoinTransaction.History -> Html Msg
viewTransactions isViewingSelf remoteHistory =
    View.Card.withMaxWidth
        "UCoin History"
        400
        (case remoteHistory of
            RemoteData.NotAsked ->
                viewLoading

            RemoteData.Loading ->
                viewLoading

            RemoteData.Failure _ ->
                text <| "Something went wrong while loading UCoin history"

            RemoteData.Success history ->
                if List.length history.transactions == 0 then
                    span [] [ text "No UCoin rewards or purchases" ]
                else
                    div [] <| List.map viewTransaction history.transactions
        )


centerFacebookLinks : Dict Id String
centerFacebookLinks =
    Dict.fromList
        [ ( "-KtjlfGV36IexsIAAimB", "https://www.facebook.com/ucodehermosabeach" )
        , ( "-Ktjln0aJIwG2e2NlGpd", "https://www.facebook.com/ucodetorrance" )
        , ( "-Ktjlh_BxFle4SJ3nBAT", "https://www.facebook.com/ucodetustin" )
        , ( "-KtjmHvOs9vBs_cFhKsU", "https://www.facebook.com/ucodeLaCanada" )
        , ( "-Ktjmrci8abcJ1hKZ8Kw", "https://www.facebook.com/ucodecom" )
        ]


centerTwitterLinks : Dict Id String
centerTwitterLinks =
    Dict.fromList
        [ ( "-KtjlfGV36IexsIAAimB", "https://twitter.com/ucodehb" )
        , ( "-Ktjln0aJIwG2e2NlGpd", "https://twitter.com/ucodetorrance" )
        , ( "-Ktjlh_BxFle4SJ3nBAT", "https://twitter.com/ucodetustin" )
        , ( "-KtjmHvOs9vBs_cFhKsU", "https://twitter.com/ucodelacanada" )
        ]


centerYelpLinks : Dict Id String
centerYelpLinks =
    Dict.fromList
        [ ( "-KtjlfGV36IexsIAAimB", "https://www.yelp.com/biz/ucode-hermosa-beach-hermosa-beach" )
        , ( "-Ktjln0aJIwG2e2NlGpd", "https://www.yelp.com/biz/ucode-torrance-2" )
        , ( "-Ktjlh_BxFle4SJ3nBAT", "https://www.yelp.com/biz/ucode-la-ca%C3%B1ada-flintridge-2" )
        , ( "-KtjmHvOs9vBs_cFhKsU", "https://www.yelp.com/biz/ucode-tustin-tustin" )
        ]


centeredText : Html.Attribute msg
centeredText =
    style [ ( "text-align", "center" ) ]


likeOnFacebookInfo : Html msg
likeOnFacebookInfo =
    Icon.view
        "help_outline"
        [ Options.css "cursor" "help"
        , Options.css "font-size" "18px"
        , Options.attribute (title "Send your parent's Facebook profile page URL to your instructor to verify")
        ]


viewCenterLink : String -> String -> Html msg
viewCenterLink content link =
    a [ href link ] [ text content ]


viewMaybeCenterLink : Dict Id String -> String -> Maybe Id -> Html msg
viewMaybeCenterLink links content maybeId =
    maybeId
        |> Maybe.andThen (\id -> Dict.get id links)
        |> Maybe.map (viewCenterLink content)
        |> Maybe.withDefault (text content)


viewEarning : Model -> Html Msg
viewEarning model =
    let
        centerFacebookLink =
            RemoteData.toMaybe model.student
                |> Maybe.map .centerId
                |> viewMaybeCenterLink centerFacebookLinks "Facebook"

        centerTwitterLink =
            RemoteData.toMaybe model.student
                |> Maybe.map .centerId
                |> viewMaybeCenterLink centerTwitterLinks "Twitter"

        centerYelpLink =
            RemoteData.toMaybe model.student
                |> Maybe.map .centerId
                |> viewMaybeCenterLink centerYelpLinks "Yelp review"

        rewards =
            [ ( [ text "Parents like UCode on "
                , centerFacebookLink
                , likeOnFacebookInfo
                ]
              , 350
              )
            , ( [ text "Parents share our events on ", centerFacebookLink ]
              , 50
              )
            , ( [ text "Refer a friend for classes" ], 10000 )
            , ( [ text "Refer a friend for a workshop or event" ], 2000 )
            , ( [ text "Complete a chapter" ], 100 )
            , ( [ text "Complete a milestone" ], 2000 )
            , ( [ text "Complete UType" ], 200 )
            , ( [ text "Parents follow UCode on ", centerTwitterLink ], 50 )
            , ( [ text "Parents write a positive ", centerYelpLink ], 500 )
            , ( [ text "Parents write a testimonial that we publish on our website" ], 500 )
            , ( [ text "Student writes a testimonial that we publish on our website" ], 500 )
            ]
    in
        div []
            [ h1 [ centeredText ] [ text "How to earn UCoins" ]
            , View.Table.basic [ Options.css "margin" "0 auto 20px" ]
                [ View.Table.columnCustom "Action" (Tuple.first >> span []) False
                , View.Table.columnNumeric "UCoins" Tuple.second
                ]
                rewards
            ]


viewMainWithPermission : Model -> Html Msg
viewMainWithPermission model =
    case model.user of
        RemoteData.NotAsked ->
            viewLoading

        RemoteData.Loading ->
            viewLoading

        RemoteData.Failure error ->
            viewError "loading your account" error

        RemoteData.Success user ->
            div []
                [ viewEarning model
                , viewUcoinCount (viewingSelf model) user
                , viewTransactions (viewingSelf model) model.transactions
                , div [ style [ ( "margin-top", "20px" ) ] ]
                    [ Button.render (SharedMsg << UMsg.Mdl)
                        [ 0 ]
                        model.sharedModel.mdl
                        [ Button.ripple
                        , Button.colored
                        , Button.raised
                        , Button.link "/prizes.html"
                        ]
                        [ text "Prizes" ]
                    ]
                ]


viewMain : Model -> List (Html Msg)
viewMain model =
    [ if viewingSelf model then
        viewMainWithPermission model
      else
        let
            remoteCanView =
                RemoteData.map2 (||) model.isInstructor model.isManager
        in
            case remoteCanView of
                RemoteData.NotAsked ->
                    -- We should never be here
                    viewLoading

                RemoteData.Loading ->
                    viewLoading

                RemoteData.Failure error ->
                    viewError "checking your permissions" error

                RemoteData.Success canView ->
                    if canView then
                        viewMainWithPermission model
                    else
                        viewMissingPermission "view someone else's UCoins"
    ]


viewContainer : List (Html Msg) -> Html Msg
viewContainer =
    div
        [ style
            [ ( "max-width", "1200px" )
            , ( "margin", "0 auto 100px" )
            , ( "text-align", "center" )
            ]
        ]


viewTransactionTimestamp : Int -> Html Msg
viewTransactionTimestamp timestamp =
    Options.span [ css "font-size" "0.8em", css "color" "gray" ]
        [ text <| Data.formatDateTime timestamp ]


viewReferredBy : Dict Id String -> String
viewReferredBy referredBy =
    case Dict.values referredBy of
        name :: [] ->
            name

        name :: otherNames ->
            String.join ", " (name :: otherNames)

        [] ->
            "(no referrers listed)"


viewUcoinsReceived : Int -> Int -> String
viewUcoinsReceived total referrers =
    toString (ceiling (toFloat total / toFloat referrers))


viewTransactionDetailsType :
    UcoinTransaction.Transaction
    -> UcoinTransaction.TransactionType
    -> List (Html Msg)
viewTransactionDetailsType transaction transactionType =
    (case transactionType of
        MilestoneCompletion milestoneCompletion ->
            ( milestoneCompletion.completedAt
            , [ "Reason: Completed milestone"
              , "Milestone: " ++ milestoneCompletion.numberAndName
              , "UCoins Received: " ++ toString milestoneCompletion.ucoins
              ]
            )

        ChapterCompletion chapterCompletion ->
            ( chapterCompletion.completedAt
            , [ "Reason: Completed chapter"
              , "Chapter: " ++ chapterCompletion.numberAndName
              , "UCoins Received: " ++ toString chapterCompletion.ucoins
              ]
            )

        PrizePurchase prizePurchase ->
            ( prizePurchase.purchasedAt
            , [ "Reason: Purchased prize"
              , "Prize Name: " ++ prizePurchase.prizeName
              , "Cost: " ++ toString prizePurchase.cost
              ]
            )

        PrizeRefund canceledAt prizePurchase ->
            ( canceledAt
            , [ "Reason: Prize refund"
              , "Prize Name: " ++ prizePurchase.prizeName
              , "Cost: " ++ toString prizePurchase.cost
              ]
            )

        Referral referral ->
            ( referral.recordedAt
            , [ "Reason: Referral"
              , "Referred: " ++ referral.referredName
              , "Referred By: " ++ viewReferredBy referral.referredBy
              , "UCoins Received: "
                    ++ viewUcoinsReceived
                        referral.ucoins
                        (Dict.size referral.referredBy)
              ]
            )

        WorkshopReferral workshopReferral ->
            ( workshopReferral.recordedAt
            , [ "Reason: Workshop referral"
              , "Referred: (external ID)"
              , "Referred By: " ++ viewReferredBy workshopReferral.referredBy
              , "UCoins Received: "
                    ++ viewUcoinsReceived
                        workshopReferral.ucoins
                        (Dict.size workshopReferral.referredBy)
              ]
            )

        FacebookLike facebookLike ->
            ( facebookLike.recordedAt
            , [ "Reason: Facebook like"
              , "UCoins Received: " ++ toString facebookLike.ucoins
              ]
            )

        FacebookWorkshopShare share ->
            ( share.recordedAt
            , [ "Reason: Facebook Event Share"
              , "UCoins Received: " ++ toString share.ucoins
              ]
            )

        Adjustment ucoinAdjustment ->
            ( ucoinAdjustment.adjustedAt
            , [ "Reason: " ++ ucoinAdjustment.reason
              , "UCoins: " ++ toString ucoinAdjustment.ucoins
              ]
            )

        SurveyCompletion ->
            ( transaction.timestamp
            , [ "Reason: Survey completion"
              , "UCoins Received: " ++ toString transaction.change
              ]
            )

        UtypeCompletion ->
            ( transaction.timestamp
            , [ "Reason: UType completion"
              , "UCoins Received: " ++ toString transaction.change
              ]
            )

        TwitterFollow ->
            ( transaction.timestamp
            , [ "Reason: Twitter follow"
              , "UCoins Received: " ++ toString transaction.change
              ]
            )

        YelpReview ->
            ( transaction.timestamp
            , [ "Reason: Yelp review"
              , "UCoins Received: " ++ toString transaction.change
              ]
            )

        ParentTestimonial ->
            ( transaction.timestamp
            , [ "Reason: Parent testimonial"
              , "UCoins Received: " ++ toString transaction.change
              ]
            )

        StudentTestimonial ->
            ( transaction.timestamp
            , [ "Reason: Student testimonial"
              , "UCoins Received: " ++ toString transaction.change
              ]
            )
    )
        |> (\( timestamp, details ) ->
                [ viewTransactionTimestamp timestamp ]
                    ++ List.map
                        (\txt -> h4 [ style [ ( "margin", "0px" ) ] ] [ text txt ])
                        details
           )


viewTransactionDetails :
    UcoinTransaction.Transaction
    -> RemoteData UcoinTransaction.TransactionType
    -> List (Html Msg)
viewTransactionDetails transaction remoteTransaction =
    case remoteTransaction of
        RemoteData.NotAsked ->
            [ View.spinner ]

        RemoteData.Loading ->
            [ View.spinner ]

        RemoteData.Failure error ->
            [ text <| "Something went wrong while loading the transaction details: " ++ error ]

        RemoteData.Success transactionType ->
            viewTransactionDetailsType transaction transactionType


viewDialog : Model -> Html Msg
viewDialog model =
    case model.showingDetails of
        Just id ->
            let
                maybeTransaction =
                    RemoteData.toMaybe model.transactions
                        |> Maybe.andThen (.transactions >> List.Extra.getAt id)
            in
                case maybeTransaction of
                    Just transaction ->
                        View.Dialog.info
                            model
                            SharedMsg
                            [ 1 ]
                            "Details"
                            (Dict.get id model.transactionDetails
                                |> Maybe.withDefault (RemoteData.NotAsked)
                                |> viewTransactionDetails transaction
                            )
                            CloseShowDetails

                    Nothing ->
                        View.Dialog.info
                            model
                            SharedMsg
                            [ 1 ]
                            "Error"
                            [ text "This transaction doesn't seem to be loaded" ]
                            CloseShowDetails

        Nothing ->
            View.Dialog.empty


viewBody : Model -> ( List (Html Msg), Html Msg )
viewBody model =
    ( [ viewContainer <| viewMain model ]
    , viewDialog model
    )
