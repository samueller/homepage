const functions = require('firebase-functions')
const createTransaction = require('../utils/createTransaction')
const constants = require('../constants')

const createYelpReviewTransaction = ({ userId }) =>
  createTransaction(
    userId,
    'yelpReviews',
    null,
    false,
    constants.UCOIN_VALUES.YELP_REVIEW,
    `yelpReviews/${userId}/ucoins`
  )

module.exports =
  functions.database.ref('yelpReviews/{userId}')
    .onCreate((snap, context) =>
      createYelpReviewTransaction(context.params)
    )

module.exports._test = { createYelpReviewTransaction }
