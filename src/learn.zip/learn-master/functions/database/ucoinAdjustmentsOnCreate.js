const functions = require('firebase-functions')
const createTransaction = require('../utils/createTransaction')

const createUcoinAdjustmentTransaction = ({ userId, adjustmentId }, val) =>
  createTransaction(
    userId,
    'ucoinAdjustments',
    adjustmentId,
    false,
    val.ucoins,
    false
  )

module.exports =
  functions.database.ref('ucoinAdjustments/{userId}/{adjustmentId}')
    .onCreate((snap, context) =>
      createUcoinAdjustmentTransaction(context.params, snap.val())
    )

module.exports._test = { createUcoinAdjustmentTransaction }
