const functions = require('firebase-functions')
const createTransaction = require('../utils/createTransaction')
const constants = require('../constants')

const createStudentTestimonialsTransaction = ({ userId, testimonialId }) =>
  createTransaction(
    userId,
    'studentTestimonials',
    testimonialId,
    false,
    constants.UCOIN_VALUES.STUDENT_TESTIMONIAL,
    `studentTestimonials/${userId}/${testimonialId}/ucoins`
  )

module.exports =
  functions.database.ref('studentTestimonials/{userId}/{testimonialId}')
    .onCreate((snap, context) =>
      createStudentTestimonialsTransaction(context.params)
    )

module.exports._test = { createStudentTestimonialsTransaction }
