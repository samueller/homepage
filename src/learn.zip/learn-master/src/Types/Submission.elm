module Types.Submission exposing (..)

import Json.Encode as Encode
import Json.Decode as Decode exposing (Decoder, field)
import Task
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.Firebase
import UCode.Data as Data exposing (foldMaybe)
import UCode.Model exposing (WithSharedModel)
import Types.Activity as Activity


type alias SubmissionInstr =
    { id : Maybe String
    , instruction : String
    , rubric : String
    }


type alias Field =
    { id : Maybe String
    , name : String
    , lines : Int
    , number : Int
    }


type alias WithSubmissionInstr r =
    { r | submissionInstr : SubmissionInstr }


type alias WithMaybeSubmissionInstr r =
    { r | submissionInstr : Maybe SubmissionInstr }


type alias WithSubmissionInstrFields r =
    { r
        | instruction : String
        , rubric : String
    }


type alias WithFields r =
    { r | fields : List Field }


emptySubmissionInstr : SubmissionInstr
emptySubmissionInstr =
    SubmissionInstr Nothing "" ""


emptyField : Field
emptyField =
    Field Nothing "" 1 1


decoder : String -> Decoder SubmissionInstr
decoder id =
    Decode.map2 (SubmissionInstr (Just id))
        (Decode.field "instruction" Decode.string)
        (Decode.field "rubric" Decode.string)


fieldDecoder : String -> Decoder Field
fieldDecoder id =
    Decode.map3 (Field (Just id))
        (Decode.field "name" Decode.string)
        (Decode.field "lines" Decode.int)
        (Decode.field "number" Decode.int)


encoder : SubmissionInstr -> Encode.Value
encoder submission =
    fieldsEncoder submission.instruction submission.rubric


fieldsEncoder : String -> String -> Encode.Value
fieldsEncoder instruction rubric =
    Encode.object
        [ ( "instruction", Encode.string instruction )
        , ( "rubric", Encode.string rubric )
        ]


fieldEncoder : Field -> Encode.Value
fieldEncoder field =
    fieldFieldsEncoder field.name field.lines field.number


fieldFieldsEncoder : String -> Int -> Int -> Encode.Value
fieldFieldsEncoder name lines number =
    Encode.object
        [ ( "name", Encode.string name )
        , ( "lines", Encode.int lines )
        , ( "number", Encode.int number )
        ]


fieldWithName : Field -> String -> Field
fieldWithName field name =
    { field | name = name }


fieldWithLines : Field -> Int -> Field
fieldWithLines field lines =
    { field | lines = lines }


fieldWithNumber : Field -> Int -> Field
fieldWithNumber field number =
    { field | number = number }


recordWithJustSubmissionInstr : WithMaybeSubmissionInstr r -> SubmissionInstr -> WithMaybeSubmissionInstr r
recordWithJustSubmissionInstr record submissionInstr =
    { record | submissionInstr = Just submissionInstr }


recordWithMaybeSubmissionInstrTransformed : WithMaybeSubmissionInstr r -> (SubmissionInstr -> SubmissionInstr) -> WithMaybeSubmissionInstr r
recordWithMaybeSubmissionInstrTransformed record transform =
    { record | submissionInstr = Maybe.map transform record.submissionInstr }


recordWithAddedFieldSorted : WithFields r -> Field -> WithFields r
recordWithAddedFieldSorted record field =
    { record | fields = Data.listWithAddedObjectSorted field record.fields }


recordWithChangedFieldSorted : WithFields r -> Field -> WithFields r
recordWithChangedFieldSorted record field =
    { record | fields = Data.listWithReplacedObjectMaybeIdSorted field record.fields }


recordWithRemovedField : WithFields r -> Field -> WithFields r
recordWithRemovedField record field =
    { record | fields = Data.listWithRemovedObjectMaybeId field record.fields }


recordWithJustSubmissionInstrSnapshot : WithMaybeSubmissionInstr r -> Types.Snapshot -> WithMaybeSubmissionInstr r
recordWithJustSubmissionInstrSnapshot record =
    Data.recordWithSnapshot record (recordWithJustSubmissionInstr record) decoder


recordWithAddedFieldSnapshot : WithFields r -> Types.Snapshot -> WithFields r
recordWithAddedFieldSnapshot record =
    Data.recordWithSnapshot
        record
        (recordWithAddedFieldSorted record)
        fieldDecoder


recordWithChangedFieldSnapshot : WithFields r -> Types.Snapshot -> WithFields r
recordWithChangedFieldSnapshot record =
    Data.recordWithSnapshot
        record
        (recordWithChangedFieldSorted record)
        fieldDecoder


recordWithRemovedFieldSnapshot : WithFields r -> Types.Snapshot -> WithFields r
recordWithRemovedFieldSnapshot record =
    Data.recordWithSnapshot
        record
        (recordWithRemovedField record)
        fieldDecoder


submissionInstrWithInstruction : String -> SubmissionInstr -> SubmissionInstr
submissionInstrWithInstruction instruction submissionInstr =
    { submissionInstr | instruction = instruction }


submissionInstrWithRubric : String -> SubmissionInstr -> SubmissionInstr
submissionInstrWithRubric rubric submissionInstr =
    { submissionInstr | rubric = rubric }


recordWithMaybeSubmissionInstrInstruction : WithMaybeSubmissionInstr r -> String -> WithMaybeSubmissionInstr r
recordWithMaybeSubmissionInstrInstruction record =
    recordWithMaybeSubmissionInstrTransformed record << submissionInstrWithInstruction


recordWithMaybeSubmissionInstrRubric : WithMaybeSubmissionInstr r -> String -> WithMaybeSubmissionInstr r
recordWithMaybeSubmissionInstrRubric record =
    recordWithMaybeSubmissionInstrTransformed record << submissionInstrWithRubric


updateFieldNumber : (Result Firebase.Errors.Error () -> msg) -> WithSharedModel model a -> Maybe SubmissionInstr -> Maybe String -> Int -> Cmd msg
updateFieldNumber updatedMsg model submissionInstr fieldId number =
    Data.fold2Maybes
        Cmd.none
        (\submissionInstr fieldId ->
            Data.foldMaybe
                Cmd.none
                (\submissionInstrId ->
                    UCode.Firebase.updateValueMaybe
                        updatedMsg
                        ("submissionFields/" ++ submissionInstrId ++ "/" ++ fieldId)
                        (Encode.object [ ( "number", Encode.int number ) ])
                        model.sharedModel.firebaseApp
                )
                submissionInstr.id
        )
        submissionInstr
        fieldId


create : (String -> Result Firebase.Errors.Error () -> msg) -> String -> Int -> SubmissionInstr -> Types.Database -> Cmd msg
create createdMsg lessonId number submissionInstr db =
    let
        keyAndTask =
            UCode.Firebase.keyAndTaskFromPush db "submissionInstr" <|
                encoder submissionInstr
    in
        Task.attempt (createdMsg keyAndTask.key) <|
            Activity.andPushActivity keyAndTask.key
                "submission_instruction"
                number
                lessonId
                db
                keyAndTask.task


createMaybe : WithSharedModel r a -> (String -> Result Firebase.Errors.Error () -> msg) -> String -> Int -> SubmissionInstr -> Cmd msg
createMaybe model createdMsg lessonId number submissionInstr =
    foldMaybe
        Cmd.none
        (create createdMsg lessonId number submissionInstr << .db)
        model.sharedModel.firebaseApp


updateMaybe : WithSharedModel model a -> (Result Firebase.Errors.Error () -> msg) -> SubmissionInstr -> String -> Cmd msg
updateMaybe model updatedMsg submissionInstr id =
    UCode.Firebase.updateValueMaybe
        updatedMsg
        ("submissionInstr/" ++ id)
        (encoder submissionInstr)
        model.sharedModel.firebaseApp


createOrUpdate : WithSharedModel r a -> (String -> Result Firebase.Errors.Error () -> msg) -> (Result Firebase.Errors.Error () -> msg) -> String -> Int -> SubmissionInstr -> Cmd msg
createOrUpdate model createdMsg updatedMsg lessonId number submissionInstr =
    Data.forkMaybe
        (\() -> createMaybe model createdMsg lessonId number submissionInstr)
        (updateMaybe model updatedMsg submissionInstr)
        submissionInstr.id


createOrUpdateMaybe : WithSharedModel r a -> (String -> Result Firebase.Errors.Error () -> msg) -> (Result Firebase.Errors.Error () -> msg) -> String -> Int -> Maybe SubmissionInstr -> Cmd msg
createOrUpdateMaybe model createdMsg updatedMsg lessonId number =
    Data.foldMaybe Cmd.none <|
        createOrUpdate model createdMsg updatedMsg lessonId number


pushField : WithSharedModel (WithMaybeSubmissionInstr r) a -> (String -> Result Firebase.Errors.Error () -> msg) -> String -> Field -> Cmd msg
pushField model pushedMsg submissionInstrId field =
    case model.sharedModel.firebaseApp of
        Just firebase ->
            UCode.Firebase.cmdWithKeyFromPush
                ("submissionFields/" ++ submissionInstrId)
                pushedMsg
                (fieldEncoder field)
                firebase.db

        _ ->
            Cmd.none


fieldsSub : Types.Database -> (Types.Snapshot -> msg) -> String -> Sub msg
fieldsSub db addedMsg submissionInstrId =
    UCode.Firebase.objectsSubscription ("submissionFields/" ++ submissionInstrId) db addedMsg


fieldsChangedSub : Types.Database -> (Types.Snapshot -> msg) -> String -> Sub msg
fieldsChangedSub db changedMsg submissionInstrId =
    UCode.Firebase.objectsChangedSubscription ("submissionFields/" ++ submissionInstrId) db changedMsg


fieldsRemovedSub : Types.Database -> (Types.Snapshot -> msg) -> String -> Sub msg
fieldsRemovedSub db removedMsg submissionInstrId =
    UCode.Firebase.objectsRemovedSubscription ("submissionFields/" ++ submissionInstrId) db removedMsg


invalidFields : WithSubmissionInstrFields r -> Bool
invalidFields submissionInstr =
    List.any String.isEmpty [ submissionInstr.instruction, submissionInstr.rubric ]
