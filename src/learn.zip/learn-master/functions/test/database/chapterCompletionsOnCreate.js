import test from 'ava'
import proxyquire from 'proxyquire'
import testData from '../_data'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const chapterCompletionsOnCreate =
  proxyquire(
    '../../database/chapterCompletionsOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CREATE CHAPTER COMPLETION TRANSACTION

test.serial('createChaterCompletionTransaction creates a valid transaction', async t => {
  await chapterCompletionsOnCreate._test.createChaterCompletionTransaction(
    { userId: 'testUserId', chapterId: 'chapter-1' },
    { numberAndName: '1.1 g', completedAt: 0, ucoins: 100, milestoneId: 'milestone-1' }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'chapterCompletions',
          reasonId: 'chapter-1',
          change: 100,
          timestamp:
            ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})

// CHECK MILESTONE COMPLETION

test.serial('checkMilestoneCompletion records milestone completions', async t => {
  mockdatabase.set(
    Object.assign(
      {
        chapterCompletions: {
          'user-1': {
            'chapter-1': {
              numberAndName: '1.1 g',
              completedAt: 0,
              ucoins: 100,
              milestoneId: 'milestone-1'
            },
            'chapter-2': {
              numberAndName: '1.2 h',
              completedAt: 1,
              ucoins: 100,
              milestoneId: 'milestone-1'
            }
          }
        }
      },
      testData
    )
  )
  await chapterCompletionsOnCreate._test.checkMilestoneCompletion(
    { userId: 'user-1', chapterId: 'chapter-2' },
    {
      numberAndName: '1.2 h',
      completedAt: 1,
      ucoins: 100,
      milestoneId: 'milestone-1'
    }
  )
  const { milestoneCompletions } = mockdatabase.getData()
  t.deepEqual(
    milestoneCompletions,
    {
      'user-1': {
        'milestone-1': {
          numberAndName: '1 j',
          completedAt: milestoneCompletions['user-1']['milestone-1'].completedAt,
          ucoins: 2000
        }
      }
    }
  )
})

test.serial('checkMilestoneCompletion doesn\'t record incomplete milestones', async t => {
  mockdatabase.set(
    Object.assign(
      {
        chapterCompletions: {
          'user-1': {
            'chapter-1': {
              numberAndName: '1.1 g',
              completedAt: 0,
              ucoins: 100,
              milestoneId: 'milestone-1'
            }
          }
        }
      },
      testData
    )
  )
  await chapterCompletionsOnCreate._test.checkMilestoneCompletion(
    { userId: 'user-1', chapterId: 'chapter-1' },
    {
      numberAndName: '1.1 g',
      completedAt: 0,
      ucoins: 100,
      milestoneId: 'milestone-1'
    }
  )
  t.falsy(mockdatabase.getData().milestoneCompletions)
})
