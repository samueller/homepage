module Util.Firebase.App exposing (app)

import Firebase


app : Firebase.App
app =
    case Firebase.app () of
        Just app ->
            app

        Nothing ->
            Debug.crash "Firebase must be initialized before the Elm app runs"
