module Types.FacebookWorkshopShare
    exposing
        ( FacebookWorkshopShare
        , get
        , create
        )

import Task exposing (Task)
import Json.Decode as Decode exposing (Decoder, Value)
import Json.Encode as Encode
import UCode.Data exposing (Id)
import UCode.Model exposing (FirebaseUser)
import UCode.User as User
import Util.Firebase.Database as Db


type alias FacebookWorkshopShare =
    { userId : Id
    , eventId : String
    , sharedBy : String
    , recordedAt : Int
    , recordedById : Id
    , recordedByName : String
    , ucoins : Int
    }


decoder : Id -> Id -> Decoder FacebookWorkshopShare
decoder userId eventId =
    Decode.map5 (FacebookWorkshopShare userId eventId)
        (Decode.field "sharedBy" Decode.string)
        (Decode.field "recordedAt" Decode.int)
        (Decode.at [ "recordedBy", "userId" ] Decode.string)
        (Decode.at [ "recordedBy", "userName" ] Decode.string)
        (Decode.field "ucoins" Decode.int)


encoder : String -> FirebaseUser -> Value
encoder sharedBy manager =
    Encode.object
        [ ( "sharedBy", Encode.string sharedBy )
        , ( "recordedAt", Db.serverTime )
        , ( "recordedBy"
          , Encode.object
                [ ( "userId", Encode.string manager.uid )
                , ( "userName", Encode.string manager.displayName )
                ]
          )
        ]


hasShared : Id -> String -> Task String Bool
hasShared userId eventId =
    Db.exists [ "facebookEventShares", userId, eventId ]


get : Id -> String -> Task String FacebookWorkshopShare
get userId eventId =
    Db.value [ "facebookEventShares", userId, eventId ] (decoder userId eventId)


create : String -> String -> String -> FirebaseUser -> Task String ()
create userEmail profileId eventId manager =
    User.validateEmailNoDb userEmail
        |> Task.andThen
            (\user ->
                hasShared user.id eventId
                    |> Task.mapError (\error -> "Failed to check if \"" ++ userEmail ++ "\" has shared that event: " ++ error)
                    |> Task.andThen
                        (\hasSharedResult ->
                            if hasSharedResult then
                                Task.fail <| userEmail ++ " has already shared that event"
                            else
                                Task.succeed user
                        )
            )
        |> Task.andThen
            (\user ->
                Db.set
                    [ "facebookEventShares", user.id, eventId ]
                    (encoder profileId manager)
            )
