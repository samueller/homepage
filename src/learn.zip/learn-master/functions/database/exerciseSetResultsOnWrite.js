const functions = require('firebase-functions')
const db = require('../utils/db')
const average = require('../utils/average')

const scoreExerciseSet = ({ userId, exerciseSetId }, results) =>
  db.valueOrReject('exerciseSets', exerciseSetId)
    .then(exercises => {
      const scores = Object.keys(exercises)
        .map(exerciseId => results[exerciseId] ? results[exerciseId].score : 0)

      if (scores.every(score => score >= 95)) {
        return db.valueOrReject('exerciseSetActivities', exerciseSetId)
          .then(activityId =>
            db.ref('activityResults', userId, activityId)
              .set({
                score: average(scores),
                timestamp: db.ServerValue.TIMESTAMP
              })
          )
      }
    })

module.exports =
  functions.database.ref('exerciseSetResults/{userId}/{exerciseSetId}')
    .onWrite((change, context) => {
      const after = change.after.val()
      return after && scoreExerciseSet(context.params, after)
    })

module.exports._test = { scoreExerciseSet }
