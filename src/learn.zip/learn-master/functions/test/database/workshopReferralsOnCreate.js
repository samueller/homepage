import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const workshopReferralsOnCreate =
  proxyquire(
    '../../database/workshopReferralsOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CREATE REFERRAL TRANSACTIONS

test('createWorkshopReferralTransactions creates valid transactions', async t => {
  await workshopReferralsOnCreate._test.createWorkshopReferralTransactions(
    { eventBrightId: '1234' },
    {
      referredName: 'User 3',
      referredBy: {
        'user-1': 'User 1',
        'user-2': 'User 2'
      },
      recordedAt: 0,
      recordedBy: {
        userId: 'user-4',
        userName: 'User 4'
      },
      ucoins: 2000
    }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory,
    {
      'user-1': {
        nextTransactionId: 1,
        transactions: [
          {
            reason: 'workshopReferrals',
            reasonId: '1234',
            change: 1000,
            timestamp:
              ucoinTransactionHistory['user-1'].transactions[0].timestamp
          }
        ]
      },
      'user-2': {
        nextTransactionId: 1,
        transactions: [
          {
            reason: 'workshopReferrals',
            reasonId: '1234',
            change: 1000,
            timestamp:
              ucoinTransactionHistory['user-2'].transactions[0].timestamp
          }
        ]
      }
    }
  )
})
