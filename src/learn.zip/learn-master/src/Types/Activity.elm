module Types.Activity exposing (Activity, ActivityWithId, Result, WithActivityFields, WithResults, activityIconImage, activityIconUnicode, andPushActivity, databasePathFromActivityType, decoder, decoderWithId, deleteMaybe, encoder, fieldsEncoder, getResult, href, iconFromActivityType, lessonIdForActivityId, lessonIdForActivityIdTask, nameFromActivityType, onResultChanged, pushActivityTask, recordWithAddedResult, recordWithAddedResultSnapshot, resultDecoder, resultScoreEncoder, saveNumber, setScore, stars, starsHtml, starsHtmlFromStars, unicodeIconFromActivityType)

import Dict
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Firebase.Errors
import Html as Html exposing (Html, i, text)
import Html.Attributes as Attributes exposing (class)
import Json.Decode as Decode
import Json.Encode as Encode
import Result
import Task exposing (Task)
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)


type alias Activity =
    { activityId : String
    , activityType : String
    , number : Int
    }


type alias Result =
    { score : Float
    , timestamp : Int
    }


type alias ActivityWithId =
    { id : String
    , activityId : String
    , activityType : String
    , number : Int
    }


type alias WithResults r =
    { r | activityResults : Dict.Dict Data.Id Result }


type alias WithActivityFields r =
    { r
        | activityId : String
        , activityType : String
        , number : Int
    }


decoder : Decode.Decoder Activity
decoder =
    Decode.map3 Activity
        (Decode.field "activityId" Decode.string)
        (Decode.field "activityType" Decode.string)
        (Decode.field "number" Decode.int)


resultDecoder : Decode.Decoder Result
resultDecoder =
    Decode.map2 Result
        (Decode.field "score" Decode.float)
        (Decode.field "timestamp" Decode.int)


decoderWithId : String -> Decode.Decoder ActivityWithId
decoderWithId id =
    Decode.map3 (ActivityWithId id)
        (Decode.field "activityId" Decode.string)
        (Decode.field "activityType" Decode.string)
        (Decode.field "number" Decode.int)


fieldsEncoder : String -> String -> Int -> Encode.Value
fieldsEncoder activityId activityType number =
    Encode.object
        [ ( "activityId", Encode.string activityId )
        , ( "activityType", Encode.string activityType )
        , ( "number", Encode.int number )
        ]


encoder : WithActivityFields r -> Encode.Value
encoder activity =
    fieldsEncoder activity.activityId activity.activityType activity.number


resultScoreEncoder : Float -> Encode.Value
resultScoreEncoder score =
    Encode.object
        [ ( "score", Encode.float score )
        , ( "timestamp", UCode.Firebase.serverTime )
        ]


href : Activity -> Data.Id -> Data.Id -> String
href activity activityId lessonId =
    activity.activityType ++ ".html?id=" ++ activity.activityId ++ "&activity=" ++ activityId ++ "&lesson=" ++ lessonId


pushActivityTask : String -> String -> Int -> String -> Types.Database -> Task.Task Firebase.Errors.Error ()
pushActivityTask activityId activityType number lessonId =
    UCode.Firebase.pushValueTask ("activities/" ++ lessonId) <|
        fieldsEncoder activityId activityType number


andPushActivity : String -> String -> Int -> String -> Types.Database -> Task.Task Firebase.Errors.Error () -> Task.Task Firebase.Errors.Error ()
andPushActivity activityId activityType number lessonId db =
    Task.andThen <|
        \_ ->
            pushActivityTask activityId activityType number lessonId db


recordWithAddedResult : WithResults r -> Data.Id -> Result -> WithResults r
recordWithAddedResult record activityId result =
    { record | activityResults = Dict.insert activityId result record.activityResults }


recordWithAddedResultSnapshot : WithResults r -> Types.Snapshot -> WithResults r
recordWithAddedResultSnapshot record snapshot =
    Data.recordUpdatedFromSnapshot
        record
        recordWithAddedResult
        resultDecoder
        snapshot


getResult :
    Id
    -> Id
    -> (Result.Result String (Maybe Result) -> msg)
    -> Maybe UCode.Firebase.FirebaseApp
    -> Cmd msg
getResult studentId activityId onFinish =
    UCode.Firebase.onceMaybe
        (Result.mapError toString
            >> Result.andThen
                (Snapshot.value
                    >> Decode.decodeValue (Decode.nullable resultDecoder)
                )
            >> onFinish
        )
        ("activityResults/" ++ studentId ++ "/" ++ activityId)


onResultChanged :
    Id
    -> Id
    -> (Maybe Result -> msg)
    -> (String -> msg)
    -> UCode.Firebase.FirebaseApp
    -> Sub msg
onResultChanged studentId activityId onChange onError app =
    UCode.Firebase.idSubscription
        ("activityResults/" ++ studentId)
        app
        (Snapshot.value
            >> Decode.decodeValue (Decode.nullable resultDecoder)
            >> (\decodeResult ->
                    case decodeResult of
                        Ok maybeResult ->
                            onChange maybeResult

                        Err error ->
                            onError error
               )
        )
        activityId


saveNumber : Data.Id -> Data.Id -> (Result.Result Firebase.Errors.Error () -> msg) -> Int -> Types.Database -> Cmd msg
saveNumber lessonId activityId =
    UCode.Firebase.saveInt ("activities/" ++ lessonId ++ "/" ++ activityId ++ "/number")


setScore : Id -> Id -> Float -> FirebaseApp -> Task String ()
setScore studentId activityId score =
    UCode.Firebase.setTask
        [ "activityResults", studentId, activityId ]
        (resultScoreEncoder score)


deleteMaybe : (Result.Result Firebase.Errors.Error () -> msg) -> Data.Id -> Data.Id -> Maybe UCode.Firebase.FirebaseApp -> Cmd msg
deleteMaybe deletedMsg lessonId id =
    UCode.Firebase.removeNodeMaybe ("activities/" ++ lessonId ++ "/" ++ id) deletedMsg


lessonIdForActivityIdTask : Id -> Types.Database -> Task String Id
lessonIdForActivityIdTask activityId =
    UCode.Firebase.onceTask ("activityLessons/" ++ activityId)
        >> Task.andThen
            (Snapshot.value
                >> Decode.decodeValue Decode.string
                >> Data.taskFromResult
            )


lessonIdForActivityId : Id -> (Result.Result String Id -> msg) -> Maybe UCode.Firebase.FirebaseApp -> Cmd msg
lessonIdForActivityId activityId onFinish app =
    UCode.Firebase.onceMaybe
        (Result.mapError toString
            >> Result.andThen
                (Snapshot.value >> Decode.decodeValue Decode.string)
            >> onFinish
        )
        ("activityLessons/" ++ activityId)
        app


imageUrlFromActivityType : String -> String
imageUrlFromActivityType activityType =
    let
        path =
            "/img/"
    in
    case activityType of
        "video" ->
            path ++ "Video_Icon.svg"

        "quiz" ->
            path ++ "Quiz_Icon.svg"

        "exercises" ->
            path ++ "Exercise_Icon.svg"

        "project_step" ->
            path ++ "Project_Step_Icon.svg"

        _ ->
            ""


iconFromActivityType : String -> String
iconFromActivityType activityType =
    case activityType of
        "video" ->
            "video_library"

        "instruction" ->
            "description"

        "quiz" ->
            "check_box"

        "exercises" ->
            "code"

        "exam" ->
            "assessment"

        "project_step" ->
            "assignment"

        "submission_instruction" ->
            "attach_file"

        _ ->
            ""


databasePathFromActivityType : String -> String
databasePathFromActivityType activityType =
    case activityType of
        "video" ->
            "videos"

        "instruction" ->
            "instructions"

        "quiz" ->
            "quizzes"

        "exercises" ->
            "exerciseSets"

        "exam" ->
            "exams"

        "project_step" ->
            "projectSteps"

        "submission_instruction" ->
            "submissionInstr"

        _ ->
            ""


unicodeIconFromActivityType : String -> String
unicodeIconFromActivityType activityType =
    case activityType of
        "video" ->
            "▶️"

        "instruction" ->
            "📜"

        "quiz" ->
            "📋"

        "exercises" ->
            "🖥"

        "exam" ->
            "⏱"

        "project_step" ->
            "📎"

        "submission_instruction" ->
            "📎"

        _ ->
            ""


nameFromActivityType : String -> String
nameFromActivityType activityType =
    case activityType of
        "video" ->
            "Video"

        "instruction" ->
            "Instruction"

        "quiz" ->
            "Quiz"

        "exercises" ->
            "Exercises"

        "exam" ->
            "Exam"

        "project_step" ->
            "Project step"

        "submission_instruction" ->
            "Submission"

        _ ->
            ""


activityIconUnicode : String -> Html msg
activityIconUnicode activityType =
    i [ class "unicode" ] [ text (unicodeIconFromActivityType activityType) ]


activityIconImage : String -> Html msg
activityIconImage activityType =
    Html.div [ class "activity__icon" ] [ Html.img [ Attributes.src (imageUrlFromActivityType activityType) ] [] ]


stars : Float -> Int
stars =
    floor << flip (/) 20


starsHtmlFromStars : Int -> Html.Html msg
starsHtmlFromStars stars =
    Html.span [ Attributes.class "activity__progress" ]
        [ Html.div
            [ Attributes.class "activity__progress-outer" ]
            [ Html.div
                [ Attributes.class "activity__progress-inner"
                , Attributes.style [ ( "width", toString (20 * stars) ++ "%" ) ]
                ]
                []
            ]
        ]


starsHtml : Float -> Html.Html msg
starsHtml =
    starsHtmlFromStars << stars
