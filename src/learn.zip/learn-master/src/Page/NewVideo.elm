module Page.NewVideo exposing (main)

import Markdown
import Html exposing (Html, nav, header, h1, h2, h3, h4, h5, h6, p, strong, text, ol, ul, li, span, br, div, a, img, select, option)
import Html.Attributes exposing (class)
import Navigation
import Material
import Material.Options as Options exposing (css)
import Material.Button as Button
import Material.Icon as Icon
import Material.Tabs as Tabs
import Material.Textfield as Textfield
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.View exposing (view, maybeBreadcrumbs, fillGrid, markdownOptions)
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Firebase exposing (FirebaseApp, ref, firebaseDbTask, logout)
import UCode.Data as Data exposing (foldMaybe, foldMaybes, foldFlattenMaybes, sortedListAddedTo, updateSortedNumberListWithSnapshot, recordWithSnapshot)
import UCode.Model exposing (User, openHomepage)
import Types.Chapter exposing (Chapter)
import Types.Milestone exposing (Milestone)
import Types.Video as Video
import Util.Curriculum exposing (Lesson, milestoneDecoder, chapterDecoder, lessonDecoder, milestoneFromChapterSub, lessonSub, createVideo, chapterFromLessonSub)
import Util.Heading exposing (viewHeadingWithEditBreadcrumbs)


main : Program User Model Msg
main =
    Html.programWithFlags
        { init = Users.initDeprecated Mdl (Model Nothing Nothing Nothing Browser.queryId "youtube" "" "" 0)
        , view = view Mdl Logout viewBody
        , update = update
        , subscriptions = subscriptions
        }


type alias Model =
    { milestone : Maybe Milestone
    , chapter : Maybe Chapter
    , lesson : Maybe Lesson
    , lessonId : String
    , videoType : String
    , videoId : String
    , content : String
    , tab : Int
    , mdl : Material.Model
    , firebaseApp : Maybe FirebaseApp
    , user : User
    }


type Msg
    = Mdl (Material.Msg Msg)
    | Logout
    | LoggedOut ()
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | InputVideoId String
    | InputContent String
    | SelectTab Int
    | Create
    | Created (Result Firebase.Errors.Error ())


number : Int
number =
    Result.withDefault 1 (String.toInt (Browser.queryParam "number"))


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            recordWithSnapshot model (\lesson -> { model | lesson = Just lesson }) lessonDecoder snapshot ! []

        ChangedChapter snapshot ->
            recordWithSnapshot model (\chapter -> { model | chapter = Just chapter }) chapterDecoder snapshot ! []

        ChangedMilestone snapshot ->
            recordWithSnapshot model (\milestone -> { model | milestone = Just milestone }) milestoneDecoder snapshot ! []

        InputVideoId videoId ->
            { model | videoId = videoId } ! []

        InputContent content ->
            { model | content = content } ! []

        SelectTab tab ->
            { model | tab = tab } ! []

        Create ->
            ( model, Video.createMaybe model Created model.lessonId number model.videoId model.videoType model.content )

        Created _ ->
            ( model, Data.foldMaybe Cmd.none (\lesson -> Navigation.load ("/edit/chapter.html?id=" ++ lesson.chapterId ++ "#lesson_" ++ model.lessonId)) model.lesson )

        Mdl msg_ ->
            Material.update Mdl msg_ model

        Logout ->
            logout model LoggedOut

        LoggedOut _ ->
            openHomepage model


viewBody : Model -> List (Html Msg)
viewBody model =
    [ fillGrid <|
        foldFlattenMaybes
            [ Just <| viewHeadingWithEditBreadcrumbs model.milestone model.chapter "New Video"
            , Just
                [ select []
                    [ option []
                        [ text "youtube" ]
                    ]
                , br [] []
                , Textfield.render Mdl
                    [ 0 ]
                    model.mdl
                    [ Textfield.label "Video Id"
                    , Textfield.floatingLabel
                    , Textfield.text_
                    , Textfield.value model.videoId
                    , Textfield.autofocus
                    , Options.onInput InputVideoId
                    ]
                    []
                , br [] []
                , Button.render Mdl
                    [ 2 ]
                    model.mdl
                    [ Button.ripple
                    , Button.colored
                    , Button.raised
                    , Button.disabled
                        |> Options.when (String.isEmpty model.videoId)
                    , Options.onClick Create
                    ]
                    [ text "Create" ]
                , br [] []
                , Tabs.render Mdl
                    [ 3 ]
                    model.mdl
                    [ Tabs.ripple
                    , Tabs.onSelectTab SelectTab
                    , Tabs.activeTab model.tab
                    ]
                    [ Tabs.label
                        [ Options.center ]
                        [ Icon.i "description"
                        , Options.span [ css "width" "4px" ] []
                        , text " Content"
                        ]
                    , Tabs.label
                        [ Options.center ]
                        [ Icon.i "visibility"
                        , Options.span [ css "width" "4px" ] []
                        , text " Preview"
                        ]
                    ]
                    [ case model.tab of
                        0 ->
                            Textfield.render Mdl
                                [ 1 ]
                                model.mdl
                                [ Textfield.label "GitHub-Flavored Markdown"
                                , Textfield.floatingLabel
                                , Textfield.textarea
                                , Textfield.rows 20
                                , Textfield.value model.content
                                , Options.onInput InputContent
                                , Options.cs "textarea-panel"
                                ]
                                []

                        _ ->
                            Markdown.toHtmlWith
                                markdownOptions
                                [ class "instructions" ]
                                model.content
                    ]
                ]
            ]
    ]


firebaseSubs : Model -> FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch <|
        foldMaybes
            [ Just <| lessonSub firebase ChangedLesson Browser.queryId
            , Maybe.map (chapterFromLessonSub firebase ChangedChapter) model.lesson
            , Maybe.map (milestoneFromChapterSub firebase ChangedMilestone) model.chapter
            ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch <|
        foldMaybes
            [ Just (Material.subscriptions Mdl model)
            , Maybe.map (firebaseSubs model) model.firebaseApp
            ]
