import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const milestoneCompletionsOnCreate =
  proxyquire(
    '../../database/milestoneCompletionsOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

test('cacheByCenter writes to the cache location', async t => {
  await milestoneCompletionsOnCreate._test.cacheByCenter(
    { userId: 'testUserId', milestoneId: 'milestone-1' },
    { numberAndName: '1 j', completedAt: 1000, ucoins: 1000, centerId: 'center-test' }
  )
  const centerCompletions = mockdatabase.getData().milestoneCompletionsByCenter['center-test']
  t.is(Object.keys(centerCompletions).length, 1)
  const completionId = Object.keys(centerCompletions)[0]
  t.deepEqual(
    centerCompletions[completionId],
    {
      userId: 'testUserId',
      milestoneId: 'milestone-1',
      completedAt: 1000
    }
  )
})

test('createMilestoneCompletionTransaction creates a valid transaction', async t => {
  await milestoneCompletionsOnCreate._test.createMilestoneCompletionTransaction(
    { userId: 'testUserId', milestoneId: 'milestone-1' },
    { numberAndName: '1 j', completedAt: 1000, ucoins: 1000, centerId: 'center-test' }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'milestoneCompletions',
          reasonId: 'milestone-1',
          change: 1000,
          timestamp:
            ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})
