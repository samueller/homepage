module Util.Firebase.Database
    exposing
        ( database
        , ref
        , value
        , getIndexed
        , exists
        , queryByChild
        , queryByChildFirst
        , set
        , push
        , pushId
        , update
        , listen
        , listenExists
        , listenChildAdded
        , listenChildren
        , remove
        , serverTime
        , decodeSnapshot
        , decodeSnapshotKeyed
        )

import Task exposing (Task)
import Json.Decode as Decode exposing (Decoder, Value)
import Json.Encode as Encode
import Firebase.Database.Types exposing (Database, Snapshot, Reference)
import Firebase.Database as Database
import Firebase.Database.Reference as Reference
import Firebase.Database.Query as Query
import Firebase.Database.Snapshot as Snapshot
import UCode.Data as Data exposing (taskFromResult)
import Util.Firebase.App exposing (app)


database : Database
database =
    Database.init app


decodeSnapshot : Decoder a -> Snapshot -> Result String a
decodeSnapshot decoder =
    Snapshot.value >> Decode.decodeValue decoder


decodeSnapshotKeyed : (String -> Decoder a) -> Snapshot -> Result String a
decodeSnapshotKeyed decoder snapshot =
    let
        key =
            Snapshot.key snapshot |> Maybe.withDefault ""
    in
        Decode.decodeValue (decoder key) (Snapshot.value snapshot)


{-| Use this instead of Firebase.Database.Snapshot.exists. See
<https://github.com/pairshaped/elm-firebase/pull/31>
-}
snapshotExists : Snapshot -> Bool
snapshotExists =
    decodeSnapshot (Decode.oneOf [ Decode.null False, Decode.succeed True ])
        >> Result.withDefault False


ref : List String -> Reference
ref path =
    List.foldl Reference.child (Database.ref (Just "/") database) path


value : List String -> Decoder a -> Task String a
value path decoder =
    ref path
        |> Reference.once "value"
        |> Task.andThen (decodeSnapshot decoder >> taskFromResult)


getIndexed : List String -> (String -> Decoder a) -> Task String (List a)
getIndexed path decoder =
    value
        path
        (Decode.oneOf [ Data.indexedKeyValueDecoder decoder, Decode.null [] ])


exists : List String -> Task String Bool
exists path =
    ref path |> Reference.once "value" |> Task.map snapshotExists


queryByChild : List String -> String -> Value -> Decoder a -> Task String a
queryByChild path child value decoder =
    ref path
        |> Reference.orderByChild child
        >> Query.equalTo value Nothing
        >> Query.once "value"
        |> Task.andThen (decodeSnapshot decoder >> taskFromResult)


queryByChildFirst :
    List String
    -> String
    -> Value
    -> (String -> Decoder a)
    -> Task String (Maybe a)
queryByChildFirst path child value decoder =
    queryByChild
        path
        child
        value
        (Decode.nullable (Data.indexedKeyValueDecoder decoder)
            |> Decode.map (Maybe.andThen List.head)
        )


set : List String -> Value -> Task String ()
set path value =
    ref path |> Reference.set value |> Task.mapError toString


push : List String -> Value -> ( String, Task String () )
push path value =
    let
        reference =
            ref path |> Reference.push
    in
        ( Reference.key reference
        , Reference.set value reference |> Task.mapError toString
        )


pushId : () -> String
pushId () =
    ref [] |> Reference.push |> Reference.key


update : List String -> List ( List String, Value ) -> Task String ()
update path updates =
    ref path
        |> Reference.updateMulti
            (List.map (Tuple.mapFirst (String.join "/")) updates)
        |> Task.mapError toString


listen : List String -> Decoder a -> (Result String a -> msg) -> Sub msg
listen path decoder tagger =
    Reference.on
        "value"
        (ref path)
        (decodeSnapshot decoder >> tagger)


listenChildAdded :
    List String
    -> (String -> Decoder a)
    -> (Result String a -> msg)
    -> Sub msg
listenChildAdded path decoder tagger =
    Reference.on
        "child_added"
        (ref path)
        (decodeSnapshotKeyed decoder >> tagger)


listenChildren :
    List String
    -> (String -> Decoder a)
    -> (Result String ( a, Bool ) -> msg)
    -> Sub msg
listenChildren path decoder tagger =
    let
        reference =
            ref path

        decode removed =
            decodeSnapshotKeyed decoder
                >> Result.map (\value -> ( value, removed ))

        on eventType removed =
            Reference.on eventType reference (decode removed >> tagger)
    in
        Sub.batch
            [ on "child_added" False
            , on "child_changed" False
            , on "child_removed" True
            ]


listenExists : List String -> (Bool -> msg) -> Sub msg
listenExists path tagger =
    Reference.on "value" (ref path) (Snapshot.exists >> tagger)


remove : List String -> Task String ()
remove path =
    ref path |> Reference.remove


serverTime : Value
serverTime =
    Encode.object [ ( ".sv", Encode.string "timestamp" ) ]
