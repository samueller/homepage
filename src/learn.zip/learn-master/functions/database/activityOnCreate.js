const functions = require('firebase-functions')
const db = require('../utils/db')
const promiseAllIgnoreReject = require('../utils/promise-all-ignore-reject')

const cacheByLesson = ({ lessonId, id }) =>
  db.ref('activityLessons', id).set(lessonId)

const cacheExerciseSetByActivity = ({ id }, activity) =>
  activity.activityType === 'exercises'
    && db.ref('exerciseSetActivities', activity.activityId).set(id)

const cacheByProjectStepByActivity = ({ id }, activity) =>
  activity.activityType === 'project_step'
    && db.ref('projectStepActivities', activity.activityId).set(id)

module.exports =
  functions.database.ref('activities/{lessonId}/{id}')
    .onCreate((snapshot, context) => {
      const activity = snapshot.val()
      return promiseAllIgnoreReject([
        cacheByLesson(context.params, activity),
        cacheExerciseSetByActivity(context.params, activity),
        cacheByProjectStepByActivity(context.params, activity)
      ])
    })

module.exports._test = {
  cacheByLesson,
  cacheExerciseSetByActivity,
  cacheByProjectStepByActivity
}
