const teamup = require('./teamup')
const sessionEndTimeUtc = require('./session-end-in-utc')
const findTeamupTokenByCenter = require('./teamup-token-by-center')

/**
 * Determines if the given session is close enough to be considered "current",
 * in other words, is this session activly happening? If a session starts within
 * 30 minutes, or ended at most 30 minutes ago, it is considered "current"
 * @param  {Session}  session A session object from the Teamup API
 * @return {boolean}
 */
const isCurrentSession = session => {
  const start = new Date(session.utc_start)
  const end = sessionEndTimeUtc(session)
  const now = Date.now()
  const minuteMs = 60 * 1000
  return start - 30 * minuteMs < now && end + 30 * minuteMs > now
}

/**
 * @param  {Session[]} sessions
 * @return {Session?}
 */
const currentSession = sessions =>
  sessions.filter(isCurrentSession)[0] || null

/**
 * Find a student's current session (if they're in a session)
 * @param  {string} teamupId The Teamup ID of the student
 * @param  {string} centerId The student's center ID
 * @return {Session?}
 */
module.exports = (teamupId, centerId) => {
  const dayMs = 24 * 60 * 60 * 1000
  let token
  try {
    token = findTeamupTokenByCenter(centerId)
  } catch (e) {
    return Promise.reject(e)
  }
  return teamup.getSessionAttendances(
    token,
    teamupId,
    new Date(Date.now() - dayMs)
  )
    .then(data => {
      if (data.results.length === 0) {
        return null
      }
      return currentSession(data.results.map(({ session }) => session))
    })
}
