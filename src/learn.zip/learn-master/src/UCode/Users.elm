module UCode.Users exposing (..)

import Regex
import Material
import Material.Snackbar as Snackbar
import Firebase.Errors
import Firebase.Database.Types as Types
import UCode.Firebase exposing (FirebaseApp, maybeFirebaseApp)
import UCode.Model as Model exposing (SharedModelUser, SharedModelFirebaseUser, WithSharedModelFirebaseUser, User, FirebaseUser, SharedModelMaybeFirebaseUser)
import UCode.Msg exposing (Msg(..))
import UCode.Browser as Browser
import UCode.Data as Data


init :
    (Msg -> msg)
    -> (SharedModelFirebaseUser -> ( WithSharedModelFirebaseUser model, Cmd msg ))
    -> FirebaseUser
    -> ( WithSharedModelFirebaseUser model, Cmd msg )
init liftMsg pageInit user =
    pageInit
        { mdl = Material.model
        , firebaseApp = maybeFirebaseApp
        , user = user
        , snackbar = Snackbar.model
        }
        |> Tuple.mapSecond
            (\cmd -> Cmd.batch [ Cmd.map liftMsg (Material.init Mdl), cmd ])


initMaybeUser :
    (Msg -> msg)
    -> (SharedModelMaybeFirebaseUser -> ( { model | sharedModel : SharedModelMaybeFirebaseUser }, Cmd msg ))
    -> Maybe FirebaseUser
    -> ( { model | sharedModel : SharedModelMaybeFirebaseUser }, Cmd msg )
initMaybeUser liftMsg pageInit maybeUser =
    pageInit
        { mdl = Material.model
        , firebaseApp = maybeFirebaseApp
        , user = maybeUser
        , snackbar = Snackbar.model
        }
        |> Tuple.mapSecond
            (\cmd -> Cmd.batch [ Cmd.map liftMsg (Material.init Mdl), cmd ])


initNoUser :
    (Msg -> msg)
    ->
        (SharedModelMaybeFirebaseUser
         -> ( { model | sharedModel : SharedModelMaybeFirebaseUser }, Cmd msg )
        )
    -> ( { model | sharedModel : SharedModelMaybeFirebaseUser }, Cmd msg )
initNoUser liftMsg pageInit =
    pageInit
        { mdl = Material.model
        , firebaseApp = maybeFirebaseApp
        , user = Nothing
        , snackbar = Snackbar.model
        }
        |> Tuple.mapSecond
            (\cmd -> Cmd.batch [ Cmd.map liftMsg (Material.init Mdl), cmd ])


{-| This old function is kept around for the few pages that still use it
-}
initDeprecated : (Material.Msg msg -> msg) -> (Material.Model -> Maybe FirebaseApp -> User -> model) -> User -> ( model, Cmd msg )
initDeprecated mdl model user =
    ( model Material.model maybeFirebaseApp user
    , Material.init mdl
    )


modelWithSharedModelUser : (SharedModelUser -> model) -> User -> model
modelWithSharedModelUser model user =
    model <|
        SharedModelUser Material.model maybeFirebaseApp user Snackbar.model


modelWithSharedModelFirebaseUser : (SharedModelFirebaseUser -> model) -> FirebaseUser -> model
modelWithSharedModelFirebaseUser model firebaseUser =
    model <|
        SharedModelFirebaseUser Material.model maybeFirebaseApp firebaseUser Snackbar.model


initWithCmd : (Msg -> msg) -> (SharedModelUser -> model) -> Cmd msg -> User -> ( model, Cmd msg )
initWithCmd liftMsg model cmd user =
    ( modelWithSharedModelUser model user
    , Cmd.batch
        [ Cmd.map liftMsg (Material.init Mdl)
        , cmd
        ]
    )


initWithUser : (Msg -> msg) -> (SharedModelUser -> model) -> User -> ( model, Cmd msg )
initWithUser liftMsg model user =
    ( modelWithSharedModelUser model user
    , Cmd.map liftMsg (Material.init Mdl)
    )


initWithFirebaseUser : (Msg -> msg) -> (SharedModelFirebaseUser -> model) -> FirebaseUser -> ( model, Cmd msg )
initWithFirebaseUser liftMsg model user =
    ( modelWithSharedModelFirebaseUser model user
    , Cmd.map liftMsg (Material.init Mdl)
    )


initWithFirebaseUserAndData : (Msg -> msg) -> (SharedModelFirebaseUser -> Model.WithSharedModelFirebaseUser model) -> (Result Firebase.Errors.Error Types.Snapshot -> msg) -> String -> FirebaseUser -> ( Model.WithSharedModelFirebaseUser model, Cmd msg )
initWithFirebaseUserAndData liftMsg model gotDataMsg dataPath user =
    let
        newModel =
            modelWithSharedModelFirebaseUser model user
    in
        ( newModel
        , Cmd.batch
            [ Cmd.map liftMsg (Material.init Mdl)
            , UCode.Firebase.onceMaybe gotDataMsg (dataPath ++ "/" ++ Browser.queryId) newModel.sharedModel.firebaseApp
            ]
        )


initWithFirebaseUserAndCmd : (Msg -> msg) -> (SharedModelFirebaseUser -> Model.WithSharedModelFirebaseUser model) -> (SharedModelFirebaseUser -> Cmd msg) -> FirebaseUser -> ( Model.WithSharedModelFirebaseUser model, Cmd msg )
initWithFirebaseUserAndCmd liftMsg model cmd user =
    let
        newModel =
            modelWithSharedModelFirebaseUser model user
    in
        ( newModel
        , Cmd.batch
            [ Cmd.map liftMsg (Material.init Mdl)
            , cmd newModel.sharedModel
            ]
        )


initWithFireData : (Msg -> msg) -> (SharedModelUser -> model) -> (Result Firebase.Errors.Error Types.Snapshot -> msg) -> String -> User -> ( model, Cmd msg )
initWithFireData liftMsg model gotDataMsg dataPath user =
    ( modelWithSharedModelUser model user
    , Cmd.batch
        [ Cmd.map liftMsg (Material.init Mdl)
        , UCode.Firebase.onceOrNone gotDataMsg (dataPath ++ "/" ++ Browser.queryId)
        ]
    )


initWithFireDataMaybe : (Msg -> msg) -> (SharedModelUser -> model) -> (Result Firebase.Errors.Error Types.Snapshot -> msg) -> String -> Maybe String -> User -> ( model, Cmd msg )
initWithFireDataMaybe liftMsg model gotDataMsg dataPath dataId user =
    ( modelWithSharedModelUser model user
    , Cmd.batch <|
        Cmd.map liftMsg (Material.init Mdl)
            :: (Data.foldMaybe
                    []
                    (List.singleton
                        << UCode.Firebase.onceOrNone gotDataMsg
                        << (++) (dataPath ++ "/")
                    )
                    dataId
               )
    )


validEmailRegex : Regex.Regex
validEmailRegex =
    Regex.regex "^(([^<>()\\[\\]\\\\.,;:\\s@\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\"]+)*)|(\".+\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$"


invalidEmail : String -> Bool
invalidEmail =
    not << Regex.contains validEmailRegex


validBirthDateRegex : Regex.Regex
validBirthDateRegex =
    Regex.regex "^(194|195|196|197|198|199|200|201)\\d-[01]\\d-[0123]\\d$"


invalidBirthDate : String -> Bool
invalidBirthDate =
    not << Regex.contains validBirthDateRegex
