module Types.Chapter exposing (..)

import Dict
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Json.Decode as Decode
import Json.Encode as Encode
import Navigation
import Task exposing (Task)
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)


type alias Chapter =
    { id : String
    , name : String
    , number : Int
    , milestoneId : String
    }


type alias ChapterNoId =
    { name : String
    , number : Int
    , milestoneId : String
    }


type alias WithChapter r =
    { r | chapter : Chapter }


type alias WithChaptersDict r =
    { r | chapters : Dict.Dict Data.Id ChapterNoId }


type alias WithMaybeChapter r =
    { r | chapter : Maybe Chapter }


type alias WithChapterId r =
    { r | chapterId : String }


noIdDecoder : Decode.Decoder ChapterNoId
noIdDecoder =
    Decode.map3 ChapterNoId
        (Decode.field "name" Decode.string)
        (Decode.field "number" Decode.int)
        (Decode.field "milestoneId" Decode.string)


chapterDecoder : String -> Decode.Decoder Chapter
chapterDecoder id =
    Decode.map3 (Chapter id)
        (Decode.field "name" Decode.string)
        (Decode.field "number" Decode.int)
        (Decode.field "milestoneId" Decode.string)


recordWithJustChapter : WithMaybeChapter a -> Chapter -> WithMaybeChapter a
recordWithJustChapter record chapter =
    { record | chapter = Just chapter }


recordWithJustChapterSnapshot : WithMaybeChapter a -> Types.Snapshot -> WithMaybeChapter a
recordWithJustChapterSnapshot record =
    Data.recordWithSnapshot record (recordWithJustChapter record) chapterDecoder


recordWithChangedDictEntry : WithChaptersDict r -> Data.Id -> ChapterNoId -> WithChaptersDict r
recordWithChangedDictEntry record id chapter =
    { record | chapters = Dict.insert id chapter record.chapters }


recordWithRemovedDictEntry : WithChaptersDict r -> Types.Snapshot -> WithChaptersDict r
recordWithRemovedDictEntry record snapshot =
    { record | chapters = Data.dictWithRemovedElementFromSnapshot record.chapters snapshot }


editUrl : String -> String
editUrl chapterId =
    "/edit/chapter.html?id=" ++ chapterId


openEditUrl : String -> Cmd msg
openEditUrl =
    Navigation.load << editUrl


editUrlWithLesson : String -> String -> String
editUrlWithLesson lessonId chapterId =
    "/edit/chapter.html?id=" ++ chapterId ++ "#lesson_" ++ lessonId


openEditUrlWithLesson : String -> String -> Cmd msg
openEditUrlWithLesson lessonId =
    Navigation.load << editUrlWithLesson lessonId


maybeOpenEditUrlWithLesson : String -> Maybe Chapter -> Cmd msg
maybeOpenEditUrlWithLesson lessonId =
    Data.foldMaybe
        Cmd.none
        (openEditUrlWithLesson lessonId << .id)


sub : UCode.Firebase.FirebaseApp -> (Types.Snapshot -> msg) -> String -> Sub msg
sub =
    UCode.Firebase.idSubscription "chapters"


get : Data.Id -> Types.Database -> Task String Chapter
get id =
    UCode.Firebase.onceTask ("chapters/" ++ id)
        >> Task.andThen
            (Snapshot.value
                >> Decode.decodeValue (chapterDecoder id)
                >> Data.taskFromResult
            )


getAll : Types.Database -> Task String (List Chapter)
getAll =
    UCode.Firebase.onceTask "chapters"
        >> Task.andThen
            (Snapshot.value
                >> Decode.decodeValue (Data.indexedKeyValueDecoder chapterDecoder)
                >> Data.taskFromResult
            )


getAllInMilestone : Id -> (Result String (List Chapter) -> msg) -> Maybe FirebaseApp -> Cmd msg
getAllInMilestone milestoneId onReceive app =
    UCode.Firebase.onceByChildMaybe
        (Result.mapError toString
            >> Result.andThen
                (Snapshot.value
                    >> Decode.decodeValue (Data.indexedKeyValueDecoder chapterDecoder)
                )
            >> onReceive
        )
        "chapters"
        "milestoneId"
        (Encode.string milestoneId)
        app
