import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const exerciseSetResultsOnWrite =
  proxyquire(
    '../../database/exerciseSetResultsOnWrite',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// SCORE EXERCISE SET

test.serial('scoreExerciseSet records completed exercise sets', async t => {
  mockdatabase.set({
    exerciseSets: {
      'exercise-set-1': {
        'exercise-1': true,
        'exercise-2': true,
        'exercise-3': true
      }
    },
    exerciseSetActivities: {
      'exercise-set-1': 'activity-1'
    }
  })
  await exerciseSetResultsOnWrite._test.scoreExerciseSet(
    { userId: 'user-1', exerciseSetId: 'exercise-set-1' },
    {
      'exercise-1': { score: 97 },
      'exercise-2': { score: 96 },
      'exercise-3': { score: 95 }
    }
  )
  const { activityResults } = mockdatabase.getData()
  t.deepEqual(
    activityResults,
    {
      'user-1': {
        'activity-1': {
          score: 96,
          timestamp: activityResults['user-1']['activity-1'].timestamp
        }
      }
    }
  )
})

test.serial('scoreExerciseSet does not record failed exercise sets', async t => {
  mockdatabase.set({
    exerciseSets: {
      'exercise-set-1': {
        'exercise-1': true,
        'exercise-2': true,
        'exercise-3': true
      }
    },
    exerciseSetActivities: {
      'exercise-set-1': 'activity-1'
    }
  })
  await exerciseSetResultsOnWrite._test.scoreExerciseSet(
    { userId: 'user-1', exerciseSetId: 'exercise-set-1' },
    {
      'exercise-1': { score: 100 },
      'exercise-2': { score: 100 },
      'exercise-3': { score: 0 }
    }
  )
  t.falsy(mockdatabase.getData().activityResults)
})

test.serial('scoreExerciseSet considers unattempted exercises to be failed', async t => {
  mockdatabase.set({
    exerciseSets: {
      'exercise-set-1': {
        'exercise-1': true,
        'exercise-2': true,
        'exercise-3': true
      }
    },
    exerciseSetActivities: {
      'exercise-set-1': 'activity-1'
    }
  })
  await exerciseSetResultsOnWrite._test.scoreExerciseSet(
    { userId: 'user-1', exerciseSetId: 'exercise-set-1' },
    {
      'exercise-1': { score: 100 },
      'exercise-2': { score: 100 }
    }
  )
  t.falsy(mockdatabase.getData().activityResults)
})
