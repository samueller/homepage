module Types.Lti exposing (..)

import Json.Encode as Encode
import Json.Decode as Decode
import Task
import Navigation
import Firebase.Database.Types as Types
import Firebase.Errors
import Firebase.Database.Snapshot as Snapshot
import UCode.Firebase as UFirebase
import UCode.Data as Data
import UCode.Model as Model
import Types.Activity as Activity
import Types.Chapter as Chapter
import Types.Lesson as Lesson


type alias Lti =
    { url : String
    , key : String
    , secret : String
    }


type alias Exercise =
    { name : String
    , number : Int
    }


type alias Outcome =
    { score : Float
    , attempts : Int
    , timestamp : Int
    }


type alias ExerciseLti =
    { exercise : Exercise
    , lti : Lti
    }


type alias ExerciseAndMaybeLti =
    { exercise : Exercise
    , lti : Maybe Lti
    }


type alias WithLti r =
    { r | lti : Lti }


type alias WithMaybeLti r =
    { r | lti : Maybe Lti }


type alias WithMaybeLtiId r =
    { r | ltiId : Maybe Data.Id }


type alias WithMaybeOutcome r =
    { r | ltiOutcome : Maybe Outcome }


type alias WithMaybeExercise r =
    { r | exercise : Maybe Exercise }


type alias WithLtiFields r =
    { r
        | url : String
        , key : String
        , secret : String
    }


empty : Lti
empty =
    Lti "" "ucode" "secret"


emptyExercise : Exercise
emptyExercise =
    Exercise "" 1


emptyExerciseLti : ExerciseLti
emptyExerciseLti =
    ExerciseLti emptyExercise empty


emptyExerciseLtiWithNumber : Int -> ExerciseLti
emptyExerciseLtiWithNumber number =
    ExerciseLti (Exercise "" number) empty


decoder : Decode.Decoder Lti
decoder =
    Decode.map3 Lti
        (Decode.field "url" Decode.string)
        (Decode.field "key" Decode.string)
        (Decode.field "secret" Decode.string)


outcomeDecoder : Decode.Decoder Outcome
outcomeDecoder =
    Decode.map3 Outcome
        (Decode.field "score" Decode.float)
        (Decode.field "attempts" Decode.int)
        (Decode.field "timestamp" Decode.int)


exerciseDecoder : Decode.Decoder Exercise
exerciseDecoder =
    Decode.map2 Exercise
        (Decode.field "name" Decode.string)
        (Decode.field "number" Decode.int)


encoded : Lti -> Encode.Value
encoded lti =
    fieldsEncoded lti.url lti.key lti.secret


fieldsEncoded : String -> String -> String -> Encode.Value
fieldsEncoded url key secret =
    Encode.object
        [ ( "url", Encode.string url )
        , ( "key", Encode.string key )
        , ( "secret", Encode.string secret )
        ]


exercisesLtiEncoded : Data.Id -> String -> Int -> Encode.Value
exercisesLtiEncoded ltiId name number =
    Encode.object
        [ ( ltiId
          , Encode.object
                [ ( "name", Encode.string name )
                , ( "number", Encode.int number )
                ]
          )
        ]


exerciseWithName : String -> Exercise -> Exercise
exerciseWithName name exercise =
    { exercise | name = name }


exerciseWithNumber : Int -> Exercise -> Exercise
exerciseWithNumber number exercise =
    { exercise | number = number }


exerciseLtiWithName : String -> ExerciseLti -> ExerciseLti
exerciseLtiWithName name exerciseLti =
    { exerciseLti | exercise = exerciseWithName name exerciseLti.exercise }


exerciseLtiWithNumber : Int -> ExerciseLti -> ExerciseLti
exerciseLtiWithNumber number exerciseLti =
    { exerciseLti | exercise = exerciseWithNumber number exerciseLti.exercise }


exerciseLtiWithUrl : String -> ExerciseLti -> ExerciseLti
exerciseLtiWithUrl url exerciseLti =
    { exerciseLti | lti = ltiWithUrl url exerciseLti.lti }


exerciseLtiWithKey : String -> ExerciseLti -> ExerciseLti
exerciseLtiWithKey key exerciseLti =
    { exerciseLti | lti = ltiWithKey key exerciseLti.lti }


exerciseLtiWithSecret : String -> ExerciseLti -> ExerciseLti
exerciseLtiWithSecret secret exerciseLti =
    { exerciseLti | lti = ltiWithSecret secret exerciseLti.lti }


recordWithLti : Lti -> WithLti r -> WithLti r
recordWithLti lti record =
    { record | lti = lti }


recordWithMaybeLti : Maybe Lti -> WithMaybeLti r -> WithMaybeLti r
recordWithMaybeLti maybeLti record =
    { record | lti = maybeLti }


recordWithJustLti : WithMaybeLti r -> Lti -> WithMaybeLti r
recordWithJustLti record lti =
    { record | lti = Just lti }


recordWithMaybeLtiTransformed : WithMaybeLti r -> (Lti -> Lti) -> WithMaybeLti r
recordWithMaybeLtiTransformed record transform =
    { record | lti = Maybe.map transform record.lti }


recordWithMaybeLtiSnapshot : WithMaybeLti r -> Types.Snapshot -> WithMaybeLti r
recordWithMaybeLtiSnapshot record =
    Data.recordUpdatedFromSnapshotValue record recordWithJustLti decoder


recordWithJustLtiSnapshot : WithMaybeLti r -> Types.Snapshot -> WithMaybeLti r
recordWithJustLtiSnapshot =
    recordWithMaybeLtiSnapshot


recordWithJustOutcome : WithMaybeOutcome r -> Outcome -> WithMaybeOutcome r
recordWithJustOutcome record outcome =
    { record | ltiOutcome = Just outcome }


recordWithMaybeOutcomeSnapshot : WithMaybeOutcome r -> Types.Snapshot -> WithMaybeOutcome r
recordWithMaybeOutcomeSnapshot record =
    Data.recordUpdatedFromSnapshotValue record recordWithJustOutcome outcomeDecoder


recordWithJustExercise : WithMaybeExercise r -> Exercise -> WithMaybeExercise r
recordWithJustExercise record exercise =
    { record | exercise = Just exercise }


recordWithMaybeExerciseSnapshot : WithMaybeExercise r -> Types.Snapshot -> WithMaybeExercise r
recordWithMaybeExerciseSnapshot record =
    Data.recordUpdatedFromSnapshotValue record recordWithJustExercise exerciseDecoder


recordWithMaybeFirstExerciseAndId : WithMaybeExercise (WithMaybeLtiId r) -> List ( Data.Id, Exercise ) -> WithMaybeExercise (WithMaybeLtiId r)
recordWithMaybeFirstExerciseAndId record exercises =
    Data.foldMaybe record
        (\( ltiId, exercise ) ->
            { record
                | ltiId = Just ltiId
                , exercise = Just exercise
            }
        )
        (List.head exercises)


recordWithMaybeFirstExerciseAndIdSnapshot : WithMaybeExercise (WithMaybeLtiId r) -> Types.Snapshot -> WithMaybeExercise (WithMaybeLtiId r)
recordWithMaybeFirstExerciseAndIdSnapshot record =
    Data.foldResult record
        (recordWithMaybeFirstExerciseAndId record)
        << Decode.decodeValue (Decode.keyValuePairs exerciseDecoder)
        << Snapshot.value


ltiWithUrl : String -> Lti -> Lti
ltiWithUrl url lti =
    { lti | url = url }


ltiWithKey : String -> Lti -> Lti
ltiWithKey key lti =
    { lti | key = key }


ltiWithSecret : String -> Lti -> Lti
ltiWithSecret secret lti =
    { lti | secret = secret }


recordWithLtiUrl : String -> WithLti r -> WithLti r
recordWithLtiUrl url record =
    recordWithLti
        (ltiWithUrl url record.lti)
        record


recordWithLtiKey : String -> WithLti r -> WithLti r
recordWithLtiKey key record =
    recordWithLti
        (ltiWithKey key record.lti)
        record


recordWithLtiSecret : String -> WithLti r -> WithLti r
recordWithLtiSecret secret record =
    recordWithLti
        (ltiWithSecret secret record.lti)
        record


recordWithMaybeLtiUrl : WithMaybeLti r -> String -> WithMaybeLti r
recordWithMaybeLtiUrl record =
    recordWithMaybeLtiTransformed record << ltiWithUrl


recordWithMaybeLtiKey : WithMaybeLti r -> String -> WithMaybeLti r
recordWithMaybeLtiKey record =
    recordWithMaybeLtiTransformed record << ltiWithKey


recordWithMaybeLtiSecret : WithMaybeLti r -> String -> WithMaybeLti r
recordWithMaybeLtiSecret record =
    recordWithMaybeLtiTransformed record << ltiWithSecret


update : (Result Firebase.Errors.Error () -> msg) -> Data.Id -> Lti -> Types.Database -> Cmd msg
update updatedMsg id lti =
    UFirebase.setValue
        ("ltis/" ++ id)
        (encoded lti)
        updatedMsg


createExerciseLti : (Result Firebase.Errors.Error () -> msg) -> Data.Id -> ExerciseLti -> Types.Database -> Cmd msg
createExerciseLti createdMsg exercisesId exerciseLti db =
    let
        keyAndTask =
            UFirebase.keyAndTaskFromPush db "ltis" (encoded exerciseLti.lti)
    in
        Task.attempt createdMsg <|
            Task.andThen
                (\_ ->
                    UFirebase.updateValueTask
                        ("exerciseSets/" ++ exercisesId)
                        (exercisesLtiEncoded keyAndTask.key exerciseLti.exercise.name exerciseLti.exercise.number)
                        db
                )
                keyAndTask.task


updateExerciseName : (Result Firebase.Errors.Error () -> msg) -> Data.Id -> Data.Id -> String -> Types.Database -> Cmd msg
updateExerciseName updatedMsg exercisesId ltiId name =
    UFirebase.setValue
        ("exerciseSets/" ++ exercisesId ++ "/" ++ ltiId ++ "/name")
        (Encode.string name)
        updatedMsg


updateExerciseNumber : (Result Firebase.Errors.Error () -> msg) -> String -> Int -> Data.WithId r -> Types.Database -> Cmd msg
updateExerciseNumber updatedMsg ltiId number model =
    UFirebase.updateValue
        ("exerciseSets/" ++ model.id ++ "/" ++ ltiId)
        (Encode.object [ ( "number", Encode.int number ) ])
        updatedMsg


deleteExercise : (Result Firebase.Errors.Error () -> msg) -> Data.Id -> Data.Id -> Types.Database -> Cmd msg
deleteExercise deletedMsg exercisesId ltiId =
    UFirebase.removeNode
        ("exerciseSets/" ++ exercisesId ++ "/" ++ ltiId)
        deletedMsg


createExercises : (Data.Id -> Result Firebase.Errors.Error () -> msg) -> Lesson.WithLessonId (Data.WithNumber (Data.WithName (WithLti r))) -> Types.Database -> Cmd msg
createExercises createdMsg model db =
    let
        ltiKeyAndTask =
            UFirebase.keyAndTaskFromPush db "ltis" <|
                encoded model.lti

        exercisesKeyAndTask =
            UFirebase.keyAndTaskFromPush db "exerciseSets" <|
                exercisesLtiEncoded ltiKeyAndTask.key model.name 1

        activityTask =
            Activity.pushActivityTask exercisesKeyAndTask.key "exercises" model.number model.lessonId db
    in
        Task.attempt (createdMsg exercisesKeyAndTask.key) <|
            Task.map (\_ -> ()) <|
                Task.sequence
                    [ ltiKeyAndTask.task, exercisesKeyAndTask.task, activityTask ]


invalidFields : WithLtiFields r -> Bool
invalidFields lti =
    List.any String.isEmpty [ lti.url, lti.key, lti.secret ]


editExercisesUrlWithLesson : Data.Id -> Data.Id -> String
editExercisesUrlWithLesson lessonId exercisesId =
    "/edit/exercises.html?id=" ++ exercisesId ++ "&lesson=" ++ lessonId


openEditExercisesUrlWithLesson : Data.Id -> Data.Id -> Cmd msg
openEditExercisesUrlWithLesson lessonId =
    Navigation.load << editExercisesUrlWithLesson lessonId


exercisesUrlWithNumber : Data.Id -> Data.Id -> Data.Id -> Int -> String
exercisesUrlWithNumber lessonId activityId exercisesId number =
    "/exercises.html?id=" ++ exercisesId ++ "&lesson=" ++ lessonId ++ "&activity=" ++ activityId ++ "&number=" ++ (toString number)


openExercisesUrlWithNumber : Data.Id -> Data.Id -> Data.Id -> Int -> Cmd msg
openExercisesUrlWithNumber lessonId activityId exercisesId =
    Navigation.load
        << exercisesUrlWithNumber lessonId activityId exercisesId
