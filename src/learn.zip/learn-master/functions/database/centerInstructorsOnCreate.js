const functions = require('firebase-functions')
const db = require('../utils/db')

const cacheByUser = ({ centerId, userId }) =>
  db.valueOrReject('centers', centerId, 'name')
    .then(centerName =>
      db.ref('instructorCenters', userId, centerId).set(centerName)
    )

module.exports =
  functions.database.ref('centerInstructors/{centerId}/{userId}')
    .onCreate((snap, context) => cacheByUser(context.params))

module.exports._test = { cacheByUser }
