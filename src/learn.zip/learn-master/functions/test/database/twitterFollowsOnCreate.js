import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const twitterFollowsOnCreate =
  proxyquire(
    '../../database/twitterFollowsOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CREATE TWITTER FOLLOWS TRANSACTION

test('createTwitterFollowTransaction creates a valid transaction', async t => {
  await twitterFollowsOnCreate._test.createTwitterFollowTransaction(
    { userId: 'testUserId' }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'twitterFollows',
          change: 50,
          timestamp:
            ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})
