const functions = require('firebase-functions')
const db = require('../utils/db')
const createTransaction = require('../utils/createTransaction')
const constants = require('../constants')

const createReferalTransactions = ({ referredUserId }, val) => {
  const referredByUserIds = Object.keys(val.referredBy)
  const perUserReward =
    constants.UCOIN_VALUES.REFERRAL / referredByUserIds.length
  return Promise.all(
    [
      db.ref('referrals', referredUserId, 'ucoins')
        .set(constants.UCOIN_VALUES.REFERRAL)
    ]
      .concat(
        referredByUserIds
          .map(userId =>
            createTransaction(
              userId,
              'referrals',
              referredUserId,
              false,
              perUserReward,
              false
            )
          )
      )
  )
}

module.exports =
  functions.database.ref('referrals/{referredUserId}')
    .onCreate((snap, context) =>
      createReferalTransactions(context.params, snap.val())
    )

module.exports._test = { createReferalTransactions }
