if [ $# -eq 1 ]
  then
    elm-live src/Page/$1.elm --output public/elm/$1.js
else
    elm-live src/Page/$1.elm --output public/elm/$1.js --port=$2
fi
