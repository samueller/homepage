import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const prizePurchasesOnCreate =
  proxyquire(
    '../../database/prizePurchasesOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

test.beforeEach(t => {
  mockdatabase.set({
    prizes: {
      'prize-1': {
        name: 'Prize 1',
        imageUrl: 'https://example.com',
        description: 'This is a test prize',
        price: 99
      }
    },
    users: {
      testUserId: {
        ucoins: 100,
        name: 'Bob'
      }
    },
    students: {
      testUserId: {
        centerId: 'center-1',
        active: true
      }
    }
  })
})

// VALIDATE PURCHASE

test.serial('validatePurchase creates a valid transaction', async t => {
  await prizePurchasesOnCreate._test.validatePurchase(
    { userId: 'testUserId', purchaseId: 'purchase-1' },
    { prizeId: 'prize-1', prizeName: 'Prize 1', purchasedAt: 1 }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'prizePurchases',
          reasonId: 'purchase-1',
          change: -99,
          timestamp:
            ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})

test.serial('validatePurchase does not allow inactive students', async t => {
  mockdatabase.child('students/testUserId/active').set(false)
  await prizePurchasesOnCreate._test.validatePurchase(
    { userId: 'testUserId', purchaseId: 'purchase-1' },
    { prizeId: 'prize-1', prizeName: 'Prize 1', purchasedAt: 1 }
  )
  t.falsy(mockdatabase.getData().prizePurchases)
})

test.serial('validatePurchase caches purchases by center', async t => {
  await prizePurchasesOnCreate._test.validatePurchase(
    { userId: 'testUserId', purchaseId: 'purchase-1' },
    { prizeId: 'prize-1', prizeName: 'Prize 1', purchasedAt: 1 }
  )
  const { pendingCenterPurchases } = mockdatabase.getData()
  t.deepEqual(
    pendingCenterPurchases,
    {
      'center-1': {
        'purchase-1': {
          userName: 'Bob',
          userId: 'testUserId',
          prizeName: 'Prize 1'
        }
      }
    }
  )
})

test.serial('validatePurchase updates the purchase details', async t => {
  await prizePurchasesOnCreate._test.validatePurchase(
    { userId: 'testUserId', purchaseId: 'purchase-1' },
    { prizeId: 'prize-1', prizeName: 'Prize 1', purchasedAt: 1 }
  )
  const { prizePurchases } = mockdatabase.getData()
  t.deepEqual(
    prizePurchases,
    {
      'testUserId': {
        'purchase-1': {
          cost: 99,
          validated: true
        }
      }
    }
  )
})
