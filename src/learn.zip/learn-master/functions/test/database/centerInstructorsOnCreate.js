import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const centerInstructorsOnCreate =
  proxyquire(
    '../../database/centerInstructorsOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CREATE CHAPTER COMPLETION TRANSACTION

test.serial('cacheByUser creates a valid transaction', async t => {
  mockdatabase.set({
    centers: {
      'center-1': {
        name: 'Center 1'
      }
    }
  })
  await centerInstructorsOnCreate._test.cacheByUser(
    { centerId: 'center-1', userId: 'user-1' }
  )
  const { instructorCenters } = mockdatabase.getData()
  t.deepEqual(
    instructorCenters['user-1'],
    { 'center-1': 'Center 1' }
  )
})
