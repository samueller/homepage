const functions = require('firebase-functions')
const createTransaction = require('../utils/createTransaction')
const constants = require('../constants')

const createFacebookEventShareTransaction = ({ userId, eventId }) =>
  createTransaction(
    userId,
    'facebookEventShares',
    eventId,
    false,
    constants.UCOIN_VALUES.FACEBOOK_WORKSHOP_SHARE,
    `facebookEventShares/${userId}/${eventId}/ucoins`
  )

module.exports =
  functions.database.ref('facebookEventShares/{userId}/{eventId}')
    .onCreate((snap, context) =>
      createFacebookEventShareTransaction(context.params)
    )

module.exports._test = { createFacebookEventShareTransaction }
