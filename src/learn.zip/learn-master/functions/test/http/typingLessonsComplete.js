import test from 'ava'
import proxyquire from 'proxyquire'
import sinon from 'sinon'
import { createAdminMock, middlewareTest } from '../_test_utils'
import * as functions from 'firebase-functions'

const { mockdatabase, adminMock } = createAdminMock()
const uidOfEmailStub = sinon.stub()
sinon.stub(functions, 'config').returns({ utype: { webhook_secret: 'secret' } })

const typingLessonsComplete =
  proxyquire(
    '../../http/typingLessonsComplete',
    {
      '../utils/uid-of-email': uidOfEmailStub,
      '../utils/db': proxyquire('../../utils/db', { 'firebase-admin': adminMock })
    }
  )

test(
  'Only accepts POST requests',
  middlewareTest,
  typingLessonsComplete,
  { method: 'GET' },
  405,
  'This route only accepts POST requests'
)

test(
  'Validates email',
  middlewareTest,
  typingLessonsComplete,
  { method: 'POST', body: { email: 1 } },
  400,
  'Expected `req.body.email` to be a string'
)

test(
  'Validates secret',
  middlewareTest,
  typingLessonsComplete,
  { method: 'POST', body: { email: 'test@test.com' }, headers: {} },
  400,
  'Bad secret'
)

test.serial('Does nothing for unknown emails', async t => {
  uidOfEmailStub.withArgs('test@test.com').resolves(null)
  await middlewareTest(
    t,
    typingLessonsComplete,
    {
      method: 'POST',
      body: { email: 'test@test.com' },
      headers: { 'x-utype-webhook-secret': 'secret' }
    },
    204
  )
  t.falsy(mockdatabase.getData())
})

test.serial('Records completions by user ID', async t => {
  uidOfEmailStub.withArgs('test@test.com').resolves('user-1')
  await middlewareTest(
    t,
    typingLessonsComplete,
    {
      method: 'POST',
      body: { email: 'test@test.com' },
      headers: { 'x-utype-webhook-secret': 'secret' }
    },
    204
  )
  const { utypeCompletions } = mockdatabase.getData()
  const timestamp = utypeCompletions['user-1'].completedAt
  t.deepEqual(
    utypeCompletions,
    {
      'user-1': {
        ucoins: 200,
        completedAt: timestamp
      }
    }
  )
})
