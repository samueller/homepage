module Page.EditProjectStep exposing (main)

import Html exposing (..)
import Html.Attributes exposing (class, value, id)
import Material
import Material.Grid as Grid
import Material.Dialog as Dialog
import Material.Icon as Icon
import Material.Menu as Menu
import Material.Options as Options
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.View as View
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Model as UModel
import UCode.Msg
import UCode.Firebase as UFirebase
import UCode.Data as Data
import UCode.Sub as USub
import Types.Lesson as Lesson
import Types.Chapter as Chapter
import Types.Milestone as Milestone
import Types.Instruction as Instruction
import Types.Project as Project
import Util.Heading as Heading


main : Program UModel.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUserAndData SharedMsg initialModel GotProjectStep "projectSteps"
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialModel : UModel.SharedModelFirebaseUser -> Model
initialModel =
    Model Nothing Nothing Nothing (Browser.queryParam "lesson") (Browser.intQueryParam "number") Browser.queryId Nothing [] False NoDialog


type DialogState
    = NoDialog
    | New Project.SubmissionField
    | Edit Data.Id Project.SubmissionField
    | DeleteConfirmation Data.Id String


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , lessonId : Data.Id
    , number : Int
    , id : Data.Id
    , projectStep : Maybe Project.Step
    , projectSubmissionFields : List ( Data.Id, Project.SubmissionField )
    , updating : Bool
    , dialog : DialogState
    , sharedModel : UModel.SharedModelFirebaseUser
    }


type Msg
    = SharedMsg UCode.Msg.Msg
    | Mdl (Material.Msg Msg)
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | GotProjectStep (Result Firebase.Errors.Error Types.Snapshot)
    | AddedSubmissionField Types.Snapshot
    | ChangedSubmissionField Types.Snapshot
    | RemovedSubmissionField Types.Snapshot
    | MoveSubmissionField Data.Id Int
    | MovedSubmissionField (Result Firebase.Errors.Error ())
    | InputInstruction String
    | InputRubric String
    | InputName String
    | InputLines Int
    | Update
    | Updated (Result Firebase.Errors.Error ())
    | NewSubmissionFieldDialog
    | EditSubmissionFieldDialog Data.Id Project.SubmissionField
    | DeleteSubmissionFieldDialog Data.Id String
    | CreateSubmissionField Project.SubmissionField
    | UpdateSubmissionField Data.Id Project.SubmissionField
    | DeleteSubmissionField Data.Id
    | Cancel
    | UpdatedSubmissionField (Result Firebase.Errors.Error ())


updatedDialog : (Project.SubmissionField -> Project.SubmissionField) -> Model -> Model
updatedDialog updateFunc model =
    case model.dialog of
        Edit id submissionField ->
            { model | dialog = Edit id (updateFunc submissionField) }

        New submissionField ->
            { model | dialog = New (updateFunc submissionField) }

        _ ->
            model


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        GotProjectStep (Ok projectStepSnapshot) ->
            Project.recordWithJustStepSnapshot model projectStepSnapshot ! []

        GotProjectStep (Err _) ->
            model ! []

        AddedSubmissionField snapshot ->
            Project.recordWithAddedSubmissionFieldSnapshot model snapshot ! []

        ChangedSubmissionField snapshot ->
            Project.recordWithChangedSubmissionFieldSnapshot model snapshot ! []

        RemovedSubmissionField snapshot ->
            Project.recordWithRemovedSubmissionFieldSnapshot model snapshot ! []

        MoveSubmissionField submissionFieldId number ->
            ( model
            , UFirebase.withDb (Project.updateSubmissionFieldNumber MovedSubmissionField model.id submissionFieldId number) model
            )

        MovedSubmissionField _ ->
            model ! []

        InputInstruction instruction ->
            Project.recordWithMaybeStepInstruction instruction model ! []

        InputRubric rubric ->
            Project.recordWithMaybeStepRubric rubric model ! []

        InputName name ->
            updatedDialog (Project.submissionFieldWithName name) model ! []

        InputLines lines ->
            updatedDialog (Project.submissionFieldWithLines lines) model ! []

        Update ->
            ( { model | updating = True }
            , UFirebase.withDb (Project.updateMaybeStep Updated model.projectStep model.id) model
            )

        Updated _ ->
            { model | updating = False } ! []

        NewSubmissionFieldDialog ->
            { model | dialog = New (Project.nextSubmissionField model.projectSubmissionFields) } ! []

        EditSubmissionFieldDialog submissionFieldId submissionField ->
            { model | dialog = Edit submissionFieldId submissionField } ! []

        DeleteSubmissionFieldDialog submissionFieldId name ->
            { model | dialog = DeleteConfirmation submissionFieldId name } ! []

        CreateSubmissionField submissionField ->
            ( { model | dialog = NoDialog }
            , UFirebase.withDb (Project.createSubmissionField UpdatedSubmissionField model.id submissionField) model
            )

        UpdateSubmissionField id submissionField ->
            ( { model | dialog = NoDialog }
            , UFirebase.withDb (Project.updateSubmissionField UpdatedSubmissionField model.id id submissionField) model
            )

        DeleteSubmissionField id ->
            ( { model | dialog = NoDialog }
            , UFirebase.withDb (Project.deleteSubmissionField UpdatedSubmissionField model.id id) model
            )

        UpdatedSubmissionField _ ->
            model ! []

        Cancel ->
            { model | dialog = NoDialog } ! []

        SharedMsg msg_ ->
            UModel.update SharedMsg msg_ model

        Mdl msg_ ->
            Tuple.mapFirst (\sharedModel -> { model | sharedModel = sharedModel }) <|
                Material.update Mdl msg_ model.sharedModel


viewSubmissionField : Model -> Int -> ( Data.Id, Project.SubmissionField ) -> Html Msg
viewSubmissionField model index ( submissionFieldId, submissionField ) =
    li
        [ value (toString submissionField.number)
        , class "submission_field"
        ]
        [ h5
            [ id ("submission_field_" ++ submissionFieldId) ]
            [ text submissionField.name
            , text " "
            , Menu.render Mdl
                [ 0, index ]
                model.sharedModel.mdl
                [ Menu.ripple, Options.cs "menu-button" ]
                [ View.menuItemOpensDialog
                    (EditSubmissionFieldDialog submissionFieldId submissionField)
                    "edit"
                    "Edit"
                    False
                , View.menuItemOpensDialog
                    (DeleteSubmissionFieldDialog submissionFieldId submissionField.name)
                    "delete"
                    "Delete"
                    False
                ]
            , text " "
            , View.buttonMini model SharedMsg (MoveSubmissionField submissionFieldId (submissionField.number - 1)) False False [ 1, index ] [ Icon.view "arrow_upward" [ Icon.size18 ] ]
            , text " "
            , View.buttonMini model SharedMsg (MoveSubmissionField submissionFieldId (submissionField.number + 1)) False False [ 2, index ] [ Icon.view "arrow_downward" [ Icon.size18 ] ]
            ]
        , p
            [ class "instruction" ]
            [ text ((toString submissionField.lines) ++ " lines for input") ]
        ]


viewFields : Model -> Project.Step -> List (Grid.Cell Msg)
viewFields model projectStep =
    [ View.halfWidthDesktopTabletCell
        [ View.fieldsetH3 "📜 Instruction"
            [ View.textarea model SharedMsg InputInstruction 10 "GitHub-Flavored Markdown" True False [ 0 ] projectStep.instruction ]
        ]
    , View.halfWidthDesktopTabletWideCell
        [ View.fieldsetH3 "👁 Preview"
            [ Instruction.div projectStep.instruction ]
        ]
    , View.halfWidthDesktopTabletCell
        [ View.fieldsetH3 "💯 Rubric"
            [ View.textarea model SharedMsg InputRubric 10 "GitHub-Flavored Markdown" False False [ 1 ] projectStep.rubric ]
        ]
    , View.halfWidthDesktopTabletWideCell
        [ View.fieldsetH3 "👁 Preview"
            [ Instruction.div projectStep.rubric ]
        ]
    , View.fullWidthCell
        [ View.buttonWithText model SharedMsg Update (Project.invalidStep projectStep || model.updating) [ 2 ] "Update"
        , h2 []
            [ text "Submission Fields "
            , View.buttonMini model SharedMsg NewSubmissionFieldDialog False True [ 3 ] [ Icon.i "add" ]
            ]
        , ol [ class "submission_fields" ] <|
            List.indexedMap (viewSubmissionField model) model.projectSubmissionFields
        ]
    ]


viewSubmissionFieldEdit : Model -> Project.SubmissionField -> List (Grid.Cell Msg)
viewSubmissionFieldEdit model submissionField =
    [ View.halfWidthDesktopCell
        [ View.textfield model SharedMsg InputName "Name" True False [ 0, 0 ] submissionField.name ]
    , View.halfWidthDesktopCell
        [ View.intfield model SharedMsg InputLines "# of lines" submissionField.lines [ 1, 0 ] ]
    ]


dialog : Model -> Html Msg
dialog model =
    case model.dialog of
        New submissionField ->
            Dialog.view []
                [ Dialog.title [] [ text "Add Field" ]
                , Dialog.content []
                    [ Grid.grid [] <|
                        viewSubmissionFieldEdit model submissionField
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg (CreateSubmissionField submissionField) (Project.invalidSubmissionField submissionField) [ 5, 0, 0 ] "Add"
                    , View.dialogButtonWithText model SharedMsg Cancel False [ 6, 0, 0 ] "Cancel"
                    ]
                ]

        Edit id submissionField ->
            Dialog.view []
                [ Dialog.title [] [ text "Edit Field" ]
                , Dialog.content []
                    [ Grid.grid [] <|
                        viewSubmissionFieldEdit model submissionField
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg (UpdateSubmissionField id submissionField) (Project.invalidSubmissionField submissionField) [ 5, 0, 0 ] "Update"
                    , View.dialogButtonWithText model SharedMsg Cancel False [ 6, 0, 0 ] "Cancel"
                    ]
                ]

        DeleteConfirmation id name ->
            Dialog.view []
                [ Dialog.title [] [ text "Confirmation" ]
                , Dialog.content []
                    [ text ("Are you sure you want to delete \"" ++ name ++ "\"?") ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg (DeleteSubmissionField id) False [ 1 ] "Delete"
                    , View.dialogButtonWithText model SharedMsg Cancel False [ 2 ] "Cancel"
                    ]
                ]

        NoDialog ->
            Dialog.view [] []


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid [] <|
        Heading.viewActivityEditHeading model "Edit Project Step"
            :: (Data.foldMaybe
                    [ View.spinnerCell ]
                    (viewFields model)
                    model.projectStep
               )
    , dialog model
    ]


firebaseSubs : Model -> UFirebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    UFirebase.objectsSubscriptions
        ("projectStepSubmissionFields/" ++ model.id)
        firebase.db
        AddedSubmissionField
        ChangedSubmissionField
        RemovedSubmissionField


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch <|
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        , USub.firebaseSubs model firebaseSubs
        ]
