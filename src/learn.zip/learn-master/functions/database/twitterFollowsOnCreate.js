const functions = require('firebase-functions')
const createTransaction = require('../utils/createTransaction')
const constants = require('../constants')

const createTwitterFollowTransaction = ({ userId }) =>
  createTransaction(
    userId,
    'twitterFollows',
    null,
    false,
    constants.UCOIN_VALUES.TWITTER_FOLLOW,
    `twitterFollows/${userId}/ucoins`
  )

module.exports =
  functions.database.ref('twitterFollows/{userId}')
    .onCreate((snap, context) =>
      createTwitterFollowTransaction(context.params)
    )

module.exports._test = { createTwitterFollowTransaction }
