module Page.ManageUcoins exposing (main)

import Task
import Html exposing (..)
import Html.Attributes exposing (..)
import List.Extra
import RemoteData exposing (RemoteData)
import UCode.Model exposing (SharedModelFirebaseUser)
import UCode.Msg
import UCode.Firebase exposing (FirebaseApp)
import UCode.Sub
import UCode.View as View
import UCode.Users as Users
import UCode.Data as Data exposing (Id)
import View.Dropdown exposing (Item(..))
import Types.Referral as Referral
import Types.WorkshopReferral as WorkshopReferral
import Types.FacebookLike as FacebookLike
import Types.FacebookWorkshopShare as FacebookWorkshopShare
import Types.UcoinAdjustments as UcoinAdjustments
import Types.TwitterFollow as TwitterFollow
import Types.YelpReview as YelpReview
import Types.ParentTestimonial as ParentTestimonial
import Types.StudentTestimonial as StudentTestimonial
import Types.Manager as Manager
import Types.Admin as Admin
import Util.Form as Form exposing (Form)
import Util.Form.View as Form
import Util.Form.Value as Value exposing (Value)
import Util.Form.Field
import View.Loading


main : Program UCode.Model.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.init SharedMsg init
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }



-- MODEL


type alias ReferralFormValues =
    { referredEmail : Value String
    , referredByEmails : Value String
    }


type alias WorkshopReferralFormValues =
    { referredId : Value String
    , referredByEmails : Value String
    }


type alias FacebookLikeFormValues =
    { userEmail : Value String
    , profileId : Value String
    }


type alias FacebookWorkshopFormValues =
    { userEmail : Value String
    , profileId : Value String
    , eventId : Value String
    }


type alias AdjustmentFormValues =
    { userEmail : Value String
    , reason : Value String
    , ucoins : Value String
    }


type alias TwitterFollowFormValues =
    { userEmail : Value String
    , profileId : Value String
    }


type alias YelpReviewFormValues =
    { userEmail : Value String }


type alias StudentTestimonialFormValues =
    { userEmail : Value String }


type alias ParentTestimonialFormValues =
    { userEmail : Value String }


type TransactionForm
    = None
    | ReferralForm (Form.Model ReferralFormValues)
    | WorkshopReferralForm (Form.Model WorkshopReferralFormValues)
    | FacebookLikeForm (Form.Model FacebookLikeFormValues)
    | FacebookWorkshopForm (Form.Model FacebookWorkshopFormValues)
    | AdjustmentForm (Form.Model AdjustmentFormValues)
    | TwitterFollowForm (Form.Model TwitterFollowFormValues)
    | YelpReviewForm (Form.Model YelpReviewFormValues)
    | StudentTestimonialForm (Form.Model StudentTestimonialFormValues)
    | ParentTestimonialForm (Form.Model ParentTestimonialFormValues)


type alias Model =
    { sharedModel : SharedModelFirebaseUser
    , form : TransactionForm
    , isManager : RemoteData String Bool
    , isAdmin : RemoteData String Bool
    }


init : SharedModelFirebaseUser -> ( Model, Cmd Msg )
init sharedModel =
    { sharedModel = sharedModel
    , form = None
    , isManager = RemoteData.Loading
    , isAdmin = RemoteData.Loading
    }
        ! []


emptyReferralForm : TransactionForm
emptyReferralForm =
    { referredEmail = Value.blank, referredByEmails = Value.blank }
        |> Form.idle
        |> ReferralForm


emptyWorkshopReferralForm : TransactionForm
emptyWorkshopReferralForm =
    { referredId = Value.blank, referredByEmails = Value.blank }
        |> Form.idle
        |> WorkshopReferralForm


emptyFacebookLikeForm : TransactionForm
emptyFacebookLikeForm =
    { userEmail = Value.blank, profileId = Value.blank }
        |> Form.idle
        |> FacebookLikeForm


emptyFacebookWorkshopForm : TransactionForm
emptyFacebookWorkshopForm =
    { userEmail = Value.blank, profileId = Value.blank, eventId = Value.blank }
        |> Form.idle
        |> FacebookWorkshopForm


emptyAdjustmentsForm : TransactionForm
emptyAdjustmentsForm =
    { userEmail = Value.blank, reason = Value.blank, ucoins = Value.blank }
        |> Form.idle
        |> AdjustmentForm


emptyTwitterFollowForm : TransactionForm
emptyTwitterFollowForm =
    { userEmail = Value.blank, profileId = Value.blank }
        |> Form.idle
        |> TwitterFollowForm


emptyYelpReviewForm : TransactionForm
emptyYelpReviewForm =
    { userEmail = Value.blank }
        |> Form.idle
        |> YelpReviewForm


emptyStudentTestimonialForm : TransactionForm
emptyStudentTestimonialForm =
    { userEmail = Value.blank }
        |> Form.idle
        |> StudentTestimonialForm


emptyParentTestimonialForm : TransactionForm
emptyParentTestimonialForm =
    { userEmail = Value.blank }
        |> Form.idle
        |> ParentTestimonialForm



-- UPDATE


type Msg
    = SharedMsg UCode.Msg.Msg
    | ChangedIsManager (Result String Bool)
    | ChangedIsAdmin (Result String Bool)
    | SelectedTransaction String
    | FormChanged TransactionForm
    | SubmitReferralForm String (List String)
    | FinishSubmitReferralForm (Result String ())
    | SubmitWorkshopReferralForm String (List String)
    | FinishSubmitWorkshopReferralForm (Result String ())
    | SubmitFacebookLikeForm String String
    | FinishSubmitFacebookLikeForm (Result String ())
    | SubmitFacebookWorkshopForm String String String
    | FinishSubmitFacebookWorkshopForm (Result String ())
    | SubmitAdjustmentForm String String Int
    | FinishSubmitAdjustmentForm (Result String ())
    | SubmitTwitterFollowForm String String
    | FinishSubmitTwitterFollowForm (Result String ())
    | SubmitYelpReviewForm String
    | FinishSubmitYelpReviewForm (Result String ())
    | SubmitStudentTestimonialForm String
    | FinishSubmitStudentTestimonialForm (Result String ())
    | SubmitParentTestimonialForm String
    | FinishSubmitParentTestimonialForm (Result String ())


setFormState : Form.State -> TransactionForm -> TransactionForm
setFormState state selectedForm =
    case selectedForm of
        None ->
            None

        ReferralForm form ->
            ReferralForm { form | state = state }

        WorkshopReferralForm form ->
            WorkshopReferralForm { form | state = state }

        FacebookLikeForm form ->
            FacebookLikeForm { form | state = state }

        FacebookWorkshopForm form ->
            FacebookWorkshopForm { form | state = state }

        AdjustmentForm form ->
            AdjustmentForm { form | state = state }

        TwitterFollowForm form ->
            TwitterFollowForm { form | state = state }

        YelpReviewForm form ->
            YelpReviewForm { form | state = state }

        StudentTestimonialForm form ->
            StudentTestimonialForm { form | state = state }

        ParentTestimonialForm form ->
            ParentTestimonialForm { form | state = state }


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model

        ChangedIsManager result ->
            { model | isManager = RemoteData.fromResult result } ! []

        ChangedIsAdmin result ->
            { model | isAdmin = RemoteData.fromResult result } ! []

        SelectedTransaction formId ->
            { model
                | form =
                    case formId of
                        "referral" ->
                            emptyReferralForm

                        "workshopReferral" ->
                            emptyWorkshopReferralForm

                        "facebookLike" ->
                            emptyFacebookLikeForm

                        "facebookWorkshop" ->
                            emptyFacebookWorkshopForm

                        "custom" ->
                            emptyAdjustmentsForm

                        "twitterFollow" ->
                            emptyTwitterFollowForm

                        "yelpReview" ->
                            emptyYelpReviewForm

                        "studentTestimonial" ->
                            emptyStudentTestimonialForm

                        "parentTestimonial" ->
                            emptyParentTestimonialForm

                        _ ->
                            model.form
            }
                ! []

        FormChanged form ->
            { model | form = form } ! []

        SubmitReferralForm email emails ->
            { model | form = setFormState Form.Loading model.form }
                ! [ case model.form of
                        ReferralForm form ->
                            Data.foldMaybe
                                Cmd.none
                                (Referral.create
                                    email
                                    emails
                                    model.sharedModel.user
                                    FinishSubmitReferralForm
                                )
                                model.sharedModel.firebaseApp

                        _ ->
                            Cmd.none
                  ]

        FinishSubmitReferralForm (Ok ()) ->
            { model | form = emptyReferralForm }
                |> View.notify "Referral saved" SharedMsg

        FinishSubmitReferralForm (Err error) ->
            { model | form = setFormState (Form.Error error) model.form } ! []

        SubmitWorkshopReferralForm id emails ->
            { model | form = setFormState Form.Loading model.form }
                ! [ case model.form of
                        WorkshopReferralForm form ->
                            WorkshopReferral.create id emails model.sharedModel.user
                                |> Task.attempt FinishSubmitWorkshopReferralForm

                        _ ->
                            Cmd.none
                  ]

        FinishSubmitWorkshopReferralForm (Ok ()) ->
            { model | form = emptyWorkshopReferralForm }
                |> View.notify "Workshop referral saved" SharedMsg

        FinishSubmitWorkshopReferralForm (Err error) ->
            { model | form = setFormState (Form.Error error) model.form } ! []

        SubmitFacebookLikeForm email profileId ->
            { model | form = setFormState Form.Loading model.form }
                ! [ case model.form of
                        FacebookLikeForm form ->
                            Data.foldMaybe
                                Cmd.none
                                (FacebookLike.create
                                    email
                                    profileId
                                    model.sharedModel.user
                                    FinishSubmitFacebookLikeForm
                                )
                                model.sharedModel.firebaseApp

                        _ ->
                            Cmd.none
                  ]

        FinishSubmitFacebookLikeForm (Ok ()) ->
            { model | form = emptyFacebookLikeForm }
                |> View.notify "Facebook like saved" SharedMsg

        FinishSubmitFacebookLikeForm (Err error) ->
            { model | form = setFormState (Form.Error error) model.form } ! []

        SubmitFacebookWorkshopForm email profileId eventId ->
            { model | form = setFormState Form.Loading model.form }
                ! [ case model.form of
                        FacebookWorkshopForm form ->
                            FacebookWorkshopShare.create
                                email
                                profileId
                                eventId
                                model.sharedModel.user
                                |> Task.attempt FinishSubmitFacebookWorkshopForm

                        _ ->
                            Cmd.none
                  ]

        FinishSubmitFacebookWorkshopForm (Ok ()) ->
            { model | form = emptyFacebookWorkshopForm }
                |> View.notify "Facebook event saved" SharedMsg

        FinishSubmitFacebookWorkshopForm (Err error) ->
            { model | form = setFormState (Form.Error error) model.form } ! []

        SubmitAdjustmentForm email reason ucoins ->
            { model | form = setFormState Form.Loading model.form }
                ! [ case model.form of
                        AdjustmentForm form ->
                            Data.foldMaybe
                                Cmd.none
                                (UcoinAdjustments.create
                                    email
                                    reason
                                    ucoins
                                    model.sharedModel.user
                                    FinishSubmitAdjustmentForm
                                )
                                model.sharedModel.firebaseApp

                        _ ->
                            Cmd.none
                  ]

        FinishSubmitAdjustmentForm (Ok ()) ->
            { model | form = emptyAdjustmentsForm }
                |> View.notify "Custom UCoins saved" SharedMsg

        FinishSubmitAdjustmentForm (Err error) ->
            { model | form = setFormState (Form.Error error) model.form } ! []

        SubmitTwitterFollowForm email profileId ->
            { model | form = setFormState Form.Loading model.form }
                ! [ TwitterFollow.create email profileId model.sharedModel.user
                        |> Task.attempt FinishSubmitTwitterFollowForm
                  ]

        FinishSubmitTwitterFollowForm (Ok ()) ->
            { model | form = emptyTwitterFollowForm }
                |> View.notify "Twitter follow saved" SharedMsg

        FinishSubmitTwitterFollowForm (Err error) ->
            { model | form = setFormState (Form.Error error) model.form } ! []

        SubmitYelpReviewForm email ->
            { model | form = setFormState Form.Loading model.form }
                ! [ YelpReview.create email model.sharedModel.user
                        |> Task.attempt FinishSubmitYelpReviewForm
                  ]

        FinishSubmitYelpReviewForm (Ok ()) ->
            { model | form = emptyYelpReviewForm }
                |> View.notify "Yelp review saved" SharedMsg

        FinishSubmitYelpReviewForm (Err error) ->
            { model | form = setFormState (Form.Error error) model.form } ! []

        SubmitStudentTestimonialForm email ->
            { model | form = setFormState Form.Loading model.form }
                ! [ StudentTestimonial.create email model.sharedModel.user
                        |> Task.attempt FinishSubmitStudentTestimonialForm
                  ]

        FinishSubmitStudentTestimonialForm (Ok ()) ->
            { model | form = emptyStudentTestimonialForm }
                |> View.notify "Student Testimonial saved" SharedMsg

        FinishSubmitStudentTestimonialForm (Err error) ->
            { model | form = setFormState (Form.Error error) model.form } ! []

        SubmitParentTestimonialForm email ->
            { model | form = setFormState Form.Loading model.form }
                ! [ ParentTestimonial.create email model.sharedModel.user
                        |> Task.attempt FinishSubmitParentTestimonialForm
                  ]

        FinishSubmitParentTestimonialForm (Ok ()) ->
            { model | form = emptyParentTestimonialForm }
                |> View.notify "Parent Testimonial saved" SharedMsg

        FinishSubmitParentTestimonialForm (Err error) ->
            { model | form = setFormState (Form.Error error) model.form } ! []



-- SUBSCRIPTIONS


firebaseSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    let
        uid =
            model.sharedModel.user.uid
    in
        Sub.batch
            [ Manager.subIsManager uid ChangedIsManager firebase
            , Admin.subIsAdmin uid ChangedIsAdmin firebase
            ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , UCode.Sub.firebaseSubs model firebaseSubs
        ]



-- VIEW


isSubmitting : TransactionForm -> Bool
isSubmitting form =
    case form of
        None ->
            False

        ReferralForm form ->
            form.state == Form.Loading

        WorkshopReferralForm form ->
            form.state == Form.Loading

        FacebookLikeForm form ->
            form.state == Form.Loading

        FacebookWorkshopForm form ->
            form.state == Form.Loading

        AdjustmentForm form ->
            form.state == Form.Loading

        TwitterFollowForm form ->
            form.state == Form.Loading

        YelpReviewForm form ->
            form.state == Form.Loading

        StudentTestimonialForm form ->
            form.state == Form.Loading

        ParentTestimonialForm form ->
            form.state == Form.Loading


formToId : TransactionForm -> Maybe String
formToId form =
    case form of
        None ->
            Nothing

        ReferralForm _ ->
            Just "referral"

        WorkshopReferralForm _ ->
            Just "workshopReferral"

        FacebookLikeForm _ ->
            Just "facebookLike"

        FacebookWorkshopForm _ ->
            Just "facebookWorkshop"

        AdjustmentForm _ ->
            Just "custom"

        TwitterFollowForm _ ->
            Just "twitterFollow"

        YelpReviewForm _ ->
            Just "yelpReview"

        StudentTestimonialForm _ ->
            Just "studentTestimonial"

        ParentTestimonialForm _ ->
            Just "parentTestimonial"


viewDropdown : Bool -> TransactionForm -> Html Msg
viewDropdown admin form =
    View.Dropdown.render
        { placeholder = ""
        , options =
            [ Option { text = "Referral", id = "referral", disabled = False }
            , Option { text = "Workshop Referral", id = "workshopReferral", disabled = False }
            , Option { text = "Facebook Like", id = "facebookLike", disabled = False }
            , Option { text = "Facebook Workshop Event Share", id = "facebookWorkshop", disabled = False }
            , Option { text = "Yelp Review", id = "yelpReview", disabled = False }
            , Option { text = "Twitter Follow", id = "twitterFollow", disabled = False }
            , Option { text = "Parent Testimonial", id = "parentTestimonial", disabled = False }
            , Option { text = "Student Testimonial", id = "studentTestimonial", disabled = False }
            ]
                ++ (if admin then
                        [ Option { text = "Custom", id = "custom", disabled = False } ]
                    else
                        []
                   )
        , onSelect = SelectedTransaction
        , selected = formToId form
        , disabled = isSubmitting form
        }



-- FIELDS


nonEmptyParser : String -> Result String String
nonEmptyParser string =
    let
        trimmed =
            String.trim string
    in
        if trimmed /= "" then
            Ok trimmed
        else
            Err "This field is required"


emailField :
    (values -> Value String)
    -> (Value String -> values -> values)
    -> Util.Form.Field.TextFieldAttributes
    -> Form values String
emailField value update attributes =
    Form.emailField
        { parser = nonEmptyParser
        , value = value
        , update = update
        , attributes = attributes
        }


multiEmailField :
    (values -> Value String)
    -> (Value String -> values -> values)
    -> Util.Form.Field.TextFieldAttributes
    -> Form values (List String)
multiEmailField value update attributes =
    Form.textField
        { parser =
            (\input ->
                let
                    emails =
                        String.split "," input
                            |> List.map String.trim
                            |> List.filter ((/=) "")
                            |> List.Extra.unique
                in
                    if List.length emails /= 0 then
                        Ok emails
                    else
                        Err "This can't be empty"
            )
        , value = value
        , update = update
        , attributes = attributes
        }



-- FORMS (built from fields)


referralForm : Form ReferralFormValues Msg
referralForm =
    Form.empty SubmitReferralForm
        |> Form.append
            (emailField
                .referredEmail
                (\v r -> { r | referredEmail = v })
                { label = "Referred Student's Email"
                , placeholder = ""
                }
            )
        |> Form.append
            (multiEmailField
                .referredByEmails
                (\v r -> { r | referredByEmails = v })
                { label = "Referred By Students' Emails"
                , placeholder = "email1@example.com, email2@example.com"
                }
            )


workshopReferralForm : Form WorkshopReferralFormValues Msg
workshopReferralForm =
    Form.empty SubmitWorkshopReferralForm
        |> Form.append
            (Form.textField
                { parser = nonEmptyParser
                , value = .referredId
                , update = \v r -> { r | referredId = v }
                , attributes =
                    { label = "EventBright ID of referred non-member"
                    , placeholder = ""
                    }
                }
            )
        |> Form.append
            (multiEmailField
                .referredByEmails
                (\v r -> { r | referredByEmails = v })
                { label = "Referred By Students' Emails"
                , placeholder = "email1@example.com, email2@example.com"
                }
            )


facebookLikeForm : Form FacebookLikeFormValues Msg
facebookLikeForm =
    Form.empty SubmitFacebookLikeForm
        |> Form.append
            (emailField
                .userEmail
                (\v r -> { r | userEmail = v })
                { label = "Student's Email"
                , placeholder = ""
                }
            )
        |> Form.append
            (Form.textField
                { parser = Ok
                , value = .profileId
                , update = \v r -> { r | profileId = v }
                , attributes =
                    { label = "Facebook Profile ID"
                    , placeholder = "Ex: scottmueller"
                    }
                }
            )


facebookWorkshopForm : Form FacebookWorkshopFormValues Msg
facebookWorkshopForm =
    Form.empty SubmitFacebookWorkshopForm
        |> Form.append
            (emailField
                .userEmail
                (\v r -> { r | userEmail = v })
                { label = "Student's Email"
                , placeholder = ""
                }
            )
        |> Form.append
            (Form.textField
                { parser = Ok
                , value = .profileId
                , update = \v r -> { r | profileId = v }
                , attributes =
                    { label = "Facebook Profile ID"
                    , placeholder = "Ex: scottmueller"
                    }
                }
            )
        |> Form.append
            (Form.textField
                { parser = Ok
                , value = .eventId
                , update = \v r -> { r | eventId = v }
                , attributes =
                    { label = "Event ID"
                    , placeholder = "Ex: 2071121702901098"
                    }
                }
            )


adjustmentForm : Form AdjustmentFormValues Msg
adjustmentForm =
    Form.empty SubmitAdjustmentForm
        |> Form.append
            (emailField
                .userEmail
                (\v r -> { r | userEmail = v })
                { label = "Student's Email"
                , placeholder = ""
                }
            )
        |> Form.append
            (Form.textField
                { parser = Ok
                , value = .reason
                , update = \v r -> { r | reason = v }
                , attributes =
                    { label = "Reason"
                    , placeholder = ""
                    }
                }
            )
        |> Form.append
            (Form.textField
                { parser =
                    String.toInt
                        >> Result.mapError (always "Must be a positive or negative integer")
                , value = .ucoins
                , update = \v r -> { r | ucoins = v }
                , attributes =
                    { label = "UCoins"
                    , placeholder = ""
                    }
                }
            )


twitterFollowForm : Form TwitterFollowFormValues Msg
twitterFollowForm =
    Form.empty SubmitTwitterFollowForm
        |> Form.append
            (emailField
                .userEmail
                (\v r -> { r | userEmail = v })
                { label = "Student's email", placeholder = "" }
            )
        |> Form.append
            (Form.textField
                { parser = Ok
                , value = .profileId
                , update = \v r -> { r | profileId = v }
                , attributes =
                    { label = "Twitter Profile ID"
                    , placeholder = ""
                    }
                }
            )


yelpReviewForm : Form YelpReviewFormValues Msg
yelpReviewForm =
    Form.empty SubmitYelpReviewForm
        |> Form.append
            (emailField
                .userEmail
                (\v r -> { r | userEmail = v })
                { label = "Student's email", placeholder = "" }
            )


studentTestimonialForm : Form StudentTestimonialFormValues Msg
studentTestimonialForm =
    Form.empty SubmitStudentTestimonialForm
        |> Form.append
            (emailField
                .userEmail
                (\v r -> { r | userEmail = v })
                { label = "Student's email", placeholder = "" }
            )


parentTestimonialForm : Form ParentTestimonialFormValues Msg
parentTestimonialForm =
    Form.empty SubmitParentTestimonialForm
        |> Form.append
            (emailField
                .userEmail
                (\v r -> { r | userEmail = v })
                { label = "Student's email", placeholder = "" }
            )


viewForm : Model -> Html Msg
viewForm model =
    let
        viewBasicForm type_ config values =
            Form.basic
                { onChange = type_ >> FormChanged
                , action = "Submit"
                , loadingMessage = "Saving..."
                , validation = Form.ValidateOnSubmit
                }
                model.sharedModel.mdl
                (UCode.Msg.Mdl >> SharedMsg)
                config
                values
    in
        case model.form of
            None ->
                text ""

            ReferralForm form ->
                viewBasicForm ReferralForm referralForm form

            WorkshopReferralForm form ->
                viewBasicForm WorkshopReferralForm workshopReferralForm form

            FacebookLikeForm form ->
                viewBasicForm FacebookLikeForm facebookLikeForm form

            FacebookWorkshopForm form ->
                viewBasicForm FacebookWorkshopForm facebookWorkshopForm form

            AdjustmentForm form ->
                viewBasicForm AdjustmentForm adjustmentForm form

            TwitterFollowForm form ->
                viewBasicForm TwitterFollowForm twitterFollowForm form

            YelpReviewForm form ->
                viewBasicForm YelpReviewForm yelpReviewForm form

            StudentTestimonialForm form ->
                viewBasicForm StudentTestimonialForm studentTestimonialForm form

            ParentTestimonialForm form ->
                viewBasicForm ParentTestimonialForm parentTestimonialForm form


viewError : String -> List (Html msg)
viewError error =
    [ h3 [] [ text "Error checking auth" ]
    , p [] [ text error ]
    ]


viewFormSelection : Model -> Bool -> Bool -> List (Html Msg)
viewFormSelection model isAdmin isManager =
    if isManager then
        [ h3 [] [ text "Choose a transaction" ]
        , viewDropdown isAdmin model.form
        , viewForm model
        ]
    else
        [ h3 [] [ text "Access denied" ]
        , p [] [ text "You must be an Academic Director to view this page" ]
        ]


viewMain : Model -> List (Html Msg)
viewMain model =
    RemoteData.succeed (viewFormSelection model)
        |> RemoteData.andMap model.isAdmin
        |> RemoteData.andMap model.isManager
        |> View.Loading.andFork Nothing [ View.Loading.large ] viewError


viewContainer : List (Html Msg) -> Html Msg
viewContainer =
    div
        [ style
            [ ( "max-width", "1200px" )
            , ( "margin", "0 auto 100px" )
            , ( "text-align", "center" )
            ]
        ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ viewMain model |> viewContainer ]
