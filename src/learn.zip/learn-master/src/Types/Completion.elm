module Types.Completion exposing (..)

import Task exposing (Task)
import Dict exposing (Dict)
import Json.Decode as Decode exposing (Decoder)
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Types.Milestone as Milestone


type alias MilestoneCompletion =
    { userId : Id
    , id : Id
    , numberAndName : String
    , completedAt : Int
    , ucoins : Int
    }


type alias ChapterCompletion =
    { userId : Id
    , id : Id
    , numberAndName : String
    , completedAt : Int
    , ucoins : Int
    }


type alias CachedMilestone =
    { centerId : Id
    , completionId : Id
    , userId : Id
    , milestoneId : Id
    , completedAt : Int
    }


milestoneDecoder : Id -> Id -> Decoder MilestoneCompletion
milestoneDecoder userId milestoneId =
    Decode.map3 (MilestoneCompletion userId milestoneId)
        (Decode.field "numberAndName" Decode.string)
        (Decode.field "completedAt" Decode.int)
        (Decode.field "ucoins" Decode.int)


chapterDecoder : Id -> Id -> Decoder ChapterCompletion
chapterDecoder userId chapterId =
    Decode.map3 (ChapterCompletion userId chapterId)
        (Decode.field "numberAndName" Decode.string)
        (Decode.field "completedAt" Decode.int)
        (Decode.field "ucoins" Decode.int)


cachedMilestoneDecoder : Id -> Id -> Decoder CachedMilestone
cachedMilestoneDecoder centerId completionId =
    Decode.map3 (CachedMilestone centerId completionId)
        (Decode.field "userId" Decode.string)
        (Decode.field "milestoneId" Decode.string)
        (Decode.field "completedAt" Decode.int)


getMilestone : Id -> Id -> (Result String MilestoneCompletion -> msg) -> FirebaseApp -> Cmd msg
getMilestone userId milestoneId onFinish =
    UCode.Firebase.valueTask
        [ "milestoneCompletions", userId, milestoneId ]
        (milestoneDecoder userId milestoneId)
        >> Task.attempt onFinish


getChapter : Id -> Id -> (Result String ChapterCompletion -> msg) -> FirebaseApp -> Cmd msg
getChapter userId chapterId onFinish =
    UCode.Firebase.valueTask
        [ "chapterCompletions", userId, chapterId ]
        (chapterDecoder userId chapterId)
        >> Task.attempt onFinish


getMilestonesForUser : Id -> FirebaseApp -> Task String (Dict Id MilestoneCompletion)
getMilestonesForUser id =
    UCode.Firebase.valueTask
        [ "milestoneCompletions", id ]
        (Decode.nullable
            (Data.indexedKeyValueDecoderDict (milestoneDecoder id))
            |> Decode.map (Maybe.withDefault Dict.empty)
        )


getMilestonesByCenter : Id -> FirebaseApp -> Task String (Dict Id CachedMilestone)
getMilestonesByCenter centerId =
    UCode.Firebase.valueTask
        [ "milestoneCompletionsByCenter", centerId ]
        (Decode.nullable
            (Data.indexedKeyValueDecoderDict (cachedMilestoneDecoder centerId))
            |> Decode.map (Maybe.withDefault Dict.empty)
        )


{-| Transforms a Dict of CachedMilestones into a list, grouped by month, then by milestone
-}
groupByMilestone :
    Dict Id CachedMilestone
    -> List ( String, Dict Id (List CachedMilestone) )
groupByMilestone =
    Data.groupEntitiesByMonth .completionId (.completedAt >> toFloat)
        >> Dict.map
            (\_ ->
                Data.groupEntitiesBy .completionId .milestoneId
                    >> Dict.map (\_ -> Dict.values >> List.sortBy .completedAt)
            )
        >> Dict.toList
        >> List.sortBy Tuple.first
        >> List.map (Tuple.mapFirst (\( year, _, month ) -> month ++ " " ++ toString year))
        >> List.reverse


{-| Fetches the cached milestone completions and the current milestones. Groups
completions by month, then by milestone number.
-}
getMilestonesForCenterByMonth :
    Id
    -> FirebaseApp
    -> Task String (List ( String, Dict Int (List CachedMilestone) ))
getMilestonesForCenterByMonth centerId app =
    Task.map2
        (\completions milestones ->
            List.map
                (Tuple.mapSecond
                    (Dict.foldl
                        (\milestoneId count completionsWithNumber ->
                            Dict.get
                                milestoneId
                                milestones
                                |> Maybe.map
                                    (\{ number } ->
                                        Dict.insert
                                            number
                                            count
                                            completionsWithNumber
                                    )
                                |> Maybe.withDefault completionsWithNumber
                        )
                        Dict.empty
                    )
                )
                completions
        )
        (getMilestonesByCenter centerId app |> Task.map groupByMilestone)
        (Milestone.getAll app.db |> Task.map Data.entityDict)
