module UCode.Sub exposing (..)

import UCode.Data as Data
import UCode.Model as UModel
import UCode.Firebase as UFirebase
import RemoteData


foldMaybe : (a -> Sub msg) -> Maybe a -> Sub msg
foldMaybe f =
    Data.foldMaybe Sub.none f


fold2Maybes : (a -> b -> Sub msg) -> Maybe a -> Maybe b -> Sub msg
fold2Maybes f =
    Data.fold2Maybes Sub.none f


firebaseSubs : UModel.WithSharedModel m a -> (UModel.WithSharedModel m a -> UFirebase.FirebaseApp -> Sub msg) -> Sub msg
firebaseSubs model f =
    foldMaybe (f model) model.sharedModel.firebaseApp


firebaseSubsIfRemoteData : UModel.WithSharedModelFirebaseUser m -> RemoteData.RemoteData e Bool -> (UModel.WithSharedModelFirebaseUser m -> UFirebase.FirebaseApp -> Sub msg) -> Sub msg
firebaseSubsIfRemoteData model remoteData f =
    case remoteData of
        RemoteData.Success True ->
            firebaseSubs model f

        _ ->
            Sub.none
