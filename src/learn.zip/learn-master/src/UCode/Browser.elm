module UCode.Browser exposing (..)

import Native.Browser


queryParam : String -> String
queryParam =
    Native.Browser.queryParam


queryParamMaybe : String -> Maybe String
queryParamMaybe =
    Native.Browser.queryParamMaybe


fragment : String
fragment =
    Native.Browser.fragment ()


intQueryParam : String -> Int
intQueryParam =
    Maybe.withDefault 1
        << Maybe.andThen Result.toMaybe
        << Maybe.map String.toInt
        << queryParamMaybe


intQueryParamMaybe : String -> Maybe Int
intQueryParamMaybe =
    Maybe.andThen Result.toMaybe
        << Maybe.map String.toInt
        << queryParamMaybe


queryId : String
queryId =
    queryParam "id"


queryIdMaybe : Maybe String
queryIdMaybe =
    queryParamMaybe "id"
