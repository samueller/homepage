const functions = require('firebase-functions')
const createTransaction = require('../utils/createTransaction')

const createUtypeCompletionTransaction = ({ userId }, val) =>
  createTransaction(
    userId,
    'utypeCompletions',
    null,
    false,
    val.ucoins,
    false
  )

module.exports =
  functions.database.ref('utypeCompletions/{userId}')
    .onCreate((snap, context) =>
      createUtypeCompletionTransaction(context.params, snap.val())
    )

module.exports._test = {
  createUtypeCompletionTransaction
}
