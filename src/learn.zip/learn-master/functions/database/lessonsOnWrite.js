const functions = require('firebase-functions')
const db = require('../utils/db')

const cacheByChapter = (lessonId, before, after) => {
  const chapterId = before ? before.chapterId : after.chapterId
  db.ref('lessonNumbers', chapterId, lessonId)
    .set(after && after.number)
}

module.exports =
  functions.database.ref('lessons/{lessonId}')
    .onWrite((change, context) =>
      cacheByChapter(
        context.params.lessonId,
        change.before.val(),
        change.after.val()
      )
    )

module.exports._test = { cacheByChapter }
