module Page.EditMultResp exposing (main)

import Html exposing (Html, nav, header, fieldset, legend, h1, h2, h3, h4, h5, h6, p, strong, text, ol, ul, li, span, br, div, a, img, select, option)
import Html.Attributes exposing (id, class, value, href)
import Material
import Material.Grid as Grid
import Material.Options as Options
import Material.Menu as Menu
import Material.Icon as Icon
import Material.Dialog as Dialog
import Firebase.Database.Types as Types
import Firebase.Errors
import Markdown
import UCode.View as View
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Data as Data
import UCode.Model exposing (User, SharedModelUser)
import UCode.Msg
import UCode.Firebase as UFirebase
import Types.Lesson as Lesson
import Types.Chapter as Chapter
import Types.Milestone as Milestone
import Types.Instruction as Instruction
import Types.MultResp as MultResp
import Util.Heading as Heading


main : Program User Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFireData SharedMsg initialModel GotMultResp "questions/multResp"
        , view = View.viewWithUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialModel : SharedModelUser -> Model
initialModel =
    Model Nothing Nothing Nothing Nothing Browser.queryId (Browser.queryParam "quiz_question") (Browser.queryParam "quiz") (Browser.queryParam "lesson") MultResp.emptyOption Nothing Nothing False


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , multResp : Maybe MultResp.MultResp
    , multRespId : String
    , quizQuestionId : String
    , quizId : String
    , lessonId : String
    , optionToAdd : MultResp.Option
    , optionToEdit : Maybe ( Data.Id, MultResp.Option )
    , optionToDelete : Maybe MultResp.Option
    , updating : Bool
    , sharedModel : SharedModelUser
    }


type Msg
    = SharedMsg UCode.Msg.Msg
    | Mdl (Material.Msg Msg)
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | GotMultResp (Result Firebase.Errors.Error Types.Snapshot)
    | AddedOption Types.Snapshot
    | ChangedOption Types.Snapshot
    | RemovedOption Types.Snapshot
    | EditOptionDialog Data.Id MultResp.Option
    | UpdateOption Data.Id MultResp.Option
    | DeleteOption MultResp.Option
    | ConfirmDeleteOption
    | CanceledEditOption
    | CanceledDelete
    | DeletedOption (Result Firebase.Errors.Error ())
    | InputQuestion String
    | InputOptionContent String
    | InputOptionCorrect Bool
    | InputOptionFeedback String
    | Update
    | Updated (Result Firebase.Errors.Error ())
    | UpdatedOption (Result Firebase.Errors.Error ())
    | AddOption
    | AddedOptionHere String (Result Firebase.Errors.Error ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        GotMultResp (Ok snapshot) ->
            MultResp.recordWithJustMultRespSnapshot model snapshot ! []

        GotMultResp (Err error) ->
            Debug.log "Error retrieving multiple response question" model ! []

        AddedOption snapshot ->
            MultResp.recordMaybeWithOptionSnapshot model snapshot ! []

        ChangedOption snapshot ->
            MultResp.recordMaybeWithChangedOptionSnapshot model snapshot ! []

        RemovedOption snapshot ->
            MultResp.recordMaybeWithRemovedOptionSnapshot model snapshot ! []

        EditOptionDialog optionId option ->
            { model | optionToEdit = Just ( optionId, option ) } ! []

        DeleteOption optionToDelete ->
            { model | optionToDelete = Just optionToDelete } ! []

        ConfirmDeleteOption ->
            case model.optionToDelete of
                Just optionToDelete ->
                    ( model
                    , Data.foldMaybe
                        Cmd.none
                        (\id ->
                            UFirebase.removeNodeMaybe
                                ("multRespOptions/" ++ model.multRespId ++ "/" ++ id)
                                DeletedOption
                                model.sharedModel.firebaseApp
                        )
                        optionToDelete.id
                    )

                Nothing ->
                    ( model, Cmd.none )

        CanceledEditOption ->
            { model | optionToEdit = Nothing } ! []

        CanceledDelete ->
            { model | optionToDelete = Nothing } ! []

        DeletedOption _ ->
            { model | optionToDelete = Nothing } ! []

        InputQuestion question ->
            { model | multResp = Maybe.map (\multResp -> { multResp | question = question }) model.multResp } ! []

        InputOptionContent content ->
            case model.optionToEdit of
                Just ( optionId, option ) ->
                    { model | optionToEdit = Just ( optionId, MultResp.optionWithContent option content ) } ! []

                Nothing ->
                    { model | optionToAdd = MultResp.optionWithContent model.optionToAdd content } ! []

        InputOptionCorrect correct ->
            case model.optionToEdit of
                Just ( optionId, option ) ->
                    { model | optionToEdit = Just ( optionId, MultResp.optionWithCorrect option correct ) } ! []

                Nothing ->
                    { model | optionToAdd = MultResp.optionWithCorrect model.optionToAdd correct } ! []

        InputOptionFeedback feedback ->
            case model.optionToEdit of
                Just ( optionId, option ) ->
                    { model | optionToEdit = Just ( optionId, MultResp.optionWithFeedback option feedback ) } ! []

                Nothing ->
                    { model | optionToAdd = MultResp.optionWithFeedback model.optionToAdd feedback } ! []

        AddOption ->
            ( model, MultResp.pushOption model AddedOptionHere model.multRespId model.optionToAdd )

        UpdateOption optionId option ->
            ( { model | optionToEdit = Nothing }
            , UFirebase.withDb (MultResp.updateOption UpdatedOption model.multRespId optionId option) model
            )

        UpdatedOption _ ->
            model ! []

        AddedOptionHere optionId _ ->
            { model | optionToAdd = MultResp.emptyOption } ! []

        Update ->
            ( { model | updating = True }, MultResp.updateMaybe model Updated )

        Updated _ ->
            ( { model | updating = False }, Cmd.none )

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model

        Mdl msg_ ->
            Tuple.mapFirst (\sharedModel -> { model | sharedModel = sharedModel }) <|
                Material.update Mdl msg_ model.sharedModel


checkMarkOrX : MultResp.Option -> Html Msg
checkMarkOrX option =
    if option.correct then
        span [ class "check" ] [ text "✓" ]
    else
        span [ class "x" ] [ text "✗" ]


viewOption : Model -> Int -> MultResp.Option -> Html Msg
viewOption model index option =
    li
        [ class "quiz_option"
        ]
        [ h5
            [ id ("quiz_option_" ++ (Maybe.withDefault "" option.id)) ]
            [ checkMarkOrX option
            , text " Option "
            , Menu.render Mdl
                [ 0, index ]
                model.sharedModel.mdl
                [ Menu.ripple, Options.cs "menu-button" ]
                [ View.menuItemOpensDialog
                    (EditOptionDialog (Maybe.withDefault "" option.id) option)
                    "edit"
                    "Edit"
                    False
                , View.menuItemOpensDialog
                    (DeleteOption option)
                    "delete"
                    "Delete"
                    False
                ]
            ]
        , Instruction.div option.content
        , h5 [] [ text "💬 Feedback" ]
        , Instruction.div option.feedback
        ]


viewMultResp : Model -> MultResp.MultResp -> List (Grid.Cell Msg)
viewMultResp model multResp =
    [ View.halfWidthDesktopTabletCell
        [ View.fieldsetH3 "📜 Question"
            [ View.textarea model SharedMsg InputQuestion 6 "GitHub-Flavored Markdown" True False [ 0 ] multResp.question ]
        ]
    , View.halfWidthDesktopTabletWideCell
        [ View.fieldsetH3 "👁 Preview"
            [ Instruction.divQuestion multResp.question ]
        ]
    , View.fullWidthCell
        [ View.buttonWithText model SharedMsg Update (MultResp.invalidFields multResp || model.updating) [ 1 ] "Update"
        , h2 []
            [ text "Options "
            , View.buttonMini model SharedMsg CanceledDelete False True [ 2 ] [ Icon.i "add" ]
            ]
        , ul [ class "quiz_options" ] <|
            List.indexedMap (viewOption model) multResp.options
        ]
    ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        (Heading.viewSubActivityEditHeading
            model
            ( "quiz.html?id=" ++ model.quizId ++ "&lesson=" ++ model.lessonId ++ "#quiz_question_" ++ model.quizQuestionId, "Quiz" )
            "Edit Multiple Response Question"
            :: (Data.foldMaybe
                    [ View.fullWidthCell [ View.spinner ] ]
                    (viewMultResp model)
                    model.multResp
               )
        )
    , dialog model
    ]


dialog : Model -> Html Msg
dialog model =
    case ( model.optionToEdit, model.optionToDelete ) of
        ( Just ( optionId, option ), Nothing ) ->
            Dialog.view [ Options.cs "with_preview" ]
                [ Dialog.title [] [ text "Edit Option" ]
                , Dialog.content []
                    [ Grid.grid []
                        [ View.fullWidthCell
                            [ View.checkboxWithText model SharedMsg InputOptionCorrect False [ 1, 0, 0 ] option.correct "Correct?" ]
                        , View.halfWidthDesktopTabletCell
                            [ View.fieldsetH3 "📋 Option"
                                [ View.textarea model SharedMsg InputOptionContent 6 "GitHub-Flavored Markdown" True False [ 2, 0, 0 ] option.content ]
                            ]
                        , View.halfWidthDesktopTabletWideCell
                            [ View.fieldsetH3 "👁 Preview"
                                [ Instruction.divQuestion option.content ]
                            ]
                        , View.halfWidthDesktopTabletCell
                            [ View.fieldsetH3 "💬 Feedback"
                                [ View.textarea model SharedMsg InputOptionFeedback 6 "GitHub-Flavored Markdown" False False [ 3, 0, 0 ] option.feedback ]
                            ]
                        , View.halfWidthDesktopTabletWideCell
                            [ View.fieldsetH3 "👁 Preview"
                                [ Instruction.divQuestion option.feedback ]
                            ]
                        ]
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg (UpdateOption optionId option) False [ 4, 0, 0 ] "Update"
                    , View.dialogButtonWithText model SharedMsg CanceledEditOption False [ 5, 0, 0 ] "Cancel"
                    ]
                ]

        ( _, Just optionToDelete ) ->
            Dialog.view []
                [ Dialog.title [] [ text "Confirmation" ]
                , Dialog.content []
                    [ text "Are you sure you want to delete this option?"
                    , Instruction.div optionToDelete.content
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg ConfirmDeleteOption False [ 1, 0, 0 ] "Delete"
                    , View.dialogButtonWithText model SharedMsg CanceledDelete False [ 2, 0, 0 ] "Cancel"
                    ]
                ]

        _ ->
            Dialog.view [ Options.cs "with_preview" ]
                [ Dialog.title [] [ text "Add Option" ]
                , Dialog.content []
                    [ Grid.grid []
                        [ View.fullWidthCell
                            [ View.checkboxWithText model SharedMsg InputOptionCorrect False [ 1, 0, 0 ] model.optionToAdd.correct "Correct?" ]
                        , View.halfWidthDesktopTabletCell
                            [ View.fieldsetH3 "📋 Option"
                                [ View.textarea model SharedMsg InputOptionContent 6 "GitHub-Flavored Markdown" True False [ 2, 0, 0 ] model.optionToAdd.content ]
                            ]
                        , View.halfWidthDesktopTabletWideCell
                            [ View.fieldsetH3 "👁 Preview"
                                [ Instruction.divQuestion model.optionToAdd.content ]
                            ]
                        , View.halfWidthDesktopTabletCell
                            [ View.fieldsetH3 "💬 Feedback"
                                [ View.textarea model SharedMsg InputOptionFeedback 6 "GitHub-Flavored Markdown" False False [ 3, 0, 0 ] model.optionToAdd.feedback ]
                            ]
                        , View.halfWidthDesktopTabletWideCell
                            [ View.fieldsetH3 "👁 Preview"
                                [ Instruction.divQuestion model.optionToAdd.feedback ]
                            ]
                        ]
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg AddOption False [ 4, 0, 0 ] "Add"
                    , View.dialogButtonWithText model SharedMsg CanceledDelete False [ 5, 0, 0 ] "Cancel"
                    ]
                ]


firebaseSubs : Model -> UFirebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ MultResp.optionsSub firebase.db AddedOption model.multRespId
        , UFirebase.objectsChangedSubscription ("multRespOptions/" ++ model.multRespId) firebase.db ChangedOption
        , UFirebase.objectsRemovedSubscription ("multRespOptions/" ++ model.multRespId) firebase.db RemovedOption
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        , Data.foldMaybe Sub.none (firebaseSubs model) model.sharedModel.firebaseApp
        ]
