module Types.TwitterFollow exposing (create, exists)

import Task exposing (Task)
import Json.Encode as Encode exposing (Value)
import UCode.Data exposing (Id)
import UCode.Model exposing (FirebaseUser)
import UCode.User as User
import Util.Firebase.Database as Db


encoder : String -> FirebaseUser -> Value
encoder profileId manager =
    Encode.object
        [ ( "followedBy", Encode.string profileId )
        , ( "recordedAt", Db.serverTime )
        , ( "recordedByUserId", Encode.string manager.uid )
        , ( "recordedByUserName", Encode.string manager.displayName )
        ]


exists : Id -> Task String Bool
exists userId =
    Db.exists [ "twitterFollows", userId ]


create : String -> String -> FirebaseUser -> Task String ()
create userEmail profileId manager =
    User.validateEmailNoDb userEmail
        |> Task.andThen
            (\user ->
                exists user.id
                    |> Task.mapError (\error -> "Failed to check if \"" ++ userEmail ++ "\" already got credit for a twitter follow: " ++ error)
                    |> Task.andThen
                        (\hasReviewed ->
                            if hasReviewed then
                                Task.fail <| "\"" ++ userEmail ++ "\" has already gotten credit for a twitter follow"
                            else
                                Task.succeed user
                        )
            )
        |> Task.andThen
            (\user ->
                Db.set [ "twitterFollows", user.id ] (encoder profileId manager)
            )
