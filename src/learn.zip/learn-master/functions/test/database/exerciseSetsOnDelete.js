import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const exerciseSetsOnDelete =
  proxyquire(
    '../../database/exerciseSetsOnDelete',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// DELETE CACHE BY USER

test('deleteCacheByActivity removes the related cache', async t => {
  mockdatabase.set({
    exerciseSetActivities: {
      'exercise-set-1': true
    }
  })
  await exerciseSetsOnDelete._test.deleteCacheByActivity(
    { exerciseSetId: 'exercise-set-1' }
  )
  t.falsy(mockdatabase.getData())
})
