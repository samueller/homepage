module Page.GradeSubmission exposing (main)

import Html exposing (..)
import Html.Attributes exposing (..)
import Html.Events exposing (onInput)
import Task exposing (Task)
import Dict
import Material.Options as Options exposing (css)
import Material.Grid as Grid
import RemoteData exposing (RemoteData)
import Types.Activity as Activity
import Types.Chapter as Chapter exposing (Chapter)
import Types.Curricula as Curricula
import Types.Lesson as Lesson exposing (LessonWithId)
import Types.Milestone as Milestone exposing (Milestone)
import Types.Project as Project exposing (Message)
import Types.Student as Student exposing (Student)
import UCode.Browser as Browser
import UCode.Data as Data exposing (Id)
import UCode.Firebase as UFirebase
import UCode.Model as UModel
import UCode.Msg as UMsg
import UCode.Sub as USub
import UCode.Users as Users
import UCode.View as View
import View.Card
import View.Table


main : Program UModel.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init =
            Users.initWithFirebaseUserAndCmd
                SharedMsg
                initialModel
                initialCmd
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


type alias Model =
    { studentId : Id
    , projectStepId : Id
    , sharedModel : UModel.SharedModelFirebaseUser
    , data : PageData
    , lesson : RemoteData String ( Milestone, Chapter, LessonWithId )
    , gradeInput : String
    , feedbackInput : String
    , saveGradeResult : RemoteData String ()
    , saveFeedbackResult : RemoteData String ()
    , error : Maybe String
    }


type alias Submission =
    Project.Submission Id Id String


type alias Project =
    Project.StepExt Project.Fields


type alias LoadingPageData =
    { activityId : String
    , submission : Maybe Submission
    , student : Maybe Student
    , projectStep : Maybe Project

    -- outer Maybe indicates loading, inner Maybe indicates existance
    , activityResult : Maybe (Maybe Activity.Result)
    , feedback : Maybe (Maybe Message)
    }


type alias LoadedPageData =
    { activityId : String
    , submission : Submission
    , student : Student
    , projectStep : Project
    , activityResult : Maybe Activity.Result
    , feedback : Maybe Message
    }


type PageData
    = LoadingActivityId
    | StateLoadingPageData LoadingPageData
    | StateLoadedPageData LoadedPageData
    | ErrorPageData String


initialModel : UModel.SharedModelFirebaseUser -> Model
initialModel sharedModel =
    { studentId = Browser.queryParam "student"
    , projectStepId = Browser.queryParam "project_step"
    , sharedModel = sharedModel
    , data = LoadingActivityId
    , lesson = RemoteData.Loading
    , gradeInput = ""
    , feedbackInput = ""
    , saveGradeResult = RemoteData.NotAsked
    , saveFeedbackResult = RemoteData.NotAsked
    , error = Nothing
    }


initialCmd : UModel.SharedModelFirebaseUser -> Cmd Msg
initialCmd sharedModel =
    Project.activityIdForProjectStep
        (Browser.queryParam "project_step")
        ReceivedActivityId
        sharedModel.firebaseApp


type Msg
    = SharedMsg UMsg.Msg
    | ReceivedActivityId (Result String Id)
    | ReceivedProjectSubmission (Result String Submission)
    | ReceivedStudent (Result String Student)
    | ReceivedProject (Result String Project)
    | ReceivedLesson (Result String ( Milestone, Chapter, LessonWithId ))
    | ReceivedActivityResult (Result String (Maybe Activity.Result))
    | ReceivedFeedback (Result String (Maybe Message))
    | FinishedSaveScore (Result String ())
    | FinishedSaveFeedback (Maybe Id) (Result String ())
    | SetGradeInput String
    | SetFeedbackInput String
    | HandleSubmit


batchWith : a -> List (a -> Cmd msg) -> Cmd msg
batchWith argument =
    List.map (\fn -> fn argument) >> Cmd.batch


fetchPageDataAndLesson : Id -> Model -> Cmd Msg
fetchPageDataAndLesson activityId model =
    batchWith
        model.sharedModel.firebaseApp
        [ Project.getSubmission model.studentId model.projectStepId ReceivedProjectSubmission
        , Student.get model.studentId ReceivedStudent
        , (\maybeApp ->
            case maybeApp of
                Just { db } ->
                    Cmd.batch
                        [ Project.get model.projectStepId db
                            |> Project.andGetFields db
                            |> Task.attempt ReceivedProject
                        , Activity.lessonIdForActivityIdTask activityId db
                            |> Task.andThen
                                (\lessonId -> Curricula.getLessonTask lessonId db)
                            |> Task.attempt ReceivedLesson
                        ]

                Nothing ->
                    Cmd.none
          )
        , Activity.getResult model.studentId activityId ReceivedActivityResult
        , Project.getFirstMessage model.studentId model.projectStepId ReceivedFeedback
        ]


transitionToLoadingPageData : Result String Id -> Model -> ( Model, Cmd Msg )
transitionToLoadingPageData result model =
    case result of
        Ok activityId ->
            { model
                | data =
                    StateLoadingPageData
                        { activityId = activityId
                        , submission = Nothing
                        , student = Nothing
                        , projectStep = Nothing
                        , activityResult = Nothing
                        , feedback = Nothing
                        }
            }
                ! [ fetchPageDataAndLesson activityId model ]

        Err error ->
            { model | data = ErrorPageData error } ! []


transitionToLoadedPageData : Model -> ( Model, Cmd Msg )
transitionToLoadedPageData model =
    case model.data of
        StateLoadingPageData data ->
            Maybe.map5
                (\submission student projectStep activityResult feedback ->
                    { model
                        | data =
                            StateLoadedPageData
                                { activityId = data.activityId
                                , submission = submission
                                , student = student
                                , projectStep = projectStep
                                , activityResult = activityResult
                                , feedback = feedback
                                }
                        , gradeInput =
                            Maybe.map (.score >> toString) activityResult
                                |> Maybe.withDefault ""
                        , feedbackInput =
                            Maybe.map .message feedback
                                |> Maybe.withDefault ""
                    }
                        ! []
                )
                data.submission
                data.student
                data.projectStep
                data.activityResult
                data.feedback
                |> Maybe.withDefault (model ! [])

        _ ->
            model ! []


receivedLessonPageData :
    String
    -> (a -> LoadingPageData -> LoadingPageData)
    -> Result String a
    -> Model
    -> ( Model, Cmd Msg )
receivedLessonPageData label setter result model =
    case ( model.data, result ) of
        ( StateLoadingPageData loadedData, Ok newData ) ->
            { model | data = StateLoadingPageData <| setter newData loadedData }
                |> transitionToLoadedPageData

        ( StateLoadingPageData loadedData, Err error ) ->
            { model | data = ErrorPageData (error ++ " for field " ++ label) } ! []

        ( _, Err error ) ->
            Debug.log "Error loading page data" (error ++ " for field " ++ label)
                |> always (model ! [])

        _ ->
            model ! []


verifyFeedbackInput : String -> Result String String
verifyFeedbackInput input =
    if input == "" then
        Err "You should provde some feedback, even if it's just \"Nice job!\""
    else
        Ok input


verifyGradeInput : String -> Result String Float
verifyGradeInput =
    String.toFloat
        >> Result.mapError (always "Grade must be a valid decimal")
        >> Result.andThen
            (\grade ->
                if grade > 100 || grade < 0 then
                    Err "Grade must be between 0 and 100"
                else
                    Ok grade
            )


verifyInputs : Model -> Result String { feedback : String, grade : Float }
verifyInputs { feedbackInput, gradeInput } =
    Result.map2
        (\feedback grade -> { feedback = feedback, grade = grade })
        (verifyFeedbackInput feedbackInput)
        (verifyGradeInput gradeInput)


saveGradeAndFeedback : Model -> LoadedPageData -> ( Model, Cmd Msg )
saveGradeAndFeedback model data =
    case verifyInputs model of
        Ok { feedback, grade } ->
            { model
                | saveGradeResult = RemoteData.Loading
                , saveFeedbackResult = RemoteData.Loading
                , error = Nothing
            }
                ! [ Data.foldMaybe
                        Cmd.none
                        (Activity.setScore model.studentId data.activityId grade
                            >> Task.attempt FinishedSaveScore
                        )
                        model.sharedModel.firebaseApp
                  , case data.feedback of
                        Just message ->
                            Project.setFeedback
                                model.studentId
                                model.projectStepId
                                { message | message = feedback }
                                (FinishedSaveFeedback Nothing)
                                model.sharedModel.firebaseApp

                        Nothing ->
                            Project.addFeedback
                                model.studentId
                                model.projectStepId
                                { sender = model.sharedModel.user.uid
                                , senderName = model.sharedModel.user.displayName
                                , message = feedback
                                }
                                (Just >> FinishedSaveFeedback)
                                model.sharedModel.firebaseApp
                  ]

        Err error ->
            { model | error = Just error } ! []


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        SharedMsg msg_ ->
            UModel.update SharedMsg msg_ model

        ReceivedActivityId result ->
            transitionToLoadingPageData result model

        ReceivedProjectSubmission result ->
            receivedLessonPageData
                "Submission"
                (\submission data -> { data | submission = Just submission })
                result
                model

        ReceivedStudent result ->
            receivedLessonPageData
                "Student"
                (\student data -> { data | student = Just student })
                result
                model

        ReceivedProject result ->
            receivedLessonPageData
                "Project Step"
                (\projectStep data -> { data | projectStep = Just projectStep })
                result
                model

        ReceivedActivityResult result ->
            receivedLessonPageData
                "Activity Result"
                (\activityResult data -> { data | activityResult = Just activityResult })
                result
                model

        ReceivedFeedback result ->
            receivedLessonPageData
                "Feedback"
                (\feedback data -> { data | feedback = Just feedback })
                result
                model

        ReceivedLesson result ->
            { model | lesson = RemoteData.fromResult result } ! []

        FinishedSaveScore result ->
            { model | saveGradeResult = RemoteData.fromResult result } ! []

        FinishedSaveFeedback maybeNewId result ->
            { model
                | saveFeedbackResult = RemoteData.fromResult result
                , data =
                    case ( model.data, maybeNewId ) of
                        ( StateLoadedPageData data, Just newId ) ->
                            StateLoadedPageData
                                { data
                                    | feedback =
                                        Just
                                            { id = newId
                                            , sender = model.sharedModel.user.uid
                                            , senderName = model.sharedModel.user.displayName
                                            , message = model.feedbackInput
                                            , timestamp = 0 -- TODO this is invalid, but timestamp isn't used currently
                                            }
                                }

                        _ ->
                            model.data
            }
                ! []

        SetGradeInput input ->
            { model | gradeInput = input } ! []

        SetFeedbackInput input ->
            { model | feedbackInput = input } ! []

        HandleSubmit ->
            case model.data of
                StateLoadedPageData data ->
                    saveGradeAndFeedback model data

                _ ->
                    model ! []


firebaseSubs : Model -> UFirebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.none


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , USub.firebaseSubs model firebaseSubs
        ]


viewContainer : List (Html Msg) -> Html Msg
viewContainer =
    div
        [ style
            [ ( "max-width", "1200px" )
            , ( "margin", "0 auto 100px" )
            ]
        ]


viewLoading : Html Msg
viewLoading =
    div []
        [ h1 [] [ text "Loading..." ]
        , View.spinner
        ]


viewTitle : Student -> Html Msg
viewTitle { name } =
    h1 [] [ text <| "Grading " ++ name ++ "'s Project" ]


viewLesson : ( Milestone, Chapter, LessonWithId ) -> Html Msg
viewLesson ( milestone, chapter, lesson ) =
    span
        [ title <|
            "Milestone "
                ++ toString milestone.number
                ++ ": "
                ++ milestone.name
                ++ "\n"
                ++ "Chapter "
                ++ toString chapter.number
                ++ ": "
                ++ chapter.name
                ++ "\n"
                ++ "Lesson "
                ++ toString lesson.number
                ++ ": "
                ++ lesson.name
        ]
        [ text <|
            toString milestone.number
                ++ "."
                ++ toString chapter.number
                ++ "."
                ++ toString lesson.number
        ]


viewSubtitle : RemoteData String ( Milestone, Chapter, LessonWithId ) -> Submission -> Html Msg
viewSubtitle remoteLesson submission =
    case remoteLesson of
        RemoteData.NotAsked ->
            div []
                [ h4 [ style [ ( "color", "gray" ) ] ]
                    [ text <| "Submitted on " ++ Data.formatDateTime submission.timestamp ]
                , h5 [] [ text "Loading lesson..." ]
                , View.spinner
                ]

        RemoteData.Loading ->
            div []
                [ h4 [ style [ ( "color", "gray" ) ] ]
                    [ text <| "Submitted on " ++ Data.formatDateTime submission.timestamp ]
                , h5 [] [ text "Loading lesson..." ]
                , View.spinner
                ]

        RemoteData.Failure error ->
            div []
                [ h4 [ style [ ( "color", "gray" ) ] ]
                    [ text <| "Submitted on " ++ Data.formatDateTime submission.timestamp ]
                , h5
                    [ title error ]
                    [ text "Failed to load lesson" ]
                ]

        RemoteData.Success ( milestone, chapter, lesson ) ->
            h4 [ style [ ( "color", "gray" ) ] ]
                [ text "Submitted for "
                , viewLesson ( milestone, chapter, lesson )
                , text <| " on " ++ Data.formatDateTime submission.timestamp
                ]


viewInstructionsRubric : Project -> Html Msg
viewInstructionsRubric { instruction, rubric } =
    div []
        [ View.Card.basic "INSTRUCTIONS" <| View.markdown instruction
        , View.Card.basic "RUBRIC" <| View.markdown rubric
        ]


viewFieldName : Project.Fields -> String -> Html msg
viewFieldName fields fieldId =
    case Dict.get fieldId fields of
        Just { name } ->
            text name

        Nothing ->
            Options.span [ css "color" "gray" ]
                [ text "Unknown field" ]


viewSubmissionFieldsTable : Project -> Submission -> Html Msg
viewSubmissionFieldsTable project submission =
    View.Table.basic []
        [ View.Table.columnCustom "Field" (Tuple.first >> viewFieldName project.fields) False
        , View.Table.column "Submission" Tuple.second
        ]
        (Dict.toList submission.fields)


viewSubmissionFields : Project -> Submission -> Html Msg
viewSubmissionFields project submission =
    div []
        [ h4 [] [ text "STUDENT'S SUBMISSION" ]
        , if Dict.isEmpty project.fields && Dict.isEmpty submission.fields then
            Options.span [ css "color" "gray", css "font-style" "italic" ]
                [ text "No fields were submitted and this step has no created fields" ]
          else
            viewSubmissionFieldsTable project submission
        ]


viewGradeInput : String -> Maybe Activity.Result -> Maybe String -> Html Msg
viewGradeInput gradeInput maybeResult instructorName =
    div []
        [ h4 [] [ text "GRADE" ]
        , div []
            [ input
                [ type_ "number"
                , onInput SetGradeInput
                , value gradeInput
                , style [ ( "margin-right", "10px" ) ]
                ]
                []
            , text "%"
            ]
        , case maybeResult of
            Just result ->
                span [ style [ ( "font-style", "italic" ) ] ]
                    [ text <|
                        "The grade of "
                            ++ toString result.score
                            ++ (case instructorName of
                                    Just name ->
                                        " was given by " ++ name

                                    Nothing ->
                                        " was given automatically"
                               )
                            ++ " on "
                            ++ Data.formatDateTime result.timestamp
                    ]

            Nothing ->
                text ""
        ]


viewFeedbackInput : String -> Model -> Html Msg
viewFeedbackInput feedbackInput model =
    Grid.grid []
        [ Grid.cell [ Grid.size Grid.All 6, Grid.stretch ]
            [ View.textarea
                model
                SharedMsg
                SetFeedbackInput
                4
                "Feedback (Markdown)"
                False
                False
                [ 0 ]
                feedbackInput
            ]
        , Grid.cell [ Grid.size Grid.All 6, Grid.stretch ]
            [ View.Card.basic
                "FEEDBACK PREVIEW"
                (View.markdown feedbackInput)
            ]
        ]


viewPageError : Maybe String -> Html Msg
viewPageError maybeError =
    case maybeError of
        Just error ->
            Options.div [ css "color" "red" ] [ text error ]

        Nothing ->
            text ""


isSaving : Model -> Bool
isSaving model =
    RemoteData.isLoading model.saveGradeResult
        && RemoteData.isLoading model.saveFeedbackResult


viewSaveButton : Model -> Html Msg
viewSaveButton model =
    if isSaving model then
        div []
            [ View.buttonWithText
                model
                SharedMsg
                HandleSubmit
                True
                [ 1 ]
                "Saving..."
            , View.spinner
            ]
    else
        View.buttonWithText
            model
            SharedMsg
            HandleSubmit
            False
            [ 1 ]
            "Save"


viewError : String -> Html Msg
viewError error =
    div []
        [ h1 [] [ text "Failed to load submission" ]
        , h3 [] [ text <| error ]
        ]


viewMain : Model -> List (Html Msg)
viewMain model =
    case model.data of
        LoadingActivityId ->
            [ viewLoading ]

        StateLoadingPageData data ->
            [ viewLoading ]

        StateLoadedPageData data ->
            [ viewTitle data.student
            , viewSubtitle model.lesson data.submission
            , viewInstructionsRubric data.projectStep
            , viewSubmissionFields data.projectStep data.submission
            , viewGradeInput model.gradeInput
                data.activityResult
                (Maybe.map .senderName data.feedback)
            , viewFeedbackInput model.feedbackInput model
            , viewPageError model.error
            , viewSaveButton model
            ]

        ErrorPageData error ->
            [ viewError error ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ viewContainer <| viewMain model ]
