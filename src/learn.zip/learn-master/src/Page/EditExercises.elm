module Page.EditExercises exposing (main)

import Html exposing (..)
import Html.Attributes exposing (..)
import Material
import Material.Grid as Grid
import Material.Icon as Icon
import Material.Menu as Menu
import Material.Dialog as Dialog
import Material.Options as Options
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.View as View
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Data as Data
import UCode.Model as UModel
import UCode.Msg as UMsg
import UCode.Firebase as UFirebase
import UCode.Sub as USub
import Types.Lesson as Lesson
import Types.Chapter as Chapter
import Types.Milestone as Milestone
import Types.Lti as Lti
import Types.Instruction as Instruction
import Util.Heading as Heading


main : Program UModel.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUser SharedMsg initialModel
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialModel : UModel.SharedModelFirebaseUser -> Model
initialModel =
    Model Nothing Nothing Nothing (Browser.queryParam "lesson") Browser.queryId [] NoDialog


type DialogState
    = NoDialog
    | New Lti.ExerciseLti
    | Edit Data.Id Lti.Lti
    | EditName Data.Id String
    | DeleteConfirmation Data.Id String


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , lessonId : Data.Id
    , id : Data.Id
    , exercises : List ( Data.Id, Lti.ExerciseAndMaybeLti )
    , dialog : DialogState
    , sharedModel : UModel.SharedModelFirebaseUser
    }


type Msg
    = SharedMsg UMsg.Msg
    | Mdl (Material.Msg Msg)
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | AddedExercise Types.Snapshot
    | ChangedExercise Types.Snapshot
    | RemovedExercise Types.Snapshot
    | MoveExercise Data.Id Int
    | MovedExercise (Result Firebase.Errors.Error ())
    | ChangedLti Types.Snapshot
    | InputName String
    | InputUrl String
    | InputKey String
    | InputSecret String
    | NewDialog
    | EditDialog Data.Id Lti.Lti
    | EditNameDialog Data.Id String
    | DeleteDialog Data.Id String
    | Create Lti.ExerciseLti
    | Created (Result Firebase.Errors.Error ())
    | Update Data.Id Lti.Lti
    | UpdateName Data.Id String
    | Updated (Result Firebase.Errors.Error ())
    | Delete Data.Id
    | Deleted (Result Firebase.Errors.Error ())
    | Cancel


updatedLtiToAddOrEdit : (Lti.Lti -> Lti.Lti) -> Model -> Model
updatedLtiToAddOrEdit updateFunc model =
    case model.dialog of
        Edit id lti ->
            { model | dialog = Edit id (updateFunc lti) }

        New { exercise, lti } ->
            { model | dialog = New (Lti.ExerciseLti exercise (updateFunc lti)) }

        _ ->
            model


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        AddedExercise snapshot ->
            ( Data.recordUpdatedFromSnapshot model
                (\model ltiId exercise ->
                    { model
                        | exercises =
                            List.sortBy
                                (.number << .exercise << Tuple.second)
                            <|
                                ( ltiId, Lti.ExerciseAndMaybeLti exercise Nothing )
                                    :: model.exercises
                    }
                )
                Lti.exerciseDecoder
                snapshot
            , Cmd.none
            )

        ChangedExercise snapshot ->
            ( Data.recordUpdatedFromSnapshot model
                (\model ltiId exercise ->
                    { model
                        | exercises =
                            List.sortBy
                                (.number << .exercise << Tuple.second)
                            <|
                                Data.idListUpdated ltiId
                                    (\exerciseLti ->
                                        { exerciseLti | exercise = exercise }
                                    )
                                    model.exercises
                    }
                )
                Lti.exerciseDecoder
                snapshot
            , Cmd.none
            )

        RemovedExercise snapshot ->
            { model | exercises = Data.idListRemovedSnapshot model.exercises snapshot } ! []

        MoveExercise ltiId number ->
            ( model, UFirebase.withModelDb (Lti.updateExerciseNumber MovedExercise ltiId number) model )

        MovedExercise _ ->
            model ! []

        ChangedLti snapshot ->
            ( Data.recordUpdatedFromSnapshot model
                (\model ltiId lti ->
                    { model
                        | exercises =
                            Data.idListUpdated ltiId
                                (\exerciseLti ->
                                    { exerciseLti | lti = Just lti }
                                )
                                model.exercises
                    }
                )
                Lti.decoder
                snapshot
            , Cmd.none
            )

        InputName name ->
            case model.dialog of
                New exerciseLti ->
                    { model | dialog = New (Lti.exerciseLtiWithName name exerciseLti) } ! []

                EditName id _ ->
                    { model | dialog = EditName id name } ! []

                _ ->
                    model ! []

        InputUrl url ->
            updatedLtiToAddOrEdit (Lti.ltiWithUrl url) model ! []

        InputKey key ->
            updatedLtiToAddOrEdit (Lti.ltiWithKey key) model ! []

        InputSecret secret ->
            updatedLtiToAddOrEdit (Lti.ltiWithSecret secret) model ! []

        NewDialog ->
            { model | dialog = New (Lti.emptyExerciseLtiWithNumber (List.length model.exercises + 1)) } ! []

        EditDialog ltiId lti ->
            { model | dialog = Edit ltiId lti } ! []

        EditNameDialog ltiId name ->
            { model | dialog = EditName ltiId name } ! []

        DeleteDialog ltiId name ->
            { model | dialog = DeleteConfirmation ltiId name } ! []

        Create exerciseLti ->
            ( model, UFirebase.withDb (Lti.createExerciseLti Created model.id exerciseLti) model )

        Created _ ->
            model ! []

        Update ltiId lti ->
            ( model, UFirebase.withDb (Lti.update Updated ltiId lti) model )

        UpdateName ltiId name ->
            ( model, UFirebase.withDb (Lti.updateExerciseName Updated model.id ltiId name) model )

        Updated _ ->
            model ! []

        Delete ltiId ->
            ( model, UFirebase.withDb (Lti.deleteExercise Deleted model.id ltiId) model )

        Deleted _ ->
            model ! []

        Cancel ->
            { model | dialog = NoDialog } ! []

        SharedMsg msg_ ->
            UModel.update SharedMsg msg_ model

        Mdl msg_ ->
            Tuple.mapFirst (\sharedModel -> { model | sharedModel = sharedModel }) <|
                Material.update Mdl msg_ model.sharedModel


viewLtiFields : Model -> Lti.Lti -> List (Grid.Cell Msg)
viewLtiFields model lti =
    [ View.halfWidthDesktopCell
        [ View.textfield model
            SharedMsg
            InputUrl
            "URL"
            True
            False
            [ 1, 0, 0 ]
            lti.url
        ]
    , View.halfWidthDesktopCell
        [ View.textfield model
            SharedMsg
            InputKey
            "Key"
            False
            False
            [ 2, 0, 0 ]
            lti.key
        ]
    , View.halfWidthDesktopCell
        [ View.textfield model
            SharedMsg
            InputSecret
            "Secret"
            False
            False
            [ 3, 0, 0 ]
            lti.secret
        ]
    ]


viewFields : Model -> Lti.ExerciseLti -> List (Grid.Cell Msg)
viewFields model exerciseLti =
    View.halfWidthDesktopCell
        [ View.textfield model
            SharedMsg
            InputName
            "Name"
            True
            False
            [ 0, 0, 0 ]
            exerciseLti.exercise.name
        ]
        :: (viewLtiFields model exerciseLti.lti)


viewExercise : Model -> Int -> ( Data.Id, Lti.ExerciseAndMaybeLti ) -> Html Msg
viewExercise model index ( ltiId, { exercise, lti } ) =
    li
        [ class "problem"
        , value (toString exercise.number)
        ]
        [ h4
            [ id ("lti_" ++ ltiId) ]
            [ text exercise.name
            , text " "
            , Menu.render Mdl
                [ 0, index ]
                model.sharedModel.mdl
                [ Menu.ripple, Options.cs "menu-button" ]
                (Data.foldMaybe []
                    (\lti ->
                        [ View.menuItemOpensDialog
                            (EditDialog ltiId lti)
                            "edit"
                            "Edit LTI"
                            False
                        ]
                    )
                    lti
                    ++ [ View.menuItemOpensDialog
                            (EditNameDialog ltiId exercise.name)
                            "edit"
                            "Edit name"
                            False
                       , View.menuItemOpensDialog
                            (DeleteDialog ltiId exercise.name)
                            "delete"
                            "Delete"
                            False
                       ]
                )
            , text " "
            , View.buttonMini model SharedMsg (MoveExercise ltiId (exercise.number - 1)) False False [ 1, index ] [ Icon.view "arrow_upward" [ Icon.size18 ] ]
            , text " "
            , View.buttonMini model SharedMsg (MoveExercise ltiId (exercise.number + 1)) False False [ 2, index ] [ Icon.view "arrow_downward" [ Icon.size18 ] ]
            ]
        ]


dialog : Model -> Html Msg
dialog model =
    case model.dialog of
        New exerciseLti ->
            Dialog.view []
                [ Dialog.title [] [ text "Add Exercise" ]
                , Dialog.content []
                    [ Grid.grid [] <|
                        viewFields model exerciseLti
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg (Create exerciseLti) (Lti.invalidFields exerciseLti.lti || (String.isEmpty exerciseLti.exercise.name)) [ 5, 0, 0 ] "Add"
                    , View.dialogButtonWithText model SharedMsg Cancel False [ 6, 0, 0 ] "Cancel"
                    ]
                ]

        Edit ltiId lti ->
            Dialog.view []
                [ Dialog.title [] [ text "Edit Exercise" ]
                , Dialog.content []
                    [ Grid.grid [] <|
                        viewLtiFields model lti
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg (Update ltiId lti) (Lti.invalidFields lti) [ 5, 0, 0 ] "Update"
                    , View.dialogButtonWithText model SharedMsg Cancel False [ 6, 0, 0 ] "Cancel"
                    ]
                ]

        EditName ltiId name ->
            Dialog.view []
                [ Dialog.title [] [ text "Edit Exercise" ]
                , Dialog.content []
                    [ Grid.grid []
                        [ View.fullWidthCell
                            [ View.textfield model
                                SharedMsg
                                InputName
                                "Name"
                                True
                                False
                                [ 0, 0, 0 ]
                                name
                            ]
                        ]
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg (UpdateName ltiId name) (String.isEmpty name) [ 5, 0, 0 ] "Update"
                    , View.dialogButtonWithText model SharedMsg Cancel False [ 6, 0, 0 ] "Cancel"
                    ]
                ]

        DeleteConfirmation ltiId name ->
            Dialog.view []
                [ Dialog.title [] [ text "Confirmation" ]
                , Dialog.content []
                    [ text ("Are you sure you want to delete \"" ++ name ++ "\"?") ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg (Delete ltiId) False [ 1 ] "Delete"
                    , View.dialogButtonWithText model SharedMsg Cancel False [ 2 ] "Cancel"
                    ]
                ]

        NoDialog ->
            Dialog.view [] []


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        (Heading.viewActivityEditHeading model "Edit Exercises"
            :: [ View.fullWidthCell
                    [ h2 []
                        [ text "Exercises "
                        , View.buttonMini model SharedMsg NewDialog False True [ 0 ] [ Icon.i "add" ]
                        ]
                    , ol [ class "problems" ] (List.indexedMap (viewExercise model) model.exercises)
                    ]
               ]
        )
    , dialog model
    ]


firebaseSubs : Model -> UFirebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ UFirebase.objectsSubscriptions ("exerciseSets/" ++ model.id) firebase.db AddedExercise ChangedExercise RemovedExercise
        , Sub.batch <|
            List.map
                (UFirebase.idSubscription "ltis" firebase ChangedLti << Tuple.first)
                model.exercises
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch <|
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        , USub.firebaseSubs model firebaseSubs
        ]
