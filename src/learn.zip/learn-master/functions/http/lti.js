const functions = require('firebase-functions')
const db = require('../utils/db')

module.exports =
  functions.https.onRequest((req, res) =>
    Promise.resolve()
      .then(() => {
        const xml = req.body.toString()
        /* eslint no-unused-vars: ["error", { "varsIgnorePattern": "kind" }] */
        const [ kind, activityId, userId, ltiId ] =
          xml.match(/<sourcedId>(.+)<\/sourcedId>/)[1].split(' ')
        const score =
          parseFloat(xml.match(/<textString>(.+)<\/textString>/)[1]) * 100
        const activityResultRef =
          db.ref('exerciseSetResults', userId, activityId, ltiId)
        return db.valueOf(activityResultRef)
          .then(result => {
            return activityResultRef
              .set({
                score,
                attempts: ((result && result.attempts) || 0) + 1,
                timestamp: db.ServerValue.TIMESTAMP
              })
          })
          .then(() => res.status(204).end())
      })
      .catch(e => {
        console.error(e)
        res.status(500).send('Internal Error')
      })
  )
