module Util.Heading exposing (activityBreadcrumbs, activityBreadcrumbsSub, activityBreadcrumbsSubFromFirebase, activityEditBreadcrumbs, chapterBreadcrumb, chapterBreadcrumbs, chapterBreadcrumbsSub, chapterEditBreadcrumbs, chapterHeadingOrChapter, editChapterBreadcrumb, editLessonBreadcrumb, editMilestoneBreadcrumb, editMilestonesBreadcrumb, headingCellWithMaybeBreadcrumbs, headingHtmlWithMaybeBreadcrumbs, headingsCellWithMaybeBreadcrumbs, lessonBreadcrumb, lessonNoIdBreadcrumb, milestoneBreadcrumb, milestoneEditBreadcrumbs, milestoneHeadingOrMilestone, milestonesBreadcrumb, viewActivityEditHeading, viewActivityHeading, viewActivityHeadingHtml, viewChapterEditHeading, viewChapterHeading, viewHeadingWithEditBreadcrumbs, viewHeadingsWithEditBreadcrumbs, viewMilestoneEditHeading, viewSubActivityEditHeading)

import Firebase.Database.Types exposing (Snapshot)
import Html exposing (Html, div, h1, h2, h3, text)
import Html.Attributes exposing (class)
import List exposing (singleton)
import Material.Grid exposing (Cell)
import Types.Chapter as Chapter exposing (Chapter, WithMaybeChapter)
import Types.Lesson as Lesson exposing (Lesson, WithLessonId)
import Types.Milestone as Milestone exposing (Milestone, WithMaybeMilestone)
import UCode.Data as Data exposing (Id, foldMaybe, foldMaybes)
import UCode.Firebase exposing (FirebaseApp)
import UCode.Model exposing (WithSharedModel)
import UCode.View as View exposing (breadcrumb, fullWidthCell, maybeBreadcrumbs)
import Util.Curriculum exposing (chapterFromLessonSub, lessonSub, milestoneFromChapterSub)


viewHeadingWithEditBreadcrumbs : Maybe Milestone -> Maybe Chapter -> String -> List (Html msg)
viewHeadingWithEditBreadcrumbs milestone chapter heading =
    [ maybeBreadcrumbs
        [ Just editMilestonesBreadcrumb
        , Maybe.map editMilestoneBreadcrumb milestone
        , Maybe.map editChapterBreadcrumb chapter
        ]
    , h1 [ class "page__heading" ] [ text heading ]
    ]


viewHeadingsWithEditBreadcrumbs : Maybe Milestone -> Maybe Chapter -> String -> Maybe String -> List (Html msg)
viewHeadingsWithEditBreadcrumbs milestone chapter heading subHeading =
    foldMaybes
        [ Just <|
            maybeBreadcrumbs
                [ Just editMilestonesBreadcrumb
                , Maybe.map editMilestoneBreadcrumb milestone
                , Maybe.map editChapterBreadcrumb chapter
                ]
        , Just <| h1 [ class "page__heading" ] [ text heading ]
        , Maybe.map (h3 [] << singleton << text) subHeading
        ]


milestoneEditBreadcrumbs : Milestone.WithMaybeMilestoneNoId r -> Data.Id -> List (Maybe ( String, String ))
milestoneEditBreadcrumbs model milestoneId =
    [ Just editMilestonesBreadcrumb
    , Maybe.map
        (\milestone -> View.breadcrumbFromId "edit/milestone" "Milestone" milestoneId milestone)
        model.milestone
    ]


chapterBreadcrumbs : WithMaybeMilestone (WithMaybeChapter r) -> List (Maybe ( String, String ))
chapterBreadcrumbs model =
    [ Just milestonesBreadcrumb
    , Maybe.map milestoneBreadcrumb model.milestone
    , Maybe.map chapterBreadcrumb model.chapter
    ]


chapterEditBreadcrumbs : WithMaybeMilestone (WithMaybeChapter r) -> List (Maybe ( String, String ))
chapterEditBreadcrumbs model =
    [ Just editMilestonesBreadcrumb
    , Maybe.map editMilestoneBreadcrumb model.milestone
    , Maybe.map editChapterBreadcrumb model.chapter
    ]


activityBreadcrumbs : Maybe Milestone -> Maybe Chapter -> Data.Id -> Maybe Lesson.Lesson -> List (Maybe ( String, String ))
activityBreadcrumbs milestone chapter lessonId lesson =
    [ Just milestonesBreadcrumb
    , Maybe.map milestoneBreadcrumb milestone
    , Maybe.map chapterBreadcrumb chapter
    , Maybe.map (lessonNoIdBreadcrumb lessonId) lesson
    ]


activityEditBreadcrumbs : Maybe Milestone -> Maybe Chapter -> Data.Id -> Maybe Lesson.Lesson -> List (Maybe ( String, String ))
activityEditBreadcrumbs milestone chapter lessonId lesson =
    [ Just editMilestonesBreadcrumb
    , Maybe.map editMilestoneBreadcrumb milestone
    , Maybe.map editChapterBreadcrumb chapter
    , Maybe.map (editLessonBreadcrumb lessonId) lesson
    ]


headingHtmlWithMaybeBreadcrumbs : List (Maybe ( String, String )) -> String -> Html msg
headingHtmlWithMaybeBreadcrumbs breadcrumbs =
    div []
        << (::) (maybeBreadcrumbs breadcrumbs)
        << singleton
        << h1 []
        << singleton
        << text


headingCellWithMaybeBreadcrumbs : List (Maybe ( String, String )) -> String -> Cell msg
headingCellWithMaybeBreadcrumbs breadcrumbs =
    fullWidthCell
        << (::) (maybeBreadcrumbs breadcrumbs)
        << singleton
        << h1 [ class "page__heading" ]
        << singleton
        << text


headingsCellWithMaybeBreadcrumbs : List (Maybe ( String, String )) -> String -> String -> Cell msg
headingsCellWithMaybeBreadcrumbs breadcrumbs heading subHeading =
    fullWidthCell
        [ maybeBreadcrumbs breadcrumbs
        ]


milestoneHeadingOrMilestone : Maybe Milestone.MilestoneNoId -> String
milestoneHeadingOrMilestone milestone =
    Data.foldMaybe
        "Milestone"
        ((++) "Milestone " << toString << .number)
        milestone


chapterHeadingOrChapter : Maybe Chapter -> String
chapterHeadingOrChapter chapter =
    Data.foldMaybe
        "Chapter"
        ((++) "Chapter " << toString << .number)
        chapter


viewMilestoneEditHeading : Milestone.WithMaybeMilestoneNoId r -> Data.Id -> Cell msg
viewMilestoneEditHeading model milestoneId =
    headingsCellWithMaybeBreadcrumbs
        (milestoneEditBreadcrumbs model milestoneId)
        (milestoneHeadingOrMilestone model.milestone)
        (Data.foldMaybe "" .name model.milestone)


viewChapterHeading : WithMaybeMilestone (WithMaybeChapter r) -> Cell msg
viewChapterHeading model =
    headingsCellWithMaybeBreadcrumbs
        (chapterBreadcrumbs model)
        (chapterHeadingOrChapter model.chapter)
        (Data.foldMaybe "" .name model.chapter)


viewChapterEditHeading : WithMaybeMilestone (WithMaybeChapter r) -> Cell msg
viewChapterEditHeading model =
    headingsCellWithMaybeBreadcrumbs
        (chapterEditBreadcrumbs model)
        (chapterHeadingOrChapter model.chapter)
        (Data.foldMaybe "" .name model.chapter)


viewActivityHeading :
    { model
        | milestone : Maybe Milestone
        , chapter : Maybe Chapter
        , lesson : Maybe Lesson
        , lessonId : Id
    }
    -> String
    -> Cell msg
viewActivityHeading { milestone, chapter, lesson, lessonId } =
    headingCellWithMaybeBreadcrumbs <|
        activityBreadcrumbs milestone chapter lessonId lesson


viewActivityHeadingHtml :
    { model
        | milestone : Maybe Milestone
        , chapter : Maybe Chapter
        , lesson : Maybe Lesson
        , lessonId : Id
    }
    -> String
    -> Html msg
viewActivityHeadingHtml { milestone, chapter, lesson, lessonId } =
    headingHtmlWithMaybeBreadcrumbs <|
        activityBreadcrumbs milestone chapter lessonId lesson


viewActivityEditHeading : WithMaybeMilestone (WithMaybeChapter (Lesson.WithMaybeLesson (Lesson.WithLessonId r))) -> String -> Cell msg
viewActivityEditHeading record =
    headingCellWithMaybeBreadcrumbs <|
        activityEditBreadcrumbs record.milestone record.chapter record.lessonId record.lesson


viewSubActivityEditHeading : WithMaybeMilestone (WithMaybeChapter (Lesson.WithMaybeLesson (Lesson.WithLessonId r))) -> ( String, String ) -> String -> Cell msg
viewSubActivityEditHeading record subActivityBreadcrumb =
    headingCellWithMaybeBreadcrumbs <|
        activityEditBreadcrumbs record.milestone record.chapter record.lessonId record.lesson
            ++ [ Just subActivityBreadcrumb ]


lessonBreadcrumb : Lesson.LessonWithId -> ( String, String )
lessonBreadcrumb lesson =
    breadcrumb "lesson" "Lesson" lesson


lessonNoIdBreadcrumb : Data.Id -> Lesson.Lesson -> ( String, String )
lessonNoIdBreadcrumb id lesson =
    View.breadcrumbFromIdAndFragment "chapter" "Lesson" lesson lesson.chapterId ("lesson_" ++ id)


editLessonBreadcrumb : Data.Id -> Lesson.Lesson -> ( String, String )
editLessonBreadcrumb lessonId lesson =
    View.breadcrumbFromIdAndFragment "edit/chapter" "Lesson" lesson lesson.chapterId ("lesson_" ++ lessonId)


chapterBreadcrumb : Chapter -> ( String, String )
chapterBreadcrumb chapter =
    breadcrumb "chapter" "Chapter" chapter


editChapterBreadcrumb : Chapter -> ( String, String )
editChapterBreadcrumb chapter =
    breadcrumb "edit/chapter" "Chapter" chapter


milestoneBreadcrumb : Milestone -> ( String, String )
milestoneBreadcrumb milestone =
    breadcrumb "milestone" "Milestone" milestone


editMilestoneBreadcrumb : Milestone -> ( String, String )
editMilestoneBreadcrumb milestone =
    breadcrumb "edit/milestone" "Milestone" milestone


milestonesBreadcrumb : ( String, String )
milestonesBreadcrumb =
    ( "/milestones.html", "All milestones" )


editMilestonesBreadcrumb : ( String, String )
editMilestonesBreadcrumb =
    ( "/edit/milestones.html", "All milestones" )


chapterBreadcrumbsSub : WithSharedModel (Chapter.WithChapterId (WithMaybeChapter model)) a -> (Snapshot -> msg) -> (Snapshot -> msg) -> FirebaseApp -> Sub msg
chapterBreadcrumbsSub model chapterMsg milestoneMsg firebase =
    Sub.batch <|
        foldMaybes
            [ Just <| Chapter.sub firebase chapterMsg model.chapterId
            , Maybe.map (Milestone.sub firebase milestoneMsg << .milestoneId) model.chapter
            ]


activityBreadcrumbsSubFromFirebase : WithSharedModel (WithLessonId (Lesson.WithMaybeLesson (WithMaybeChapter model))) a -> (Snapshot -> msg) -> (Snapshot -> msg) -> (Snapshot -> msg) -> FirebaseApp -> Sub msg
activityBreadcrumbsSubFromFirebase model lessonMsg chapterMsg milestoneMsg firebase =
    Sub.batch <|
        foldMaybes
            [ Just <| lessonSub firebase lessonMsg model.lessonId
            , Maybe.map (chapterFromLessonSub firebase chapterMsg) model.lesson
            , Maybe.map (milestoneFromChapterSub firebase milestoneMsg) model.chapter
            ]


activityBreadcrumbsSub : WithSharedModel (WithLessonId (Lesson.WithMaybeLesson (WithMaybeChapter model))) a -> (Snapshot -> msg) -> (Snapshot -> msg) -> (Snapshot -> msg) -> Sub msg
activityBreadcrumbsSub model lessonMsg chapterMsg milestoneMsg =
    foldMaybe
        Sub.none
        (activityBreadcrumbsSubFromFirebase model lessonMsg chapterMsg milestoneMsg)
        model.sharedModel.firebaseApp
