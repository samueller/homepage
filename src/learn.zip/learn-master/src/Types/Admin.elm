module Types.Admin exposing (isAdmin, subIsAdmin)

import Json.Decode as Decode
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Util.Firebase.Database as Db
import Task exposing (Task)


isAdmin : Id -> Task String Bool
isAdmin userId =
    Db.exists [ "admins", userId ]


subIsAdmin : Id -> (Result String Bool -> msg) -> FirebaseApp -> Sub msg
subIsAdmin userId =
    UCode.Firebase.subValue
        [ "admins", userId ]
        (Decode.oneOf [ Decode.null False, Decode.succeed True ])
