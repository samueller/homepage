module View.Table
    exposing
        ( Column
        , column
        , columnNumeric
        , columnCustom
        , columnIndexed
        , basic
        , expandable
        , dialog
        )

import Html exposing (Html, text)
import Html.Attributes as Attribute
import Material.Options as Options exposing (Property)
import Material.Table as Table
import Material.Dialog as Dialog


-- COLUMN


type alias Column_ a msg =
    { header : String
    , view : Int -> a -> Html msg
    , numeric : Bool
    }


{-| Describes a single column of the table
-}
type Column a msg
    = Column (Column_ a msg)


column : String -> (a -> String) -> Column a msg
column header view =
    Column { header = header, view = \_ -> view >> text, numeric = False }


columnNumeric : String -> (a -> number) -> Column a msg
columnNumeric header view =
    Column
        { header = header
        , view = \_ -> view >> toString >> text
        , numeric = True
        }


columnCustom : String -> (a -> Html msg) -> Bool -> Column a msg
columnCustom header view numeric =
    Column { header = header, view = \_ -> view, numeric = numeric }


columnIndexed : String -> (Int -> a -> Html msg) -> Bool -> Column a msg
columnIndexed header view numeric =
    Column { header = header, view = view, numeric = numeric }


viewNumeric : Bool -> Options.Property c m
viewNumeric numeric =
    if not numeric then
        Options.cs "mdl-data-table__cell--non-numeric"
    else
        Options.nop


viewColumnHeader : Column a msg -> Html msg
viewColumnHeader (Column { header, numeric }) =
    Table.th [ viewNumeric numeric ] [ text header ]


viewColumnCell : Int -> a -> Column a msg -> Html msg
viewColumnCell index item (Column { header, view, numeric }) =
    Table.td [ viewNumeric numeric ] [ view index item ]



-- TABLE


{-| A simple table, made from a list of data and list of columns that describe
how each column displays a list item.
-}
basic : List (Property {} msg) -> List (Column a msg) -> List a -> Html msg
basic attributes columns items =
    Table.table attributes
        [ Table.thead [] [ Table.tr [] (List.map viewColumnHeader columns) ]
        , Table.tbody []
            (List.indexedMap
                (\index item ->
                    Table.tr [] (List.map (viewColumnCell index item) columns)
                )
                items
            )
        ]


{-| Allows each row to be clicked to reveal more information.
-}
expandable :
    List (Property {} msg)
    -> List (Column a msg)
    -> (a -> Maybe (List (Html msg)))
    -> (a -> msg)
    -> List a
    -> Html msg
expandable attrs columns viewDetails toggle items =
    Table.table attrs
        [ Table.thead [] [ Table.tr [] (List.map viewColumnHeader columns) ]
        , Table.tbody []
            (List.indexedMap
                (\index item ->
                    [ Table.tr
                        [ Options.onClick (toggle item)
                        , Options.css "cursor" "pointer"
                        ]
                        (List.map (viewColumnCell index item) columns)
                    ]
                        ++ (viewDetails item
                                |> Maybe.map
                                    (Table.td
                                        [ List.length columns
                                            |> Attribute.colspan
                                            |> Options.attribute
                                        ]
                                        >> List.singleton
                                        >> Table.tr
                                            [ Options.cs "--no-hover" ]
                                        >> List.singleton
                                    )
                                |> Maybe.withDefault []
                           )
                )
                items
                |> List.concat
            )
        ]


{-| Allows each row to be clicked and open a dialog.
-}
dialog :
    List (Property {} msg)
    -> List (Column a msg)
    -> (a -> msg)
    -> List a
    -> Html msg
dialog attrs columns onClickRow items =
    Table.table attrs
        [ Table.thead [] [ Table.tr [] (List.map viewColumnHeader columns) ]
        , Table.tbody [] <|
            List.indexedMap
                (\index item ->
                    Table.tr
                        [ Options.onClick (onClickRow item)
                        , Options.css "cursor" "pointer"
                        , Dialog.openOn "click"
                        ]
                        (List.map (viewColumnCell index item) columns)
                )
                items
        ]
