import test from 'ava'
import sinon from 'sinon'
import * as functions from 'firebase-functions'

sinon.stub(functions, 'config').returns({
  teamup: {
    token_center_1: 'token-for-center-1',
    token_center_2: 'token-for-center-2'
  }
})

const findTeamupTokenByCenter = require('../../utils/teamup-token-by-center')

test.serial('finds a valid token', t => {
  t.is(findTeamupTokenByCenter('Center_1'), 'token-for-center-1')
})

test.serial('errors on centers with no token', t => {
  t.throws(
    () => findTeamupTokenByCenter('Center_3'),
    { code: 'no-center-token' }
  )
})
