module Types.Quiz exposing (..)

import Json.Encode as Encode
import Json.Decode as Decode exposing (Decoder, field)
import Task
import Navigation
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.Firebase
import UCode.Data as Data exposing (foldMaybe, recordWithSnapshot)
import UCode.Model exposing (WithSharedModel)
import Types.Activity as Activity
import Types.Question as Question


type alias Quiz =
    { id : String
    , questions : List QuizQuestion
    }


type alias Question =
    { questionId : String
    , kind : String
    , number : Int
    }


type alias QuizQuestion =
    { id : String
    , question : Maybe String -- cached from Question
    , questionId : String
    , kind : String
    , number : Int
    }


type alias WithQuiz r q =
    { r | quiz : q }


type alias WithQuizQuestions r qq =
    { r | questions : List qq }


type alias WithQuizQuestionFields qq =
    Data.WithIdAndNumber { qq | questionId : String, kind : String }


type alias WithMaybeQuiz r q =
    { r | quiz : Maybe q }


quizQuestionFieldsEncoder : String -> String -> Int -> Encode.Value
quizQuestionFieldsEncoder questionId kind number =
    Encode.object
        [ ( "questionId", Encode.string questionId )
        , ( "kind", Encode.string kind )
        , ( "number", Encode.int number )
        ]


questionDecoder : Decoder Question
questionDecoder =
    Decode.map3 Question
        (Decode.field "questionId" Decode.string)
        (Decode.field "kind" Decode.string)
        (Decode.field "number" Decode.int)


quizQuestionDecoder : String -> Decoder QuizQuestion
quizQuestionDecoder id =
    Decode.map3 (QuizQuestion id Nothing)
        (Decode.field "questionId" Decode.string)
        (Decode.field "kind" Decode.string)
        (Decode.field "number" Decode.int)


emptyQuestion : Question
emptyQuestion =
    Question "" "" 1


quizWithQuizQuestions : WithQuizQuestions r qq -> List qq -> WithQuizQuestions r qq
quizWithQuizQuestions quiz quizQuestions =
    { quiz | questions = quizQuestions }


quizWithQuizQuestionSorted : WithQuizQuestions q (WithQuizQuestionFields qq) -> WithQuizQuestionFields qq -> WithQuizQuestions q (WithQuizQuestionFields qq)
quizWithQuizQuestionSorted quiz quizQuestion =
    { quiz
        | questions =
            Data.sortedListAddedTo quiz.questions quizQuestion
    }


recordWithQuizQuestion : WithQuiz r (WithQuizQuestions q (WithQuizQuestionFields qq)) -> WithQuizQuestionFields qq -> WithQuiz r (WithQuizQuestions q (WithQuizQuestionFields qq))
recordWithQuizQuestion record quizQuestion =
    { record | quiz = quizWithQuizQuestionSorted record.quiz quizQuestion }


recordWithQuizQuestions : WithQuiz r (WithQuizQuestions q qq) -> List qq -> WithQuiz r (WithQuizQuestions q qq)
recordWithQuizQuestions record quizQuestions =
    { record | quiz = quizWithQuizQuestions record.quiz quizQuestions }


recordWithJustQuiz : WithMaybeQuiz r q -> q -> WithMaybeQuiz r q
recordWithJustQuiz record quiz =
    { record | quiz = Just quiz }


recordWithMaybeQuizTransformed : WithMaybeQuiz r q -> (q -> q) -> WithMaybeQuiz r q
recordWithMaybeQuizTransformed record transform =
    { record | quiz = Maybe.map transform record.quiz }


recordWithQuizQuestionSnapshot : WithQuiz r (WithQuizQuestions q QuizQuestion) -> Types.Snapshot -> WithQuiz r (WithQuizQuestions q QuizQuestion)
recordWithQuizQuestionSnapshot record =
    Data.updateSortedNumberListWithSnapshot
        record
        (recordWithQuizQuestions record)
        record.quiz.questions
        quizQuestionDecoder


recordWithChangedQuizQuestion : WithQuiz r (WithQuizQuestions q QuizQuestion) -> QuizQuestion -> WithQuiz r (WithQuizQuestions q QuizQuestion)
recordWithChangedQuizQuestion record quizQuestion =
    recordWithQuizQuestions record <|
        List.sortBy .number <|
            List.map
                (\quizQuestion_ ->
                    if quizQuestion_.id == quizQuestion.id then
                        { quizQuestion_ | number = quizQuestion.number }
                    else
                        quizQuestion_
                )
                record.quiz.questions


recordWithChangedQuizQuestionSnapshot : WithQuiz r (WithQuizQuestions q QuizQuestion) -> Types.Snapshot -> WithQuiz r (WithQuizQuestions q QuizQuestion)
recordWithChangedQuizQuestionSnapshot record =
    Data.recordWithSnapshot
        record
        (recordWithChangedQuizQuestion record)
        quizQuestionDecoder


recordWithRemovedQuizQuestionSnapshot : WithQuiz r (WithQuizQuestions q QuizQuestion) -> Types.Snapshot -> WithQuiz r (WithQuizQuestions q QuizQuestion)
recordWithRemovedQuizQuestionSnapshot record =
    recordWithQuizQuestions record
        << Data.listWithRemovedSnapshot
            quizQuestionDecoder
            record.quiz.questions


recordWithChangedQuestion : WithQuiz r (WithQuizQuestions q QuizQuestion) -> String -> String -> WithQuiz r (WithQuizQuestions q QuizQuestion)
recordWithChangedQuestion record questionId question =
    recordWithQuizQuestions record <|
        List.map
            (\quizQuestion ->
                if questionId == quizQuestion.questionId then
                    { quizQuestion | question = Just question }
                else
                    quizQuestion
            )
            record.quiz.questions


recordWithChangedQuestionSnapshot : WithQuiz r (WithQuizQuestions q QuizQuestion) -> String -> Types.Snapshot -> WithQuiz r (WithQuizQuestions q QuizQuestion)
recordWithChangedQuestionSnapshot record questionId =
    Data.withSnapshot
        Decode.string
        (recordWithChangedQuestion record questionId)
        record


createQuizMultRespQuestion : (String -> Result Firebase.Errors.Error () -> msg) -> String -> String -> Int -> Types.Database -> Cmd msg
createQuizMultRespQuestion createdMsg question quizId number db =
    let
        questionKeyAndTask =
            UCode.Firebase.keyAndTaskFromPush db "questions/multResp" <|
                Question.fieldsEncoder question

        quizQuestionKeyAndTask =
            UCode.Firebase.keyAndTaskFromPush db ("quizzes/" ++ quizId ++ "/questions") <|
                quizQuestionFieldsEncoder questionKeyAndTask.key "multResp" number
    in
        Task.attempt (createdMsg questionKeyAndTask.key) <|
            Task.map (\_ -> ()) <|
                Task.sequence
                    [ questionKeyAndTask.task, quizQuestionKeyAndTask.task ]


createQuizMultRespQuestionMaybe : WithSharedModel r a -> (String -> Result Firebase.Errors.Error () -> msg) -> String -> String -> Int -> Cmd msg
createQuizMultRespQuestionMaybe model createdMsg question quizId number =
    foldMaybe
        Cmd.none
        (createQuizMultRespQuestion createdMsg question quizId number << .db)
        model.sharedModel.firebaseApp


createWithMultRespQuestion : (Data.Id -> Result Firebase.Errors.Error () -> msg) -> String -> String -> Int -> Types.Database -> Cmd msg
createWithMultRespQuestion createdMsg question lessonId number db =
    let
        questionKeyAndTask =
            UCode.Firebase.keyAndTaskFromPush db "questions/multResp" <|
                Question.fieldsEncoder question

        quizKeysAndTask =
            UCode.Firebase.keysAndTaskFromPushPush db "quizzes" "questions" <|
                quizQuestionFieldsEncoder questionKeyAndTask.key "multResp" 1

        activityTask =
            Activity.pushActivityTask (Tuple.first quizKeysAndTask.keys) "quiz" number lessonId db
    in
        Task.attempt (createdMsg (Tuple.first quizKeysAndTask.keys)) <|
            Task.map (\_ -> ()) <|
                Task.sequence
                    [ questionKeyAndTask.task, quizKeysAndTask.task, activityTask ]


createWithMultRespQuestionMaybe : WithSharedModel r a -> (String -> Result Firebase.Errors.Error () -> msg) -> String -> String -> Int -> Cmd msg
createWithMultRespQuestionMaybe model createdMsg question lessonId number =
    foldMaybe
        Cmd.none
        (createWithMultRespQuestion createdMsg question lessonId number << .db)
        model.sharedModel.firebaseApp


quizQuestionsSub : Types.Database -> (Types.Snapshot -> msg) -> String -> Sub msg
quizQuestionsSub db addedMsg quizId =
    UCode.Firebase.objectsSubscription ("quizzes/" ++ quizId ++ "/questions") db addedMsg


updateQuizQuestionNumber : (Result Firebase.Errors.Error () -> msg) -> WithQuiz (WithSharedModel model a) (WithQuizQuestions (Data.WithId m) qq) -> String -> Int -> Cmd msg
updateQuizQuestionNumber updatedMsg model quizQuestionId number =
    UCode.Firebase.updateValueMaybe
        updatedMsg
        ("quizzes/" ++ model.quiz.id ++ "/questions/" ++ quizQuestionId)
        (Encode.object [ ( "number", Encode.int number ) ])
        model.sharedModel.firebaseApp


editUrlWithLesson : String -> String -> String
editUrlWithLesson lessonId quizId =
    "/edit/quiz.html?id=" ++ quizId ++ "&lesson=" ++ lessonId


openEditUrlWithLesson : String -> String -> Cmd msg
openEditUrlWithLesson lessonId =
    Navigation.load << editUrlWithLesson lessonId
