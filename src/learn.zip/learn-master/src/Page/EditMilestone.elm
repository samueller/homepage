module Page.EditMilestone exposing (main)

import Html exposing (..)
import Html.Attributes exposing (..)
import Material
import Material.Layout as Layout
import Material.Grid as Grid
import Material.Options as Options
import Material.Card as Card
import Json.Decode as Decode
import Json.Encode as Encode
import Task
import Firebase
import Firebase.Authentication
import Firebase.Database
import Firebase.Database.Types as Types
import Firebase.Database.Reference as Reference
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Query as Query
import List
import Navigation
import UCode.View as View
import UCode.Data as Data
import UCode.Browser as Browser
import UCode.Model as UModel
import UCode.Firebase as UFirebase
import UCode.Users as Users
import UCode.Msg as UMsg
import Util.Heading as Heading
import Types.Milestone as Milestone
import Types.Chapter as Chapter


main : Program UModel.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUser SharedMsg initialModel
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


type alias Model =
    { milestone : Maybe Milestone.MilestoneNoId
    , id : Data.Id
    , chapters : List ( Data.Id, Chapter.ChapterNoId )
    , sharedModel : UModel.SharedModelFirebaseUser
    }


initialModel : UModel.SharedModelFirebaseUser -> Model
initialModel =
    Model Nothing Browser.queryId []


type Msg
    = SharedMsg UMsg.Msg
    | ChangedMilestone Types.Snapshot
    | ChangedChapters Types.Snapshot
    | OpenChapter Data.Id


modelWithChaptersSnapshot : Model -> List ( Data.Id, Chapter.ChapterNoId ) -> Model
modelWithChaptersSnapshot model chapters =
    { model | chapters = Data.idListSorted chapters }


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedMilestone snapshot ->
            Data.recordUpdatedFromSnapshotValue model (\model milestone -> { model | milestone = Just milestone }) Milestone.noIdDecoder snapshot ! []

        ChangedChapters snapshot ->
            Data.recordUpdatedFromSnapshotValue model modelWithChaptersSnapshot (Decode.keyValuePairs Chapter.noIdDecoder) snapshot ! []

        OpenChapter chapterId ->
            ( model, Chapter.openEditUrl chapterId )

        SharedMsg msg_ ->
            UModel.update SharedMsg msg_ model


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        [ Heading.viewMilestoneEditHeading model model.id
        , View.fullWidthCell
            [ h1 [] [ text "Chapters" ]
            , ul [ class "cards chapters" ] <|
                List.map (viewChapter model) model.chapters
            ]
        ]
    ]


viewChapter : Model -> ( Data.Id, Chapter.ChapterNoId ) -> Html Msg
viewChapter model ( chapterId, chapter ) =
    li
        [ class "card chapter locked" ]
        [ Card.view
            [ Options.onClick (OpenChapter chapterId)
            , Options.css "cursor" "pointer"
            ]
            [ Card.title [] [ div [] [] ]
            , Card.text []
                [ h2 [ class "number" ] [ text <| toString chapter.number ]
                , h4 [ class "name" ] [ text chapter.name ]
                ]
            ]
        ]


firebaseSubs : Model -> UFirebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ UFirebase.idSubscription "milestones" firebase ChangedMilestone model.id
        , UFirebase.valuesByChildSubscription ChangedChapters "chapters" "milestoneId" firebase (Encode.string model.id)
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , Data.foldMaybe Sub.none (firebaseSubs model) model.sharedModel.firebaseApp
        ]
