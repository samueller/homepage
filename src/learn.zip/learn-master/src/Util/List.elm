module Util.List exposing (flattenPairs)


flattenPairs : List ( a, List b ) -> List ( a, b )
flattenPairs list =
    List.foldl
        (\( a, subList ) flatList ->
            List.concat [ flatList, List.map ((,) a) subList ]
        )
        []
        list
