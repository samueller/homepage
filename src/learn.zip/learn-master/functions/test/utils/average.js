import test from 'ava'
import average from '../../utils/average'

test('average calculates the average of the given numbers', async t => {
  t.is(average([5, 5]), 5)
  t.is(average([5, 7]), 6)
  t.is(average([100, 200, 300, 400, 500]), 300)
})
