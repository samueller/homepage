module Types.Manager exposing (..)

import Task exposing (Task)
import Json.Decode as Decode
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Util.Firebase.Database as Db


type alias ManagerCenter =
    { centerId : Id
    , name : String
    }


subIsManager : Id -> (Result String Bool -> msg) -> FirebaseApp -> Sub msg
subIsManager userId =
    UCode.Firebase.subValue
        [ "managerCenters", userId ]
        (Decode.oneOf [ Decode.null False, Decode.succeed True ])


getCenters : Id -> Task String (List ManagerCenter)
getCenters id =
    Db.getIndexed [ "managerCenters", id ]
        (\centerId -> Decode.map (ManagerCenter centerId) Decode.string)
