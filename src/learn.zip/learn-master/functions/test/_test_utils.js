import firebaseMock from 'firebase-mock'

export const middlewareTest = (t, middleware, req, expectedCode, expectedData) =>
  new Promise(resolve => {
    const res = {
      status: givenCode => {
        t.is(givenCode, expectedCode)
        return {
          send: givenData => {
            t.deepEqual(givenData, expectedData)
            resolve()
          },
          end: () => {
            t.falsy(expectedData)
            resolve()
          }
        }
      }
    }
    middleware(req, res)
  })

export const createAdminMock = () => {
  const mockdatabase = new firebaseMock.MockFirebase()
  mockdatabase.autoFlush(true)
  const adminMock = new firebaseMock.MockFirebaseSdk(
    path => path && path !== '/' ? mockdatabase.child(path) : mockdatabase
  )
  return { adminMock, mockdatabase }
}
