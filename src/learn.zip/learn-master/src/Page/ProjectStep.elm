module Page.ProjectStep exposing (main)

import Dict
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Firebase.Errors
import Html exposing (..)
import Html.Attributes exposing (..)
import Json.Decode as Decode
import Json.Encode as Encode
import List
import Material.Grid as Grid
import Task
import Time exposing (Time)
import Types.Activity as Activity
import Types.Chapter as Chapter
import Types.Instruction as Instruction
import Types.Lesson as Lesson
import Types.Milestone as Milestone
import Types.Project as Project exposing (Message)
import UCode.Browser as Browser
import UCode.Data as Data exposing (Id)
import UCode.Firebase as UFirebase
import UCode.Model
import UCode.Msg
import UCode.Users as Users
import UCode.View as View
import Util.Heading as Heading


main : Program UCode.Model.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUserAndCmd SharedMsg initialModel initialCmds
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialCmds : UCode.Model.SharedModelFirebaseUser -> Cmd Msg
initialCmds sharedModel =
    Project.getSubmission
        sharedModel.user.uid
        Browser.queryId
        ReceivedSubmission
        sharedModel.firebaseApp


type alias Submission =
    Project.Submission Id Id String


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , lessonId : Data.Id
    , lessonResult : Maybe Lesson.Result
    , activityId : Data.Id
    , activity : Maybe Activity.Activity
    , nextActivityId : Maybe Data.Id
    , nextActivity : Maybe Activity.Activity
    , nextLessonId : Maybe Data.Id
    , nextLesson : Maybe Lesson.Lesson
    , nextLessonActivityId : Maybe Data.Id
    , nextLessonActivity : Maybe Activity.Activity
    , id : Data.Id
    , projectStep : Maybe Project.Step
    , projectSubmissionFields : List ( Data.Id, Project.SubmissionField )
    , projectSubmissions : Dict.Dict Data.Id String
    , lastSubmitted : Maybe Int
    , submitting : Bool
    , activityResult : Maybe Activity.Result
    , feedback : Maybe Message
    , sharedModel : UCode.Model.SharedModelFirebaseUser
    }


initialModel : UCode.Model.SharedModelFirebaseUser -> Model
initialModel sharedModel =
    { milestone = Nothing
    , chapter = Nothing
    , lesson = Nothing
    , lessonId = Browser.queryParam "lesson"
    , lessonResult = Nothing
    , activityId = Browser.queryParam "activity"
    , activity = Nothing
    , nextActivityId = Nothing
    , nextActivity = Nothing
    , nextLessonId = Nothing
    , nextLesson = Nothing
    , nextLessonActivityId = Nothing
    , nextLessonActivity = Nothing
    , id = Browser.queryId
    , projectStep = Nothing
    , projectSubmissionFields = []
    , projectSubmissions = Dict.empty
    , lastSubmitted = Nothing
    , submitting = False
    , activityResult = Nothing
    , feedback = Nothing
    , sharedModel = sharedModel
    }


type Msg
    = SharedMsg UCode.Msg.Msg
    | LogError String
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | ChangedLessonResult Types.Snapshot
    | Scored (Result String ())
    | ChangedActivity Types.Snapshot
    | ChangedNextActivity Types.Snapshot
    | ChangedNextLesson Types.Snapshot
    | ChangedNextLessonActivity Types.Snapshot
    | ChangedProjectStep Types.Snapshot
    | ChangedSubmissionFields Types.Snapshot
    | ChangedActivityResult (Maybe Activity.Result)
    | ChangedFeedback (Maybe Message)
    | ReceivedSubmission (Result String Submission)
    | SetLastSubmitted Time
    | InputSubmissionField Data.Id String
    | Submit
    | Submitted (Result Firebase.Errors.Error ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        LogError error ->
            Debug.log "Error:" error
                |> always (model ! [])

        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedLessonResult snapshot ->
            Lesson.recordMaybeLessonResultSnapshot model snapshot ! []

        Scored _ ->
            model ! []

        ChangedActivity snapshot ->
            case Decode.decodeValue Activity.decoder (Snapshot.value snapshot) of
                Ok activity ->
                    { model | activity = Just activity } ! []

                Err _ ->
                    { model | activity = Nothing } ! []

        ChangedNextActivity snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Activity.decoder) (Snapshot.value snapshot) of
                Ok (( activityId, activity ) :: _) ->
                    { model
                        | nextActivityId = Just activityId
                        , nextActivity = Just activity
                    }
                        ! []

                _ ->
                    { model
                        | nextActivityId = Nothing
                        , nextActivity = Nothing
                    }
                        ! []

        ChangedNextLesson snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Decode.int) (Snapshot.value snapshot) of
                Ok (( lessonId, number ) :: _) ->
                    { model | nextLessonId = Just lessonId } ! []

                _ ->
                    { model | nextLessonId = Nothing } ! []

        ChangedNextLessonActivity snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Activity.decoder) (Snapshot.value snapshot) of
                Ok (( activityId, activity ) :: _) ->
                    { model
                        | nextLessonActivityId = Just activityId
                        , nextLessonActivity = Just activity
                    }
                        ! []

                _ ->
                    { model
                        | nextLessonActivityId = Nothing
                        , nextLessonActivity = Nothing
                    }
                        ! []

        ChangedProjectStep snapshot ->
            Project.recordWithJustStepSnapshot model snapshot ! []

        ChangedSubmissionFields snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Project.submissionFieldDecoder) (Snapshot.value snapshot) of
                Ok submissionFields ->
                    { model | projectSubmissionFields = Data.idListSorted submissionFields } ! []

                _ ->
                    ( model
                    , Data.foldMaybe
                        Cmd.none
                        (Activity.setScore model.sharedModel.user.uid model.activityId 100.0
                            >> Task.attempt Scored
                        )
                        model.sharedModel.firebaseApp
                    )

        ChangedActivityResult maybeActivityResult ->
            { model | activityResult = maybeActivityResult } ! []

        ChangedFeedback maybeFeedback ->
            { model | feedback = maybeFeedback } ! []

        ReceivedSubmission result ->
            case result of
                Ok submission ->
                    { model
                        | projectSubmissions = submission.fields
                        , lastSubmitted = Just submission.timestamp
                    }
                        ! []

                Err error ->
                    Debug.log "Failed to fetch submission" error
                        |> always (model ! [])

        SetLastSubmitted time ->
            { model | lastSubmitted = Just (round time) } ! []

        InputSubmissionField submissionFieldId value ->
            { model | projectSubmissions = Dict.insert submissionFieldId value model.projectSubmissions } ! []

        Submit ->
            ( { model | submitting = True }
            , UFirebase.withDb
                (Project.submitStep Submitted model.sharedModel.user.uid model.id (Dict.toList model.projectSubmissions))
                model
            )

        Submitted (Ok _) ->
            { model | submitting = False }
                ! [ Time.now |> Task.perform SetLastSubmitted ]

        Submitted (Err _) ->
            { model | submitting = False } ! []

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model


nextLink : Model -> Maybe String
nextLink model =
    case ( model.nextActivityId, model.nextActivity, model.nextLessonId, model.nextLessonActivityId, model.nextLessonActivity ) of
        ( Just nextActivityId, Just nextActivity, _, _, _ ) ->
            Just (Activity.href nextActivity nextActivityId model.lessonId)

        ( _, _, Just nextLessonId, Just nextActivityId, Just nextActivity ) ->
            Just (Activity.href nextActivity nextActivityId nextLessonId)

        _ ->
            Nothing


viewSubmissionField : Model -> Int -> ( Data.Id, Project.SubmissionField ) -> Html Msg
viewSubmissionField model index ( submissionFieldId, submissionField ) =
    let
        value =
            model.projectSubmissions
                |> Dict.get submissionFieldId
                |> Maybe.withDefault ""
    in
    li [ classList [ ( "input", True ), ( "input-textarea", submissionField.lines > 1 ) ] ]
        [ if submissionField.lines == 1 then
            View.textfield model
                SharedMsg
                (InputSubmissionField submissionFieldId)
                submissionField.name
                False
                model.submitting
                [ 0, index ]
                value

          else
            View.textarea model
                SharedMsg
                (InputSubmissionField submissionFieldId)
                submissionField.lines
                submissionField.name
                False
                model.submitting
                [ 0, index ]
                value
        ]


viewSubmissionFields : Model -> Html Msg
viewSubmissionFields model =
    ol [] <|
        List.indexedMap (viewSubmissionField model) model.projectSubmissionFields


submissionFieldsNotFilled : Model -> Bool
submissionFieldsNotFilled model =
    not <|
        List.all
            (flip Dict.member model.projectSubmissions << Tuple.first)
            model.projectSubmissionFields


viewSubmissionTime : Maybe Int -> Html Msg
viewSubmissionTime maybeTime =
    case maybeTime of
        Just timestamp ->
            div [] [ text <| "You submitted this on " ++ Data.formatDateTime timestamp ]

        Nothing ->
            text ""


viewGrade : Maybe Activity.Result -> Maybe Message -> Html Msg
viewGrade maybeActivityResult maybeFeedback =
    case maybeActivityResult of
        Just activityResult ->
            div []
                ([ h3 [] [ text "Grade:" ]
                 , div [ title <| "Graded on " ++ Data.formatDateTime activityResult.timestamp ]
                    [ text <| toString activityResult.score ++ "%" ]
                 ]
                    ++ (case maybeFeedback of
                            Just feedback ->
                                [ h3 [] [ text "Feedback:" ]
                                , div [] [ View.markdown feedback.message ]
                                ]

                            Nothing ->
                                []
                       )
                )

        Nothing ->
            div [] [ text "It hasn't been graded yet" ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        (case model.projectStep of
            Nothing ->
                [ View.fullWidthCell [ View.spinner ] ]

            Just projectStep ->
                [ Heading.viewActivityHeading model ""
                , View.fullWidthCell
                    [ Instruction.divWithClass "project__instruction" projectStep.instruction
                    , Instruction.divWithClass "rubric" projectStep.rubric
                    , if List.length model.projectSubmissionFields /= 0 then
                        div [ class "grading" ]
                            [ viewSubmissionFields model
                            , hr [] []
                            , viewSubmissionTime model.lastSubmitted
                            , if model.lastSubmitted /= Nothing then
                                viewGrade model.activityResult model.feedback

                              else
                                text ""
                            ]

                      else
                        div [] []
                    , View.activityActions
                        [ viewSubmitButton model
                        , text " "
                        , View.buttonLink model SharedMsg (nextLink model) [ 1 ] [ text "Next Activity" ]
                        ]
                    ]
                ]
        )
    ]


viewSubmitButton : Model -> Html Msg
viewSubmitButton model =
    if List.length model.projectSubmissionFields /= 0 then
        View.button model SharedMsg Submit (submissionFieldsNotFilled model || model.submitting) (List.isEmpty model.projectSubmissionFields) [ 0 ] [ text "Submit" ]

    else
        text ""


activitySubs : Model -> UFirebase.FirebaseApp -> Activity.Activity -> Sub Msg
activitySubs model firebase activity =
    UFirebase.valuesByChildSubscription ChangedNextActivity ("activities/" ++ model.lessonId) "number" firebase (Encode.int (activity.number + 1))


nextLessonActivitySubs : Model -> UFirebase.FirebaseApp -> Data.Id -> Sub Msg
nextLessonActivitySubs model firebase nextLessonId =
    UFirebase.valuesByChildSubscription ChangedNextLessonActivity ("activities/" ++ nextLessonId) "number" firebase (Encode.int 1)


nextLessonSubs : Model -> UFirebase.FirebaseApp -> Lesson.Result -> Lesson.Lesson -> Sub Msg
nextLessonSubs model firebase lessonResult lesson =
    UFirebase.valuesByChildValueSubscription ChangedNextLesson ("lessonNumbers/" ++ lesson.chapterId) firebase (Encode.int (lesson.number + 1))


firebaseSubs : Model -> UFirebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ UFirebase.idSubscription "projectSteps" firebase ChangedProjectStep model.id
        , UFirebase.idSubscription "projectStepSubmissionFields" firebase ChangedSubmissionFields model.id
        , UFirebase.idSubscription ("lessonResults/" ++ model.sharedModel.user.uid) firebase ChangedLessonResult model.lessonId
        , UFirebase.idSubscription ("activities/" ++ model.lessonId) firebase ChangedActivity model.activityId
        , Data.foldMaybe Sub.none (activitySubs model firebase) model.activity
        , Data.foldMaybe Sub.none (nextLessonActivitySubs model firebase) model.nextLessonId
        , Data.fold2Maybes Sub.none (nextLessonSubs model firebase) model.lessonResult model.lesson
        , Activity.onResultChanged model.sharedModel.user.uid model.activityId ChangedActivityResult LogError firebase
        , Project.onFirstMessageChanged model.sharedModel.user.uid model.id ChangedFeedback LogError firebase
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        , Data.foldMaybe Sub.none (firebaseSubs model) model.sharedModel.firebaseApp
        ]
