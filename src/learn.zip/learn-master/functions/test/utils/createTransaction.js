import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const createTransaction =
  proxyquire(
    '../../utils/createTransaction',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

test.serial('initializes ucoins and transaction history', async t => {
  await createTransaction(
    'testUserId',
    'ucoinAdjustments',
    'ucoin-adjustment-1',
    'center-1',
    100,
    false
  )
  const data = mockdatabase.getData()
  t.is(data.users.testUserId.ucoins, 100)
  t.deepEqual(
    data.ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'ucoinAdjustments',
          reasonId: 'ucoin-adjustment-1',
          centerId: 'center-1',
          change: 100,
          timestamp:
            data.ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})

test.serial('increments and inserts new transactions', async t => {
  await createTransaction(
    'testUserId',
    'ucoinAdjustments',
    'ucoin-adjustment-2',
    'center-1',
    100,
    false
  )
  const data = mockdatabase.getData()
  t.is(data.users.testUserId.ucoins, 200)
  t.is(data.ucoinTransactionHistory.testUserId.nextTransactionId, 2)
  t.deepEqual(
    data.ucoinTransactionHistory.testUserId.transactions[1],
    {
      reason: 'ucoinAdjustments',
      reasonId: 'ucoin-adjustment-2',
      centerId: 'center-1',
      change: 100,
      timestamp:
        data.ucoinTransactionHistory.testUserId.transactions[1].timestamp
    }
  )
})
