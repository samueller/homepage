module Page.EditInstruction exposing (main)

import Markdown
import Html exposing (Html, nav, header, fieldset, legend, h1, h2, h3, h4, h5, h6, p, strong, text, ol, ul, li, span, br, div, a, img, select, option)
import Html.Attributes exposing (class)
import List exposing (concat)
import Material.Grid exposing (Cell, grid)
import Firebase.Database.Types exposing (Snapshot)
import Firebase.Errors
import UCode.View as View exposing (fullWidthCell, halfWidthDesktopTabletCell, halfWidthDesktopTabletWideCell, viewWithUser, maybeBreadcrumbs, fillGrid, spinner, markdownOptions, materialSub, textfield, textarea, button, fieldsetH3)
import UCode.Browser as Browser
import UCode.Users as Users exposing (initWithFireData)
import UCode.Data exposing (foldMaybe, foldMaybes, foldFlattenMaybes, sortedListAddedTo, updateSortedNumberListWithSnapshot, recordWithSnapshot)
import UCode.Model exposing (User, SharedModelUser, WithSharedModel)
import UCode.Msg
import Types.Lesson as Lesson
import Types.Chapter as Chapter exposing (Chapter, recordWithJustChapterSnapshot)
import Types.Milestone exposing (Milestone, recordWithJustMilestoneSnapshot)
import Types.Instruction as Instruction exposing (Instruction, recordWithJustInstructionSnapshot, recordWithMaybeInstructionContent)
import Util.Heading as Heading


main : Program User Model Msg
main =
    Html.programWithFlags
        { init = initWithFireData SharedMsg initialModel GotInstruction "instructions"
        , view = viewWithUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialModel : SharedModelUser -> Model
initialModel =
    Model Nothing Nothing Nothing Nothing 0 (Browser.queryParam "lesson")


type alias Model =
    { milestone : Maybe Milestone
    , chapter : Maybe Chapter
    , lesson : Maybe Lesson.Lesson
    , instruction : Maybe Instruction.InstructionWithId
    , tab : Int
    , lessonId : String
    , sharedModel : SharedModelUser
    }


type Msg
    = SharedMsg UCode.Msg.Msg
    | ChangedMilestone Snapshot
    | ChangedChapter Snapshot
    | ChangedLesson Snapshot
    | GotInstruction (Result Firebase.Errors.Error Snapshot)
    | InputContent String
    | Update
    | Updated (Result Firebase.Errors.Error ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            recordWithJustChapterSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            recordWithJustMilestoneSnapshot model snapshot ! []

        GotInstruction (Ok snapshot) ->
            recordWithJustInstructionSnapshot model snapshot ! []

        GotInstruction (Err error) ->
            model ! []

        InputContent content ->
            recordWithMaybeInstructionContent model content ! []

        Update ->
            ( model, Instruction.updateMaybe model Updated )

        Updated _ ->
            ( model, Chapter.maybeOpenEditUrlWithLesson model.lessonId model.chapter )

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model


viewInstructionFields : Model -> Instruction.InstructionWithId -> List (Cell Msg)
viewInstructionFields model instruction =
    [ fullWidthCell
        [ View.buttonWithText model SharedMsg Update (String.isEmpty instruction.content) [ 2 ] "Update" ]
    , halfWidthDesktopTabletCell
        [ fieldsetH3 "📜 Instruction"
            [ textarea model SharedMsg InputContent 20 "GitHub-Flavored Markdown" True False [ 1 ] instruction.content ]
        ]
    , halfWidthDesktopTabletWideCell
        [ fieldsetH3 "👁 Preview"
            [ Markdown.toHtmlWith markdownOptions [ class "instruction" ] instruction.content ]
        ]
    ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ grid []
        (Heading.viewActivityEditHeading model "Edit Instruction"
            :: foldMaybe
                [ fullWidthCell [ spinner ] ]
                (viewInstructionFields model)
                model.instruction
        )
    ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch <|
        [ materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        ]
