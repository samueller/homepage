module Types.MultResp exposing (..)

import Dict
import Set
import Json.Encode as Encode
import Json.Decode as Decode exposing (Decoder, field)
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.Firebase as UFirebase
import UCode.Data as Data exposing (foldMaybe)
import UCode.Model exposing (WithSharedModel)


type alias Question =
    { question : String
    }


type alias MultResp =
    { id : Maybe String
    , options : List Option
    , question : String
    }


type alias Option =
    { id : Maybe String
    , content : String
    , correct : Bool
    , feedback : String
    }


type alias OptionNoId =
    { content : String
    , correct : Bool
    , feedback : String
    }


type alias WithMultResp r =
    { r | multResp : MultResp }


type alias WithMaybeMultResp r =
    { r | multResp : Maybe MultResp }


type alias WithMultRespFields r =
    { r
        | question : String
        , options : List Option
    }


emptyOption : Option
emptyOption =
    Option Nothing "" False ""


questionDecoder : Decoder Question
questionDecoder =
    Decode.map Question
        (Decode.field "question" Decode.string)


decoder : String -> Decoder MultResp
decoder id =
    Decode.map (MultResp (Just id) [])
        (Decode.field "question" Decode.string)


optionDecoder : String -> Decoder Option
optionDecoder id =
    Decode.map3 (Option (Just id))
        (Decode.field "content" Decode.string)
        (Decode.field "correct" Decode.bool)
        (Decode.field "feedback" Decode.string)


optionNoIdDecoder : Decoder OptionNoId
optionNoIdDecoder =
    Decode.map3 OptionNoId
        (Decode.field "content" Decode.string)
        (Decode.field "correct" Decode.bool)
        (Decode.field "feedback" Decode.string)


encoder : MultResp -> Encode.Value
encoder multResp =
    fieldsEncoder multResp.question


fieldsEncoder : String -> Encode.Value
fieldsEncoder question =
    Encode.object
        [ ( "question", Encode.string question )
        ]


optionEncoded : Option -> Encode.Value
optionEncoded option =
    optionFieldsEncoder option.content option.correct option.feedback


optionEncoder : Option -> Encode.Value
optionEncoder =
    optionEncoded


optionFieldsEncoder : String -> Bool -> String -> Encode.Value
optionFieldsEncoder content correct feedback =
    Encode.object
        [ ( "content", Encode.string content )
        , ( "correct", Encode.bool correct )
        , ( "feedback", Encode.string feedback )
        ]


valueFromSelections : List ( Data.Id, Bool ) -> Encode.Value
valueFromSelections =
    Encode.object
        << List.map (Tuple.mapSecond Encode.bool)


valueFromResponse : ( Data.Id, List ( Data.Id, Bool ) ) -> ( Data.Id, Encode.Value )
valueFromResponse ( multRespId, set ) =
    ( multRespId
    , Encode.object [ ( "selections", valueFromSelections set ) ]
    )


valueFromResponses : Dict.Dict Data.Id (List ( Data.Id, Bool )) -> Encode.Value
valueFromResponses dict =
    Encode.object
        [ ( "timestamp", UFirebase.serverTime )
        , ( "multResp"
          , Encode.object <|
                List.map valueFromResponse (Dict.toList dict)
          )
        ]


optionWithContent : Option -> String -> Option
optionWithContent option content =
    { option | content = content }


optionWithCorrect : Option -> Bool -> Option
optionWithCorrect option correct =
    { option | correct = correct }


optionWithFeedback : Option -> String -> Option
optionWithFeedback option feedback =
    { option | feedback = feedback }


recordWithJustMultResp : WithMaybeMultResp r -> MultResp -> WithMaybeMultResp r
recordWithJustMultResp record multResp =
    { record | multResp = Just multResp }


recordMaybeWithOptions : WithMaybeMultResp r -> List Option -> WithMaybeMultResp r
recordMaybeWithOptions record options =
    { record
        | multResp =
            Maybe.map
                (\multResp ->
                    { multResp | options = options }
                )
                record.multResp
    }


recordWithMaybeMultRespTransformed : WithMaybeMultResp r -> (MultResp -> MultResp) -> WithMaybeMultResp r
recordWithMaybeMultRespTransformed record transform =
    { record | multResp = Maybe.map transform record.multResp }


recordWithJustMultRespSnapshot : WithMaybeMultResp r -> Types.Snapshot -> WithMaybeMultResp r
recordWithJustMultRespSnapshot record =
    Data.recordWithSnapshot record (recordWithJustMultResp record) decoder


multRespWithQuestion : String -> MultResp -> MultResp
multRespWithQuestion question multResp =
    { multResp | question = question }


multRespWithOption : Option -> MultResp -> MultResp
multRespWithOption option multResp =
    { multResp | options = option :: multResp.options }


multRespWithChangedOption : Option -> MultResp -> MultResp
multRespWithChangedOption option multResp =
    { multResp
        | options =
            List.map
                (\option_ ->
                    if option_.id == option.id then
                        option
                    else
                        option_
                )
                multResp.options
    }


recordWithChangedOption : WithMaybeMultResp r -> Option -> MultResp -> WithMaybeMultResp r
recordWithChangedOption record option multResp =
    { record | multResp = Just (multRespWithChangedOption option multResp) }


multRespWithRemovedOption : Maybe String -> MultResp -> MultResp
multRespWithRemovedOption optionId multResp =
    { multResp
        | options =
            List.filter
                ((/=) optionId << .id)
                multResp.options
    }


recordWithRemovedOption : WithMaybeMultResp r -> Option -> MultResp -> WithMaybeMultResp r
recordWithRemovedOption record option multResp =
    { record | multResp = Just (multRespWithRemovedOption option.id multResp) }


recordMaybeWithRemovedOption : WithMaybeMultResp r -> Option -> WithMaybeMultResp r
recordMaybeWithRemovedOption record option =
    { record
        | multResp =
            Maybe.map
                (multRespWithRemovedOption option.id)
                record.multResp
    }


recordWithMaybeMultRespQuestion : WithMaybeMultResp r -> String -> WithMaybeMultResp r
recordWithMaybeMultRespQuestion record =
    recordWithMaybeMultRespTransformed record << multRespWithQuestion


recordWithMaybeMultRespOption : WithMaybeMultResp r -> Option -> WithMaybeMultResp r
recordWithMaybeMultRespOption record =
    recordWithMaybeMultRespTransformed record << multRespWithOption


updateMultResp : WithSharedModel model a -> (Result Firebase.Errors.Error () -> msg) -> MultResp -> Cmd msg
updateMultResp model updatedMsg multResp =
    foldMaybe
        Cmd.none
        (\id ->
            UFirebase.updateValueMaybe
                updatedMsg
                ("questions/multResp/" ++ id)
                (encoder multResp)
                model.sharedModel.firebaseApp
        )
        multResp.id


updateMaybe : WithSharedModel (WithMaybeMultResp r) a -> (Result Firebase.Errors.Error () -> msg) -> Cmd msg
updateMaybe model updatedMsg =
    foldMaybe
        Cmd.none
        (updateMultResp model updatedMsg)
        model.multResp


updateOption : (Result Firebase.Errors.Error () -> msg) -> Data.Id -> Data.Id -> Option -> Types.Database -> Cmd msg
updateOption updatedMsg multRespId optionId option =
    UFirebase.updateValue
        ("multRespOptions/" ++ multRespId ++ "/" ++ optionId)
        (optionEncoded option)
        updatedMsg


pushOption : WithSharedModel (WithMaybeMultResp r) a -> (String -> Result Firebase.Errors.Error () -> msg) -> String -> Option -> Cmd msg
pushOption model pushedMsg multRespId option =
    case model.sharedModel.firebaseApp of
        Just firebase ->
            UFirebase.cmdWithKeyFromPush
                ("multRespOptions/" ++ multRespId)
                pushedMsg
                (optionEncoder option)
                firebase.db

        _ ->
            Cmd.none


recordMaybeWithOptionSnapshot : WithMaybeMultResp r -> Types.Snapshot -> WithMaybeMultResp r
recordMaybeWithOptionSnapshot record =
    Data.recordWithSnapshot
        record
        (recordWithMaybeMultRespOption record)
        optionDecoder


recordMaybeWithChangedOption : WithMaybeMultResp r -> Option -> WithMaybeMultResp r
recordMaybeWithChangedOption record option =
    Data.foldMaybe
        record
        (recordWithChangedOption record option)
        record.multResp


recordMaybeWithChangedOptionSnapshot : WithMaybeMultResp r -> Types.Snapshot -> WithMaybeMultResp r
recordMaybeWithChangedOptionSnapshot record =
    Data.recordWithSnapshot
        record
        (recordMaybeWithChangedOption record)
        optionDecoder


recordMaybeWithRemovedOptionSnapshot : WithMaybeMultResp r -> Types.Snapshot -> WithMaybeMultResp r
recordMaybeWithRemovedOptionSnapshot record =
    Data.recordWithSnapshot
        record
        (recordMaybeWithRemovedOption record)
        optionDecoder


optionsSub : Types.Database -> (Types.Snapshot -> msg) -> String -> Sub msg
optionsSub db addedMsg multRespId =
    UFirebase.objectsSubscription ("multRespOptions/" ++ multRespId) db addedMsg


invalidFields : WithMultRespFields r -> Bool
invalidFields multResp =
    List.any String.isEmpty [ multResp.question ]
