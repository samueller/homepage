module Types.Curricula
    exposing
        ( Curricula
        , get
        , getTask
        , findLesson
        , getLessonTask
        , getChaptersByMilestone
        , firstLessonOfMilestone
        , firstLessonOfChapter
        , milestone
        )

import Task exposing (Task)
import List.Extra as List
import Firebase.Database.Types exposing (Database)
import UCode.Data exposing (Id, firstSuccess)
import Types.Chapter as Chapter exposing (Chapter)
import Types.Milestone as Milestone exposing (Milestone)
import Types.Chapter as Chapter exposing (Chapter)
import Types.Lesson as Lesson exposing (LessonWithId)


type alias Lessons =
    List LessonWithId


type alias Chapters =
    List ( Chapter, Lessons )


type alias Curricula =
    List ( Milestone, Chapters )


type alias FlatCurricula =
    List ( Milestone, Chapter, LessonWithId )


getTask : Database -> Task String Curricula
getTask database =
    Task.map3
        (\milestones chapters lessons ->
            List.foldl
                (\milestone curricula ->
                    ( milestone
                    , List.foldl
                        (\chapter chapters ->
                            ( chapter
                            , List.filter (.chapterId >> (==) chapter.id) lessons
                                |> List.sortBy .number
                            )
                                :: chapters
                                |> List.sortBy (Tuple.first >> .number)
                        )
                        []
                        (List.filter (.milestoneId >> (==) milestone.id) chapters)
                    )
                        :: curricula
                        |> List.sortBy (Tuple.first >> .number)
                )
                []
                milestones
        )
        (Milestone.getAll database)
        (Chapter.getAll database)
        (Lesson.getAll database)


get : (Result String Curricula -> msg) -> Database -> Cmd msg
get onFinish =
    getTask >> Task.attempt onFinish


getFlat : (Result String FlatCurricula -> msg) -> Database -> Cmd msg
getFlat onFinish =
    getTask
        >> Task.map
            (List.foldl
                (\( milestone, chapters ) flatLessons ->
                    (List.foldl
                        (\( chapter, lessons ) flatLessons ->
                            List.foldl
                                (\lesson flatLessons ->
                                    List.append
                                        flatLessons
                                        [ ( milestone, chapter, lesson ) ]
                                )
                                flatLessons
                                lessons
                        )
                        flatLessons
                        chapters
                    )
                )
                []
            )
        >> Task.attempt onFinish


getChaptersByMilestone : (Result String (List ( Milestone, List Chapter )) -> msg) -> Database -> Cmd msg
getChaptersByMilestone onFinish database =
    Task.map2
        (\milestones chapters ->
            List.foldl
                (\milestone curricula ->
                    ( milestone
                    , List.filter (.milestoneId >> (==) milestone.id) chapters
                        |> List.sortBy .number
                    )
                        :: curricula
                        |> List.sortBy (Tuple.first >> .number)
                )
                []
                milestones
        )
        (Milestone.getAll database)
        (Chapter.getAll database)
        |> Task.attempt onFinish


findLesson : Id -> Curricula -> Maybe ( Milestone, Chapter, LessonWithId )
findLesson id =
    firstSuccess
        (\( milestone, chapters ) ->
            firstSuccess
                (\( chapter, lessons ) ->
                    List.find (.id >> (==) id) lessons
                        |> Maybe.map (\lesson -> ( chapter, lesson ))
                )
                chapters
                |> Maybe.map (\( chapter, lesson ) -> ( milestone, chapter, lesson ))
        )


firstLessonOfMilestone : Id -> Curricula -> Maybe ( Milestone, Chapter, LessonWithId )
firstLessonOfMilestone milestoneId =
    firstSuccess
        (\( milestone, chapters ) ->
            if milestone.id == milestoneId then
                List.head chapters
                    |> Maybe.andThen
                        (\( chapter, lessons ) ->
                            List.head lessons
                                |> Maybe.map (\lesson -> ( milestone, chapter, lesson ))
                        )
            else
                Nothing
        )


milestone : Id -> Curricula -> Maybe ( Milestone, Chapters )
milestone id =
    firstSuccess
        (\( milestone, chapters ) ->
            if milestone.id == id then
                Just ( milestone, chapters )
            else
                Nothing
        )


firstLessonOfChapter : Id -> Curricula -> Maybe ( Milestone, Chapter, LessonWithId )
firstLessonOfChapter id =
    firstSuccess
        (\( milestone, chapters ) ->
            firstSuccess
                (\( chapter, lessons ) ->
                    if chapter.id == id then
                        List.head lessons
                            |> Maybe.map (\lesson -> ( milestone, chapter, lesson ))
                    else
                        Nothing
                )
                chapters
        )


{-| Given a lesson ID, fetches the lesson, chapter, and milestone. Useful when
displaying the current lesson like "1.1.1".
-}
getLessonTask : Id -> Database -> Task String ( Milestone, Chapter, LessonWithId )
getLessonTask id db =
    Lesson.get id db
        |> Task.andThen
            (\lesson ->
                Chapter.get lesson.chapterId db
                    |> Task.andThen
                        (\chapter ->
                            Milestone.get chapter.milestoneId db
                                |> Task.map
                                    (\milestone ->
                                        ( milestone, chapter, lesson )
                                    )
                        )
            )
