module Page.EditVideo exposing (main)

import Html exposing (Html, nav, header, fieldset, legend, h1, h2, h3, h4, h5, h6, p, strong, text, ol, ul, li, span, br, div, a, img, select, option)
import Material.Grid as Grid
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.View as View
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Data as Data exposing (foldMaybe)
import UCode.Model exposing (User, SharedModelUser)
import UCode.Msg
import Types.Lesson as Lesson
import Types.Chapter as Chapter
import Types.Milestone as Milestone
import Types.Video as Video
import Types.Instruction as Instruction
import Util.Heading as Heading


main : Program User Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFireData SharedMsg initialModel GotVideo "videos"
        , view = View.viewWithUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialModel : SharedModelUser -> Model
initialModel =
    Model Nothing Nothing Nothing Browser.queryId Nothing (Browser.queryParam "lesson")


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , id : Data.Id
    , video : Maybe Video.Video
    , lessonId : String
    , sharedModel : SharedModelUser
    }


type Msg
    = SharedMsg UCode.Msg.Msg
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | GotVideo (Result Firebase.Errors.Error Types.Snapshot)
    | SelectVideoType String
    | InputVideoId String
    | InputContent String
    | Update
    | Updated (Result Firebase.Errors.Error ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        GotVideo (Ok snapshot) ->
            Video.recordUpdatedFromSnapshotValue model snapshot ! []

        GotVideo (Err error) ->
            model ! []

        SelectVideoType videoType ->
            Video.recordWithMaybeVideoVideoType model videoType ! []

        InputVideoId videoId ->
            Video.recordWithMaybeVideoVideoId model videoId ! []

        InputContent content ->
            Video.recordWithMaybeVideoContent model content ! []

        Update ->
            ( model, Video.updateMaybe model Updated )

        Updated _ ->
            ( model, Chapter.maybeOpenEditUrlWithLesson model.lessonId model.chapter )

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model


invalidFields : Video.Video -> Bool
invalidFields =
    String.isEmpty << .videoId


viewVideoFields : Model -> Video.Video -> List (Grid.Cell Msg)
viewVideoFields model video =
    [ View.halfWidthDesktopTabletCell
        [ View.textfield model SharedMsg InputVideoId "Video Id" True False [ 0 ] video.videoId ]
    , View.halfWidthDesktopTabletCell
        [ View.buttonWithText model SharedMsg Update (invalidFields video) [ 2 ] "Update" ]
    , View.halfWidthDesktopTabletCell
        [ View.fieldsetH3 "📜 Instruction"
            [ View.textarea model SharedMsg InputContent 20 "GitHub-Flavored Markdown" False False [ 1 ] video.content ]
        ]
    , View.halfWidthDesktopTabletWideCell
        [ View.fieldsetH3 "👁 Preview"
            [ Instruction.div video.content ]
        ]
    ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        (Heading.viewActivityEditHeading model "Edit Video"
            :: foldMaybe
                [ View.fullWidthCell [ View.spinner ] ]
                (viewVideoFields model)
                model.video
        )
    ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch <|
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        ]
