const functions = require('firebase-functions')

module.exports = centerId => {
  const token = functions.config().teamup['token_' + centerId.toLowerCase()]
  if (!token) {
    const error = new Error('No teamup token for center ' + centerId)
    error.code = 'no-center-token'
    throw error
  }
  return token
}
