module Types.SurveyCompletion
    exposing
        ( SurveyCompletion
        , Response(..)
        , ResponseText
        , getAllForCenterByTime
        , getByUser
        , question
        , response
        )

import Dict exposing (Dict)
import Task exposing (Task)
import Json.Decode as Decode exposing (Decoder)
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Util.Firebase.Database as Db
import Types.Center as Center


type alias ResponseText =
    { question : String
    , response : String
    }


type Response
    = ShortResponse ResponseText
    | MultipleChoice Id ResponseText


type alias SurveyCompletion =
    { centerId : Id
    , userId : Id
    , teamupSessionId : Id
    , responses : Dict Id Response
    , timestamp : Int
    , instructorTeamupId : Int
    , currentLessonId : String
    }



-- TYPE ACCESORS


question : Response -> String
question response =
    case response of
        ShortResponse { question } ->
            question

        MultipleChoice _ { question } ->
            question


response : Response -> String
response response =
    case response of
        ShortResponse { response } ->
            response

        MultipleChoice _ { response } ->
            response



-- DECODERS


responseTextDecoder : Decoder ResponseText
responseTextDecoder =
    Decode.map2 ResponseText
        (Decode.field "questionText" Decode.string)
        (Decode.field "text" Decode.string)


responseDecoder : Decoder Response
responseDecoder =
    (Decode.maybe <| Decode.field "optionId" Decode.string)
        |> Decode.andThen
            (\maybeOptionId ->
                case maybeOptionId of
                    Just optionId ->
                        Decode.map (MultipleChoice optionId) responseTextDecoder

                    Nothing ->
                        Decode.map ShortResponse responseTextDecoder
            )


decoder : Id -> Id -> Id -> Decoder SurveyCompletion
decoder centerId userId teamupSessionId =
    Decode.map4 (SurveyCompletion centerId userId teamupSessionId)
        (Decode.field "responses"
            (Decode.keyValuePairs responseDecoder
                |> Decode.map Dict.fromList
            )
        )
        (Decode.field "timestamp" Decode.int)
        (Decode.field "instructorTeamupId" Decode.int)
        (Decode.field "currentLessonId" Decode.string)


byTeamupSessionIdDecoder : Id -> Id -> Decoder (List SurveyCompletion)
byTeamupSessionIdDecoder centerId userId =
    Data.indexedKeyValueDecoder (decoder centerId userId)


byUserIdDecoder : Id -> Decoder (List SurveyCompletion)
byUserIdDecoder centerId =
    Data.indexedKeyValueDecoder (byTeamupSessionIdDecoder centerId)
        |> Decode.map (List.concat)



-- REQUESTS


getAllForCenterByTime : Id -> FirebaseApp -> Task String (List SurveyCompletion)
getAllForCenterByTime centerId =
    UCode.Firebase.valueTask
        [ "exitSurveySubmissions", centerId ]
        (byUserIdDecoder centerId)
        >> Task.map (List.sortBy .timestamp >> List.reverse)


getByUserHelp : Id -> Id -> Task String (List SurveyCompletion)
getByUserHelp userId centerId =
    Db.value [ "exitSurveySubmissions", centerId, userId ]
        (Decode.oneOf
            [ byTeamupSessionIdDecoder centerId userId
            , Decode.null []
            ]
        )


{-| Fetches all survey submissions for the given user ID. (Note: only includes
submissions from centers that exist in /centers).
-}
getByUser : Id -> Task String (List SurveyCompletion)
getByUser id =
    Center.getAll ()
        |> Task.andThen
            (Dict.keys >> List.map (getByUserHelp id) >> Task.sequence)
        |> Task.map (List.concat >> List.sortBy .timestamp)
