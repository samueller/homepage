module Types.Instruction exposing (..)

import Html exposing (Html)
import Html.Attributes exposing (class)
import Task
import Json.Encode as Encode
import Json.Decode as Decode exposing (Decoder, field)
import Markdown
import Firebase.Database.Types as Types exposing (Snapshot)
import Firebase.Errors
import UCode.Firebase exposing (firebaseDbTask, updateValueMaybe)
import UCode.Data as Data exposing (foldMaybe, recordWithSnapshot)
import UCode.Model
import UCode.View as View
import Types.Activity as Activity


type alias Instruction =
    { content : String
    }


type alias InstructionWithId =
    { id : String
    , content : String
    }


type alias WithInstruction r =
    { r | instruction : Instruction }


type alias WithMaybeInstruction r =
    { r | instruction : Maybe Instruction }


type alias WithInstructionWithId r =
    { r | instruction : InstructionWithId }


type alias WithMaybeInstructionWithId r =
    { r | instruction : Maybe InstructionWithId }


type alias WithContent r =
    { r | content : String }


decoder : Decoder Instruction
decoder =
    Decode.map Instruction
        (field "content" Decode.string)


instructionDecoder : String -> Decoder InstructionWithId
instructionDecoder id =
    Decode.map (InstructionWithId id)
        (field "content" Decode.string)


encoder : WithContent r -> Encode.Value
encoder instruction =
    Encode.object
        [ ( "content", Encode.string instruction.content )
        ]


fieldsEncoder : String -> Encode.Value
fieldsEncoder content =
    Encode.object
        [ ( "content", Encode.string content )
        ]


recordWithJustInstructionWithId : WithMaybeInstructionWithId r -> InstructionWithId -> WithMaybeInstructionWithId r
recordWithJustInstructionWithId record instruction =
    { record | instruction = Just instruction }


recordWithJustInstruction : WithMaybeInstruction r -> Instruction -> WithMaybeInstruction r
recordWithJustInstruction record instruction =
    { record | instruction = Just instruction }


recordUpdatedFromSnapshotValue : WithMaybeInstruction r -> Snapshot -> WithMaybeInstruction r
recordUpdatedFromSnapshotValue record =
    Data.recordUpdatedFromSnapshotValue record recordWithJustInstruction decoder


recordWithMaybeInstructionTransform : WithMaybeInstructionWithId r -> (InstructionWithId -> InstructionWithId) -> WithMaybeInstructionWithId r
recordWithMaybeInstructionTransform record transform =
    { record | instruction = Maybe.map transform record.instruction }


recordWithJustInstructionSnapshot : WithMaybeInstructionWithId r -> Snapshot -> WithMaybeInstructionWithId r
recordWithJustInstructionSnapshot record =
    recordWithSnapshot record (recordWithJustInstructionWithId record) instructionDecoder


instructionWithContent : String -> WithContent r -> WithContent r
instructionWithContent content instruction =
    { instruction | content = content }


recordWithMaybeInstructionContent : WithMaybeInstructionWithId r -> String -> WithMaybeInstructionWithId r
recordWithMaybeInstructionContent record =
    recordWithMaybeInstructionTransform record << instructionWithContent


update : UCode.Model.WithSharedModel model a -> (Result Firebase.Errors.Error () -> msg) -> InstructionWithId -> Cmd msg
update model updatedMsg instruction =
    updateValueMaybe
        updatedMsg
        ("instructions/" ++ instruction.id)
        (encoder instruction)
        model.sharedModel.firebaseApp


updateMaybe : UCode.Model.WithSharedModel (WithMaybeInstructionWithId r) a -> (Result Firebase.Errors.Error () -> msg) -> Cmd msg
updateMaybe model updatedMsg =
    foldMaybe
        Cmd.none
        (update model updatedMsg)
        model.instruction


create : (Result Firebase.Errors.Error () -> msg) -> String -> Int -> String -> Types.Database -> Cmd msg
create createdMsg lessonId number content db =
    let
        keyAndTask =
            UCode.Firebase.keyAndTaskFromPush db "instructions" <|
                fieldsEncoder content
    in
        Task.attempt createdMsg <|
            Activity.andPushActivity
                keyAndTask.key
                "instruction"
                number
                lessonId
                db
                keyAndTask.task


createMaybe : { r | firebaseApp : Maybe UCode.Firebase.FirebaseApp } -> (Result Firebase.Errors.Error () -> msg) -> String -> Int -> String -> Cmd msg
createMaybe model createdMsg lessonId number content =
    foldMaybe
        Cmd.none
        (create createdMsg lessonId number content << .db)
        model.firebaseApp


divWithClass : String -> String -> Html msg
divWithClass className content =
    Markdown.toHtmlWith
        View.markdownOptions
        [ class className ]
        content


div : String -> Html msg
div =
    divWithClass "quiz__instruction"


divQuestion : String -> Html msg
divQuestion =
    divWithClass "quiz__instruction question"
