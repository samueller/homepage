module Page.EditQuiz exposing (main)

import Html exposing (Html, nav, header, fieldset, legend, h1, h2, h3, h4, h5, h6, p, strong, text, ol, ul, li, span, br, div, a, img, select, option)
import Html.Attributes exposing (id, class, value, href)
import Material
import Material.Grid as Grid
import Material.Options as Options
import Material.Menu as Menu
import Material.Icon as Icon
import Material.Dialog as Dialog
import Firebase.Database.Types as Types
import Firebase.Errors
import Markdown
import UCode.View as View
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Data as Data
import UCode.Model exposing (User, SharedModelUser)
import UCode.Msg
import UCode.Firebase
import Types.Lesson as Lesson
import Types.Chapter as Chapter
import Types.Milestone as Milestone
import Types.Quiz as Quiz
import Types.Question as Question
import Types.Instruction as Instruction
import Util.Heading as Heading


main : Program User Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithUser SharedMsg initialModel
        , view = View.viewWithUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialModel : SharedModelUser -> Model
initialModel =
    Model Nothing Nothing Nothing (Quiz.Quiz Browser.queryId []) Nothing "" (Browser.queryParam "lesson")


type alias QuizQuestionToDelete =
    { question : Maybe String
    , quizQuestionId : String
    , questionId : String
    }


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , quiz : Quiz.Quiz
    , quizQuestionToDelete : Maybe QuizQuestionToDelete
    , questionToAdd : String
    , lessonId : String
    , sharedModel : SharedModelUser
    }


type Msg
    = SharedMsg UCode.Msg.Msg
    | Mdl (Material.Msg Msg)
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | AddedQuizQuestion Types.Snapshot
    | ChangedQuizQuestion Types.Snapshot
    | RemovedQuizQuestion Types.Snapshot
    | MoveQuizQuestion String Int
    | MovedQuizQuestion (Result Firebase.Errors.Error ())
    | ChangedQuestion String Types.Snapshot
    | DeleteQuizQuestion QuizQuestionToDelete
    | ConfirmDeleteQuizQuestion
    | CanceledDelete
    | DeletedQuizQuestion (Result Firebase.Errors.Error ())
    | InputQuestion String
    | AddQuestion
    | AddedQuestion String (Result Firebase.Errors.Error ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        AddedQuizQuestion snapshot ->
            Quiz.recordWithQuizQuestionSnapshot model snapshot ! []

        ChangedQuizQuestion snapshot ->
            Quiz.recordWithChangedQuizQuestionSnapshot model snapshot ! []

        RemovedQuizQuestion snapshot ->
            Quiz.recordWithRemovedQuizQuestionSnapshot model snapshot ! []

        MoveQuizQuestion quizQuestionId number ->
            ( model, Quiz.updateQuizQuestionNumber MovedQuizQuestion model quizQuestionId number )

        MovedQuizQuestion _ ->
            model ! []

        ChangedQuestion questionId snapshot ->
            Quiz.recordWithChangedQuestionSnapshot model questionId snapshot ! []

        DeleteQuizQuestion quizQuestionToDelete ->
            { model | quizQuestionToDelete = Just quizQuestionToDelete } ! []

        ConfirmDeleteQuizQuestion ->
            case model.quizQuestionToDelete of
                Just quizQuestionToDelete ->
                    ( model
                    , UCode.Firebase.remove2NodesMaybe
                        ("quizzes/" ++ model.quiz.id ++ "/questions/" ++ quizQuestionToDelete.quizQuestionId)
                        ("questions/multResp/" ++ quizQuestionToDelete.questionId)
                        DeletedQuizQuestion
                        model.sharedModel.firebaseApp
                    )

                Nothing ->
                    ( model, Cmd.none )

        CanceledDelete ->
            { model | quizQuestionToDelete = Nothing } ! []

        DeletedQuizQuestion _ ->
            { model | quizQuestionToDelete = Nothing } ! []

        InputQuestion questionToAdd ->
            { model | questionToAdd = questionToAdd } ! []

        AddQuestion ->
            ( model
            , Quiz.createQuizMultRespQuestionMaybe model AddedQuestion model.questionToAdd model.quiz.id (List.length model.quiz.questions + 1)
            )

        AddedQuestion questionId _ ->
            { model | questionToAdd = "" } ! []

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model

        Mdl msg_ ->
            Tuple.mapFirst (\sharedModel -> { model | sharedModel = sharedModel }) <|
                Material.update Mdl msg_ model.sharedModel


viewQuizQuestion : Model -> Int -> Quiz.QuizQuestion -> Html Msg
viewQuizQuestion model index quizQuestion =
    li
        [ class "question"
        , value (toString quizQuestion.number)
        ]
        ([ h4
            [ id ("quiz_question_" ++ quizQuestion.id) ]
            [ a
                [ href ("/edit/multiple_response.html?id=" ++ quizQuestion.questionId ++ "&quiz_question=" ++ quizQuestion.id ++ "&quiz=" ++ model.quiz.id ++ "&lesson=" ++ model.lessonId) ]
                [ text "Multiple Response" ]
            , text " "
            , Menu.render Mdl
                [ 0, index ]
                model.sharedModel.mdl
                [ Menu.ripple, Options.cs "menu-button" ]
                [ View.menuItemOpensDialog
                    (DeleteQuizQuestion (QuizQuestionToDelete quizQuestion.question quizQuestion.id quizQuestion.questionId))
                    "delete"
                    "Delete"
                    False
                ]
            , text " "
            , View.buttonMini model SharedMsg (MoveQuizQuestion quizQuestion.id (quizQuestion.number - 1)) False False [ 1, index ] [ Icon.view "arrow_upward" [ Icon.size18 ] ]
            , text " "
            , View.buttonMini model SharedMsg (MoveQuizQuestion quizQuestion.id (quizQuestion.number + 1)) False False [ 2, index ] [ Icon.view "arrow_downward" [ Icon.size18 ] ]
            ]
         ]
            ++ (Data.foldMaybe []
                    (List.singleton << Markdown.toHtmlWith View.markdownOptions [ class "instruction" ])
                    quizQuestion.question
               )
        )


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        (Heading.viewActivityEditHeading model "Edit Quiz"
            :: [ View.fullWidthCell
                    [ h2 []
                        [ text "Questions "
                        , View.buttonMini model SharedMsg CanceledDelete False True [ 0 ] [ Icon.i "add" ]
                        ]
                    , ol [ class "questions" ] (List.indexedMap (viewQuizQuestion model) model.quiz.questions)
                    ]
               ]
        )
    , dialog model
    ]


dialog : Model -> Html Msg
dialog model =
    case model.quizQuestionToDelete of
        Just quizQuestionToDelete ->
            Dialog.view []
                [ Dialog.title [] [ text "Confirmation" ]
                , Dialog.content []
                    [ text "Are you sure you want to delete this question?"
                    , Data.foldMaybe
                        (div [] [])
                        (Markdown.toHtmlWith View.markdownOptions [ class "instruction" ])
                        quizQuestionToDelete.question
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg ConfirmDeleteQuizQuestion False [ 1 ] "Delete"
                    , View.dialogButtonWithText model SharedMsg CanceledDelete False [ 2 ] "Cancel"
                    ]
                ]

        Nothing ->
            Dialog.view [ Options.cs "with_preview" ]
                [ Dialog.title [] [ text "Add Question" ]
                , Dialog.content []
                    [ Grid.grid []
                        [ View.halfWidthDesktopTabletCell
                            [ View.fieldsetH3 "📋 Question"
                                [ View.textarea model SharedMsg InputQuestion 6 "GitHub-Flavored Markdown" True False [ 1 ] model.questionToAdd ]
                            ]
                        , View.halfWidthDesktopTabletWideCell
                            [ View.fieldsetH3 "👁 Preview"
                                [ Instruction.divQuestion model.questionToAdd ]
                            ]
                        ]
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg AddQuestion False [ 2 ] "Add"
                    , View.dialogButtonWithText model SharedMsg CanceledDelete False [ 3 ] "Cancel"
                    ]
                ]


changedQuestionSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
changedQuestionSubs model firebase =
    Sub.batch <|
        List.map
            (Question.multRespQuestionSub firebase.db ChangedQuestion << .questionId)
            model.quiz.questions


firebaseSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ Quiz.quizQuestionsSub firebase.db AddedQuizQuestion model.quiz.id
        , changedQuestionSubs model firebase
        , UCode.Firebase.objectsChangedSubscription ("quizzes/" ++ model.quiz.id ++ "/questions") firebase.db ChangedQuizQuestion
        , UCode.Firebase.objectsRemovedSubscription ("quizzes/" ++ model.quiz.id ++ "/questions") firebase.db RemovedQuizQuestion
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        , Data.foldMaybe Sub.none (firebaseSubs model) model.sharedModel.firebaseApp
        ]
