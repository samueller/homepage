module Types.Referral exposing (..)

import Task exposing (Task)
import Dict exposing (Dict)
import Json.Decode as Decode exposing (Decoder, Value)
import Json.Encode as Encode
import UCode.Data as Data exposing (Id)
import UCode.Model exposing (FirebaseUser)
import UCode.Firebase exposing (FirebaseApp)
import UCode.User as User exposing (UserWithId)


type alias Referral =
    { referred : Id
    , referredName : String
    , referredBy : Dict Id String
    , recordedById : Id
    , recordedByName : String
    , recordedAt : Int
    , ucoins : Int
    }


referralDecoder : Id -> Decoder Referral
referralDecoder referredUserId =
    Decode.map6 (Referral referredUserId)
        (Decode.field "referredName" Decode.string)
        (Decode.field "referredBy" (Decode.dict Decode.string))
        (Decode.at [ "recordedBy", "userId" ] Decode.string)
        (Decode.at [ "recordedBy", "userName" ] Decode.string)
        (Decode.field "recordedAt" Decode.int)
        (Decode.field "ucoins" Decode.int)


referralEncoder : Referral -> Value
referralEncoder referral =
    Encode.object
        [ ( "referredName", Encode.string referral.referredName )
        , ( "referredBy"
          , Encode.object
                (Dict.toList referral.referredBy |> List.map (Tuple.mapSecond Encode.string))
          )
        , ( "recordedBy"
          , Encode.object
                [ ( "userId", Encode.string referral.recordedById )
                , ( "userName", Encode.string referral.recordedByName )
                ]
          )
        , ( "recordedAt", UCode.Firebase.serverTime )
        ]


get : Id -> (Result String Referral -> msg) -> FirebaseApp -> Cmd msg
get referredUserId onFinish =
    UCode.Firebase.valueTask
        [ "referrals", referredUserId ]
        (referralDecoder referredUserId)
        >> Task.attempt onFinish


hasBeenReferredTask : Id -> FirebaseApp -> Task String Bool
hasBeenReferredTask id =
    UCode.Firebase.valueTask
        [ "referrals", id ]
        (Decode.oneOf [ Decode.null False, Decode.succeed True ])


validateReferredUser : String -> FirebaseApp -> Task String UserWithId
validateReferredUser email app =
    User.validateEmail email app
        |> Task.andThen
            (\referredUser ->
                hasBeenReferredTask referredUser.id app
                    |> Task.mapError
                        (\error -> "Failed to check if \"" ++ email ++ "\" has been referred: " ++ error)
                    |> Task.andThen
                        (\hasBeenReferred ->
                            if hasBeenReferred then
                                Task.fail <| "\"" ++ email ++ "\" has already been referred"
                            else
                                Task.succeed referredUser
                        )
            )


validateReferrerUsers : String -> List String -> FirebaseApp -> Task String (List UserWithId)
validateReferrerUsers referredEmail emails app =
    List.map
        (\email ->
            User.validateEmail email app
                |> Task.andThen
                    (\user ->
                        if email /= referredEmail then
                            Task.succeed user
                        else
                            Task.fail <| "A student can't refer themself! (" ++ email ++ ")"
                    )
        )
        emails
        |> Task.sequence


create : String -> List String -> FirebaseUser -> (Result String () -> msg) -> FirebaseApp -> Cmd msg
create referredUserEmail referrerUserEmails manager onFinish app =
    Task.map2
        (\referredUser referrerUsers ->
            { referred = referredUser.id
            , referredName = referredUser.name
            , referredBy =
                List.map (\user -> ( user.id, user.name )) referrerUsers
                    |> Dict.fromList
            , recordedById = manager.uid
            , recordedByName = manager.displayName
            , recordedAt = 0
            , ucoins = 0
            }
        )
        (validateReferredUser referredUserEmail app)
        (validateReferrerUsers referredUserEmail referrerUserEmails app)
        |> Task.andThen
            (\referral ->
                UCode.Firebase.setTask
                    [ "referrals", referral.referred ]
                    (referralEncoder referral)
                    app
            )
        |> Task.attempt onFinish
