module Types.WorkshopReferral
    exposing
        ( WorkshopReferral
        , get
        , create
        )

import Task exposing (Task)
import Dict exposing (Dict)
import Json.Decode as Decode exposing (Decoder, Value)
import Json.Encode as Encode
import UCode.Data exposing (Id)
import UCode.Model exposing (FirebaseUser)
import UCode.User as User exposing (UserWithId)
import Util.Firebase.Database as Db


type alias WorkshopReferral =
    { eventBrightUserId : Id
    , referredBy : Dict Id String
    , recordedAt : Int
    , recordedById : Id
    , recordedByName : String
    , ucoins : Int
    }


decoder : Id -> Decoder WorkshopReferral
decoder userId =
    Decode.map5 (WorkshopReferral userId)
        (Decode.field "referredBy" (Decode.dict Decode.string))
        (Decode.field "recordedAt" Decode.int)
        (Decode.at [ "recordedBy", "userId" ] Decode.string)
        (Decode.at [ "recordedBy", "userName" ] Decode.string)
        (Decode.field "ucoins" Decode.int)


encoder : Dict Id String -> FirebaseUser -> Value
encoder referredBy manager =
    Encode.object
        [ ( "referredBy"
          , Encode.object
                (referredBy
                    |> Dict.toList
                    |> List.map (Tuple.mapSecond Encode.string)
                )
          )
        , ( "recordedAt", Db.serverTime )
        , ( "recordedBy"
          , Encode.object
                [ ( "userId", Encode.string manager.uid )
                , ( "userName", Encode.string manager.displayName )
                ]
          )
        ]


hasBeenReferred : Id -> Task String Bool
hasBeenReferred eventBrightUserId =
    Db.exists [ "workshopReferrals", eventBrightUserId ]


get : Id -> Task String WorkshopReferral
get eventBrightUserId =
    Db.value
        [ "workshopReferrals", eventBrightUserId ]
        (decoder eventBrightUserId)


validatedReferredId : Id -> Task String ()
validatedReferredId id =
    hasBeenReferred id
        |> Task.mapError
            (\error -> "Failed to check if \"" ++ id ++ "\" has been referred: " ++ error)
        |> Task.andThen
            (\hasBeenReferredResult ->
                if hasBeenReferredResult then
                    Task.fail ("\"" ++ id ++ "\" has already been referred")
                else
                    Task.succeed ()
            )


validateReferrerUsers : List String -> Task String (List UserWithId)
validateReferrerUsers emails =
    List.map (User.validateEmailNoDb) emails |> Task.sequence


create : Id -> List String -> FirebaseUser -> Task String ()
create eventBrightUserId referrerEmails manager =
    validatedReferredId eventBrightUserId
        |> Task.andThen (\() -> validateReferrerUsers referrerEmails)
        |> Task.andThen
            (\referrerUsers ->
                Db.set
                    [ "workshopReferrals", eventBrightUserId ]
                    (encoder
                        (referrerUsers
                            |> List.map (\user -> ( user.id, user.name ))
                            |> Dict.fromList
                        )
                        manager
                    )
            )
