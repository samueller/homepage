/* global firebase */
/* eslint-env browser */
/* eslint-disable indent, no-return-assign */
'use strict'

// eslint-disable-next-line no-unused-vars
const log = message => data => {
    console.log(message, data)
    return data
}

const scrollToElement = id =>
    document.getElementById(id).scrollIntoView()

// eslint-disable-next-line no-unused-vars
const scrollToElementNextFrame = id =>
    requestAnimationFrame(() => scrollToElement(id))

// eslint-disable-next-line no-unused-vars
const scrollToFragment = () =>
    document.querySelector(window.location.hash).scrollIntoView()

const elmObjectFromFirebase = snapshot =>
    Object.assign({id: snapshot.key}, snapshot.val())

const elmUserFromFirebase = id => user =>
    Object.assign({id}, user)

const elmStudentFromFirebase = userSnap => studentSnap => lessonSnap => chapterSnap => milestoneSnap =>
    [ elmObjectFromFirebase(userSnap)
    , { centerId: studentSnap.val().centerId
      , active: studentSnap.val().active
      , currentLesson:
            { id: lessonSnap.key
            , name: lessonSnap.val().name
            , number: lessonSnap.val().number
            , chapterId: chapterSnap.key
            , chapterName: chapterSnap.val().name
            , chapterNumber: chapterSnap.val().number
            , milestoneId: milestoneSnap.key
            , milestoneName: milestoneSnap.val().name
            , milestoneNumber: milestoneSnap.val().number
            }
      }
    ]

const reload = () =>
    window.location.reload(false)

const alertAndReload = message => {
    alert(message)
    reload()
}

const signIn = () =>
  firebase.auth().signInWithRedirect(
    (new firebase.auth.GoogleAuthProvider())
      .setCustomParameters({ prompt: 'select_account' })
  )

const updateUserName = user =>
    firebase.database().ref(`users/${user.uid}`).update({ name: user.displayName })

const runAndReload = f => arg =>
    f(arg)
        .then(reload)
        .catch(alertAndReload)

const runApp = app => authenticatedUser => userFromDB =>
    authenticatedUser.displayName && userFromDB.name === 'anonymous'
        ? runAndReload(updateUserName)(authenticatedUser)
        : app.fullscreen(elmUserFromFirebase(authenticatedUser.uid)(userFromDB))

const runStudentApp = app => userSnap => studentSnap =>
    studentSnap.val()
        ? firebase.database().ref(`lessons/${studentSnap.val().currentLessonId}`).once('value').then(lessonSnap =>
            firebase.database().ref(`chapters/${lessonSnap.val().chapterId}`).once('value').then(chapterSnap =>
                firebase.database().ref(`milestones/${chapterSnap.val().milestoneId}`).once('value')
                    .then(elmStudentFromFirebase(userSnap)(studentSnap)(lessonSnap)(chapterSnap))
                    .then(app.fullscreen)
            )
          ).catch(console.error)
        : app.fullscreen([ elmObjectFromFirebase(userSnap), null ])

const authenticatedApp = app => user =>
    firebase.database().ref(`users/${user.uid}`).once('value').then(snapshot =>
        snapshot.val()
            ? runApp(app)(user)(snapshot.val())
            : window.location.href = '/user_not_found.html'
    )

const loadActiveStudentAndRunApp = app => userSnapshot =>
    firebase.database().ref(`students/${userSnapshot.key}`).once('value').then(studentSnapshot =>
        studentSnapshot.val() && studentSnapshot.val().active
            ? runStudentApp(app)(userSnapshot)(studentSnapshot)
            : window.location.href = '/not_active.html'
    )

const authenticatedStudentApp = app => user =>
    firebase.database().ref(`users/${user.uid}`).once('value').then(snapshot =>
        snapshot.val()
            ? loadActiveStudentAndRunApp(app)(snapshot)
            : window.location.href = '/user_not_found.html'
    )

// eslint-disable-next-line no-unused-vars
const authenticateUserAndRunApp = app =>
    document.addEventListener('DOMContentLoaded', () =>
        firebase.auth().onAuthStateChanged(user =>
            user
                ? authenticatedApp(app)(user)
                : signIn()
        )
    )

// eslint-disable-next-line no-unused-vars
const authenticateAndRunApp = app =>
    new Promise((resolve, reject) =>
        document.addEventListener('DOMContentLoaded', () =>
            firebase.auth().onAuthStateChanged(user =>
                user
                    ? resolve(app.fullscreen(user))
                    : signIn()
            )
        )
)

// eslint-disable-next-line no-unused-vars
const maybeAuthenticateAndRunApp = app =>
    new Promise((resolve, reject) =>
        document.addEventListener('DOMContentLoaded', () => {
            const unsubscribe = firebase.auth().onAuthStateChanged(user => {
                unsubscribe()
                resolve(app.fullscreen(user))
            })
        })
)

// eslint-disable-next-line no-unused-vars
const authenticateStudentAndRunApp = app =>
    document.addEventListener('DOMContentLoaded', () =>
        firebase.auth().onAuthStateChanged(user =>
            user
                ? authenticatedStudentApp(app)(user)
                : signIn()
        )
    )
