module Util.Curriculum exposing (..)

import Json.Decode as Decode exposing (Decoder, decodeValue, map2, map3, map4, field, string, int)
import Json.Encode as Encode
import Task
import Firebase.Database.Types as Types exposing (Snapshot)
import Firebase.Errors
import Firebase.Database.Reference as Reference
import UCode.Firebase exposing (FirebaseApp, ref, idSubscription, objectsByIdSubscription, objectsByIdChangedSubscription, objectsByIdRemovedSubscription, saveInt, saveString, pushValue, updateValue, removeNode, remove2Nodes, once)
import List exposing (map, filter, sortBy)
import UCode.Data exposing (WithId, foldResult, foldMaybe, sortedListAddedTo, recordWithSnapshot)
import Types.Video exposing (Video, videoFieldsEncoder)
import Types.Activity exposing (databasePathFromActivityType)
import Types.Chapter exposing (Chapter)
import Types.Milestone exposing (Milestone)


type alias Activity =
    { id : String
    , activityId : String
    , activityType : String
    , number : Int
    , lessonId : String
    }


type alias Instruction =
    { id : String
    , content : String
    }


type alias Lesson =
    { id : String
    , name : String
    , number : Int
    , chapterId : String
    }


type alias LessonWithActivities =
    { id : String
    , activities : List Activity
    , name : String
    , number : Int
    , chapterId : String
    }


type alias WithLessonsWithActivities a =
    { a | lessons : List (WithLessonFields (WithId (WithActivities {}))) }


type alias WithLessons a =
    { a | lessons : List (WithLessonFields (WithId {})) }


type alias WithActivities a =
    { a | activities : List (WithActivityFields (WithId {})) }


type alias WithLessonFields a =
    { a
        | name : String
        , number : Int
        , chapterId : String
    }


type alias WithActivityFields a =
    { a
        | activityId : String
        , activityType : String
        , number : Int
        , lessonId : String
    }


activityDecoder : String -> Decoder Activity
activityDecoder id =
    map4 (Activity id)
        (field "activityId" string)
        (field "activityType" string)
        (field "number" int)
        (field "lessonId" string)


activityEncoder : String -> String -> Int -> String -> Encode.Value
activityEncoder activityId activityType number lessonId =
    Encode.object
        [ ( "activityId", Encode.string activityId )
        , ( "activityType", Encode.string activityType )
        , ( "number", Encode.int number )
        , ( "lessonId", Encode.string lessonId )
        ]


instructionDecoder : String -> Decoder Instruction
instructionDecoder id =
    Decode.map (Instruction id)
        (field "content" string)


instructionEncoder : Instruction -> Encode.Value
instructionEncoder instruction =
    Encode.object
        [ ( "content", Encode.string instruction.content )
        ]


instructionFieldsEncoder : String -> Encode.Value
instructionFieldsEncoder content =
    Encode.object
        [ ( "content", Encode.string content )
        ]


lessonDecoder : String -> Decoder Lesson
lessonDecoder id =
    map3 (Lesson id)
        (field "name" string)
        (field "number" int)
        (field "chapterId" string)


lessonEncoder : String -> Int -> String -> Encode.Value
lessonEncoder name number chapterId =
    Encode.object
        [ ( "name", Encode.string name )
        , ( "number", Encode.int number )
        , ( "chapterId", Encode.string chapterId )
        ]


lessonWithActivitiesDecoder : String -> Decoder LessonWithActivities
lessonWithActivitiesDecoder id =
    map3 (LessonWithActivities id [])
        (field "name" string)
        (field "number" int)
        (field "chapterId" string)


chapterDecoder : String -> Decoder Chapter
chapterDecoder id =
    map3 (Chapter id)
        (field "name" string)
        (field "number" int)
        (field "milestoneId" string)


milestoneDecoder : String -> Decoder Milestone
milestoneDecoder id =
    map2 (Milestone id)
        (field "name" string)
        (field "number" int)


milestoneSub : FirebaseApp -> (Snapshot -> msg) -> String -> Sub msg
milestoneSub =
    idSubscription "milestones"


milestoneFromChapterSub : FirebaseApp -> (Snapshot -> msg) -> Chapter -> Sub msg
milestoneFromChapterSub firebase msg =
    milestoneSub firebase msg << .milestoneId


chapterFromLessonSub : FirebaseApp -> (Snapshot -> msg) -> WithLessonFields a -> Sub msg
chapterFromLessonSub firebase msg =
    chapterSub firebase msg << .chapterId


chapterSub : FirebaseApp -> (Snapshot -> msg) -> String -> Sub msg
chapterSub =
    idSubscription "chapters"


lessonSub : FirebaseApp -> (Snapshot -> msg) -> String -> Sub msg
lessonSub =
    idSubscription "lessons"


lessonsByChapterIdSub : FirebaseApp -> (Snapshot -> msg) -> String -> Sub msg
lessonsByChapterIdSub =
    objectsByIdSubscription "lessons" "chapterId"


lessonsByChapterIdChangedSub : FirebaseApp -> (Snapshot -> msg) -> String -> Sub msg
lessonsByChapterIdChangedSub =
    objectsByIdChangedSubscription "lessons" "chapterId"


lessonsByChapterIdRemovedSub : FirebaseApp -> (Snapshot -> msg) -> String -> Sub msg
lessonsByChapterIdRemovedSub =
    objectsByIdRemovedSubscription "lessons" "chapterId"


activitiesByLessonIdSub : FirebaseApp -> (Snapshot -> msg) -> String -> Sub msg
activitiesByLessonIdSub =
    objectsByIdSubscription "activities" "lessonId"


activitiesByLessonIdChangedSub : FirebaseApp -> (Snapshot -> msg) -> String -> Sub msg
activitiesByLessonIdChangedSub =
    objectsByIdChangedSubscription "activities" "lessonId"


activitiesByLessonIdRemovedSub : FirebaseApp -> (Snapshot -> msg) -> String -> Sub msg
activitiesByLessonIdRemovedSub =
    objectsByIdRemovedSubscription "activities" "lessonId"


activitiesByLessonSub : FirebaseApp -> (String -> Snapshot -> msg) -> { a | id : String } -> Sub msg
activitiesByLessonSub firebase gotActivityMsg lesson =
    activitiesByLessonIdSub firebase (gotActivityMsg lesson.id) lesson.id


activitiesByLessonChangedSub : FirebaseApp -> (Snapshot -> msg) -> { a | id : String } -> Sub msg
activitiesByLessonChangedSub firebase gotActivityMsg lesson =
    activitiesByLessonIdChangedSub firebase gotActivityMsg lesson.id


activitiesByLessonRemovedSub : FirebaseApp -> (Snapshot -> msg) -> { a | id : String } -> Sub msg
activitiesByLessonRemovedSub firebase removedActivityMsg lesson =
    activitiesByLessonIdRemovedSub firebase removedActivityMsg lesson.id


lessonsActivitiesSub : FirebaseApp -> (String -> Snapshot -> msg) -> List { a | id : String } -> Sub msg
lessonsActivitiesSub firebase gotActivityMsg lessons =
    Sub.batch <|
        map (activitiesByLessonSub firebase gotActivityMsg) lessons


lessonsActivitiesChangedSub : FirebaseApp -> (Snapshot -> msg) -> List { a | id : String } -> Sub msg
lessonsActivitiesChangedSub firebase gotActivityMsg lessons =
    Sub.batch <|
        map (activitiesByLessonChangedSub firebase gotActivityMsg) lessons


lessonsActivitiesRemovedSub : FirebaseApp -> (Snapshot -> msg) -> List { a | id : String } -> Sub msg
lessonsActivitiesRemovedSub firebase removedActivityMsg lessons =
    Sub.batch <|
        map (activitiesByLessonRemovedSub firebase removedActivityMsg) lessons


lessonWithActivity : Activity -> String -> LessonWithActivities -> LessonWithActivities
lessonWithActivity activity lessonId lesson =
    if lesson.id == lessonId then
        { lesson | activities = sortedListAddedTo lesson.activities activity }
    else
        lesson


modelWithActivity : WithLessonsWithActivities model -> String -> Activity -> WithLessonsWithActivities model
modelWithActivity model lessonId activity =
    { model | lessons = map (lessonWithActivity activity lessonId) model.lessons }


modelWithActivitySnapshot : WithLessonsWithActivities model -> String -> Snapshot -> WithLessonsWithActivities model
modelWithActivitySnapshot model lessonId =
    recordWithSnapshot model (modelWithActivity model lessonId) activityDecoder


updatedLesson : WithLessonFields a -> WithLessonFields a -> WithLessonFields a
updatedLesson target source =
    { target
        | name = source.name
        , number = source.number
        , chapterId = source.chapterId
    }


updatedActivity : WithActivityFields a -> WithActivityFields a -> WithActivityFields a
updatedActivity target source =
    { target
        | activityId = source.activityId
        , activityType = source.activityType
        , number = source.number
        , lessonId = source.lessonId
    }


lessonsWithChangedLesson : WithLessonFields (WithId (WithActivities {})) -> List (WithLessonFields (WithId (WithActivities {}))) -> List (WithLessonFields (WithId (WithActivities {})))
lessonsWithChangedLesson lesson =
    map
        (\existingLesson ->
            if existingLesson.id == lesson.id then
                updatedLesson existingLesson lesson
            else
                existingLesson
        )


activitiesWithChangedActivity : WithActivityFields (WithId {}) -> List (WithActivityFields (WithId {})) -> List (WithActivityFields (WithId {}))
activitiesWithChangedActivity activity =
    map <|
        \existingActivity ->
            if existingActivity.id == activity.id then
                updatedActivity existingActivity activity
            else
                existingActivity


lessonsWithChangedActivity : WithActivityFields (WithId {}) -> List (WithLessonFields (WithId (WithActivities {}))) -> List (WithLessonFields (WithId (WithActivities {})))
lessonsWithChangedActivity activity =
    map <|
        \existingLesson ->
            if existingLesson.id == activity.lessonId then
                { existingLesson
                    | activities =
                        sortBy .number <|
                            activitiesWithChangedActivity activity existingLesson.activities
                }
            else
                existingLesson


lessonsWithRemovedActivity : WithActivityFields (WithId {}) -> List (WithLessonFields (WithId (WithActivities {}))) -> List (WithLessonFields (WithId (WithActivities {})))
lessonsWithRemovedActivity activity =
    map <|
        \lesson ->
            if lesson.id == activity.lessonId then
                { lesson
                    | activities =
                        filter ((/=) activity.id << .id) lesson.activities
                }
            else
                lesson


modelWithChangedLessonSnapshot : WithLessonsWithActivities model -> Snapshot -> WithLessonsWithActivities model
modelWithChangedLessonSnapshot model =
    recordWithSnapshot model
        (\lesson ->
            { model
                | lessons =
                    sortBy .number <|
                        lessonsWithChangedLesson lesson model.lessons
            }
        )
        lessonWithActivitiesDecoder


modelWithRemovedLessonSnapshot : WithLessonsWithActivities model -> Snapshot -> WithLessonsWithActivities model
modelWithRemovedLessonSnapshot model =
    recordWithSnapshot model
        (\lesson ->
            { model
                | lessons =
                    filter ((/=) lesson.id << .id) model.lessons
            }
        )
        lessonDecoder


modelWithChangedActivitySnapshot : WithLessonsWithActivities model -> Snapshot -> WithLessonsWithActivities model
modelWithChangedActivitySnapshot model =
    recordWithSnapshot model
        (\activity ->
            { model | lessons = lessonsWithChangedActivity activity model.lessons }
        )
        activityDecoder


modelWithRemovedActivitySnapshot : WithLessonsWithActivities model -> Snapshot -> WithLessonsWithActivities model
modelWithRemovedActivitySnapshot model =
    recordWithSnapshot model
        (\activity ->
            { model | lessons = lessonsWithRemovedActivity activity model.lessons }
        )
        activityDecoder


saveActivityNumber : String -> (Result Firebase.Errors.Error () -> msg) -> Int -> Types.Database -> Cmd msg
saveActivityNumber activityId =
    saveInt ("activities/" ++ activityId ++ "/number")


saveLessonNumber : String -> (Result Firebase.Errors.Error () -> msg) -> Int -> Types.Database -> Cmd msg
saveLessonNumber lessonId =
    saveInt ("lessons/" ++ lessonId ++ "/number")


saveLessonName : String -> (Result Firebase.Errors.Error () -> msg) -> String -> Types.Database -> Cmd msg
saveLessonName lessonId =
    saveString ("lessons/" ++ lessonId ++ "/name")


createLesson : (Result Firebase.Errors.Error () -> msg) -> String -> Int -> String -> Types.Database -> Cmd msg
createLesson createdMsg name number chapterId =
    pushValue "lessons" createdMsg <|
        lessonEncoder name number chapterId


deleteLesson : (Result Firebase.Errors.Error () -> msg) -> String -> Types.Database -> Cmd msg
deleteLesson deletedMsg lessonId =
    removeNode ("lessons/" ++ lessonId) deletedMsg


deleteActivity : (Result Firebase.Errors.Error () -> msg) -> Activity -> Types.Database -> Cmd msg
deleteActivity deletedMsg activity =
    remove2Nodes
        ("activities/" ++ activity.id)
        ((databasePathFromActivityType activity.activityType) ++ "/" ++ activity.activityId)
        deletedMsg


createVideo : (Result Firebase.Errors.Error () -> msg) -> String -> String -> String -> String -> Int -> Types.Database -> Cmd msg
createVideo createdMsg videoId videoType content lessonId number db =
    let
        videoPushRef =
            Reference.push (ref "videos" db)

        videoKey =
            Reference.key videoPushRef

        videoTask =
            Reference.set (videoFieldsEncoder videoId videoType content) videoPushRef

        activityTask =
            Task.andThen
                (\_ ->
                    Reference.set
                        (activityEncoder videoKey "video" number lessonId)
                        (Reference.push (ref "activities" db))
                )
                videoTask
    in
        Task.attempt createdMsg activityTask


createInstruction : (Result Firebase.Errors.Error () -> msg) -> String -> String -> Int -> Types.Database -> Cmd msg
createInstruction createdMsg content lessonId number db =
    let
        instructionPushRef =
            Reference.push (ref "instructions" db)

        instructionKey =
            Reference.key instructionPushRef

        instructionTask =
            Reference.set (instructionFieldsEncoder content) instructionPushRef

        activityTask =
            Task.andThen
                (\_ ->
                    Reference.set
                        (activityEncoder instructionKey "instruction" number lessonId)
                        (Reference.push (ref "activities" db))
                )
                instructionTask
    in
        Task.attempt createdMsg activityTask


updateInstruction : Instruction -> (Result Firebase.Errors.Error () -> msg) -> Types.Database -> Cmd msg
updateInstruction instruction =
    updateValue ("instructions/" ++ instruction.id) <|
        instructionEncoder instruction


videoOnce : (Result Firebase.Errors.Error Types.Snapshot -> msg) -> String -> FirebaseApp -> Cmd msg
videoOnce gotVideoMsg id =
    once ("videos/" ++ id) gotVideoMsg << .db
