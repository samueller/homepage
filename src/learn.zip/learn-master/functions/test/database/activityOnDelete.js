import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const activityOnDelete =
  proxyquire(
    '../../database/activityOnDelete',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// DELETE CACHE BY LESSON

test.serial('deleteCacheByLesson removes the related cache', async t => {
  mockdatabase.set({ activityLessons: { 'activity-1': 'lesson-1' } })
  await activityOnDelete._test.deleteCacheByLesson({ id: 'activity-1' })
  t.falsy(mockdatabase.getData())
})

// DELETE ACTIVITY

test.serial('deleteActivity removes the activity', async t => {
  mockdatabase.set({
    videos: { 'video-1': true },
    instructions: { 'instruction-1': true },
    quizzes: { 'quiz-1': true },
    lti: { 'lti-1': true },
    exerciseSets: { 'exerciseSet-1': true },
    exams: { 'exam-1': true },
    projectSteps: { 'projectStep-1': true },
    submissionInstr: { 'submissionInstr-1': true }
  })
  await activityOnDelete._test.deleteActivity(
    { activityType: 'video', activityId: 'video-1' }
  )
  await activityOnDelete._test.deleteActivity(
    { activityType: 'instruction', activityId: 'instruction-1' }
  )
  await activityOnDelete._test.deleteActivity(
    { activityType: 'quiz', activityId: 'quiz-1' }
  )
  await activityOnDelete._test.deleteActivity(
    { activityType: 'lti', activityId: 'lti-1' }
  )
  await activityOnDelete._test.deleteActivity(
    { activityType: 'exercises', activityId: 'exerciseSet-1' }
  )
  await activityOnDelete._test.deleteActivity(
    { activityType: 'exams', activityId: 'exam-1' }
  )
  await activityOnDelete._test.deleteActivity(
    { activityType: 'project_step', activityId: 'projectStep-1' }
  )
  await activityOnDelete._test.deleteActivity(
    { activityType: 'submission_instruction', activityId: 'submissionInstr-1' }
  )
  t.falsy(mockdatabase.getData())
})
