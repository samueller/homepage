module Types.InstrDesigner exposing (..)

import Json.Decode as Decode
import Firebase.Database.Types as Types
import UCode.Data as Data
import UCode.Firebase
import Task exposing (Task)
import Util.Firebase.Database as Db
import UCode.Data as Data exposing (Id)


type alias InstrDesigner =
    { active : Bool
    }


type alias WithMaybeInstrDesigner r =
    { r | instrDesigner : Maybe InstrDesigner }


decoder : Decode.Decoder InstrDesigner
decoder =
    Decode.map InstrDesigner
        (Decode.field "active" Decode.bool)


isInstrDesigner : Id -> Task String Bool
isInstrDesigner id =
    Db.value [ "instrDesigners", id, "active" ] (Decode.oneOf [ Decode.bool, Decode.succeed False ])


recordWithJustInstrDesigner : WithMaybeInstrDesigner r -> InstrDesigner -> WithMaybeInstrDesigner r
recordWithJustInstrDesigner record instrDesigner =
    { record | instrDesigner = Just instrDesigner }


recordWithJustInstrDesignerSnapshot : WithMaybeInstrDesigner r -> Types.Snapshot -> WithMaybeInstrDesigner r
recordWithJustInstrDesignerSnapshot record =
    Data.recordWithSnapshotValue record (recordWithJustInstrDesigner record) decoder


fromSnapshot : Types.Snapshot -> Maybe InstrDesigner
fromSnapshot =
    Data.maybeFromSnapshot decoder


sub : UCode.Firebase.FirebaseApp -> (Types.Snapshot -> msg) -> String -> Sub msg
sub =
    UCode.Firebase.idSubscription "instrDesigners"
