const functions = require('firebase-functions')
const db = require('../utils/db')
const promiseAllIgnoreReject = require('../utils/promise-all-ignore-reject')
const constants = require('../constants')

// CHECK CHAPTER COMPLETION

const lessonsOfChapterPassed = (userId, chapterId) =>
  db.valueOrReject('lessonNumbers', chapterId)
    .then(lessons =>
      Promise.all(
        Object.keys(lessons)
          .map(lessonId => db.exists('lessonResults', userId, lessonId))
      )
    )
    .then(lessonsPassed => lessonsPassed.every(a => a))

const hasCompletedChapter = (userId, chapterId) =>
  db.exists('chapterCompletions', userId, chapterId)

const markChapterComplete = (userId, chapterId) =>
  db.valueOrReject('chapters', chapterId)
    .then(chapter =>
      db.valueOrReject('milestones', chapter.milestoneId)
        .then(milestone =>
          db.ref('chapterCompletions', userId, chapterId)
            .set({
              numberAndName: `${milestone.number}.${chapter.number} ${chapter.name}`,
              completedAt: db.ServerValue.TIMESTAMP,
              ucoins: constants.UCOIN_VALUES.CHAPTER_COMPLETION,
              milestoneId: chapter.milestoneId
            })
        )
    )

const checkChapterCompletion = ({ userId, lessonId }, lessonResult) =>
  db.valueOrReject('lessons', lessonId, 'chapterId')
    .then(chapterId =>
      Promise.all([
        lessonsOfChapterPassed(userId, chapterId),
        hasCompletedChapter(userId, chapterId)
      ])
        .then(([ passedChapterLessons, hasCompletedChapter ]) =>
          !hasCompletedChapter && passedChapterLessons
            ? markChapterComplete(userId, chapterId)
            : null
        )
    )

// CHECK CURRENT LESSON

const fetchWithFallback = (fetch, fallback = () => null) =>
  fetch().then(next => next || fallback())

const firstOf = (path, id, by = 'orderByValue', byArgs = []) =>
  db.valueOf(
    db.ref(path, id)[by](...byArgs).equalTo(1)
  )
    .then(list => list && Object.keys(list)[0])

const nextOf = (path, id, number, by = 'orderByValue', byArgs = []) =>
  db.valueOf(
    db.ref(path, id)[by](...byArgs).equalTo(number + 1)
  )
    .then(list => list && Object.keys(list)[0])

const nextLessonId = lessonId =>
  db.valueOrReject('lessons', lessonId)
    .then(lesson =>
      fetchWithFallback(
        () => nextOf('lessonNumbers', lesson.chapterId, lesson.number),
        () =>
          db.valueOrReject('chapters', lesson.chapterId)
            .then(chapter =>
              fetchWithFallback(
                () =>
                  nextOf('chapterNumbers', chapter.milestoneId, chapter.number),
                () =>
                  db.valueOrReject('milestones', chapter.milestoneId)
                    .then(milestone =>
                      nextOf(
                        'milestones',
                        '',
                        milestone.number,
                        'orderByChild',
                        ['number']
                      )
                    )
                    .then(milestoneId =>
                      milestoneId && firstOf('chapterNumbers', milestoneId)
                    )
              )
            )
            .then(nextChapterId =>
              nextChapterId && firstOf('lessonNumbers', nextChapterId)
            )
      )
    )

const incrementLesson = (userId, lessonId) =>
  nextLessonId(lessonId)
    .then(nextLessonId => {
      if (nextLessonId) {
        console.log(`User now on lesson ${nextLessonId}`)
        return db.ref('students', userId, 'currentLessonId')
          .set(nextLessonId)
      } else {
        console.log(`User is still on the last lesson ${lessonId}`)
      }
    })

const checkCurrentLesson = ({ userId, lessonId }) =>
  db.valueOrReject('students', userId, 'currentLessonId')
    .then(currentLessonId => {
      if (currentLessonId === lessonId) {
        return incrementLesson(userId, lessonId)
      } else {
        console.log(`Not incrementing current lesson ${currentLessonId} because user completed ${lessonId}`)
      }
    })

// CACHE BY INSTRUCTOR

const cacheByInstructor = ({ userId, lessonId }, { instructor, timestamp }) => {
  if (instructor) {
    return db.valueOrReject('students', userId, 'centerId')
      .then(centerId =>
        db.ref('instructorLessonResults', instructor)
          .push({
            studentId: userId,
            lessonId,
            centerId,
            timestamp
          })
      )
  }
}

// LISTENER

module.exports =
  functions.database.ref('lessonResults/{userId}/{lessonId}')
    .onWrite((change, context) => {
      const val = change.after.val()
      return promiseAllIgnoreReject([
        checkChapterCompletion(context.params, val),
        checkCurrentLesson(context.params, val),
        cacheByInstructor(context.params, val)
      ])
    })

// TEST EXPORTS

module.exports._test = {
  checkChapterCompletion,
  checkCurrentLesson,
  cacheByInstructor
}
