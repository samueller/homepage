port module UCode.View exposing (WithMdlUser, activityActions, breadcrumb, breadcrumbFromId, breadcrumbFromIdAndFragment, breadcrumbLink, breadcrumbs, button, buttonLink, buttonMini, buttonWithText, checkbox, checkboxWithText, dialogButtonWithText, fieldsetH3, fillGrid, fullWidthCell, halfWidthDesktopCell, halfWidthDesktopTabletCell, halfWidthDesktopTabletWideCell, intfield, logoutLinkText, markdown, markdownOptions, materialSub, maybeBreadcrumbs, maybeBreadcrumbsDashboard, menuItem, menuItemAndDivider, menuItemOpensDialog, navLinksDrawer, navLinksDrawerWithUcoins, navLinksHeader, navLinksHeaderWithUcoins, notify, notifyWhenError, scrollIfFragmentEndsWith, scrollToElement, spinner, spinnerCell, textWithNbsp, textarea, textfield, thirdWidthDesktopCell, view, viewDrawer, viewDrawerNoUser, viewDrawerWithUcoins, viewFbUserUcoins, viewHeader, viewHeaderNoUser, viewHeaderWithUcoins, viewMaybeUser, viewMaybeUserUcoins, viewWithDialog, viewWithFirebaseUser, viewWithUser, youtubeEmbed)

import Html exposing (Html, a, div, fieldset, h1, h3, iframe, img, legend, nav, span, text)
import Html.Attributes exposing (attribute, class, href, property, src)
import Json.Encode as Encode
import List exposing (intersperse, map, singleton)
import Markdown exposing (defaultOptions, toHtmlWith)
import Material
import Material.Button as Button
import Material.Dialog as Dialog
import Material.Grid as Grid exposing (..)
import Material.Icon as Icon
import Material.Layout as Layout
import Material.Menu as Menu
import Material.Options as Options
import Material.Snackbar as Snackbar
import Material.Spinner as Spinner
import Material.Textfield as Textfield
import Material.Toggles as Toggles
import UCode.Data as Data exposing (foldMaybes)
import UCode.Model
    exposing
        ( WithSharedModel
        , WithSharedModelFirebaseUser
        , WithSharedModelMaybeUser
        , WithSharedModelUser
        )
import UCode.Msg exposing (Msg)
import UCode.User exposing (UserWithId)


type alias WithMdlUser model user =
    { model | mdl : Material.Model, user : { user | name : String } }


notify : String -> (Msg -> msg) -> WithSharedModel model a -> ( WithSharedModel model a, Cmd msg )
notify message liftMsg model =
    UCode.Model.updateSnackbar liftMsg (Snackbar.add (Snackbar.toast () message)) model


notifyWhenError :
    String
    -> (Msg -> msg)
    -> WithSharedModel model a
    -> Result String ()
    -> ( WithSharedModel model a, Cmd msg )
notifyWhenError action liftMsg model result =
    case result of
        Ok () ->
            model ! []

        Err error ->
            Debug.log ("Error " ++ action) error
                |> always (notify ("Error " ++ action) liftMsg model)


view : (Material.Msg msg -> msg) -> msg -> (WithMdlUser model user -> List (Html msg)) -> WithMdlUser model user -> Html msg
view mdl logout viewBody model =
    Layout.render mdl
        model.mdl
        [ Layout.fixedHeader
        , Layout.scrolling
        ]
        { header = viewHeader logout model.user.name
        , drawer = viewDrawer logout model.user.name
        , tabs = ( [], [] )
        , main = viewBody model
        }


viewWithDialog :
    (UCode.Msg.Msg -> msg)
    -> (WithSharedModelFirebaseUser model -> ( List (Html msg), Html msg ))
    -> WithSharedModelFirebaseUser model
    -> Html msg
viewWithDialog liftMsg viewPage model =
    let
        ( main, dialog ) =
            viewPage model
    in
    div []
        [ Layout.render (liftMsg << UCode.Msg.Mdl)
            model.sharedModel.mdl
            [ Layout.fixedHeader
            , Layout.scrolling
            ]
            { header = viewHeader (liftMsg UCode.Msg.LogoutAndLoadHome) model.sharedModel.user.displayName
            , drawer = viewDrawer (liftMsg UCode.Msg.LogoutAndLoadHome) model.sharedModel.user.displayName
            , tabs = ( [], [] )
            , main =
                main
                    ++ [ Html.map (UCode.Msg.Snackbar >> liftMsg) <|
                            Snackbar.view model.sharedModel.snackbar
                       ]
            }
        , dialog
        ]


viewWithUser : (UCode.Msg.Msg -> msg) -> (WithSharedModelUser model sharedModel -> List (Html msg)) -> WithSharedModelUser model sharedModel -> Html msg
viewWithUser liftMsg viewBody model =
    Layout.render (liftMsg << UCode.Msg.Mdl)
        model.sharedModel.mdl
        [ Layout.fixedHeader
        , Layout.scrolling
        ]
        { header = viewHeader (liftMsg UCode.Msg.LogoutAndLoadHome) model.sharedModel.user.name
        , drawer = viewDrawer (liftMsg UCode.Msg.LogoutAndLoadHome) model.sharedModel.user.name
        , tabs = ( [], [] )
        , main = viewBody model
        }


viewWithFirebaseUser : (UCode.Msg.Msg -> msg) -> (WithSharedModelFirebaseUser model -> List (Html msg)) -> WithSharedModelFirebaseUser model -> Html msg
viewWithFirebaseUser liftMsg viewBody model =
    Layout.render (liftMsg << UCode.Msg.Mdl)
        model.sharedModel.mdl
        [ Layout.fixedHeader
        , Layout.scrolling
        ]
        { header = viewHeader (liftMsg UCode.Msg.LogoutAndLoadHome) model.sharedModel.user.displayName
        , drawer = viewDrawer (liftMsg UCode.Msg.LogoutAndLoadHome) model.sharedModel.user.displayName
        , tabs = ( [], [] )
        , main =
            viewBody model
                ++ [ Html.map (UCode.Msg.Snackbar >> liftMsg) <|
                        Snackbar.view model.sharedModel.snackbar
                   ]
        }


viewFbUserUcoins :
    (UCode.Msg.Msg -> msg)
    -> (WithSharedModelFirebaseUser model -> ( Maybe UserWithId, List (Html msg) ))
    -> WithSharedModelFirebaseUser model
    -> Html msg
viewFbUserUcoins liftMsg viewBody model =
    let
        ( maybeUser, body ) =
            viewBody model
    in
    Layout.render (liftMsg << UCode.Msg.Mdl)
        model.sharedModel.mdl
        [ Layout.fixedHeader
        , Layout.scrolling
        ]
        { header =
            viewHeaderWithUcoins
                (liftMsg UCode.Msg.LogoutAndLoadHome)
                model.sharedModel.user.displayName
                maybeUser
        , drawer =
            viewDrawerWithUcoins
                (liftMsg UCode.Msg.LogoutAndLoadHome)
                model.sharedModel.user.displayName
                maybeUser
        , tabs = ( [], [] )
        , main =
            body
                ++ [ Html.map (UCode.Msg.Snackbar >> liftMsg) <|
                        Snackbar.view model.sharedModel.snackbar
                   ]
        }


viewMaybeUser :
    (UCode.Msg.Msg -> msg)
    -> (WithSharedModelMaybeUser model -> ( List (Html msg), Html msg ))
    -> WithSharedModelMaybeUser model
    -> Html msg
viewMaybeUser liftMsg viewPage model =
    let
        ( main, dialog ) =
            viewPage model

        ( header, drawer ) =
            case model.sharedModel.user of
                Just user ->
                    ( viewHeader
                        (liftMsg UCode.Msg.LogoutAndLoadHome)
                        user.displayName
                    , viewDrawer
                        (liftMsg UCode.Msg.LogoutAndLoadHome)
                        user.displayName
                    )

                Nothing ->
                    ( viewHeaderNoUser (liftMsg UCode.Msg.SignIn)
                    , viewDrawerNoUser (liftMsg UCode.Msg.SignIn)
                    )

        snackbar =
            Snackbar.view model.sharedModel.snackbar
                |> Html.map (UCode.Msg.Snackbar >> liftMsg)
    in
    div []
        [ Layout.render (liftMsg << UCode.Msg.Mdl)
            model.sharedModel.mdl
            [ Layout.fixedHeader
            , Layout.scrolling
            ]
            { header = header
            , drawer = drawer
            , tabs = ( [], [] )
            , main = main ++ [ snackbar ]
            }
        , dialog
        ]


viewMaybeUserUcoins :
    (UCode.Msg.Msg -> msg)
    -> (WithSharedModelMaybeUser model -> ( Maybe UserWithId, List (Html msg) ))
    -> WithSharedModelMaybeUser model
    -> Html msg
viewMaybeUserUcoins liftMsg viewBody model =
    let
        ( maybeUser, body ) =
            viewBody model

        ( header, drawer ) =
            case model.sharedModel.user of
                Just user ->
                    ( viewHeaderWithUcoins
                        (liftMsg UCode.Msg.LogoutAndLoadHome)
                        user.displayName
                        maybeUser
                    , viewDrawerWithUcoins
                        (liftMsg UCode.Msg.LogoutAndLoadHome)
                        user.displayName
                        maybeUser
                    )

                Nothing ->
                    ( viewHeaderNoUser (liftMsg UCode.Msg.SignIn)
                    , viewDrawerNoUser (liftMsg UCode.Msg.SignIn)
                    )
    in
    Layout.render (liftMsg << UCode.Msg.Mdl)
        model.sharedModel.mdl
        [ Layout.fixedHeader
        , Layout.scrolling
        ]
        { header = header
        , drawer = drawer
        , tabs = ( [], [] )
        , main =
            body
                ++ [ Html.map (UCode.Msg.Snackbar >> liftMsg) <|
                        Snackbar.view model.sharedModel.snackbar
                   ]
        }


fullWidthCell : List (Html msg) -> Cell msg
fullWidthCell =
    cell [ Grid.size Tablet 8, Grid.size Desktop 12, Grid.size Phone 4 ]


halfWidthDesktopTabletCell : List (Html msg) -> Cell msg
halfWidthDesktopTabletCell =
    cell [ Grid.size Tablet 4, Grid.size Desktop 6, Grid.size Phone 4 ]


halfWidthDesktopTabletWideCell : List (Html msg) -> Cell msg
halfWidthDesktopTabletWideCell =
    cell [ Options.cs "wide", Grid.size Tablet 4, Grid.size Desktop 6, Grid.size Phone 4 ]


halfWidthDesktopCell : List (Html msg) -> Cell msg
halfWidthDesktopCell =
    cell [ Grid.size Tablet 8, Grid.size Desktop 6, Grid.size Phone 4 ]


thirdWidthDesktopCell : List (Html msg) -> Cell msg
thirdWidthDesktopCell =
    cell [ Grid.size Grid.All 4 ]


fillGrid : List (Html msg) -> Html msg
fillGrid =
    grid []
        << singleton
        << fullWidthCell


breadcrumbLink : ( String, String ) -> Html msg
breadcrumbLink link =
    a [ href (Tuple.first link) ] [ text (Tuple.second link) ]


breadcrumbArrow : Html msg
breadcrumbArrow =
    div [ class "breadcrumbs__arrow" ] [ img [ src "/img/breadcrumb_arrow.svg" ] [] ]


breadcrumbs : List ( String, String ) -> Html msg
breadcrumbs =
    nav [ class "breadcrumbs" ]
        << intersperse breadcrumbArrow
        << map breadcrumbLink


breadcrumbsDashboard : List ( String, String ) -> Html msg
breadcrumbsDashboard =
    nav [ class "breadcrumbs-dashboard" ]
        << map breadcrumbLink


breadcrumb : String -> String -> Data.WithIdNameAndNumber r -> ( String, String )
breadcrumb page title object =
    ( "/" ++ page ++ ".html?id=" ++ object.id, title ++ " " ++ toString object.number ++ ": " ++ object.name )


breadcrumbFromId : String -> String -> String -> Data.WithNameAndNumber r -> ( String, String )
breadcrumbFromId page title id object =
    ( "/" ++ page ++ ".html?id=" ++ id, title ++ " " ++ toString object.number ++ ": " ++ object.name )


breadcrumbFromIdAndFragment : String -> String -> Data.WithNameAndNumber r -> String -> String -> ( String, String )
breadcrumbFromIdAndFragment page title object id fragment =
    ( "/" ++ page ++ ".html?id=" ++ id ++ "#" ++ fragment, title ++ " " ++ toString object.number ++ ": " ++ object.name )


maybeBreadcrumbs : List (Maybe ( String, String )) -> Html msg
maybeBreadcrumbs =
    breadcrumbs << foldMaybes


maybeBreadcrumbsDashboard : List (Maybe ( String, String )) -> Html msg
maybeBreadcrumbsDashboard =
    breadcrumbsDashboard << foldMaybes


spinner : Html msg
spinner =
    Spinner.spinner [ Spinner.active True ]


spinnerCell : Cell msg
spinnerCell =
    fullWidthCell
        [ Spinner.spinner [ Spinner.active True ] ]


textWithNbsp : String -> Html msg
textWithNbsp content =
    span [] [ span [ property "innerHTML" (Encode.string "&nbsp;") ] [], text content ]


logoutLinkText : String -> String
logoutLinkText name =
    if name == "anonymous" then
        "Logout"

    else
        "Logout " ++ name


navLinksHeader : logoutMsg -> String -> List (Html logoutMsg)
navLinksHeader logoutMsg name =
    [ Layout.link
        [ Layout.href "/" ]
        [ text "Dashboard" ]
    , Layout.link
        [ Options.onClick logoutMsg
        , Options.css "cursor" "pointer"
        ]
        [ text (logoutLinkText name) ]
    ]


navLinksDrawer : logoutMsg -> String -> List (Html logoutMsg)
navLinksDrawer logoutMsg name =
    [ Layout.link
        [ Layout.href "/" ]
        [ img [ src "/img/Icon_Dashboard.png", class "icon__img" ] [], text "Dashboard" ]
    , Layout.link
        [ Layout.href "/milestones.html" ]
        [ img [ src "/img/Icon_Milestones.png", class "icon__img" ] [], text "Milestones" ]
    , Layout.link
        [ Layout.href "https://edit.ucode.com/" ]
        [ img [ src "/img/Icon_Editor.png", class "icon__img" ] [], text "UCode Editor" ]
    , Layout.link
        [ Layout.href "https://uty.pe/" ]
        [ img [ src "/img/Icon_UType.png", class "icon__img" ] [], text "UType" ]
    , Layout.link
        [ Options.onClick logoutMsg
        , Options.css "cursor" "pointer"
        ]
        [ text (logoutLinkText name) ]
    ]


viewHeader : logoutMsg -> String -> List (Html logoutMsg)
viewHeader logoutMsg name =
    [ Layout.row
        []
        [ Layout.title []
            [ div [ class "app-bar__logo" ]
                [ a [ href "/" ]
                    [ img
                        [ src "/img/UCodeLogoBlue.png"
                        , class "app-bar__logo-img"
                        ]
                        []
                    ]
                ]
            ]
        , Layout.spacer
        , Layout.navigation [ Options.cs "mdl-layout--large-screen-only" ] (navLinksHeader logoutMsg name)
        ]
    ]


viewDrawer : logoutMsg -> String -> List (Html logoutMsg)
viewDrawer logoutMsg name =
    [ Layout.title []
        [ div [ class "app-bar__logo" ]
            [ img
                [ src "/img/UCodeLogoWhite.png"
                , class "drawer__logo-img"
                ]
                []
            ]
        ]
    , Layout.navigation [] (navLinksDrawer logoutMsg name)
    ]


viewHeaderNoUser : msg -> List (Html msg)
viewHeaderNoUser signInMsg =
    [ Layout.row
        []
        [ Layout.title []
            [ div [ class "app-bar__logo" ]
                [ a [ href "/" ]
                    [ img
                        [ src "/img/UCodeLogoBlue.png"
                        , class "app-bar__logo-img"
                        ]
                        []
                    ]
                ]
            ]
        , Layout.spacer
        , Layout.navigation [ Options.cs "mdl-layout--large-screen-only" ]
            [ Layout.link
                [ Options.onClick signInMsg
                , Options.css "cursor" "pointer"
                ]
                [ text "Sign in" ]
            ]
        ]
    ]


viewDrawerNoUser : msg -> List (Html msg)
viewDrawerNoUser signInMsg =
    [ Layout.title []
        [ div [ class "app-bar__logo" ]
            [ img
                [ src "/img/UCodeLogoWhite.png"
                , class "drawer__logo-img"
                ]
                []
            ]
        ]
    , Layout.navigation []
        [ Layout.link
            [ Options.onClick signInMsg
            , Options.css "cursor" "pointer"
            ]
            [ text "Sign in" ]
        , Layout.link
            [ Layout.href "https://edit.ucode.com" ]
            [ text "UCode Editor" ]
        , Layout.link
            [ Layout.href "https://uty.pe/" ]
            [ text "UType" ]
        ]
    ]


navLinksHeaderWithUcoins : logoutMsg -> String -> Maybe UserWithId -> List (Html logoutMsg)
navLinksHeaderWithUcoins logoutMsg name maybeUser =
    (case maybeUser of
        Just user ->
            Layout.link
                [ Layout.href <| "/ucoins.html?user=" ++ user.id ]
                [ div [ class "ucoins" ]
                    [ div [ class "ucoins__icon" ] [ img [ src "/img/UCoinIcon.png", class "ucoins__icon-img" ] [] ]
                    , div [ class "ucoins__chip" ]
                        [ div [ class "ucoins__chip-text" ] [ text <| toString user.ucoins ++ " UCoins" ]
                        ]
                    ]
                ]

        Nothing ->
            text ""
    )
        :: navLinksHeader logoutMsg name


navLinksDrawerWithUcoins : logoutMsg -> String -> Maybe UserWithId -> List (Html logoutMsg)
navLinksDrawerWithUcoins logoutMsg name maybeUser =
    navLinksDrawer logoutMsg name


viewHeaderWithUcoins : logoutMsg -> String -> Maybe UserWithId -> List (Html logoutMsg)
viewHeaderWithUcoins logoutMsg name maybeUser =
    [ Layout.row
        []
        [ Layout.title []
            [ div [ class "app-bar__logo" ]
                [ a [ href "/" ]
                    [ img
                        [ src "/img/UCodeLogoBlue.png"
                        , class "app-bar__logo-img"
                        ]
                        []
                    ]
                ]
            ]
        , Layout.spacer
        , Layout.navigation [ Options.cs "mdl-layout--large-screen-only" ]
            (navLinksHeaderWithUcoins logoutMsg name maybeUser)
        ]
    ]


viewDrawerWithUcoins : logoutMsg -> String -> Maybe UserWithId -> List (Html logoutMsg)
viewDrawerWithUcoins logoutMsg name maybeUser =
    [ Layout.title []
        [ div [ class "app-bar__logo" ]
            [ img
                [ src "/img/UCodeLogoWhite.png"
                , class "drawer__logo-img"
                ]
                []
            ]
        ]
    , Layout.navigation [] (navLinksDrawerWithUcoins logoutMsg name maybeUser)
    ]


textfield : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> (String -> msg) -> String -> Bool -> Bool -> List Int -> String -> Html msg
textfield model liftMsg inputMsg label autofocus disabled uniqueIndex value =
    Textfield.render (liftMsg << UCode.Msg.Mdl)
        uniqueIndex
        model.sharedModel.mdl
        [ Textfield.label label
        , Textfield.floatingLabel
        , Textfield.text_
        , Textfield.value value
        , Textfield.disabled
            |> Options.when disabled
        , Textfield.autofocus
            |> Options.when autofocus
        , Options.onInput inputMsg
        ]
        []


intfield : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> (Int -> msg) -> String -> Int -> List Int -> Html msg
intfield model liftMsg inputMsg label value uniqueIndex =
    Textfield.render (liftMsg << UCode.Msg.Mdl)
        uniqueIndex
        model.sharedModel.mdl
        [ Textfield.label label
        , Textfield.floatingLabel
        , Textfield.text_
        , Textfield.value (toString value)
        , Textfield.autofocus
        , Options.onInput (inputMsg << Result.withDefault 1 << String.toInt)
        ]
        []


textarea : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> (String -> msg) -> Int -> String -> Bool -> Bool -> List Int -> String -> Html msg
textarea model liftMsg inputMsg rows label autofocus disabled uniqueIndex value =
    Textfield.render (liftMsg << UCode.Msg.Mdl)
        uniqueIndex
        model.sharedModel.mdl
        [ Textfield.label label
        , Textfield.floatingLabel
        , Textfield.textarea
        , Textfield.rows rows
        , Textfield.value value
        , Textfield.disabled
            |> Options.when disabled
        , Textfield.autofocus
            |> Options.when autofocus
        , Options.onInput inputMsg
        , Options.cs "textarea-panel"
        ]
        []


button : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> msg -> Bool -> Bool -> List Int -> List (Html msg) -> Html msg
button model liftMsg clickMsg disabled triggerDialog uniqueIndex =
    Button.render (liftMsg << UCode.Msg.Mdl)
        uniqueIndex
        model.sharedModel.mdl
        [ Button.ripple
        , Button.colored
        , Button.raised
        , Button.disabled
            |> Options.when disabled
        , Dialog.openOn "click"
            |> Options.when triggerDialog
        , Options.onClick clickMsg
        ]


buttonLink : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> Maybe String -> List Int -> List (Html msg) -> Html msg
buttonLink model liftMsg href uniqueIndex =
    Button.render (liftMsg << UCode.Msg.Mdl)
        uniqueIndex
        model.sharedModel.mdl
        [ Button.ripple
        , Button.colored
        , Button.raised
        , Data.foldMaybe Button.disabled Button.link href
        ]


buttonMini : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> msg -> Bool -> Bool -> List Int -> List (Html msg) -> Html msg
buttonMini model liftMsg clickMsg disabled triggerDialog uniqueIndex =
    Button.render (liftMsg << UCode.Msg.Mdl)
        uniqueIndex
        model.sharedModel.mdl
        [ Button.minifab
        , Button.fab
        , Button.ripple
        , Button.colored
        , Button.raised
        , Button.disabled
            |> Options.when disabled
        , Dialog.openOn "click"
            |> Options.when triggerDialog
        , Options.onClick clickMsg
        ]


buttonWithText : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> msg -> Bool -> List Int -> String -> Html msg
buttonWithText model liftMsg clickMsg disabled uniqueIndex =
    button model liftMsg clickMsg disabled False uniqueIndex
        << List.singleton
        << text


dialogButtonWithText : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> msg -> Bool -> List Int -> String -> Html msg
dialogButtonWithText model liftMsg clickMsg disabled uniqueIndex =
    Button.render (liftMsg << UCode.Msg.Mdl)
        uniqueIndex
        model.sharedModel.mdl
        [ Dialog.closeOn "click"
        , Options.onClick clickMsg
        , Button.disabled
            |> Options.when disabled
        ]
        << singleton
        << text


checkbox : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> (Bool -> msg) -> Bool -> List Int -> Bool -> List (Html msg) -> Html msg
checkbox model liftMsg checkMsg disabled uniqueIndex checked =
    Toggles.checkbox (liftMsg << UCode.Msg.Mdl)
        uniqueIndex
        model.sharedModel.mdl
        [ Options.onCheck checkMsg
        , Toggles.ripple
        , Toggles.value checked
        , Toggles.disabled
            |> Options.when disabled
        , Options.cs "is-disabled"
            |> Options.when disabled
        ]


checkboxWithText : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> (Bool -> msg) -> Bool -> List Int -> Bool -> String -> Html msg
checkboxWithText model liftMsg checkMsg disabled uniqueIndex checked =
    checkbox model liftMsg checkMsg disabled uniqueIndex checked
        << singleton
        << text


menuItem : msg -> String -> String -> Menu.Item msg
menuItem clickedMsg icon label =
    Menu.item
        [ Menu.onSelect clickedMsg ]
        [ Icon.i icon, textWithNbsp label ]


menuItemAndDivider : msg -> String -> String -> Menu.Item msg
menuItemAndDivider clickedMsg icon label =
    Menu.item
        [ Menu.onSelect clickedMsg, Menu.divider ]
        [ Icon.i icon, textWithNbsp label ]


menuItemOpensDialog : msg -> String -> String -> Bool -> Menu.Item msg
menuItemOpensDialog clickedMsg icon label disabled =
    Menu.item
        [ Menu.onSelect clickedMsg
        , Menu.disabled
            |> Options.when disabled
        , Dialog.openOn "click"
        ]
        [ Icon.i icon, textWithNbsp label ]


fieldsetH3 : String -> List (Html msg) -> Html msg
fieldsetH3 title content =
    fieldset [] <|
        legend [] [ h3 [] [ text title ] ]
            :: content


markdownOptions : Markdown.Options
markdownOptions =
    { defaultOptions
        | githubFlavored = Just { tables = True, breaks = True }
        , sanitize = True
        , defaultHighlighting = Just "xml"
    }


markdown : String -> Html msg
markdown string =
    Markdown.toHtmlWith markdownOptions [] string


materialSub : WithSharedModel model a -> (UCode.Msg.Msg -> msg) -> Sub msg
materialSub model liftMsg =
    Sub.map liftMsg <|
        Material.subscriptions UCode.Msg.Mdl model.sharedModel


youtubeEmbed : String -> Html msg
youtubeEmbed videoId =
    div [ class "video__container" ]
        [ div [ class "youtube_iframe_embed" ]
            [ iframe
                [ src ("https://www.youtube.com/embed/" ++ videoId ++ "?rel=0&autoplay=1")
                , attribute "frameborder" "0"
                , attribute "allowFullScreen" ""
                ]
                []
            ]
        ]


activityActions : List (Html msg) -> Html msg
activityActions elements =
    div [ class "activity-actions" ] elements


port scrollToElement : String -> Cmd msg


scrollIfFragmentEndsWith : String -> String -> Cmd msg
scrollIfFragmentEndsWith fragment id =
    if String.endsWith id fragment then
        scrollToElement fragment

    else
        Cmd.none
