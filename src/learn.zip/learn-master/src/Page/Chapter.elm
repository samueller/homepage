module Page.Chapter exposing (main)

import Dict
import Firebase.Database
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Html exposing (..)
import Html.Attributes exposing (..)
import List
import Material.Grid as Grid
import Types.Activity as Activity
import Types.Chapter as Chapter
import Types.Lesson as Lesson
import Types.Milestone as Milestone
import Types.Student as Student
import UCode.Browser as Browser
import UCode.Data as Data
import UCode.Firebase
import UCode.Model
import UCode.Msg
import UCode.Users as Users
import UCode.View as View
import Util.Heading as Heading


main : Program UCode.Model.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUser SharedMsg initialModel
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , chapterId : String
    , fragment : String
    , lessons : List ( Data.Id, Lesson.LessonActivitiesWithIds )
    , lessonResults : Dict.Dict Data.Id Lesson.Result
    , activityResults : Dict.Dict Data.Id Activity.Result
    , student : Maybe Student.Student
    , studentLoading : Bool
    , currentLesson : Maybe Lesson.Lesson
    , sharedModel : UCode.Model.SharedModelFirebaseUser
    }


initialModel : UCode.Model.SharedModelFirebaseUser -> Model
initialModel =
    Model Nothing Nothing Browser.queryId Browser.fragment [] Dict.empty Dict.empty Nothing True Nothing


type Msg
    = SharedMsg UCode.Msg.Msg
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedStudent Types.Snapshot
    | ChangedCurrentLesson Types.Snapshot
    | AddedLesson Types.Snapshot
    | ChangedLesson Types.Snapshot
    | RemovedLesson Types.Snapshot
    | AddedActivity Data.Id Types.Snapshot
    | ChangedActivity Data.Id Types.Snapshot
    | RemovedActivity Data.Id Types.Snapshot
    | ChangedLessonResult Types.Snapshot
    | ChangedActivityResult Types.Snapshot


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedStudent snapshot ->
            { model
                | studentLoading = False
                , student = Student.fromSnapshot snapshot
            }
                ! []

        ChangedCurrentLesson snapshot ->
            { model | currentLesson = Lesson.fromSnapshot snapshot } ! []

        AddedLesson snapshot ->
            ( Lesson.recordWithAddedLessonSnapshotSorted model snapshot
            , Data.foldMaybe Cmd.none (View.scrollIfFragmentEndsWith model.fragment) (Snapshot.key snapshot)
            )

        ChangedLesson snapshot ->
            Lesson.recordWithChangedLessonSnapshotSorted model snapshot ! []

        RemovedLesson snapshot ->
            Lesson.recordWithRemovedLessonSnapshot model snapshot ! []

        AddedActivity lessonId snapshot ->
            Lesson.recordWithAddedLessonActivitySnapshotSorted model lessonId snapshot ! []

        ChangedActivity lessonId snapshot ->
            Lesson.recordWithChangedLessonActivitySnapshotSorted model lessonId snapshot ! []

        RemovedActivity lessonId snapshot ->
            Lesson.recordWithRemovedLessonActivitySnapshot model lessonId snapshot ! []

        ChangedLessonResult snapshot ->
            Lesson.recordWithAddedResultSnapshot model snapshot ! []

        ChangedActivityResult snapshot ->
            Activity.recordWithAddedResultSnapshot model snapshot ! []

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        [ Heading.viewChapterHeading model
        , View.fullWidthCell
            [ h1 [ class "lesson__title" ] [ text "Lessons" ]
            , viewLessons model
            ]
        ]
    ]


viewLessons : Model -> Html Msg
viewLessons model =
    case ( model.studentLoading, model.student ) of
        ( True, _ ) ->
            View.spinner

        ( False, Nothing ) ->
            p [] [ text "We couldn't find you as a student, ask a UCode instructor for help." ]

        ( False, Just student ) ->
            if student.active then
                ol [ class "lesson__cards" ] <|
                    List.indexedMap (viewLesson model student) model.lessons

            else
                p [] [ text "You are not an active student, ask a UCode instructor for help." ]


viewLessonLocked : Model -> Int -> Data.Id -> String -> List ( Data.Id, Activity.Activity ) -> Maybe Lesson.Result -> Html Msg
viewLessonLocked model index lessonId lessonName activities lessonResult =
    li
        [ classList [ ( "lesson__card locked", True ), ( "passed", Data.isJust lessonResult ) ] ]
        [ Lesson.listItemHeadingHtml lessonId lessonName index lessonResult
        , ol [ class "activities" ] <|
            List.indexedMap (viewActivity model lessonId index) activities
        , div [ class "lesson__overlay" ] [ img [ src "/img/Lock_Icon.svg" ] [] ]
        ]


viewLessonUnlocked : Model -> Int -> Data.Id -> String -> List ( Data.Id, Activity.Activity ) -> Maybe Lesson.Result -> Html Msg
viewLessonUnlocked model index lessonId lessonName activities lessonResult =
    li
        [ classList [ ( "lesson__card", True ), ( "passed", Data.isJust lessonResult ) ] ]
        [ Lesson.listItemHeadingHtml lessonId lessonName index lessonResult
        , ol [ class "activities" ] <|
            List.indexedMap (viewActivity model lessonId index) activities
        ]


viewLesson : Model -> Student.Student -> Int -> ( Data.Id, Lesson.LessonActivitiesWithIds ) -> Html Msg
viewLesson model student index ( lessonId, { lesson, activities } ) =
    if Student.lessonLocked student model.currentLesson lesson then
        viewLessonLocked model index lessonId lesson.name activities (Dict.get lessonId model.lessonResults)

    else
        viewLessonUnlocked model index lessonId lesson.name activities (Dict.get lessonId model.lessonResults)


viewActivity : Model -> Data.Id -> Int -> Int -> ( Data.Id, Activity.Activity ) -> Html Msg
viewActivity model lessonId lessonIndex index ( activityId, activity ) =
    li
        [ class "activity"
        , value (toString activity.number)
        ]
        [ a
            [ id ("activity_" ++ activityId), href (Activity.href activity activityId lessonId) ]
            [ Activity.activityIconImage activity.activityType
            , div [ class "activity__name" ] [ text (Activity.nameFromActivityType activity.activityType) ]
            , Activity.starsHtml (Data.foldMaybe 0 .score (Dict.get activityId model.activityResults))
            ]
        ]


ref : String -> Types.Database -> Types.Reference
ref path =
    Firebase.Database.ref (Just path)


activitySubs : Model -> UCode.Firebase.FirebaseApp -> ( Data.Id, Activity.Activity ) -> Sub Msg
activitySubs model firebase ( activityId, activity ) =
    Sub.batch
        [ UCode.Firebase.idSubscription ("activityResults/" ++ model.sharedModel.user.uid) firebase ChangedActivityResult activityId
        ]


lessonSubs : Model -> UCode.Firebase.FirebaseApp -> ( Data.Id, Lesson.LessonActivitiesWithIds ) -> Sub Msg
lessonSubs model firebase ( lessonId, lessonActivities ) =
    Sub.batch
        [ UCode.Firebase.objectsSubscriptions ("activities/" ++ lessonId) firebase.db (AddedActivity lessonId) (ChangedActivity lessonId) (RemovedActivity lessonId)
        , UCode.Firebase.idSubscription ("lessonResults/" ++ model.sharedModel.user.uid) firebase ChangedLessonResult lessonId
        , Sub.batch (List.map (activitySubs model firebase) lessonActivities.activities)
        ]


firebaseSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ Heading.chapterBreadcrumbsSub model ChangedChapter ChangedMilestone firebase
        , Student.sub firebase ChangedStudent model.sharedModel.user.uid
        , UCode.Firebase.objectsByIdSubscriptions "lessons" "chapterId" firebase AddedLesson ChangedLesson RemovedLesson model.chapterId
        , Data.foldMaybe Sub.none (Lesson.sub firebase ChangedCurrentLesson << .currentLessonId) model.student
        , Sub.batch (List.map (lessonSubs model firebase) model.lessons)
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , Data.foldMaybe Sub.none (firebaseSubs model) model.sharedModel.firebaseApp
        ]
