module Page.Dashboard exposing (main)

import Dict exposing (Dict)
import Firebase.Database.Types as Types
import Html
    exposing
        ( Html
        , a
        , br
        , div
        , h1
        , h2
        , h3
        , h4
        , h5
        , img
        , li
        , nav
        , ol
        , option
        , p
        , select
        , span
        , strong
        , text
        , ul
        )
import Html.Attributes exposing (class, classList, href, src, style, value)
import Html.Events exposing (onInput)
import Json.Decode as Decode
import Material.Button as Button
import Material.Grid as Grid
import Material.List as Lists
import Material.Options as Options
import RemoteData exposing (RemoteData(..))
import Task exposing (Task)
import Types.Admin as Admin
import Types.Chapter as Chapter exposing (Chapter)
import Types.Curricula as Curricula
import Types.InstrDesigner as InstrDesigner exposing (InstrDesigner)
import Types.Instructor as Instructor exposing (Instructor)
import Types.Lesson as Lesson
import Types.Manager as Manager exposing (ManagerCenter)
import Types.Milestone as Milestone exposing (Milestone)
import Types.PrizePurchase as PrizePurchase exposing (PendingPurchase)
import Types.Student as Student exposing (Student)
import UCode.Data as Data exposing (Id)
import UCode.Firebase as UFirebase
import UCode.Model as UModel exposing (FirebaseUser, SharedModelMaybeFirebaseUser)
import UCode.Msg as UMsg
import UCode.Sub as USub
import UCode.User as User exposing (UserWithId)
import UCode.Users as Users
import UCode.View as View
import Util.Heading as Heading
import View.Button
import View.Loading
import View.Table
import View.Textfield


main : Program (Maybe FirebaseUser) Model Msg
main =
    Html.programWithFlags
        { init = Users.initMaybeUser SharedMsg init
        , view = View.viewMaybeUserUcoins SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


type alias Chapters =
    List ( Milestone, List Chapter )


type alias Center =
    { centerId : Id
    , name : String
    , pendingPurchases : Dict Id PendingPurchase
    }


type alias Dashboard =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , student : Maybe Student.Student
    , user : Maybe UserWithId
    , chapters : RemoteData String Chapters
    , instructorCenters : List Instructor
    , managerCenters : Dict Id Center
    , isInstrDesigner : Bool
    , isAdmin : Bool
    , adminSearchInput : String
    , selectedDash : String
    , allUsers : RemoteData String (List UserWithId)
    }


type DataState
    = Loading
    | Success Dashboard
    | NoUser
    | Failed String


type alias Model =
    { userData : DataState
    , sharedModel : UModel.SharedModelMaybeFirebaseUser
    }


init : SharedModelMaybeFirebaseUser -> ( Model, Cmd Msg )
init sharedModel =
    case sharedModel.user of
        Just { uid } ->
            { userData = Loading
            , sharedModel = sharedModel
            }
                ! [ Task.attempt LoadedPermissions
                        (Task.map5
                            (,,,,)
                            (Student.getTaskMaybe uid)
                            (Manager.getCenters uid)
                            (Instructor.getCenters uid)
                            (InstrDesigner.isInstrDesigner uid)
                            (Admin.isAdmin uid)
                        )
                  ]

        Nothing ->
            { userData = NoUser
            , sharedModel = sharedModel
            }
                ! []


type Msg
    = SharedMsg UMsg.Msg
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | ChangedUser Types.Snapshot
    | ReceivedChapters (Result String Chapters)
    | UpdatePendingPurchase Id (Result String ( PendingPurchase, Bool ))
    | MarkOrdered PendingPurchase
    | MarkOrderedFinished (Result String ())
    | MarkCanceled PendingPurchase
    | MarkCanceledFinished (Result String ())
    | ChangeSelectedDash String
    | LoadedPermissions (Result String ( Maybe Student, List ManagerCenter, List Instructor, Bool, Bool ))
    | OnInputAdminSearch String
    | GotAllUsers (RemoteData String (List UserWithId))


ensureUsersFetched : Dashboard -> Cmd Msg
ensureUsersFetched dashboard =
    case dashboard.allUsers of
        NotAsked ->
            User.getAll |> RemoteData.fromTask |> Task.perform GotAllUsers

        _ ->
            Cmd.none


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case ( model.userData, msg ) of
        ( Loading, LoadedPermissions result ) ->
            case result of
                Ok ( student, managerCenters, instructorCenters, isInstrDesigner, isAdmin ) ->
                    { model
                        | userData =
                            Success
                                { milestone = Nothing
                                , chapter = Nothing
                                , lesson = Nothing
                                , student = student
                                , user = Nothing
                                , chapters = RemoteData.Loading
                                , instructorCenters = instructorCenters
                                , managerCenters =
                                    Dict.fromList
                                        (List.map
                                            (\center ->
                                                ( center.centerId
                                                , { name = center.name
                                                  , centerId = center.centerId
                                                  , pendingPurchases = Dict.empty
                                                  }
                                                )
                                            )
                                            managerCenters
                                        )
                                , selectedDash =
                                    if List.length managerCenters > 0 then
                                        "manager"

                                    else if List.length instructorCenters > 0 then
                                        "instructor"

                                    else
                                        "student"
                                , isInstrDesigner = isInstrDesigner
                                , isAdmin = isAdmin
                                , adminSearchInput = ""
                                , allUsers = NotAsked
                                }
                    }
                        ! [ if isInstrDesigner then
                                Data.foldMaybe
                                    Cmd.none
                                    (.db >> Curricula.getChaptersByMilestone ReceivedChapters)
                                    model.sharedModel.firebaseApp

                            else
                                Cmd.none
                          ]

                Err error ->
                    { model | userData = Failed ("Permissions failed to load: " ++ error) }
                        ! []

        ( Loading, _ ) ->
            model ! []

        ( Failed error, _ ) ->
            model ! []

        ( Success data, ChangedLesson snapshot ) ->
            { model | userData = Success (Lesson.recordWithJustLessonSnapshot data snapshot) } ! []

        ( Success data, ChangedMilestone snapshot ) ->
            { model | userData = Success (Milestone.recordWithJustMilestoneSnapshot data snapshot) } ! []

        ( Success data, ChangedChapter snapshot ) ->
            { model | userData = Success (Chapter.recordWithJustChapterSnapshot data snapshot) } ! []

        ( Success data, ChangedUser snapshot ) ->
            case model.sharedModel.user of
                Just { uid } ->
                    { model
                        | userData =
                            Success
                                (User.updateRecordDecodedUser
                                    data
                                    (User.decoderWithId uid |> Decode.map Just)
                                    snapshot
                                )
                    }
                        ! []

                Nothing ->
                    model ! []

        ( Success data, ReceivedChapters result ) ->
            { model | userData = Success { data | chapters = RemoteData.fromResult result } } ! []

        ( Success data, UpdatePendingPurchase centerId result ) ->
            case result of
                Ok ( pendingPurchase, removed ) ->
                    { model
                        | userData =
                            Success
                                { data
                                    | managerCenters =
                                        Dict.update
                                            centerId
                                            (Maybe.map
                                                (\center ->
                                                    { center
                                                        | pendingPurchases =
                                                            if removed then
                                                                Dict.remove
                                                                    pendingPurchase.purchaseId
                                                                    center.pendingPurchases

                                                            else
                                                                Dict.insert
                                                                    pendingPurchase.purchaseId
                                                                    pendingPurchase
                                                                    center.pendingPurchases
                                                    }
                                                )
                                            )
                                            data.managerCenters
                                }
                    }
                        ! []

                Err error ->
                    Debug.log "Error while decoding pending purchase" error
                        |> always (model ! [])

        ( Success data, MarkOrdered pendingPurchase ) ->
            model
                ! [ Data.foldMaybe
                        Cmd.none
                        (PrizePurchase.markAsPurchased pendingPurchase
                            >> Task.attempt MarkOrderedFinished
                        )
                        model.sharedModel.firebaseApp
                  ]

        ( Success data, MarkOrderedFinished (Ok ()) ) ->
            -- Do nothing
            model ! []

        ( Success data, MarkOrderedFinished (Err error) ) ->
            Debug.log "Error while marking as ordered" error
                |> always (model ! [])

        ( Success data, MarkCanceled pendingPurchase ) ->
            model
                ! [ Data.foldMaybe
                        Cmd.none
                        (PrizePurchase.markAsCanceled pendingPurchase
                            >> Task.attempt MarkCanceledFinished
                        )
                        model.sharedModel.firebaseApp
                  ]

        ( Success data, MarkCanceledFinished result ) ->
            case result of
                Ok () ->
                    model ! []

                Err error ->
                    Debug.log "Error while marking as ordered" error
                        |> always (model ! [])

        ( _, SharedMsg msg_ ) ->
            UModel.update SharedMsg msg_ model

        ( Success data, ChangeSelectedDash input ) ->
            case input of
                "student" ->
                    { model | userData = Success { data | selectedDash = "student" } } ! []

                "instructor" ->
                    { model | userData = Success { data | selectedDash = "instructor" } } ! []

                "manager" ->
                    { model | userData = Success { data | selectedDash = "manager" } } ! []

                "instructional designer" ->
                    { model | userData = Success { data | selectedDash = "instructional designer" } } ! []

                "admin" ->
                    { model | userData = Success { data | selectedDash = "admin" } }
                        ! [ ensureUsersFetched data ]

                other ->
                    let
                        _ =
                            Debug.log "Unexpected input" other
                    in
                    model ! []

        ( Success data, OnInputAdminSearch input ) ->
            { model | userData = Success { data | adminSearchInput = input } } ! []

        ( Success data, GotAllUsers remoteData ) ->
            { model | userData = Success { data | allUsers = remoteData } } ! []

        ( Success _, LoadedPermissions _ ) ->
            model ! []

        ( NoUser, _ ) ->
            model ! []


viewInstrDesignerSection : Dashboard -> Html Msg
viewInstrDesignerSection data =
    div [ style [ ( "align-self", "center" ) ] ]
        [ viewChapterEditLinks data.chapters
        ]


viewEditChapterLink : Model -> Int -> ( Data.Id, Chapter.ChapterNoId ) -> Html Msg
viewEditChapterLink model index ( chapterId, chapter ) =
    li []
        [ View.buttonLink model
            SharedMsg
            (Just ("/edit/chapter.html?id=" ++ chapterId))
            [ 3, index ]
            [ h3 [] [ text ("Chapter " ++ toString chapter.number ++ ": " ++ chapter.name) ]
            ]
        ]


viewEditMilestone : ( Milestone, List Chapter ) -> Html Msg
viewEditMilestone ( milestone, chapters ) =
    div []
        [ h5 [] [ text <| "Milestone " ++ toString milestone.number ++ ": " ++ milestone.name ]
        , if List.length chapters == 0 then
            span [ style [ ( "font-style", "italic" ) ] ] [ text "No chapters" ]

          else
            ol []
                (List.map
                    (\chapter ->
                        li []
                            [ a [ href <| "/edit/chapter.html?id=" ++ chapter.id ]
                                [ text chapter.name ]
                            ]
                    )
                    chapters
                )
        ]


viewChapterEditLinks : RemoteData String Chapters -> Html Msg
viewChapterEditLinks remoteChapters =
    div []
        (case remoteChapters of
            RemoteData.NotAsked ->
                [ text "You are not an instructional designer!" ]

            RemoteData.Loading ->
                [ text "Loading curricula..."
                , View.spinner
                ]

            RemoteData.Failure error ->
                [ div [] [ text "Failed to load curricula" ]
                , div [] [ text error ]
                ]

            RemoteData.Success chapters ->
                List.map viewEditMilestone chapters
        )


selectOptions : Dashboard -> Html Msg
selectOptions data =
    let
        options : List (Html Msg)
        options =
            List.concat
                [ if data.isAdmin then
                    [ option [ value "admin" ] [ text "Admin" ] ]

                  else
                    []
                , if List.length data.instructorCenters > 0 then
                    [ option [ value "instructor" ] [ text "Instructor" ] ]

                  else
                    []
                , if Dict.size data.managerCenters > 0 then
                    [ option [ value "manager" ] [ text "Manager" ] ]

                  else
                    []
                , if data.isInstrDesigner then
                    [ option [ value "instructional designer" ] [ text "Instructional Designer" ] ]

                  else
                    []
                , if
                    (data.student /= Nothing)
                        && (Dict.size data.managerCenters > 0)
                        || (List.length data.instructorCenters > 0)
                  then
                    [ option [ value "student" ] [ text "Student" ] ]

                  else
                    []
                ]
    in
    if List.length options > 0 then
        select
            [ onInput ChangeSelectedDash
            , style
                [ ( "margin", "auto" )
                , ( "margin-top", "10px" )
                ]
            , value data.selectedDash
            ]
            options

    else
        text ""


userMatchesFilter : String -> UserWithId -> Bool
userMatchesFilter filter user =
    filter
        == user.id
        || String.contains filter user.email
        || String.contains filter user.name


viewAdminUser : UserWithId -> Html Msg
viewAdminUser user =
    div [] [ text user.id, text " ", text user.name, text " ", text user.email ]


viewUsersFiltered : String -> List UserWithId -> Html Msg
viewUsersFiltered filter =
    List.filter (userMatchesFilter filter)
        >> View.Table.basic []
            [ View.Table.column "Name" .name
            , View.Table.column "Email" .email
            , View.Table.columnCustom ""
                (\user -> a [ href ("/profile.html?id=" ++ user.id) ] [ text "Profile" ])
                False
            ]


viewAdminDashboard : Model -> Dashboard -> Html Msg
viewAdminDashboard model dashboard =
    div
        [ style
            [ ( "display", "flex" )
            , ( "flex-direction", "column" )
            , ( "align-items", "center" )
            ]
        ]
        [ View.Textfield.basic
            SharedMsg
            [ 0 ]
            model
            []
            "Search for user by name or email"
            dashboard.adminSearchInput
            OnInputAdminSearch
        , View.Loading.remoteData
            Nothing
            View.Loading.large
            (\error -> text ("Error loading users: " ++ error))
            (viewUsersFiltered dashboard.adminSearchInput)
            dashboard.allUsers
        ]


dashHeader : Dashboard -> Html Msg
dashHeader data =
    h2
        [ style
            [ ( "margin", "auto" )
            , ( "font-weight", "800" )
            , ( "padding-top", "40px" )
            ]
        ]
        (case data.selectedDash of
            "student" ->
                if
                    (List.length data.instructorCenters > 0)
                        || (Dict.size data.managerCenters > 0)
                then
                    [ text "Student" ]

                else
                    case data.student of
                        Just student ->
                            [ text "Current Lesson:" ]

                        Nothing ->
                            []

            "instructor" ->
                [ text "Instructor" ]

            "manager" ->
                [ text "Manager" ]

            "instructional designer" ->
                [ text "Instructional Designer" ]

            "admin" ->
                [ text "Admin" ]

            other ->
                [ text "Permissions error" ]
        )


viewBody : Model -> ( Maybe UserWithId, List (Html Msg) )
viewBody model =
    case model.userData of
        Loading ->
            ( Nothing, [] )

        NoUser ->
            ( Nothing
            , [ div [ class "home__background" ]
                    [ div
                        [ style
                            [ ( "padding", "40px 0" ) ]
                        ]
                        [ img [ src "/img/UCodeLogoWhite.png", class "logo__img" ] [] ]
                    , div [ class "login__form" ]
                        [ h2 [ style [ ( "text-align", "center" ), ( "color", "black" ), ( "line-height", "1.4" ), ( "margin-top", "0" ) ] ] [ text "Programming Academy" ]
                        , Button.render (SharedMsg << UMsg.Mdl)
                            [ 0 ]
                            model.sharedModel.mdl
                            [ Options.onClick (SharedMsg UMsg.SignIn)
                            , Options.css "margin-top" "20px"
                            , Button.raised
                            , Button.primary
                            ]
                            [ text "Sign in" ]
                        ]
                    ]
              ]
            )

        Success data ->
            ( data.user
            , [ div
                    [ style
                        [ ( "display", "flex" )
                        , ( "flex-direction", "column" )
                        ]
                    ]
                    [ dashHeader data
                    , selectOptions data
                    , case data.selectedDash of
                        "instructor" ->
                            viewInstructorCenters model data ()

                        "manager" ->
                            div
                                [ style
                                    [ ( "display", "flex" )
                                    , ( "flex-direction", "column" )
                                    ]
                                ]
                                [ a
                                    [ href "/manage_ucoins.html"
                                    , style
                                        [ ( "margin", "auto" )
                                        , ( "margin-top", "10px" )
                                        ]
                                    ]
                                    [ text "Manage UCoins" ]
                                , viewManagerCenters model data
                                ]

                        "instructional designer" ->
                            viewInstrDesignerSection data

                        "admin" ->
                            viewAdminDashboard model data

                        _ ->
                            case data.student of
                                Just student ->
                                    viewCurrentLesson model data student

                                Nothing ->
                                    div
                                        [ style
                                            [ ( "margin"
                                              , "auto"
                                              )
                                            ]
                                        ]
                                        [ span []
                                            (case model.sharedModel.user of
                                                Just { email } ->
                                                    [ text
                                                        ("You have not accepted an invite with this email ("
                                                            ++ email
                                                            ++ "). Maybe you need to visit the "
                                                        )
                                                    , a [ href "/setup.html" ] [ text "setup page" ]
                                                    , text "? Ask your instructor for help setting up your account."
                                                    ]

                                                Nothing ->
                                                    [ div [] [ h1 [] [ text "Please sign in" ] ] ]
                                            )
                                        ]
                    ]
              ]
            )

        Failed error ->
            ( Nothing, [ div [] [ text ("Error loading page: " ++ error) ] ] )


viewCurrentLesson : Model -> Dashboard -> Student.Student -> Html Msg
viewCurrentLesson model data student =
    case data.lesson of
        Just lesson ->
            div
                [ class "card__body" ]
                [ div [ style [ ( "margin-top", "15px" ) ] ]
                    [ View.maybeBreadcrumbsDashboard <|
                        Heading.chapterBreadcrumbs data
                    ]
                , div
                    [ style
                        [ ( "margin", "auto" )
                        , ( "margin-top", "10px" )
                        ]
                    ]
                    [ View.buttonLink model
                        SharedMsg
                        (Maybe.map
                            (\chapter ->
                                "/chapter.html?id="
                                    ++ chapter.id
                                    ++ "#lesson_"
                                    ++ student.currentLessonId
                            )
                            data.chapter
                        )
                        [ 0, 0 ]
                        [ div [ class "card__button" ] [ text "CONTINUE ", img [ src "/img/right_arrow.svg" ] [] ]
                        ]
                    ]
                ]

        _ ->
            View.spinner


centerButton : String -> Model -> Int -> Instructor -> Html Msg
centerButton linkPrefix model index instructor =
    li [ style [ ( "margin-bottom", "10px" ), ( "text-align", "center" ) ] ]
        [ div [ style [ ( "margin", "auto" ) ] ]
            [ View.buttonLink
                model
                SharedMsg
                (Just
                    (linkPrefix ++ "center.html?id=" ++ instructor.centerId)
                )
                [ 15, index ]
                [ p
                    [ style
                        [ ( "margin-bottom", "0px" )
                        , ( "padding-top", "15px" )
                        , ( "padding-bottom", "15px" )
                        , ( "font-size", "25px" )
                        ]
                    ]
                    [ text instructor.name ]
                ]
            ]
        ]


viewInstructorCenters : Model -> Dashboard -> () -> Html Msg
viewInstructorCenters model data _ =
    div
        [ style
            [ ( "box-shadow", "0.25px 0.25px 0.25px black" )
            , ( "width", "30%" )
            , ( "margin", "auto" )
            , ( "height", "400px" )
            , ( "width", "500px" )
            , ( "display", "flex" )
            , ( "margin-top", "15px" )
            , ( "justify-content", "center" )
            ]
        ]
        [ ul
            [ style
                [ ( "list-style", "none" )
                , ( "padding", "0px" )
                , ( "display", "inline-block" )
                ]
            ]
          <|
            List.indexedMap (centerButton "instruct_" model) data.instructorCenters
        ]


viewPendingPurchase : Model -> List Int -> Int -> ( Id, PendingPurchase ) -> Html Msg
viewPendingPurchase model indexes index ( id, pendingPurchase ) =
    Lists.li []
        [ Lists.content []
            [ a
                [ href <| "/profile.html?id=" ++ pendingPurchase.userId
                , style [ ( "padding-right", "5px" ) ]
                ]
                [ text pendingPurchase.userName ]
            , text pendingPurchase.prizeName
            ]
        , View.Button.icon
            SharedMsg
            (indexes ++ [ index ])
            model
            []
            (MarkOrdered pendingPurchase)
            "check"
        , View.Button.icon
            SharedMsg
            (indexes ++ [ index, 1 ])
            model
            []
            (MarkCanceled pendingPurchase)
            "clear"
        ]


viewManagerCenter : Model -> List Int -> Int -> ( Id, Center ) -> Grid.Cell Msg
viewManagerCenter model indexes index ( id, center ) =
    Grid.cell
        [ Grid.size Grid.Desktop 6
        , Grid.size Grid.Phone 4
        , Grid.size Grid.Tablet 8
        , Options.css "box-shadow" "0.25px 0.25px 0.25px black"
        ]
        [ div
            [ style
                [ ( "margin-left", "40px" )
                , ( "margin-right", "40px" )
                , ( "display", "flex" )
                , ( "flex-direction", "column" )
                , ( "margin-bottom", "15px" )
                ]
            ]
            [ h4
                [ style
                    [ ( "text-align", "center" )
                    , ( "margin-top", "10px" )
                    , ( "margin-bottom", "10px" )
                    ]
                ]
                [ a
                    [ href <| "/manage_center.html?id=" ++ id
                    ]
                    [ text center.name ]
                ]
            , if Dict.size center.pendingPurchases == 0 then
                text ""

              else
                h5
                    [ style
                        [ ( "margin", "auto" )
                        , ( "margin-top", "20px" )
                        ]
                    ]
                    [ text "Pending Purchases" ]
            , Lists.ul [] <|
                List.indexedMap
                    (viewPendingPurchase model (indexes ++ [ index ]))
                    (Dict.toList center.pendingPurchases)
            ]
        ]


viewManagerCenters : Model -> Dashboard -> Html Msg
viewManagerCenters model data =
    Grid.grid [ Options.css "margin" "0px" ] <|
        List.indexedMap (viewManagerCenter model [ 0 ]) <|
            Dict.toList data.managerCenters


studentSubs : Model -> Dashboard -> UFirebase.FirebaseApp -> Student.Student -> Sub Msg
studentSubs model data firebase student =
    Sub.batch
        [ UFirebase.idSubscription "lessons" firebase ChangedLesson student.currentLessonId
        , USub.foldMaybe
            (UFirebase.idSubscription "chapters" firebase ChangedChapter
                << .chapterId
            )
            data.lesson
        , USub.foldMaybe
            (UFirebase.idSubscription "milestones" firebase ChangedMilestone
                << .milestoneId
            )
            data.chapter
        ]


firebaseSubs : Model -> UFirebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    case model.userData of
        Loading ->
            Sub.none

        Success data ->
            case model.sharedModel.user of
                Just { uid } ->
                    Sub.batch
                        [ UFirebase.idSubscription "users" firebase ChangedUser uid
                        , USub.foldMaybe (studentSubs model data firebase) data.student
                        , Dict.toList data.managerCenters
                            |> List.map
                                (\( id, _ ) ->
                                    PrizePurchase.subPendingPurchasesForCenter
                                        id
                                        (UpdatePendingPurchase id)
                                        firebase
                                )
                            |> Sub.batch
                        ]

                Nothing ->
                    Sub.none

        NoUser ->
            Sub.none

        Failed error ->
            Sub.none


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , USub.firebaseSubs model firebaseSubs
        ]
