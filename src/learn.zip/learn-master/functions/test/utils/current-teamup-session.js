import test from 'ava'
import sinon from 'sinon'
import proxyquire from 'proxyquire'
import { fakeSessionAttendances } from '../_data_generators'

const getSessionAttendancesStub = sinon.stub()
const teamupApiStub = { getSessionAttendances: getSessionAttendancesStub }

const currentSession =
  proxyquire(
    '../../utils/current-teamup-session',
    {
      './teamup': { ...teamupApiStub, '@noCallThru': true },
      './teamup-token-by-center':
        sinon.stub().withArgs('center-1').returns('center-1-token')
    }
  )

const currentSessionTestMacro = async (t, teamupRes, expectedId) => {
  getSessionAttendancesStub.callsFake((token, id, date) => {
    t.is(token, 'center-1-token')
    t.is(id, '1234')
    return Promise.resolve({ results: teamupRes })
  })
  const result = await currentSession('1234')
  if (expectedId === null) {
    t.is(expectedId, null)
  } else {
    t.is(expectedId, result.id)
  }
}

test.serial(
  'Returns null when there are no recent session attendances',
  currentSessionTestMacro,
  [],
  null
)

test.serial(
  'Returns null when there are no current session attendances',
  currentSessionTestMacro,
  fakeSessionAttendances([[60, 60]]),
  null
)

test.serial(
  'Returns a valid current session',
  currentSessionTestMacro,
  fakeSessionAttendances([[20, 60]]),
  'session-1'
)

test.serial(
  'Doesn\'t return old sessions',
  currentSessionTestMacro,
  fakeSessionAttendances([[31, 60], [20, 60]]),
  'session-2'
)
