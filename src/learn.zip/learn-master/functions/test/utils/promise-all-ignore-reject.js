import test from 'ava'
import sinon from 'sinon'
import promiseAllIgnoreReject from '../../utils/promise-all-ignore-reject'

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

test('resolves all promises', async t => {
  const results = await promiseAllIgnoreReject([
    sleep(1).then(() => Promise.resolve('a')),
    Promise.resolve(1),
    Promise.resolve(30)
  ])
  t.deepEqual(results, ['a', 1, 30])
})

test('still resolves when one rejects', async t => {
  sinon.spy(console, 'error')
  const results = await promiseAllIgnoreReject([
    sleep(1).then(() => Promise.resolve('a')),
    Promise.resolve(1),
    Promise.resolve(30),
    sleep(1).then(() => Promise.reject('Reject!'))
  ])
  t.deepEqual(results, ['a', 1, 30, null])
  t.is(console.error.lastCall.args[0], 'Reject!')
  console.error.restore()
})

test('resolves non-promise values', async t => {
  const results = await promiseAllIgnoreReject([
    sleep(1).then(() => Promise.resolve('a')),
    Promise.resolve(1),
    30
  ])
  t.deepEqual(results, ['a', 1, 30])
})
