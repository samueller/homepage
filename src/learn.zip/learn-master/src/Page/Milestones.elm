module Page.Milestones exposing (main)

import Firebase
import Firebase.Authentication
import Firebase.Database
import Firebase.Database.Reference as Reference
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Html exposing (Html, a, br, button, div, h1, h2, h3, h4, img, li, nav, p, span, strong, text, ul)
import Html.Attributes exposing (class, classList, href, src, style)
import Json.Decode exposing (Decoder, Value, decodeValue, field, int, map2, string)
import List exposing (indexedMap, map, sortBy)
import Material
import Material.Card as Card
import Material.Grid as Grid exposing (..)
import Material.Layout as Layout
import Material.Options exposing (cs, css, onClick)
import Navigation
import Task
import UCode.View as View


main : Program ( User, Student ) Model Msg
main =
    Html.programWithFlags
        { init = init
        , view = view
        , update = update
        , subscriptions = subscriptions
        }



-- MODEL


type alias FirebaseApp =
    { app : Firebase.App
    , db : Types.Database
    }


type alias User =
    { id : String
    , name : String
    , email : String
    , birthDate : String
    }


type alias Lesson =
    { id : String
    , name : String
    , number : Int
    , chapterId : String
    , chapterName : String
    , chapterNumber : Int
    , milestoneId : String
    , milestoneName : String
    , milestoneNumber : Int
    }


type alias Student =
    { centerId : String
    , currentLesson : Lesson
    , active : Bool
    }


type alias Milestone =
    { id : String
    , name : String
    , number : Int
    }


milestoneDecoder : String -> Decoder Milestone
milestoneDecoder id =
    map2 (Milestone id)
        (field "name" string)
        (field "number" int)


type alias Model =
    { mdl : Material.Model
    , firebaseApp : Maybe FirebaseApp
    , user : User
    , student : Student
    , milestones : List Milestone
    }


initFirebase : Firebase.App -> FirebaseApp
initFirebase app =
    FirebaseApp app (Firebase.Database.init app)


init : ( User, Student ) -> ( Model, Cmd Msg )
init ( user, student ) =
    let
        maybeApp : Maybe FirebaseApp
        maybeApp =
            Maybe.map initFirebase (Firebase.app ())
    in
    ( Model Material.model maybeApp user student []
    , Material.init Mdl
    )



-- UPDATE


type Msg
    = Mdl (Material.Msg Msg)
    | Logout
    | LoggedOut ()
    | GotMilestone Types.Snapshot
    | OpenMilestone String
    | OpenLesson String String


addMilestone : List Milestone -> Milestone -> List Milestone
addMilestone milestones milestone =
    sortBy .number (milestone :: milestones)


modelWithMilestone : Model -> String -> Value -> Model
modelWithMilestone model key value =
    case decodeValue (milestoneDecoder key) value of
        Ok milestone ->
            { model | milestones = addMilestone model.milestones milestone }

        Err _ ->
            model


modelWithMaybeMilestone : Model -> Maybe String -> Value -> Model
modelWithMaybeMilestone model maybeKey value =
    case maybeKey of
        Just key ->
            modelWithMilestone model key value

        Nothing ->
            model


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        GotMilestone snapshot ->
            modelWithMaybeMilestone model (Snapshot.key snapshot) (Snapshot.value snapshot) ! []

        OpenMilestone id ->
            ( model, Navigation.load ("milestone.html?id=" ++ id) )

        OpenLesson chapterId id ->
            ( model, Navigation.load ("chapter.html?id=" ++ chapterId ++ "#lesson_" ++ id) )

        Mdl msg_ ->
            Material.update Mdl msg_ model

        Logout ->
            case model.firebaseApp of
                Just firebase ->
                    ( model, Task.perform LoggedOut (Firebase.Authentication.signOut (Firebase.Authentication.init firebase.app)) )

                Nothing ->
                    model ! []

        LoggedOut _ ->
            model ! []



-- VIEW


view : Model -> Html Msg
view model =
    Layout.render Mdl
        model.mdl
        [ Layout.fixedHeader
        , Layout.scrolling
        ]
        { header = View.viewHeader Logout model.user.name
        , drawer = View.viewDrawer Logout model.user.name
        , tabs = ( [], [] )
        , main = viewBody model
        }


viewBody : Model -> List (Html Msg)
viewBody model =
    [ grid []
        [ cell [ Grid.size Tablet 8, Grid.size Desktop 12, Grid.size Phone 4 ]
            [ h1 [ class "milestone__subtitle" ] [ text "Milestones" ]
            , viewMilestones model model.milestones
            ]
        ]
    ]


viewMilestones : Model -> List Milestone -> Html Msg
viewMilestones model =
    ul [ class "chapter__cards" ] << map (viewMilestone model)


viewMilestone : Model -> Milestone -> Html Msg
viewMilestone model milestone =
    let
        locked =
            model.student.currentLesson.milestoneNumber < milestone.number

        cardText =
            Card.text []
                [ h3
                    [ class "chapter__card-heading-1" ]
                    [ text ("Chapter: " ++ toString milestone.number ++ " " ++ milestone.name) ]
                , button [ class "chapter__button" ] [ text "VIEW MILESTONE ", img [ src "/img/right_arrow.svg" ] [] ]
                ]

        cardView =
            Card.view
                (if locked then
                    []

                 else
                    [ onClick (OpenMilestone milestone.id)
                    , css "cursor" "pointer"
                    ]
                )
                [ Card.title []
                    [ div
                        [ style [ ( "background-image", "url('img/ms" ++ toString milestone.number ++ ".jpg')" ) ]
                        , class "chapter__card-title"
                        ]
                        []
                    ]
                , cardText
                ]
    in
    li [ classList [ ( "chapter__card", True ), ( "locked", locked ) ] ] <|
        if locked then
            div [ class "chapter__overlay" ] [ img [ src "/img/Lock_Icon.svg" ] [] ]
                :: [ cardView ]

        else
            [ cardView ]



-- SUBS


ref : String -> Types.Database -> Types.Reference
ref path =
    Firebase.Database.ref (Just path)


subscriptions : Model -> Sub Msg
subscriptions model =
    case model.firebaseApp of
        Just firebase ->
            Sub.batch
                [ Reference.on "child_added" (ref "milestones" firebase.db) GotMilestone
                , Material.subscriptions Mdl model
                ]

        Nothing ->
            Material.subscriptions Mdl model
