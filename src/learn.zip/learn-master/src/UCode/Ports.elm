port module UCode.Ports exposing (..)

{-| Ports used throught the application. Don't forget to hook up the port on
the JS side.
-}


{-| Trigger a Firebase Google oauth sign in.
-}
port signIn : () -> Cmd msg


{-| Retrieve the Firebase user ID token (used to authenticate requests to
Firebase Functions). Use with `receivedUserToken`.
-}
port userToken : () -> Cmd msg


{-| The input port for retrieving the Firebase user ID token. See `userToken`.
-}
port receivedUserToken : (String -> msg) -> Sub msg


type alias User =
    { uid : String
    , displayName : String
    , email : String
    , photoURL : String
    }


{-| Should be connnected with `firbase.auth().onAuthStateChanged`. Don't import
this, use the version from Util.Firebase.Auth
-}
port onAuthStateChanged : (Maybe User -> msg) -> Sub msg
