const functions = require('firebase-functions')
const db = require('../utils/db')

const deleteCacheByUser = ({ userId, centerId }) =>
  db.ref('instructorCenters', userId, centerId).remove()

module.exports =
  functions.database.ref('centerInstructors/{centerId}/{userId}')
    .onDelete((before, context) => deleteCacheByUser(context.params))

module.exports._test = { deleteCacheByUser }
