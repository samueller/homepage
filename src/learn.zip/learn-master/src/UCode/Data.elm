module UCode.Data exposing (..)

import Time exposing (Time)
import Date
import DateFormat
import Dict exposing (Dict)
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Json.Decode as Decode exposing (Decoder, Value, decodeValue)
import Json.Decode.Extra as Decode
import List exposing (concat, filterMap, sortBy)
import List.Extra
import Dict.Extra
import Result exposing (toMaybe)
import Set
import Task exposing (Task)


type alias Id =
    String


type alias WithId a =
    { a | id : String }


type alias WithMaybeId a =
    { a | id : Maybe String }


type alias WithName a =
    { a | name : String }


type alias WithNumber a =
    { a | number : Int }


type alias WithIdAndNumber a =
    WithId (WithNumber a)


type alias WithMaybeIdAndNumber a =
    WithMaybeId (WithNumber a)


type alias WithIdNameAndNumber a =
    WithId (WithName (WithNumber a))


type alias WithNameAndNumber a =
    WithName (WithNumber a)


isJust : Maybe a -> Bool
isJust maybe =
    case maybe of
        Just _ ->
            True

        Nothing ->
            False


isNothing : Maybe a -> Bool
isNothing =
    not << isJust


isEitherJust : Maybe a -> Maybe b -> Bool
isEitherJust a b =
    case ( a, b ) of
        ( Nothing, Nothing ) ->
            False

        _ ->
            True


listWithAddedObjectSorted : WithNumber a -> List (WithNumber a) -> List (WithNumber a)
listWithAddedObjectSorted x =
    List.sortBy .number
        << (::) x


sortedListAddedTo : List (WithNumber a) -> WithNumber a -> List (WithNumber a)
sortedListAddedTo =
    flip listWithAddedObjectSorted


idListSorted : List ( Id, WithNumber a ) -> List ( Id, WithNumber a )
idListSorted =
    List.sortBy <|
        .number
            << Tuple.second


foldResult : a -> (b -> a) -> Result x b -> a
foldResult default fold =
    foldMaybe default fold << toMaybe


maybeFlipped : a -> Maybe b -> Maybe a
maybeFlipped something maybe =
    case maybe of
        Just a ->
            Nothing

        Nothing ->
            Just something


foldMaybe : a -> (b -> a) -> Maybe b -> a
foldMaybe default fold maybe =
    Maybe.withDefault default <|
        Maybe.map fold maybe


fold2Maybes : a -> (b -> c -> a) -> Maybe b -> Maybe c -> a
fold2Maybes default fold maybe1 maybe2 =
    Maybe.withDefault default <|
        Maybe.map2 fold maybe1 maybe2


forkMaybe : (() -> a) -> (b -> a) -> Maybe b -> a
forkMaybe nothingFold justFold maybe =
    case maybe of
        Just a ->
            justFold a

        Nothing ->
            nothingFold ()


foldMaybes : List (Maybe a) -> List a
foldMaybes =
    filterMap identity


foldFlattenMaybes : List (Maybe (List a)) -> List a
foldFlattenMaybes =
    concat << foldMaybes


applyMaybe : (() -> a) -> Bool -> Maybe a
applyMaybe f apply =
    if apply then
        Just (f ())
    else
        Nothing


foldDict : a -> (v -> a) -> comparable -> Dict comparable v -> a
foldDict default f key dict =
    foldMaybe default f <|
        Dict.get key dict


updateJustId : String -> WithMaybeId r -> WithMaybeId r
updateJustId id record =
    { record | id = Just id }


idFromMaybeOfMaybe : String -> Maybe (WithMaybeId r) -> String
idFromMaybeOfMaybe default maybe =
    Maybe.withDefault default <|
        Maybe.andThen .id maybe


{-| A variation of List.Extra.find which returns the result of the predicate
(This isn't actually a predicate because it doesn't just return True or False)
-}
firstSuccess : (a -> Maybe b) -> List a -> Maybe b
firstSuccess predicate list =
    case list of
        [] ->
            Nothing

        first :: rest ->
            case predicate first of
                Just result ->
                    Just result

                Nothing ->
                    firstSuccess predicate rest


recordWithNextNumber : List (WithNumber r) -> WithNumber r -> WithNumber r
recordWithNextNumber records record =
    { record | number = List.length records + 1 }


updateSortedNumberListWithValue : r -> (List (WithNumber a) -> r) -> List (WithNumber a) -> (String -> Decoder (WithNumber a)) -> Value -> String -> r
updateSortedNumberListWithValue record updateRecord list decoder value id =
    case decodeValue (decoder id) value of
        Ok withIdAndNumber ->
            updateRecord (sortedListAddedTo list withIdAndNumber)

        Err error ->
            Debug.log error record


updateSortedNumberListWithSnapshot : r -> (List (WithNumber a) -> r) -> List (WithNumber a) -> (String -> Decoder (WithNumber a)) -> Types.Snapshot -> r
updateSortedNumberListWithSnapshot record updateRecord list decoder snapshot =
    foldMaybe
        record
        (updateSortedNumberListWithValue record updateRecord list decoder (Snapshot.value snapshot))
        (Snapshot.key snapshot)


replacedById : WithId a -> WithId a -> WithId a
replacedById new original =
    if original.id == new.id then
        new
    else
        original


replacedByMaybeId : WithMaybeId a -> WithMaybeId a -> WithMaybeId a
replacedByMaybeId new original =
    if original.id == new.id then
        new
    else
        original


idListAdded : Id -> a -> List ( Id, a ) -> List ( Id, a )
idListAdded id element =
    (::) ( id, element )


idListAddedSorted : Id -> WithNumber a -> List ( Id, WithNumber a ) -> List ( Id, WithNumber a )
idListAddedSorted id element =
    idListSorted
        << idListAdded id element


idListUpdated : Id -> (a -> a) -> List ( Id, a ) -> List ( Id, a )
idListUpdated id f =
    List.map <|
        \idAndObject ->
            if id == Tuple.first idAndObject then
                Tuple.mapSecond f idAndObject
            else
                idAndObject


idListReplaced : Id -> a -> List ( Id, a ) -> List ( Id, a )
idListReplaced id =
    idListUpdated id
        << always


idListReplacedSorted : Id -> WithNumber a -> List ( Id, WithNumber a ) -> List ( Id, WithNumber a )
idListReplacedSorted id element =
    idListSorted
        << idListReplaced id element


idListRemoved : Id -> List ( Id, a ) -> List ( Id, a )
idListRemoved id =
    List.filter <|
        (/=) id
            << Tuple.first


idListRemovedSnapshot : List ( Id, a ) -> Types.Snapshot -> List ( Id, a )
idListRemovedSnapshot list =
    foldMaybe list
        (\key -> idListRemoved key list)
        << Snapshot.key


listWithReplacedObject : WithId a -> List (WithId a) -> List (WithId a)
listWithReplacedObject object =
    List.map <|
        replacedById object


listWithReplacedObjectSorted : WithIdAndNumber a -> List (WithIdAndNumber a) -> List (WithIdAndNumber a)
listWithReplacedObjectSorted object =
    List.sortBy .number
        << List.map
            (replacedById object)


listWithReplacedObjectMaybeIdSorted : WithMaybeIdAndNumber a -> List (WithMaybeIdAndNumber a) -> List (WithMaybeIdAndNumber a)
listWithReplacedObjectMaybeIdSorted object =
    List.sortBy .number
        << List.map
            (replacedByMaybeId object)


listWithRemovedObject : WithId a -> List (WithId a) -> List (WithId a)
listWithRemovedObject object =
    List.filter <|
        (/=) object.id
            << .id


listWithRemovedObjectMaybeId : WithMaybeId a -> List (WithMaybeId a) -> List (WithMaybeId a)
listWithRemovedObjectMaybeId object =
    List.filter <|
        (/=) object.id
            << .id


listWithReplacedValueSorted : (String -> Decoder (WithIdAndNumber a)) -> List (WithIdAndNumber a) -> Value -> String -> List (WithIdAndNumber a)
listWithReplacedValueSorted decoder list value id =
    case decodeValue (decoder id) value of
        Ok decodedValue ->
            List.sortBy .number <|
                listWithReplacedObject decodedValue list

        Err error ->
            Debug.log error list


listWithReplacedSnapshotSorted : (String -> Decoder (WithIdAndNumber a)) -> List (WithIdAndNumber a) -> Types.Snapshot -> List (WithIdAndNumber a)
listWithReplacedSnapshotSorted decoder list snapshot =
    foldMaybe
        list
        (listWithReplacedValueSorted decoder list (Snapshot.value snapshot))
        (Snapshot.key snapshot)


listWithRemovedValue : (String -> Decoder (WithId a)) -> List (WithId a) -> Value -> String -> List (WithId a)
listWithRemovedValue decoder list value id =
    case decodeValue (decoder id) value of
        Ok decodedValue ->
            listWithRemovedObject decodedValue list

        Err error ->
            Debug.log error list


listWithRemovedSnapshot : (String -> Decoder (WithId a)) -> List (WithId a) -> Types.Snapshot -> List (WithId a)
listWithRemovedSnapshot decoder list snapshot =
    foldMaybe
        list
        (listWithRemovedValue decoder list (Snapshot.value snapshot))
        (Snapshot.key snapshot)


recordWithIdAndValue : r -> (a -> r) -> (String -> Decoder a) -> Value -> String -> r
recordWithIdAndValue record updateRecord decoder value id =
    case decodeValue (decoder id) value of
        Ok decodedValue ->
            updateRecord decodedValue

        Err error ->
            Debug.log error record


recordUpdatedFromIdAndValue : r -> (Id -> a -> r) -> Decoder a -> Value -> Id -> r
recordUpdatedFromIdAndValue record updateRecord decoder value id =
    case decodeValue decoder value of
        Ok decodedValue ->
            updateRecord id decodedValue

        Err error ->
            record


recordWithSnapshot : r -> (a -> r) -> (String -> Decoder a) -> Types.Snapshot -> r
recordWithSnapshot record updateRecord decoder snapshot =
    foldMaybe
        record
        (recordWithIdAndValue record updateRecord decoder (Snapshot.value snapshot))
        (Snapshot.key snapshot)


recordUpdatedFromSnapshot : r -> (r -> Id -> a -> r) -> Decoder a -> Types.Snapshot -> r
recordUpdatedFromSnapshot record updateFunc decoder snapshot =
    foldMaybe
        record
        (recordUpdatedFromIdAndValue record (updateFunc record) decoder (Snapshot.value snapshot))
        (Snapshot.key snapshot)


recordUpdatedFromSnapshotKey : r -> (r -> Id -> r) -> Types.Snapshot -> r
recordUpdatedFromSnapshotKey record updateFunc =
    foldMaybe
        record
        (updateFunc record)
        << Snapshot.key


recordUpdatedFromSnapshotValue : r -> (r -> a -> r) -> Decoder a -> Types.Snapshot -> r
recordUpdatedFromSnapshotValue record updateFunc decoder snapshot =
    case decodeValue decoder (Snapshot.value snapshot) of
        Ok decodedValue ->
            updateFunc record decodedValue

        Err error ->
            Debug.log error record


recordUpdatedFromSnapshotValueOrElse : r -> (r -> a -> r) -> (() -> r) -> Decoder a -> Types.Snapshot -> r
recordUpdatedFromSnapshotValueOrElse record updateFunc elseFunc decoder snapshot =
    case decodeValue decoder (Snapshot.value snapshot) of
        Ok decodedValue ->
            updateFunc record decodedValue

        Err _ ->
            elseFunc ()


recordWithSnapshotValue : r -> (a -> r) -> Decoder a -> Types.Snapshot -> r
recordWithSnapshotValue record updateRecord decoder snapshot =
    case decodeValue decoder (Snapshot.value snapshot) of
        Ok decodedValue ->
            updateRecord decodedValue

        Err error ->
            Debug.log error record


withSnapshot : Decoder a -> (a -> b) -> b -> Types.Snapshot -> b
withSnapshot decoder transform default snapshot =
    case decodeValue decoder (Snapshot.value snapshot) of
        Ok decodedValue ->
            transform decodedValue

        Err error ->
            Debug.log error default


maybeFromSnapshot : Decoder a -> Types.Snapshot -> Maybe a
maybeFromSnapshot decoder =
    Result.toMaybe
        << decodeValue decoder
        << Snapshot.value


maybeWithIdFromSnapshot : (String -> Decoder a) -> Types.Snapshot -> Maybe a
maybeWithIdFromSnapshot decoder snapshot =
    Maybe.andThen
        (\id ->
            (Result.toMaybe (decodeValue (decoder id) (Snapshot.value snapshot)))
        )
        (Snapshot.key snapshot)


indexedKeyValueDecoder : (String -> Decoder a) -> Decoder (List a)
indexedKeyValueDecoder valueDecoder =
    Decode.keyValuePairs Decode.value
        |> Decode.andThen
            (\values ->
                List.map
                    (\( key, value ) ->
                        Decode.decodeValue (valueDecoder key) value
                    )
                    values
                    |> List.foldr (Result.map2 (::)) (Ok [])
                    |> Decode.fromResult
            )


indexedKeyValueDecoderDict : (String -> Decoder a) -> Decoder (Dict String a)
indexedKeyValueDecoderDict valueDecoder =
    let
        nextDecodedValue : ( String, Value ) -> Result String (List ( String, a )) -> Result String (List ( String, a ))
        nextDecodedValue ( key, value ) results =
            Decode.decodeValue (valueDecoder key) value
                |> (\result -> Result.map2 (\x xs -> ( key, x ) :: xs) result results)
    in
        Decode.keyValuePairs Decode.value
            |> Decode.andThen
                (List.foldr
                    nextDecodedValue
                    (Ok [])
                    >> Decode.fromResult
                )
            |> Decode.map Dict.fromList


taskFromResult : Result x a -> Task x a
taskFromResult result =
    case result of
        Ok value ->
            Task.succeed value

        Err error ->
            Task.fail error


formatDateOptions : List DateFormat.Token
formatDateOptions =
    [ DateFormat.monthNameFull
    , DateFormat.text " "
    , DateFormat.dayOfMonthNumber
    , DateFormat.text ", "
    , DateFormat.yearNumber
    ]


formatDateTimeOptions : List DateFormat.Token
formatDateTimeOptions =
    formatDateOptions
        ++ [ DateFormat.text " "
           , DateFormat.hourNumber
           , DateFormat.text ":"
           , DateFormat.minuteFixed
           , DateFormat.text " "
           , DateFormat.amPmUppercase
           ]


formatDate : Int -> String
formatDate =
    toFloat >> Date.fromTime >> DateFormat.format formatDateOptions


formatDateTime : Int -> String
formatDateTime =
    toFloat >> Date.fromTime >> DateFormat.format formatDateTimeOptions


randomListElement : Int -> List a -> Maybe a
randomListElement randomNumber list =
    List.Extra.getAt
        (randomNumber % (List.length list))
        list


randomListElementWithDefault : Int -> a -> List a -> a
randomListElementWithDefault randomNumber default =
    Maybe.withDefault default
        << randomListElement randomNumber


idListAddedFromMaybe : a -> Maybe (List a) -> List a
idListAddedFromMaybe element =
    (::) element
        << Maybe.withDefault []


idListReplacedFromMaybe : ( Id, a ) -> Maybe (List ( Id, a )) -> List ( Id, a )
idListReplacedFromMaybe ( id, element ) =
    foldMaybe [ ( id, element ) ] <|
        idListReplaced id element


idListRemovedFromMaybe : Id -> Maybe (List ( Id, a )) -> List ( Id, a )
idListRemovedFromMaybe =
    foldMaybe []
        << idListRemoved


idSetAddedFromMaybe : comparable -> Maybe (Set.Set comparable) -> Set.Set comparable
idSetAddedFromMaybe element =
    Set.insert element
        << Maybe.withDefault Set.empty


dictWithAddedListElement : comparable -> a -> Dict comparable (List a) -> Dict comparable (List a)
dictWithAddedListElement key element =
    Dict.update key (Just << idListAddedFromMaybe element)


dictWithChangedIdListElement : comparable -> ( Id, v ) -> Dict comparable (List ( Id, v )) -> Dict comparable (List ( Id, v ))
dictWithChangedIdListElement key idElement =
    Dict.update key (Just << idListReplacedFromMaybe idElement)


dictWithRemovedIdListElement : comparable -> Id -> Dict comparable (List ( Id, v )) -> Dict comparable (List ( Id, v ))
dictWithRemovedIdListElement key id =
    Dict.update key (Just << idListRemovedFromMaybe id)


dictWithRemovedElementFromSnapshot : Dict Id a -> Types.Snapshot -> Dict Id a
dictWithRemovedElementFromSnapshot dict =
    foldMaybe dict
        (flip Dict.remove dict)
        << Snapshot.key


dictWithAddedSetElement : comparable1 -> comparable2 -> Dict comparable1 (Set.Set comparable2) -> Dict comparable1 (Set.Set comparable2)
dictWithAddedSetElement key element =
    Dict.update key (Just << idSetAddedFromMaybe element)


idListElement : Id -> List ( Id, b ) -> Maybe b
idListElement id =
    Maybe.map Tuple.second
        << List.head
        << List.filter ((==) id << Tuple.first)


idListElementWithDefault : a -> Id -> Maybe (List ( Id, a )) -> a
idListElementWithDefault default id =
    Maybe.withDefault default
        << Maybe.andThen (idListElement id)


batchWithMaybe : Maybe a -> List (a -> Cmd msg) -> Cmd msg
batchWithMaybe maybeArgument fns =
    case maybeArgument of
        Just argument ->
            List.map (\fn -> fn argument) fns |> Cmd.batch

        Nothing ->
            Cmd.none


withId : (a -> Id) -> a -> ( Id, a )
withId id a =
    ( id a, a )


entityDict : List { a | id : Id } -> Dict Id { a | id : Id }
entityDict =
    List.map (withId .id) >> Dict.fromList


groupEntitiesBy : (a -> Id) -> (a -> comparable) -> Dict Id a -> Dict comparable (Dict Id a)
groupEntitiesBy id comparable =
    Dict.values
        >> Dict.Extra.groupBy comparable
        >> Dict.map (\_ -> List.map (withId id) >> Dict.fromList)


monthNumberName : Date.Month -> ( Int, String )
monthNumberName month =
    case month of
        Date.Jan ->
            ( 1, "January" )

        Date.Feb ->
            ( 2, "February" )

        Date.Mar ->
            ( 3, "March" )

        Date.Apr ->
            ( 4, "April" )

        Date.May ->
            ( 5, "May" )

        Date.Jun ->
            ( 6, "June" )

        Date.Jul ->
            ( 7, "July" )

        Date.Aug ->
            ( 8, "August" )

        Date.Sep ->
            ( 9, "September" )

        Date.Oct ->
            ( 10, "October" )

        Date.Nov ->
            ( 11, "November" )

        Date.Dec ->
            ( 12, "December" )


groupEntitiesByMonth : (a -> Id) -> (a -> Time) -> Dict Id a -> Dict ( Int, Int, String ) (Dict Id a)
groupEntitiesByMonth id time =
    let
        formatTime =
            Date.fromTime
                >> (\date ->
                        let
                            ( monthNumber, monthName ) =
                                Date.month date |> monthNumberName
                        in
                            ( Date.year date, monthNumber, monthName )
                   )
    in
        groupEntitiesBy id (time >> formatTime)
