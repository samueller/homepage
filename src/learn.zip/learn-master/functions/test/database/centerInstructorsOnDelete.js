import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const centerInstructorsOnDelete =
  proxyquire(
    '../../database/centerInstructorsOnDelete',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// DELETE CACHE BY USER

test('deleteCacheByUser removes the related cache', async t => {
  mockdatabase.set({
    instructorCenters: { 'user-1': { 'center-1': 'Center 1' } }
  })
  await centerInstructorsOnDelete._test.deleteCacheByUser(
    { centerId: 'center-1', userId: 'user-1' }
  )
  t.falsy(mockdatabase.getData())
})
