module View.Dropdown exposing (OptionConfig, Config, Item(..), render)

import Html exposing (Html, Attribute, select, option, optgroup, text)
import Html.Attributes exposing (attribute, selected, disabled, hidden, value)
import Html.Events exposing (onInput)
import Json.Decode as Decode exposing (Decoder)
import UCode.Data exposing (foldMaybe)


type alias OptionConfig =
    { text : String
    , id : String
    , disabled : Bool
    }


type alias OptionGroupConfig =
    { label : String
    , disabled : Bool
    , options : List OptionConfig
    }


type Item
    = Option OptionConfig
    | OptionGroup OptionGroupConfig


type alias Config msg =
    { placeholder : String
    , options : List Item
    , onSelect : String -> msg
    , selected : Maybe String
    , disabled : Bool
    }


viewPlaceholder : String -> Html msg
viewPlaceholder placeholderText =
    option [ selected True, disabled True, hidden True ] [ text placeholderText ]


viewOption : Maybe String -> OptionConfig -> Html msg
viewOption maybeSelected config =
    option
        [ disabled config.disabled
        , value config.id
        , selected (foldMaybe False ((==) config.id) maybeSelected)
        ]
        [ text config.text ]


viewOptionGroup : Maybe String -> OptionGroupConfig -> Html msg
viewOptionGroup selected config =
    optgroup [ label config.label ] <| List.map (viewOption selected) config.options


viewItem : Maybe String -> Item -> Html msg
viewItem selected item =
    case item of
        Option config ->
            viewOption selected config

        OptionGroup config ->
            viewOptionGroup selected config


label : String -> Attribute msg
label =
    attribute "label"


render : Config msg -> Html msg
render config =
    select [ onInput config.onSelect, disabled config.disabled ] <|
        viewPlaceholder config.placeholder
            :: List.map (viewItem config.selected) config.options
