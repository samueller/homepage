module.exports = {
  extends: 'standard',
  plugins: [
    'standard',
    'promise'
  ],
  rules: {
    'valid-typeof': 'off',
    'spaced-comment': 'off',
    'space-in-parens': 'off',
    'space-before-function-paren': [
      'error',
      {
        anonymous: 'always',
        named: 'never',
        asyncArrow: 'always'
      }
    ],
    'operator-linebreak': [
      'error',
      'before',
      {
        overrides: {
          '=': 'after'
        }
      }
    ],
    'prefer-promise-reject-errors': 'off',
    'comma-style': 'off',
    'indent': [ 'error', 2 ],
    'func-call-spacing': 'off',
    'no-unexpected-multiline': 'off'
  }
}
