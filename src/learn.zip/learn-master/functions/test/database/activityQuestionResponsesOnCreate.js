import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils.js'

const { adminMock, mockdatabase } = createAdminMock()

const activityQuestionResponsesOnCreate =
  proxyquire(
    '../../database/activityQuestionResponsesOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// TEST SETUP

// ex: questions([[true, true], [false, false]])
const questions = questionOptions =>
  questionOptions
    .map((options, questionNumber) =>
      options.map((correct, optionNumber) => ({
        content: `Option ${optionNumber} Question ${questionNumber}`,
        feedback: '',
        correct
      }))
    )
    .reduce((questions, options, questionNumber) => {
      questions[`multResp-question-${questionNumber}`] =
        options.reduce((options, option, optionNumber) => {
          options[`multResp-option-${optionNumber}`] = option
          return options
        }, {})
      return questions
    }, {})

// SCORE QUIZ

test.serial('scoreQuiz records passing submissions', async t => {
  mockdatabase.set({
    multRespOptions: questions([[true, false]]),
    questionResponses: {
      'user-1': {
        'quiz-1': {
          'response-1': {
            timestamp: 0,
            multResp: {
              'multResp-question-0': {
                selections: {
                  'multResp-option-0': true,
                  'multResp-option-1': false
                }
              }
            }
          }
        }
      }
    }
  })
  await activityQuestionResponsesOnCreate._test.scoreQuiz(
    {
      userId: 'user-1',
      activityId: 'activity-1',
      quizId: 'quiz-1',
      responseId: 'response-1'
    }
  )
  const { activityResults } = mockdatabase.getData()
  t.deepEqual(
    activityResults,
    {
      'user-1': {
        'activity-1': {
          score: 100,
          timestamp: activityResults['user-1']['activity-1'].timestamp
        }
      }
    }
  )
})

test.serial('scoreQuiz records failing submissions', async t => {
  mockdatabase.set({
    multRespOptions: questions([[true, false]]),
    questionResponses: {
      'user-1': {
        'quiz-1': {
          'response-1': {
            timestamp: 0,
            multResp: {
              'multResp-question-0': {
                selections: {
                  'multResp-option-0': true,
                  'multResp-option-1': true
                }
              }
            }
          }
        }
      }
    }
  })
  await activityQuestionResponsesOnCreate._test.scoreQuiz(
    {
      userId: 'user-1',
      activityId: 'activity-1',
      quizId: 'quiz-1',
      responseId: 'response-1'
    }
  )
  const { activityResults } = mockdatabase.getData()
  t.deepEqual(
    activityResults,
    {
      'user-1': {
        'activity-1': {
          score: 0,
          timestamp: activityResults['user-1']['activity-1'].timestamp
        }
      }
    }
  )
})

test.serial('scoreQuiz records partial failing submissions', async t => {
  mockdatabase.set({
    multRespOptions: questions([[true, true], [true, false]]),
    questionResponses: {
      'user-1': {
        'quiz-1': {
          'response-1': {
            timestamp: 0,
            multResp: {
              'multResp-question-0': {
                selections: {
                  'multResp-option-0': true,
                  'multResp-option-1': true
                }
              },
              'multResp-question-1': {
                selections: {
                  'multResp-option-0': true,
                  'multResp-option-1': true
                }
              }
            }
          }
        }
      }
    }
  })
  await activityQuestionResponsesOnCreate._test.scoreQuiz(
    {
      userId: 'user-1',
      activityId: 'activity-1',
      quizId: 'quiz-1',
      responseId: 'response-1'
    }
  )
  const { activityResults } = mockdatabase.getData()
  t.deepEqual(
    activityResults,
    {
      'user-1': {
        'activity-1': {
          score: 50,
          timestamp: activityResults['user-1']['activity-1'].timestamp
        }
      }
    }
  )
})
