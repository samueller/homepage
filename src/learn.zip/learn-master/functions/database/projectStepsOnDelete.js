const functions = require('firebase-functions')
const db = require('../utils/db')

const deleteCacheByActivity = ({ projectStepId }) =>
  db.ref('projectStepActivities', projectStepId).remove()

module.exports =
  functions.database.ref('projectSteps/{projectStepId}')
    .onDelete((before, context) => deleteCacheByActivity(context.params))

module.exports._test = { deleteCacheByActivity }
