import test from 'ava'
import proxyquire from 'proxyquire'
import testData from '../_data'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const lessonsOnWrite =
  proxyquire(
    '../../database/lessonsOnWrite',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

test.beforeEach(t => {
  mockdatabase.set(testData)
})

test.serial('cacheByChapter creates a cache entry for new lessons', async t => {
  mockdatabase.child('lessons/lesson-7')
    .set({ name: 'Lesson 7', number: 3, chapterId: 'chapter-1' })
  await lessonsOnWrite._test.cacheByChapter(
    'lesson-7',
    null,
    { name: 'Lesson 7', number: 3, chapterId: 'chapter-1' }
  )
  const { lessonNumbers } = mockdatabase.getData()
  t.deepEqual(
    lessonNumbers['chapter-1'],
    {
      'lesson-1': 1,
      'lesson-2': 2,
      'lesson-7': 3
    }
  )
})

test.serial('cacheByChapter updates cache entries for modified lessons', async t => {
  mockdatabase.child('lessons/lesson-7')
    .set({ name: 'Lesson 7', number: 4, chapterId: 'chapter-1' })
  await lessonsOnWrite._test.cacheByChapter(
    'lesson-7',
    { name: 'Lesson 7', number: 3, chapterId: 'chapter-1' },
    { name: 'Lesson 7', number: 4, chapterId: 'chapter-1' }
  )
  const { lessonNumbers } = mockdatabase.getData()
  t.deepEqual(
    lessonNumbers['chapter-1'],
    {
      'lesson-1': 1,
      'lesson-2': 2,
      'lesson-7': 4
    }
  )
})

test.serial('cacheByChapter removes cache entries for deleted lessons', async t => {
  mockdatabase.child('lessons/lesson-7').remove()
  await lessonsOnWrite._test.cacheByChapter(
    'lesson-7',
    { name: 'Lesson 7', number: 4, chapterId: 'chapter-1' },
    null
  )
  const { lessonNumbers } = mockdatabase.getData()
  t.deepEqual(
    lessonNumbers['chapter-1'],
    {
      'lesson-1': 1,
      'lesson-2': 2
    }
  )
})
