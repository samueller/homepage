const functions = require('firebase-functions')
const db = require('../utils/db')

const deleteLti = ({ ltiId }) =>
  db.ref('ltis', ltiId).remove()

module.exports =
  functions.database.ref('exerciseSets/{exerciseSetId}/{ltiId}')
    .onDelete((before, context) => deleteLti(context.params))

module.exports._test = { deleteLti }
