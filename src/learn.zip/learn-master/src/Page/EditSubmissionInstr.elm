module Page.EditSubmissionInstr exposing (main)

import Html exposing (Html, nav, header, fieldset, legend, h1, h2, h3, h4, h5, h6, p, strong, text, ol, ul, li, span, br, div, a, img, select, option)
import Html.Attributes exposing (id, class, value, href)
import Navigation
import Material
import Material.Grid as Grid
import Material.Options as Options
import Material.Menu as Menu
import Material.Icon as Icon
import Material.Dialog as Dialog
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.View as View
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Data as Data
import UCode.Model exposing (User, SharedModelUser)
import UCode.Msg
import UCode.Firebase
import Types.Lesson as Lesson
import Types.Chapter as Chapter
import Types.Milestone as Milestone
import Types.Instruction as Instruction
import Types.Submission as Submission
import Util.Heading as Heading


main : Program User Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFireDataMaybe SharedMsg initialModel GotSubmissionInstr "submissionInstr" Browser.queryIdMaybe
        , view = View.viewWithUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialSubmissionInstr : Maybe Submission.SubmissionInstr
initialSubmissionInstr =
    Data.maybeFlipped
        Submission.emptySubmissionInstr
        Browser.queryIdMaybe


initialModel : SharedModelUser -> Model
initialModel =
    Model Nothing Nothing Nothing initialSubmissionInstr [] (Browser.queryParam "lesson") (Browser.intQueryParam "number") Submission.emptyField Nothing False


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , submissionInstr : Maybe Submission.SubmissionInstr
    , fields : List Submission.Field
    , lessonId : String
    , number : Int
    , fieldToAdd : Submission.Field
    , fieldToDelete : Maybe Submission.Field
    , updating : Bool
    , sharedModel : SharedModelUser
    }


type Msg
    = SharedMsg UCode.Msg.Msg
    | Mdl (Material.Msg Msg)
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | GotSubmissionInstr (Result Firebase.Errors.Error Types.Snapshot)
    | AddedField Types.Snapshot
    | ChangedField Types.Snapshot
    | MoveField (Maybe String) Int
    | MovedField (Result Firebase.Errors.Error ())
    | RemovedField Types.Snapshot
    | DeleteField Submission.Field
    | ConfirmDeleteField
    | CanceledDelete
    | DeletedField (Result Firebase.Errors.Error ())
    | InputInstruction String
    | InputRubric String
    | InputFieldName String
    | InputFieldLines Int
    | Update
    | Updated (Result Firebase.Errors.Error ())
    | Created String (Result Firebase.Errors.Error ())
    | AddField
    | AddedFieldHere String (Result Firebase.Errors.Error ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        GotSubmissionInstr (Ok snapshot) ->
            Submission.recordWithJustSubmissionInstrSnapshot model snapshot ! []

        GotSubmissionInstr (Err error) ->
            Debug.log "Error retrieving submission instruction" model ! []

        AddedField snapshot ->
            Submission.recordWithAddedFieldSnapshot model snapshot ! []

        ChangedField snapshot ->
            Submission.recordWithChangedFieldSnapshot model snapshot ! []

        MoveField fieldId number ->
            ( model, Submission.updateFieldNumber MovedField model model.submissionInstr fieldId number )

        MovedField _ ->
            model ! []

        RemovedField snapshot ->
            Submission.recordWithRemovedFieldSnapshot model snapshot ! []

        DeleteField fieldToDelete ->
            { model | fieldToDelete = Just fieldToDelete } ! []

        ConfirmDeleteField ->
            case ( model.fieldToDelete, model.submissionInstr ) of
                ( Just fieldToDelete, Just submissionInstr ) ->
                    ( model
                    , Data.foldMaybe
                        Cmd.none
                        (\id ->
                            UCode.Firebase.removeNodeMaybe
                                ("submissionFields/" ++ (Maybe.withDefault "" submissionInstr.id) ++ "/" ++ id)
                                DeletedField
                                model.sharedModel.firebaseApp
                        )
                        fieldToDelete.id
                    )

                ( _, _ ) ->
                    ( model, Cmd.none )

        CanceledDelete ->
            { model | fieldToDelete = Nothing } ! []

        DeletedField _ ->
            { model | fieldToDelete = Nothing } ! []

        InputInstruction instruction ->
            Submission.recordWithMaybeSubmissionInstrInstruction model instruction ! []

        InputRubric rubric ->
            Submission.recordWithMaybeSubmissionInstrRubric model rubric ! []

        InputFieldName name ->
            { model | fieldToAdd = Submission.fieldWithName model.fieldToAdd name } ! []

        InputFieldLines lines ->
            { model | fieldToAdd = Submission.fieldWithLines model.fieldToAdd lines } ! []

        AddField ->
            ( model, Submission.pushField model AddedFieldHere (Data.idFromMaybeOfMaybe "impossible" model.submissionInstr) (Data.recordWithNextNumber model.fields model.fieldToAdd) )

        AddedFieldHere fieldId _ ->
            { model | fieldToAdd = Submission.emptyField } ! []

        Update ->
            ( { model | updating = True }, Submission.createOrUpdateMaybe model Created Updated model.lessonId model.number model.submissionInstr )

        Created id _ ->
            ( { model | updating = False, submissionInstr = Maybe.map (Data.updateJustId id) model.submissionInstr }
            , Navigation.newUrl ("/edit/submission_instruction.html?id=" ++ id ++ "&lesson=" ++ model.lessonId)
            )

        Updated _ ->
            ( { model | updating = False }, Cmd.none )

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model

        Mdl msg_ ->
            Tuple.mapFirst (\sharedModel -> { model | sharedModel = sharedModel }) <|
                Material.update Mdl msg_ model.sharedModel


viewField : Model -> Int -> Submission.Field -> Html Msg
viewField model index field =
    li
        [ class "submission_field"
        , value (toString field.number)
        ]
        [ h5
            [ id ("submission_field_" ++ (Maybe.withDefault "" field.id)) ]
            [ text field.name
            , text " "
            , Menu.render Mdl
                [ 0, index ]
                model.sharedModel.mdl
                [ Menu.ripple, Options.cs "menu-button" ]
                [ View.menuItemOpensDialog
                    (DeleteField field)
                    "delete"
                    "Delete"
                    False
                ]
            , text " "
            , View.buttonMini model SharedMsg (MoveField field.id (field.number - 1)) False False [ 1, index ] [ Icon.view "arrow_upward" [ Icon.size18 ] ]
            , text " "
            , View.buttonMini model SharedMsg (MoveField field.id (field.number + 1)) False False [ 2, index ] [ Icon.view "arrow_downward" [ Icon.size18 ] ]
            ]
        , p
            [ class "instruction" ]
            [ text ((toString field.lines) ++ " lines for input") ]
        ]


createOrUpdateButton : Model -> Submission.SubmissionInstr -> Html Msg
createOrUpdateButton model submissionInstr =
    View.buttonWithText model SharedMsg Update (Submission.invalidFields submissionInstr || model.updating) [ 2 ] <|
        Data.foldMaybe
            "Create"
            (\_ -> "Update")
            submissionInstr.id


viewSubmissionInstr : Model -> Submission.SubmissionInstr -> List (Grid.Cell Msg)
viewSubmissionInstr model submissionInstr =
    [ View.halfWidthDesktopTabletCell
        [ View.fieldsetH3 "📜 Instruction"
            [ View.textarea model SharedMsg InputInstruction 10 "GitHub-Flavored Markdown" True False [ 0 ] submissionInstr.instruction ]
        ]
    , View.halfWidthDesktopTabletWideCell
        [ View.fieldsetH3 "👁 Preview"
            [ Instruction.div submissionInstr.instruction ]
        ]
    , View.halfWidthDesktopTabletCell
        [ View.fieldsetH3 "💯 Rubric"
            [ View.textarea model SharedMsg InputRubric 10 "GitHub-Flavored Markdown" False False [ 1 ] submissionInstr.rubric ]
        ]
    , View.halfWidthDesktopTabletWideCell
        [ View.fieldsetH3 "👁 Preview"
            [ Instruction.div submissionInstr.rubric ]
        ]
    , View.fullWidthCell <|
        createOrUpdateButton model submissionInstr
            :: (Data.foldMaybe
                    []
                    (\_ ->
                        [ h2 []
                            [ text "Fields "
                            , View.buttonMini model SharedMsg CanceledDelete False True [ 2 ] [ Icon.i "add" ]
                            ]
                        , ol [ class "submission_fields" ] <|
                            List.indexedMap (viewField model) model.fields
                        ]
                    )
                    submissionInstr.id
               )
    ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        (Heading.viewActivityEditHeading
            model
            "Edit Submission Instruction"
            :: (Data.foldMaybe
                    [ View.fullWidthCell [ View.spinner ] ]
                    (viewSubmissionInstr model)
                    model.submissionInstr
               )
        )
    , dialog model
    ]


dialog : Model -> Html Msg
dialog model =
    case model.fieldToDelete of
        Just fieldToDelete ->
            Dialog.view []
                [ Dialog.title [] [ text "Confirmation" ]
                , Dialog.content []
                    [ text "Are you sure you want to delete this field?"
                    , Instruction.div fieldToDelete.name
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg ConfirmDeleteField False [ 1, 0, 0 ] "Delete"
                    , View.dialogButtonWithText model SharedMsg CanceledDelete False [ 2, 0, 0 ] "Cancel"
                    ]
                ]

        Nothing ->
            Dialog.view [ Options.cs "with_preview" ]
                [ Dialog.title [] [ text "Add Field" ]
                , Dialog.content []
                    [ View.textfield model SharedMsg InputFieldName "Name" True False [ 3, 0, 0 ] model.fieldToAdd.name
                    , View.intfield model SharedMsg InputFieldLines "Number of lines" model.fieldToAdd.lines [ 4, 0, 0 ]
                    ]
                , Dialog.actions []
                    [ View.dialogButtonWithText model SharedMsg AddField False [ 5, 0, 0 ] "Add"
                    , View.dialogButtonWithText model SharedMsg CanceledDelete False [ 6, 0, 0 ] "Cancel"
                    ]
                ]


submissionInstrSubs : UCode.Firebase.FirebaseApp -> Submission.SubmissionInstr -> Sub Msg
submissionInstrSubs firebase =
    Data.foldMaybe
        Sub.none
        (\id ->
            Sub.batch
                [ Submission.fieldsSub firebase.db AddedField id
                , Submission.fieldsChangedSub firebase.db ChangedField id
                , Submission.fieldsRemovedSub firebase.db RemovedField id
                ]
        )
        << .id


firebaseSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Data.foldMaybe
        Sub.none
        (submissionInstrSubs firebase)
        model.submissionInstr


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        , Data.foldMaybe Sub.none (firebaseSubs model) model.sharedModel.firebaseApp
        ]
