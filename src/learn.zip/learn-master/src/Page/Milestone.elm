module Page.Milestone exposing (main)

import Firebase
import Firebase.Authentication
import Firebase.Database
import Firebase.Database.Query as Query
import Firebase.Database.Reference as Reference
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Html exposing (Html, a, br, button, div, h1, h2, h3, h4, img, li, nav, p, span, strong, text, ul)
import Html.Attributes exposing (class, classList, href, src, style)
import Json.Decode exposing (Decoder, Value, decodeValue, field, int, map2, string)
import Json.Encode as Encode
import List exposing (indexedMap, map, sortBy)
import Material
import Material.Card as Card
import Material.Grid as Grid exposing (..)
import Material.Layout as Layout
import Material.Options exposing (cs, css, onClick)
import Navigation
import Task
import UCode.Browser as Browser
import UCode.View as View


main : Program ( User, Student ) Model Msg
main =
    Html.programWithFlags
        { init = init
        , view = view
        , update = update
        , subscriptions = subscriptions
        }



-- MODEL


type alias FirebaseApp =
    { app : Firebase.App
    , db : Types.Database
    }


type alias User =
    { id : String
    , name : String
    , email : String
    , birthDate : String
    }


type alias Lesson =
    { id : String
    , name : String
    , number : Int
    , chapterId : String
    , chapterName : String
    , chapterNumber : Int
    , milestoneId : String
    , milestoneName : String
    , milestoneNumber : Int
    }


type alias Student =
    { centerId : String
    , currentLesson : Lesson
    , active : Bool
    }


type alias Chapter =
    { id : String
    , name : String
    , number : Int
    }


type alias Milestone =
    { id : String
    , name : String
    , number : Int
    }


categoryDecoder : (String -> String -> Int -> a) -> String -> Decoder a
categoryDecoder category id =
    map2 (category id)
        (field "name" string)
        (field "number" int)


type alias Model =
    { mdl : Material.Model
    , firebaseApp : Maybe FirebaseApp
    , user : User
    , student : Student
    , milestoneId : String
    , milestone : Maybe Milestone
    , chapters : List Chapter
    }


initFirebase : Firebase.App -> FirebaseApp
initFirebase app =
    FirebaseApp app (Firebase.Database.init app)


init : ( User, Student ) -> ( Model, Cmd Msg )
init ( user, student ) =
    let
        maybeApp : Maybe FirebaseApp
        maybeApp =
            Maybe.map initFirebase (Firebase.app ())
    in
    ( Model Material.model maybeApp user student (Browser.queryParam "id") Nothing []
    , Material.init Mdl
    )



-- UPDATE


type Msg
    = Mdl (Material.Msg Msg)
    | Logout
    | LoggedOut ()
    | GotMilestone Types.Snapshot
    | GotChapter Types.Snapshot
    | OpenChapter String


addChapter : List Chapter -> Chapter -> List Chapter
addChapter chapters chapter =
    sortBy .number (chapter :: chapters)


modelWithChapter : Model -> String -> Value -> Model
modelWithChapter model key value =
    case decodeValue (categoryDecoder Chapter key) value of
        Ok chapter ->
            { model | chapters = addChapter model.chapters chapter }

        Err _ ->
            model


modelWithMaybeChapter : Model -> Maybe String -> Value -> Model
modelWithMaybeChapter model maybeKey value =
    case maybeKey of
        Just key ->
            modelWithChapter model key value

        Nothing ->
            model


modelWithMilestone : Model -> String -> Value -> Model
modelWithMilestone model key value =
    case decodeValue (categoryDecoder Milestone key) value of
        Ok milestone ->
            { model | milestone = Just milestone }

        Err _ ->
            model


modelWithMaybeMilestone : Model -> Maybe String -> Value -> Model
modelWithMaybeMilestone model maybeKey value =
    case maybeKey of
        Just key ->
            modelWithMilestone model key value

        Nothing ->
            model


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        GotChapter snapshot ->
            modelWithMaybeChapter model (Snapshot.key snapshot) (Snapshot.value snapshot) ! []

        GotMilestone snapshot ->
            modelWithMaybeMilestone model (Snapshot.key snapshot) (Snapshot.value snapshot) ! []

        OpenChapter id ->
            ( model, Navigation.load ("chapter.html?id=" ++ id) )

        Mdl msg_ ->
            Material.update Mdl msg_ model

        Logout ->
            case model.firebaseApp of
                Just firebase ->
                    ( model, Task.perform LoggedOut (Firebase.Authentication.signOut (Firebase.Authentication.init firebase.app)) )

                Nothing ->
                    model ! []

        LoggedOut _ ->
            model ! []



-- VIEW


view : Model -> Html Msg
view model =
    Layout.render Mdl
        model.mdl
        [ Layout.fixedHeader
        , Layout.scrolling
        ]
        { header = View.viewHeader Logout model.user.name
        , drawer = View.viewDrawer Logout model.user.name
        , tabs = ( [], [] )
        , main = viewBody model
        }


viewBody : Model -> List (Html Msg)
viewBody model =
    [ grid []
        [ cell [ Grid.size Tablet 8, Grid.size Desktop 12, Grid.size Phone 4 ]
            ((case model.milestone of
                Just milestone ->
                    [ nav
                        [ class "breadcrumbs" ]
                        [ a
                            [ href "milestones.html" ]
                            [ text "All milestones" ]
                        ]
                    , h1 [ class "milestone__title" ] [ text ("Milestone " ++ toString milestone.number ++ ": " ++ milestone.name) ]
                    ]

                Nothing ->
                    []
             )
                ++ [ h1 [ class "milestone__subtitle" ] [ text "Chapters" ]
                   , viewChapters model model.chapters
                   ]
            )
        ]
    ]


viewChapters : Model -> List Chapter -> Html Msg
viewChapters model =
    ul [ class "chapter__cards" ] << map (viewChapter model)


viewChapter : Model -> Chapter -> Html Msg
viewChapter model chapter =
    let
        currentLesson =
            model.student.currentLesson

        milestoneNumber =
            model.milestone |> Maybe.map (\milestone -> milestone.number)

        locked =
            model.milestone
                |> Maybe.map
                    (\milestone ->
                        currentLesson.milestoneNumber
                            < milestone.number
                            || (currentLesson.milestoneNumber
                                    == milestone.number
                                    && currentLesson.chapterNumber
                                    < chapter.number
                               )
                    )
                |> Maybe.withDefault True

        cardText =
            Card.text []
                [ h3
                    [ class "chapter__card-heading-1" ]
                    [ text ("Chapter: " ++ toString chapter.number ++ " " ++ chapter.name) ]
                , button [ class "chapter__button" ] [ text "VIEW CHAPTER ", img [ src "/img/right_arrow.svg" ] [] ]
                ]

        cardView =
            Card.view
                (if locked then
                    []

                 else
                    [ onClick (OpenChapter chapter.id)
                    , css "cursor" "pointer"
                    ]
                )
                [ Card.title []
                    [ div
                        [ style [ ( "background-image", "url('/img/ms" ++ toString (Maybe.withDefault 0 <| milestoneNumber) ++ "ch" ++ toString chapter.number ++ ".jpg')" ) ]
                        , class "chapter__card-title"
                        ]
                        []
                    ]
                , cardText
                ]
    in
    li [ classList [ ( "chapter__card", True ), ( "locked", locked ) ] ] <|
        if locked then
            div [ class "chapter__overlay" ] [ img [ src "/img/Lock_Icon.svg" ] [] ]
                :: [ cardView ]

        else
            [ cardView ]



-- SUBS


ref : String -> Types.Database -> Types.Reference
ref path =
    Firebase.Database.ref (Just path)


subscriptions : Model -> Sub Msg
subscriptions model =
    case model.firebaseApp of
        Just firebase ->
            Sub.batch
                [ Query.on "child_added" (Query.equalTo (Encode.string model.milestoneId) Nothing (Reference.orderByChild "milestoneId" (ref "chapters" firebase.db))) GotChapter
                , Reference.on "value" (ref ("milestones/" ++ model.milestoneId) firebase.db) GotMilestone
                , Material.subscriptions Mdl model
                ]

        Nothing ->
            Material.subscriptions Mdl model
