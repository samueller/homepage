module Page.NewExercises exposing (main)

import Html exposing (..)
import Material.Grid as Grid
import Firebase.Database.Types as Types
import Firebase.Errors
import UCode.View as View
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Model
import UCode.Msg
import UCode.Firebase as UF
import UCode.Data as Data
import Types.Lesson as Lesson
import Types.Chapter as Chapter
import Types.Milestone as Milestone
import Types.Lti as Lti
import Util.Heading as Heading


main : Program UCode.Model.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUser SharedMsg initialModel
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


initialModel : UCode.Model.SharedModelFirebaseUser -> Model
initialModel =
    Model Nothing Nothing Nothing Browser.queryId (Browser.intQueryParam "number") "" Lti.empty


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , lessonId : String
    , number : Int
    , name : String
    , lti : Lti.Lti
    , sharedModel : UCode.Model.SharedModelFirebaseUser
    }


type Lti
    = Url String
    | Key String
    | Secret String


type Msg
    = SharedMsg UCode.Msg.Msg
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | InputName String
    | Input Lti
    | Create
    | Created Data.Id (Result Firebase.Errors.Error ())


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        InputName name ->
            { model | name = name } ! []

        Input (Url url) ->
            Lti.recordWithLtiUrl url model ! []

        Input (Key key) ->
            Lti.recordWithLtiKey key model ! []

        Input (Secret secret) ->
            Lti.recordWithLtiSecret secret model ! []

        Create ->
            ( model, UF.withModelDb (Lti.createExercises Created) model )

        Created exercisesId _ ->
            ( model, Lti.openEditExercisesUrlWithLesson model.lessonId exercisesId )

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model


viewFields : Model -> List (Grid.Cell Msg)
viewFields model =
    [ View.halfWidthDesktopCell
        [ View.textfield model SharedMsg (InputName) "Name" True False [ 0 ] model.name ]
    , View.halfWidthDesktopCell
        [ View.textfield model SharedMsg (Input << Url) "Url" False False [ 1 ] model.lti.url ]
    , View.halfWidthDesktopCell
        [ View.textfield model SharedMsg (Input << Key) "Key" False False [ 2 ] model.lti.key ]
    , View.halfWidthDesktopCell
        [ View.textfield model SharedMsg (Input << Secret) "Secret" False False [ 3 ] model.lti.secret ]
    , View.halfWidthDesktopCell
        [ View.buttonWithText model SharedMsg Create (Lti.invalidFields model.lti || (String.isEmpty model.name)) [ 4 ] "Create First Exercise" ]
    ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        (Heading.viewActivityEditHeading model "New Exercises with First LTI"
            :: viewFields model
        )
    ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch <|
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        ]
