module Types.Video exposing (..)

import Json.Encode as Encode
import Json.Decode as Decode exposing (Decoder, field)
import Task
import Firebase.Database.Types as Types exposing (Snapshot)
import Firebase.Errors
import UCode.Firebase exposing (firebaseDbTask, updateValueMaybe)
import UCode.Data as Data exposing (foldMaybe, recordWithSnapshot)
import UCode.Model exposing (WithSharedModel)
import Types.Activity as Activity


type alias Video =
    { videoId : String
    , videoType : String
    , content : String
    }


type alias VideoWithId =
    { id : String
    , videoId : String
    , videoType : String
    , content : String
    }


type alias WithVideo r =
    { r | video : Video }


type alias WithMaybeVideo r =
    { r | video : Maybe Video }


type alias WithMaybeVideoWithId r =
    { r | video : Maybe VideoWithId }


decoder : Decoder Video
decoder =
    Decode.map3 Video
        (Decode.field "videoId" Decode.string)
        (Decode.field "videoType" Decode.string)
        (Decode.field "content" Decode.string)


videoDecoder : String -> Decoder VideoWithId
videoDecoder id =
    Decode.map3 (VideoWithId id)
        (Decode.field "videoId" Decode.string)
        (Decode.field "videoType" Decode.string)
        (Decode.field "content" Decode.string)


encoder : Video -> Encode.Value
encoder video =
    Encode.object
        [ ( "videoId", Encode.string video.videoId )
        , ( "videoType", Encode.string video.videoType )
        , ( "content", Encode.string video.content )
        ]


encoderWithId : VideoWithId -> Encode.Value
encoderWithId video =
    Encode.object
        [ ( "videoId", Encode.string video.videoId )
        , ( "videoType", Encode.string video.videoType )
        , ( "content", Encode.string video.content )
        ]


videoFieldsEncoder : String -> String -> String -> Encode.Value
videoFieldsEncoder videoId videoType content =
    Encode.object
        [ ( "videoId", Encode.string videoId )
        , ( "videoType", Encode.string videoType )
        , ( "content", Encode.string content )
        ]


recordWithMaybeVideoTransform : WithMaybeVideo r -> (Video -> Video) -> WithMaybeVideo r
recordWithMaybeVideoTransform record transform =
    { record | video = Maybe.map transform record.video }


recordWithJustVideo : WithMaybeVideo r -> Video -> WithMaybeVideo r
recordWithJustVideo record video =
    { record | video = Just video }


recordUpdatedFromSnapshotValue : WithMaybeVideo r -> Snapshot -> WithMaybeVideo r
recordUpdatedFromSnapshotValue record =
    Data.recordUpdatedFromSnapshotValue record recordWithJustVideo decoder


videoWithVideoType : String -> Video -> Video
videoWithVideoType videoType video =
    { video | videoType = videoType }


videoWithVideoId : String -> Video -> Video
videoWithVideoId videoId video =
    { video | videoId = videoId }


videoWithContent : String -> Video -> Video
videoWithContent content video =
    { video | content = content }


recordWithMaybeVideoVideoType : WithMaybeVideo r -> String -> WithMaybeVideo r
recordWithMaybeVideoVideoType record =
    recordWithMaybeVideoTransform record << videoWithVideoType


recordWithMaybeVideoVideoId : WithMaybeVideo r -> String -> WithMaybeVideo r
recordWithMaybeVideoVideoId record =
    recordWithMaybeVideoTransform record << videoWithVideoId


recordWithMaybeVideoContent : WithMaybeVideo r -> String -> WithMaybeVideo r
recordWithMaybeVideoContent record =
    recordWithMaybeVideoTransform record << videoWithContent


updateVideo : WithSharedModel model a -> (Result Firebase.Errors.Error () -> msg) -> VideoWithId -> Cmd msg
updateVideo model updatedMsg video =
    updateValueMaybe
        updatedMsg
        ("videos/" ++ video.id)
        (encoderWithId video)
        model.sharedModel.firebaseApp


update : WithSharedModel (Data.WithId r) a -> (Result Firebase.Errors.Error () -> msg) -> Video -> Cmd msg
update model updatedMsg video =
    updateValueMaybe
        updatedMsg
        ("videos/" ++ model.id)
        (encoder video)
        model.sharedModel.firebaseApp


create : (Result Firebase.Errors.Error () -> msg) -> String -> Int -> String -> String -> String -> Types.Database -> Cmd msg
create createdMsg lessonId number videoId videoType content db =
    let
        keyAndTask =
            UCode.Firebase.keyAndTaskFromPush db "videos" <|
                videoFieldsEncoder videoId videoType content
    in
        Task.attempt createdMsg <|
            Activity.andPushActivity
                keyAndTask.key
                "video"
                number
                lessonId
                db
                keyAndTask.task


createMaybe : { r | firebaseApp : Maybe UCode.Firebase.FirebaseApp } -> (Result Firebase.Errors.Error () -> msg) -> String -> Int -> String -> String -> String -> Cmd msg
createMaybe model createdMsg lessonId number videoId videoType content =
    foldMaybe
        Cmd.none
        (create createdMsg lessonId number videoId videoType content << .db)
        model.firebaseApp


updateMaybe : WithSharedModel (WithMaybeVideo (Data.WithId r)) a -> (Result Firebase.Errors.Error () -> msg) -> Cmd msg
updateMaybe model updatedMsg =
    foldMaybe
        Cmd.none
        (update model updatedMsg)
        model.video
