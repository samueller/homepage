module Types.LessonResult exposing (InstructorCache, get, getByMonthMilestone)

import Dict exposing (Dict)
import Dict.Extra
import Task exposing (Task)
import Json.Decode as Decode exposing (Decoder)
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Types.Curricula as Curricula exposing (Curricula)


-- TYPES


type alias InstructorCache =
    { id : Id
    , instructorId : Id
    , studentId : Id
    , lessonId : Id
    , centerId : Id
    , timestamp : Int
    }



-- DECODERS


instructorLessonResultDecoder : Id -> Id -> Decoder InstructorCache
instructorLessonResultDecoder id instructorId =
    Decode.map4 (InstructorCache id instructorId)
        (Decode.field "studentId" Decode.string)
        (Decode.field "lessonId" Decode.string)
        (Decode.field "centerId" Decode.string)
        (Decode.field "timestamp" Decode.int)


instructorLessonResultsDecoder : Id -> Decoder (Dict Id InstructorCache)
instructorLessonResultsDecoder instructorId =
    Data.indexedKeyValueDecoderDict
        (\id -> instructorLessonResultDecoder id instructorId)



-- REQUESTS


{-| Transforms a Dict of CachedMilestones into a list, grouped by center, month, and milestone number
-}
groupByMilestone :
    Curricula
    -> Dict Id InstructorCache
    -> Dict Id (List ( String, Dict Int (List InstructorCache) ))
groupByMilestone curricula =
    Dict.Extra.filterMap
        (\_ result ->
            Curricula.findLesson result.lessonId curricula
                |> Maybe.map (\( { number }, _, _ ) -> ( result, number ))
        )
        >> Data.groupEntitiesBy (Tuple.first >> .id) (Tuple.first >> .centerId)
        >> Dict.map
            (\_ ->
                Data.groupEntitiesByMonth
                    (Tuple.first >> .instructorId)
                    (Tuple.first >> .timestamp >> toFloat)
                    >> Dict.map
                        (\_ ->
                            Data.groupEntitiesBy (Tuple.first >> .instructorId) Tuple.second
                                >> Dict.map
                                    (\_ ->
                                        Dict.values
                                            >> List.map Tuple.first
                                            >> List.sortBy .timestamp
                                    )
                        )
                    >> Dict.toList
                    >> List.map (Tuple.mapFirst (\( year, _, month ) -> month ++ " " ++ toString year))
                    >> List.reverse
            )


get :
    Id
    -> FirebaseApp
    -> Task String (Dict Id InstructorCache)
get instructorId =
    UCode.Firebase.valueTask
        [ "instructorLessonResults", instructorId ]
        (Decode.nullable
            (instructorLessonResultsDecoder instructorId)
            |> Decode.map (Maybe.withDefault Dict.empty)
        )


getByMonthMilestone :
    Id
    -> Maybe FirebaseApp
    -> Task String (Dict Id (List ( String, Dict Int (List InstructorCache) )))
getByMonthMilestone instructorId =
    UCode.Firebase.mapDatabaseTask
        (\app ->
            Task.map2
                groupByMilestone
                (Curricula.getTask app.db)
                (get instructorId app)
        )
