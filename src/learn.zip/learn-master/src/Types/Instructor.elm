module Types.Instructor exposing (..)

import Dict exposing (Dict)
import Task exposing (Task)
import Json.Decode as Decode exposing (Decoder)
import Json.Decode.Extra as Decode
import Firebase.Database.Types as Types
import Firebase.Database.Snapshot as Snapshot
import UCode.Firebase exposing (FirebaseApp)
import UCode.Data as Data exposing (Id)
import Util.Firebase.Database as Db


type alias Instructor =
    { centerId : String
    , name : String
    }


type alias InstructorTeamupId =
    { teamupId : Int
    , id : Id
    , name : String
    }


instructorTeamupIdDecoder : Int -> Decoder InstructorTeamupId
instructorTeamupIdDecoder teamupId =
    Decode.map2 (InstructorTeamupId teamupId)
        (Decode.field "id" Decode.string)
        (Decode.field "name" Decode.string)


existsFromSnapshot : Types.Snapshot -> Bool
existsFromSnapshot snapshot =
    case Decode.decodeValue Decode.string (Snapshot.value snapshot) of
        Ok instructor ->
            True

        Err _ ->
            False


getIsInstructor : Id -> FirebaseApp -> Task String Bool
getIsInstructor userId =
    UCode.Firebase.valueTask
        [ "instructorCenters", userId ]
        (Decode.oneOf [ Decode.null False, Decode.succeed True ])


subIsInstructor : Id -> (Result String Bool -> msg) -> FirebaseApp -> Sub msg
subIsInstructor userId =
    UCode.Firebase.subValue
        [ "instructorCenters", userId ]
        (Decode.oneOf [ Decode.null False, Decode.succeed True ])


getCenters : Id -> Task String (List Instructor)
getCenters id =
    Db.getIndexed [ "instructorCenters", id ]
        (\centerId -> Decode.map (Instructor centerId) Decode.string)


getAllForCenter : Id -> FirebaseApp -> Task String (Dict Id Instructor)
getAllForCenter centerId =
    UCode.Firebase.valueTask
        [ "centerInstructors", centerId ]
        (Decode.keyValuePairs
            (Decode.map (Instructor centerId) Decode.string)
            |> Decode.map Dict.fromList
        )


getIndexByTeamupId : () -> Task String (Dict Int InstructorTeamupId)
getIndexByTeamupId () =
    Db.value
        [ "instructorTeamupIds" ]
        (Data.indexedKeyValueDecoderDict
            (String.toInt
                >> Decode.fromResult
                >> Decode.andThen instructorTeamupIdDecoder
            )
        )
        |> Task.andThen
            (Dict.foldl
                (\key value result ->
                    Result.map2 (\intKey -> Dict.insert intKey value)
                        (String.toInt key)
                        result
                )
                (Ok Dict.empty)
                >> Data.taskFromResult
            )
