const db = require('./db')

module.exports = teamupId =>
  db.value('instructorTeamupIds', teamupId, 'userId')
