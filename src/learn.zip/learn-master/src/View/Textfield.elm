module View.Textfield exposing (basic)

import Html exposing (Html)
import Material.Options as Options
import Material.Textfield as Textfield
import UCode.Model exposing (WithSharedModel)
import UCode.Msg


basic :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> List (Textfield.Property msg)
    -> String
    -> String
    -> (String -> msg)
    -> Html msg
basic sharedMsg index model properties label value onInput =
    Textfield.render (sharedMsg << UCode.Msg.Mdl)
        index
        model.sharedModel.mdl
        ([ Textfield.floatingLabel
         , Textfield.label label
         , Textfield.value value
         , Options.onInput onInput
         ]
            ++ properties
        )
        []
