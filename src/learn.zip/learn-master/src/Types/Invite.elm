module Types.Invite
    exposing
        ( Invite
        , Permission(..)
        , getInvitesForCenter
        , createInstructor
        , createStudent
        , delete
        , permissionToString
        , stringToPermission
        )

import Dict exposing (Dict)
import Task exposing (Task)
import Json.Decode as Decode exposing (Decoder, Value)
import Json.Encode as Encode
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Util.Firebase.Database as Db


type Permission
    = Instructor
    | Student


type alias Invite =
    { id : Id
    , email : String
    , name : String
    , birthDate : String
    , centerId : String
    , timestamp : Int
    , permission : Permission
    }


type alias CreateInviteData =
    { email : String
    , name : String
    , birthDate : String
    , centerId : String
    , inviter : String
    , inviterId : Id
    }


decoder : Permission -> String -> Decoder Invite
decoder permission id =
    Decode.map6 (Invite id)
        (Decode.field "email" Decode.string)
        (Decode.field "name" Decode.string)
        (Decode.field "birthDate" Decode.string)
        (Decode.field "centerId" Decode.string)
        (Decode.field "timestamp" Decode.int)
        (Decode.succeed permission)


indexedDecoder : Permission -> Decoder (Dict Id Invite)
indexedDecoder permission =
    Decode.nullable (Data.indexedKeyValueDecoderDict (decoder permission))
        |> Decode.map (Maybe.withDefault Dict.empty)


encoder : Invite -> Value
encoder invite =
    -- Warning: since the invite does not store the inviter/inviterId, those
    -- fields would be removed if you encode an invite then `set` it in
    -- the database. Use `update` instead.
    Encode.object
        [ ( "email", Encode.string invite.email )
        , ( "name", Encode.string invite.name )
        , ( "birthDate", Encode.string invite.birthDate )
        , ( "centerId", Encode.string invite.centerId )
        , ( "timestamp", Encode.int invite.timestamp )
        ]


encoderCreateInvite : CreateInviteData -> Value
encoderCreateInvite invite =
    Encode.object
        [ ( "email", Encode.string invite.email )
        , ( "name", Encode.string invite.name )
        , ( "birthDate", Encode.string invite.birthDate )
        , ( "centerId", Encode.string invite.centerId )
        , ( "timestamp", UCode.Firebase.serverTime )
        , ( "inviter", Encode.string invite.inviter )
        , ( "inviterId", Encode.string invite.inviterId )
        ]


getInstructorsForCenter : Id -> FirebaseApp -> Task String (Dict Id Invite)
getInstructorsForCenter centerId =
    UCode.Firebase.onceByChildTask
        [ "instructorInvites" ]
        "centerId"
        (Encode.string centerId)
        (indexedDecoder Instructor)


getStudentsForCenter : Id -> FirebaseApp -> Task String (Dict Id Invite)
getStudentsForCenter centerId =
    UCode.Firebase.onceByChildTask
        [ "studentInvites" ]
        "centerId"
        (Encode.string centerId)
        (indexedDecoder Student)


getInvitesForCenter : Id -> FirebaseApp -> Task String (Dict Id Invite)
getInvitesForCenter centerId app =
    Task.map2 Dict.union
        (getStudentsForCenter centerId app)
        (getInstructorsForCenter centerId app)


createInstructor : CreateInviteData -> FirebaseApp -> Task String ()
createInstructor data =
    UCode.Firebase.pushTask
        [ "instructorInvites" ]
        (encoderCreateInvite data)


createStudent : CreateInviteData -> FirebaseApp -> Task String ()
createStudent data =
    UCode.Firebase.pushTask
        [ "studentInvites" ]
        (encoderCreateInvite data)


delete : Invite -> Task String ()
delete invite =
    case invite.permission of
        Instructor ->
            deleteInstructor invite

        Student ->
            deleteStudent invite


deleteStudent : Invite -> Task String ()
deleteStudent invite =
    Db.remove [ "studentInvites", invite.id ]


deleteInstructor : Invite -> Task String ()
deleteInstructor invite =
    Db.remove [ "instructorInvites", invite.id ]


permissionToString : Permission -> String
permissionToString permission =
    case permission of
        Student ->
            "Student"

        Instructor ->
            "Instructor"


stringToPermission : String -> Permission
stringToPermission string =
    case string of
        "Student" ->
            Student

        "Instructor" ->
            Instructor

        _ ->
            Student
