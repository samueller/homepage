const functions = require('firebase-functions')
const db = require('../utils/db')
const createTransaction = require('../utils/createTransaction')
const constants = require('../constants')

const createWorkshopReferralTransactions = ({ eventBrightId }, val) => {
  const referredByUserIds = Object.keys(val.referredBy)
  const perUserReward =
    constants.UCOIN_VALUES.WORKSHOP_REFERRAL / referredByUserIds.length
  return Promise.all(
    [
      db.ref('workshopReferrals', eventBrightId, 'ucoins')
        .set(constants.UCOIN_VALUES.WORKSHOP_REFERRAL)
    ]
      .concat(
        referredByUserIds
          .map(userId =>
            createTransaction(
              userId,
              'workshopReferrals',
              eventBrightId,
              false,
              perUserReward,
              false
            )
          )
      )
  )
}

module.exports =
  functions.database.ref('referrals/{eventBrightId}')
    .onCreate((snap, context) =>
      createWorkshopReferralTransactions(context.params, snap.val())
    )

module.exports._test = { createWorkshopReferralTransactions }
