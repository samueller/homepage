module Types.Milestone exposing (..)

import Dict
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Json.Decode as Decode
import Task exposing (Task)
import UCode.Data as Data
import UCode.Firebase


type alias Milestone =
    { id : String
    , name : String
    , number : Int
    }


type alias MilestoneNoId =
    { name : String
    , number : Int
    }


type alias WithMilestone r =
    { r | milestone : Milestone }


type alias WithMilestonesDict r =
    { r | milestones : Dict.Dict Data.Id MilestoneNoId }


type alias WithMaybeMilestone r =
    { r | milestone : Maybe Milestone }


type alias WithMaybeMilestoneNoId r =
    { r | milestone : Maybe MilestoneNoId }


noIdDecoder : Decode.Decoder MilestoneNoId
noIdDecoder =
    Decode.map2 MilestoneNoId
        (Decode.field "name" Decode.string)
        (Decode.field "number" Decode.int)


milestoneDecoder : String -> Decode.Decoder Milestone
milestoneDecoder id =
    Decode.map2 (Milestone id)
        (Decode.field "name" Decode.string)
        (Decode.field "number" Decode.int)


recordWithJustMilestone : WithMaybeMilestone a -> Milestone -> WithMaybeMilestone a
recordWithJustMilestone record milestone =
    { record | milestone = Just milestone }


recordWithJustMilestoneSnapshot : WithMaybeMilestone a -> Types.Snapshot -> WithMaybeMilestone a
recordWithJustMilestoneSnapshot record =
    Data.recordWithSnapshot record (recordWithJustMilestone record) milestoneDecoder


recordWithChangedDictEntry : WithMilestonesDict r -> Data.Id -> MilestoneNoId -> WithMilestonesDict r
recordWithChangedDictEntry record id milestone =
    { record | milestones = Dict.insert id milestone record.milestones }


recordWithRemovedDictEntry : WithMilestonesDict r -> Types.Snapshot -> WithMilestonesDict r
recordWithRemovedDictEntry record snapshot =
    { record | milestones = Data.dictWithRemovedElementFromSnapshot record.milestones snapshot }


sub : UCode.Firebase.FirebaseApp -> (Types.Snapshot -> msg) -> String -> Sub msg
sub =
    UCode.Firebase.idSubscription "milestones"


get : Data.Id -> Types.Database -> Task String Milestone
get id =
    UCode.Firebase.onceTask ("milestones/" ++ id)
        >> Task.andThen
            (Snapshot.value
                >> Decode.decodeValue (milestoneDecoder id)
                >> Data.taskFromResult
            )


getAll : Types.Database -> Task String (List Milestone)
getAll =
    UCode.Firebase.onceTask "milestones"
        >> Task.andThen
            (Snapshot.value
                >> Decode.decodeValue (Data.indexedKeyValueDecoder milestoneDecoder)
                >> Data.taskFromResult
            )
