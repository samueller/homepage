module Types.Center exposing (..)

import Dict exposing (Dict)
import Task exposing (Task)
import Json.Decode as Decode
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Util.Firebase.Database as Db


type alias Center =
    { name : String
    , shortName : String
    }


decoder : Decode.Decoder Center
decoder =
    Decode.map2 Center
        (Decode.field "name" Decode.string)
        (Decode.field "shortName" Decode.string)


sub : Id -> (Result String Center -> msg) -> FirebaseApp -> Sub msg
sub centerId =
    UCode.Firebase.subValue
        [ "centers", centerId ]
        decoder


get : Id -> FirebaseApp -> Task String Center
get centerId =
    UCode.Firebase.valueTask
        [ "centers", centerId ]
        decoder


getAll : () -> Task String (Dict Id Center)
getAll () =
    Db.value [ "centers" ] (Data.indexedKeyValueDecoderDict (\_ -> decoder))
