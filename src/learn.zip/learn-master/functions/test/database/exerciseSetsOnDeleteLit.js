import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const exerciseSetsOnDeleteLti =
  proxyquire(
    '../../database/exerciseSetsOnDeleteLti',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// DELETE CACHE BY USER

test('deleteLti removes the related cache', async t => {
  mockdatabase.set({
    ltis: {
      'lti-1': true,
      'lti-2': true
    }
  })
  await exerciseSetsOnDeleteLti._test.deleteLti(
    { ltiId: 'lti-1' }
  )
  t.deepEqual(mockdatabase.getData(), { ltis: { 'lti-2': true } })
})
