const functions = require('firebase-functions')
const db = require('../utils/db')
const createTransaction = require('../utils/createTransaction')
const promiseAllIgnoreReject = require('../utils/promise-all-ignore-reject')
const constants = require('../constants')

// CREATE CHAPTER COMPLETION TRANSACTION

const createChaterCompletionTransaction = ({ userId, chapterId }, val) =>
  createTransaction(
    userId,
    'chapterCompletions',
    chapterId,
    false,
    val.ucoins,
    false
  )

// CHECK MILESTONE COMPLETION

const markMilestoneComplete = (userId, milestoneId) =>
  Promise.all([
    db.valueOrReject('milestones', milestoneId),
    db.value('students', userId, 'centerId')
  ])
    .then(([milestone, centerId]) =>
      db.ref('milestoneCompletions', userId, milestoneId)
        .set({
          numberAndName: `${milestone.number} ${milestone.name}`,
          completedAt: db.ServerValue.TIMESTAMP,
          ucoins: constants.UCOIN_VALUES.MILESTONE_COMPLETION,
          centerId
        })
    )

const hasCompletedMilestone = (userId, milestoneId) =>
  db.exists('milestoneCompletions', userId, milestoneId)

const chaptersPassed = (userId, milestoneId) =>
  db.valueOrReject('chapterNumbers', milestoneId)
    .then(chapters =>
      Promise.all(
        Object.keys(chapters)
          .map(chapterId => db.exists('chapterCompletions', userId, chapterId))
      )
    )
    .then(completions => completions.every(Boolean))

const checkMilestoneCompletion = ({ userId }, { milestoneId }) =>
  Promise.all([
    chaptersPassed(userId, milestoneId),
    hasCompletedMilestone(userId, milestoneId)
  ])
    .then(([ chaptersPassed, hasCompletedMilestone ]) =>
      !hasCompletedMilestone && chaptersPassed
        && markMilestoneComplete(userId, milestoneId)
    )

module.exports =
  functions.database.ref('chapterCompletions/{userId}/{chapterId}')
    .onCreate((snap, context) =>
      promiseAllIgnoreReject([
        createChaterCompletionTransaction(context.params, snap.val()),
        checkMilestoneCompletion(context.params, snap.val())
      ])
    )

module.exports._test = {
  createChaterCompletionTransaction,
  checkMilestoneCompletion
}
