module Types.Project exposing (..)

import Dict exposing (Dict)
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Reference as Reference
import Firebase.Database.Query as Query
import Firebase.Database.Types as Types
import Firebase.Errors
import Json.Decode as Decode exposing (Decoder)
import Json.Encode as Encode exposing (Value)
import Json.Decode.Extra as Decode
import Navigation
import Task exposing (Task)
import Types.Activity as Activity
import UCode.Data as Data exposing (Id)
import UCode.Firebase as UFirebase


type alias Step =
    { instruction : String
    , rubric : String
    }


type alias StepExt fields =
    { id : String
    , fields : fields
    , instruction : String
    , rubric : String
    }


type alias Submission student projectStep field =
    { student : student
    , projectStep : projectStep
    , fields : Dict Id field
    , timestamp : Int
    }


type alias SubmissionField =
    { name : String
    , lines : Int
    , number : Int
    }


type alias Fields =
    Dict Id SubmissionField


type alias WithStep r =
    { r | projectStep : Step }


type alias WithMaybeStep r =
    { r | projectStep : Maybe Step }


type alias WithStepFields r =
    { r
        | instruction : String
        , rubric : String
    }


type alias WithSubmissionFields r =
    { r | projectSubmissionFields : List ( Data.Id, SubmissionField ) }


type alias Message =
    { id : Id
    , sender : Id
    , senderName : String
    , message : String
    , timestamp : Int
    }


emptyStep : Step
emptyStep =
    Step "" ""


emptySubmissionField : SubmissionField
emptySubmissionField =
    SubmissionField "" 1 1


nextSubmissionField : List a -> SubmissionField
nextSubmissionField =
    SubmissionField "" 1
        << (+) 1
        << List.length


stepDecoder : Decoder Step
stepDecoder =
    Decode.map2 Step
        (Decode.field "instruction" Decode.string)
        (Decode.field "rubric" Decode.string)


stepExtDecoder : Id -> Decoder (StepExt ())
stepExtDecoder id =
    Decode.map2 (StepExt id ())
        (Decode.field "instruction" Decode.string)
        (Decode.field "rubric" Decode.string)


submissionFieldDecoder : Decoder SubmissionField
submissionFieldDecoder =
    Decode.map3 SubmissionField
        (Decode.field "name" Decode.string)
        (Decode.field "lines" Decode.int)
        (Decode.field "number" Decode.int)


submissionDecoder : Id -> Id -> Decoder (Submission Id Id String)
submissionDecoder userId projectStepId =
    Decode.map2 (Submission userId projectStepId)
        (Decode.optionalField "fields" (Decode.keyValuePairs Decode.string)
            |> Decode.map (Maybe.withDefault [] >> Dict.fromList)
        )
        (Decode.field "timestamp" Decode.int)


messageEncoder : { a | sender : Id, senderName : String, message : String } -> Value
messageEncoder message =
    Encode.object
        [ ( "userId", Encode.string message.sender )
        , ( "name", Encode.string message.senderName )
        , ( "message", Encode.string message.message )
        , ( "timestamp", UFirebase.serverTime )
        ]


messageDecoder : Id -> Decoder Message
messageDecoder messageId =
    Decode.map4 (Message messageId)
        (Decode.field "userId" Decode.string)
        (Decode.field "name" Decode.string)
        (Decode.field "message" Decode.string)
        (Decode.field "timestamp" Decode.int)


stepEncoded : Step -> Encode.Value
stepEncoded step =
    stepFieldsEncoded step.instruction step.rubric


stepFieldsEncoded : String -> String -> Encode.Value
stepFieldsEncoded instruction rubric =
    Encode.object
        [ ( "instruction", Encode.string instruction )
        , ( "rubric", Encode.string rubric )
        ]


submissionFieldEncoded : SubmissionField -> Encode.Value
submissionFieldEncoded submissionField =
    submissionFieldFieldsEncoded submissionField.name submissionField.lines submissionField.number


submissionFieldFieldsEncoded : String -> Int -> Int -> Encode.Value
submissionFieldFieldsEncoded name lines number =
    Encode.object
        [ ( "name", Encode.string name )
        , ( "lines", Encode.int lines )
        , ( "number", Encode.int number )
        ]


submissionFieldWithName : String -> SubmissionField -> SubmissionField
submissionFieldWithName name submissionField =
    { submissionField | name = name }


submissionFieldWithLines : Int -> SubmissionField -> SubmissionField
submissionFieldWithLines lines submissionField =
    { submissionField | lines = lines }


submissionFieldWithNumber : Int -> SubmissionField -> SubmissionField
submissionFieldWithNumber number submissionField =
    { submissionField | number = number }


recordWithJustStep : WithMaybeStep r -> Step -> WithMaybeStep r
recordWithJustStep record step =
    { record | projectStep = Just step }


recordWithMaybeStepTransformed : (Step -> Step) -> WithMaybeStep r -> WithMaybeStep r
recordWithMaybeStepTransformed transform record =
    { record | projectStep = Maybe.map transform record.projectStep }


recordWithAddedSubmissionFieldSorted : WithSubmissionFields r -> Data.Id -> SubmissionField -> WithSubmissionFields r
recordWithAddedSubmissionFieldSorted record id submissionField =
    { record | projectSubmissionFields = Data.idListAddedSorted id submissionField record.projectSubmissionFields }


recordWithChangedSubmissionFieldSorted : WithSubmissionFields r -> Data.Id -> SubmissionField -> WithSubmissionFields r
recordWithChangedSubmissionFieldSorted record id submissionField =
    { record | projectSubmissionFields = Data.idListReplacedSorted id submissionField record.projectSubmissionFields }


recordWithRemovedSubmissionField : WithSubmissionFields r -> Data.Id -> WithSubmissionFields r
recordWithRemovedSubmissionField record id =
    { record | projectSubmissionFields = Data.idListRemoved id record.projectSubmissionFields }


recordWithJustStepSnapshot : WithMaybeStep r -> Types.Snapshot -> WithMaybeStep r
recordWithJustStepSnapshot record =
    Data.recordUpdatedFromSnapshotValue record recordWithJustStep stepDecoder


recordWithAddedSubmissionFieldSnapshot : WithSubmissionFields r -> Types.Snapshot -> WithSubmissionFields r
recordWithAddedSubmissionFieldSnapshot record =
    Data.recordUpdatedFromSnapshot
        record
        recordWithAddedSubmissionFieldSorted
        submissionFieldDecoder


recordWithChangedSubmissionFieldSnapshot : WithSubmissionFields r -> Types.Snapshot -> WithSubmissionFields r
recordWithChangedSubmissionFieldSnapshot record =
    Data.recordUpdatedFromSnapshot
        record
        recordWithChangedSubmissionFieldSorted
        submissionFieldDecoder


recordWithRemovedSubmissionFieldSnapshot : WithSubmissionFields r -> Types.Snapshot -> WithSubmissionFields r
recordWithRemovedSubmissionFieldSnapshot record =
    Data.recordUpdatedFromSnapshotKey
        record
        recordWithRemovedSubmissionField


stepWithInstruction : String -> Step -> Step
stepWithInstruction instruction step =
    { step | instruction = instruction }


stepWithRubric : String -> Step -> Step
stepWithRubric rubric step =
    { step | rubric = rubric }


recordWithStepInstruction : String -> WithStep r -> WithStep r
recordWithStepInstruction instruction record =
    { record | projectStep = stepWithInstruction instruction record.projectStep }


recordWithStepRubric : String -> WithStep r -> WithStep r
recordWithStepRubric rubric record =
    { record | projectStep = stepWithRubric rubric record.projectStep }


recordWithMaybeStepInstruction : String -> WithMaybeStep r -> WithMaybeStep r
recordWithMaybeStepInstruction instruction =
    recordWithMaybeStepTransformed <|
        stepWithInstruction instruction


recordWithMaybeStepRubric : String -> WithMaybeStep r -> WithMaybeStep r
recordWithMaybeStepRubric rubric =
    recordWithMaybeStepTransformed <|
        stepWithRubric rubric


updateSubmissionFieldNumber : (Result Firebase.Errors.Error () -> msg) -> Data.Id -> Data.Id -> Int -> Types.Database -> Cmd msg
updateSubmissionFieldNumber updatedMsg stepId submissionFieldId number =
    UFirebase.saveInt
        ("projectStepSubmissionFields/" ++ stepId ++ "/" ++ submissionFieldId ++ "/number")
        updatedMsg
        number


createStep : (String -> Result Firebase.Errors.Error () -> msg) -> String -> Int -> Step -> Types.Database -> Cmd msg
createStep createdMsg lessonId number step db =
    let
        keyAndTask =
            UFirebase.keyAndTaskFromPush db "projectSteps" <|
                stepEncoded step
    in
        Task.attempt (createdMsg keyAndTask.key) <|
            Activity.andPushActivity keyAndTask.key
                "project_step"
                number
                lessonId
                db
                keyAndTask.task


updateStep : (Result Firebase.Errors.Error () -> msg) -> Step -> Data.Id -> Types.Database -> Cmd msg
updateStep updatedMsg step id =
    UFirebase.updateValue
        ("projectSteps/" ++ id)
        (stepEncoded step)
        updatedMsg


updateMaybeStep : (Result Firebase.Errors.Error () -> msg) -> Maybe Step -> Data.Id -> Types.Database -> Cmd msg
updateMaybeStep updatedMsg maybeStep id db =
    Data.foldMaybe
        Cmd.none
        (\step -> updateStep updatedMsg step id db)
        maybeStep


createSubmissionField : (Result Firebase.Errors.Error () -> msg) -> Data.Id -> SubmissionField -> Types.Database -> Cmd msg
createSubmissionField pushedMsg stepId submissionField =
    UFirebase.pushValue
        ("projectStepSubmissionFields/" ++ stepId)
        pushedMsg
        (submissionFieldEncoded submissionField)


updateSubmissionField : (Result Firebase.Errors.Error () -> msg) -> Data.Id -> Data.Id -> SubmissionField -> Types.Database -> Cmd msg
updateSubmissionField updatedMsg stepId id submissionField =
    UFirebase.updateValue
        ("projectStepSubmissionFields/" ++ stepId ++ "/" ++ id)
        (submissionFieldEncoded submissionField)
        updatedMsg


deleteSubmissionField : (Result Firebase.Errors.Error () -> msg) -> Data.Id -> Data.Id -> Types.Database -> Cmd msg
deleteSubmissionField deletedMsg stepId id =
    UFirebase.removeNode
        ("projectStepSubmissionFields/" ++ stepId ++ "/" ++ id)
        deletedMsg


submissionFields : List ( Data.Id, String ) -> Encode.Value
submissionFields fields =
    Encode.object
        [ ( "fields"
          , Encode.object <|
                List.map (Tuple.mapSecond Encode.string) fields
          )
        , ( "timestamp", UFirebase.serverTime )
        ]


submitStep : (Result Firebase.Errors.Error () -> msg) -> Data.Id -> Data.Id -> List ( Data.Id, String ) -> Types.Database -> Cmd msg
submitStep submittedMsg userId projectStepId fields =
    UFirebase.setValue ("projectStepSubmissions/" ++ userId ++ "/" ++ projectStepId) (submissionFields fields) submittedMsg


invalidStep : WithStepFields r -> Bool
invalidStep step =
    List.any String.isEmpty [ step.instruction, step.rubric ]


invalidSubmissionField : SubmissionField -> Bool
invalidSubmissionField submissionField =
    List.any String.isEmpty [ submissionField.name ]


editStepUrlWithLesson : Data.Id -> Data.Id -> String
editStepUrlWithLesson lessonId stepId =
    "/edit/project_step.html?id=" ++ stepId ++ "&lesson=" ++ lessonId


openEditStepUrlWithLesson : Data.Id -> Data.Id -> Cmd msg
openEditStepUrlWithLesson lessonId =
    Navigation.load << editStepUrlWithLesson lessonId


getSubmission :
    Id
    -> Id
    -> (Result String (Submission Id Id String) -> msg)
    -> Maybe UFirebase.FirebaseApp
    -> Cmd msg
getSubmission studentId projectStepId onFinish =
    UFirebase.onceMaybe
        (Result.mapError toString
            >> Result.andThen
                (Snapshot.value >> Decode.decodeValue (submissionDecoder studentId projectStepId))
            >> onFinish
        )
        ("projectStepSubmissions/" ++ studentId ++ "/" ++ projectStepId)


onSubmissionChanged :
    Id
    -> Types.Database
    -> (Result String (Submission Id Id String) -> msg)
    -> (Result String (Submission Id Id String) -> msg)
    -> (Result String (Submission Id Id String) -> msg)
    -> Sub msg
onSubmissionChanged studentId db onCreate onChange onDelete =
    let
        decoder snapshot =
            Snapshot.key snapshot
                |> Result.fromMaybe "No key on snapshot"
                |> Result.andThen
                    (\projectStepId ->
                        Decode.decodeValue
                            (submissionDecoder studentId projectStepId)
                            (Snapshot.value snapshot)
                    )
    in
        UFirebase.objectsSubscriptions
            ("projectStepSubmissions/" ++ studentId)
            db
            (decoder >> onCreate)
            (decoder >> onChange)
            (decoder >> onDelete)


activityIdForProjectStep : Id -> (Result String Id -> msg) -> Maybe UFirebase.FirebaseApp -> Cmd msg
activityIdForProjectStep projectStepId onFinish app =
    UFirebase.onceMaybe
        (Result.mapError toString
            >> Result.andThen
                (Snapshot.value >> Decode.decodeValue Decode.string)
            >> onFinish
        )
        ("projectStepActivities/" ++ projectStepId)
        app


get : Id -> Types.Database -> Task String (StepExt ())
get projectStepId =
    UFirebase.onceTask ("projectSteps/" ++ projectStepId)
        >> Task.andThen
            (Snapshot.value
                >> Decode.decodeValue (stepExtDecoder projectStepId)
                >> Data.taskFromResult
            )


andGetFields : Types.Database -> Task String (StepExt ()) -> Task String (StepExt Fields)
andGetFields db =
    Task.andThen
        (\projectStep ->
            UFirebase.onceTask ("projectStepSubmissionFields/" ++ projectStep.id) db
                |> Task.andThen
                    (Snapshot.value
                        >> Decode.decodeValue
                            (Decode.nullable <|
                                Data.indexedKeyValueDecoder
                                    (\id ->
                                        submissionFieldDecoder
                                            |> Decode.map (\field -> ( id, field ))
                                    )
                            )
                        >> Result.map
                            (\fields ->
                                { projectStep
                                    | fields =
                                        Maybe.withDefault [] fields
                                            |> Dict.fromList
                                }
                            )
                        >> Data.taskFromResult
                    )
        )


getFirstMessage : Id -> Id -> (Result String (Maybe Message) -> msg) -> Maybe UFirebase.FirebaseApp -> Cmd msg
getFirstMessage studentId projectStepId onFinish maybeApp =
    case maybeApp of
        Just { db } ->
            UFirebase.ref ("projectStepMessages/" ++ studentId ++ "/" ++ projectStepId) db
                |> Reference.orderByKey
                |> Query.limitToFirst 1
                |> Query.once "value"
                |> Task.andThen
                    (Snapshot.value
                        >> Decode.decodeValue
                            (Decode.nullable
                                (Data.indexedKeyValueDecoder messageDecoder)
                            )
                        >> Result.map (Maybe.andThen List.head)
                        >> Data.taskFromResult
                    )
                |> Task.attempt onFinish

        Nothing ->
            Cmd.none


onFirstMessageChanged :
    Id
    -> Id
    -> (Maybe Message -> msg)
    -> (String -> msg)
    -> UFirebase.FirebaseApp
    -> Sub msg
onFirstMessageChanged studentId projectStepId onChange onError { db } =
    UFirebase.ref ("projectStepMessages/" ++ studentId ++ "/" ++ projectStepId) db
        |> Reference.orderByKey
        |> Query.limitToFirst 1
        |> (\query ->
                Query.on
                    "value"
                    query
                    (Snapshot.value
                        >> Decode.decodeValue
                            (Decode.nullable
                                (Data.indexedKeyValueDecoder messageDecoder)
                            )
                        >> Result.map (Maybe.andThen List.head)
                        >> (\result ->
                                case result of
                                    Ok message ->
                                        onChange message

                                    Err error ->
                                        onError error
                           )
                    )
           )


addFeedback :
    Id
    -> Id
    -> { sender : Id, senderName : String, message : String }
    -> (Id -> Result String () -> msg)
    -> Maybe UFirebase.FirebaseApp
    -> Cmd msg
addFeedback studentId projectStepId message onFinish maybeApp =
    case maybeApp of
        Just { db } ->
            UFirebase.cmdWithKeyFromPush
                ("projectStepMessages/" ++ studentId ++ "/" ++ projectStepId)
                (\id -> Result.mapError toString >> onFinish id)
                (messageEncoder message)
                db

        Nothing ->
            Cmd.none


setFeedback : Id -> Id -> Message -> (Result String () -> msg) -> Maybe UFirebase.FirebaseApp -> Cmd msg
setFeedback studentId projectStepId message onFinish =
    UFirebase.setValueMaybe
        (Result.mapError toString >> onFinish)
        ("projectStepMessages/" ++ studentId ++ "/" ++ projectStepId ++ "/" ++ message.id)
        (messageEncoder message)
