port module Page.EditChapter exposing (main)

import Html exposing (..)
import Html.Attributes exposing (..)
import Navigation
import Material
import Material.Options as Options
import Material.Menu as Menu
import Material.Button as Button
import Material.Icon as Icon
import Material.Grid as Grid
import Material.Dialog as Dialog
import Material.Textfield as Textfield
import Firebase.Database.Types as Types
import Firebase.Database.Snapshot as Snapshot
import Firebase.Errors
import List
import RemoteData
import UCode.View as View
import UCode.Browser as Browser
import UCode.Users as Users
import UCode.Firebase
import UCode.Data as Data
import UCode.Msg
import UCode.Model
import Types.Activity as Activity
import Types.Lesson as Lesson
import Types.Chapter as Chapter
import Types.Milestone as Milestone
import Types.InstrDesigner as InstrDesigner
import Util.Curriculum as Curriculum
import Util.Heading as Heading


main : Program UCode.Model.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUser SharedMsg initialModel
        , view = View.viewWithFirebaseUser SharedMsg viewBody
        , update = update
        , subscriptions = subscriptions
        }


type DialogState
    = NoDialog
    | LessonDeleteConfirmation Data.Id Lesson.Lesson
    | ActivityDeleteConfirmation Data.Id Data.Id Activity.Activity
    | AddLessonForm String Int
    | EditLessonForm String String


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , chapterId : String
    , fragment : String
    , lessons : List ( Data.Id, Lesson.LessonActivitiesWithIds )
    , instrDesigner : RemoteData.RemoteData Firebase.Errors.Error (Maybe InstrDesigner.InstrDesigner)
    , dialog : DialogState
    , sharedModel : UCode.Model.SharedModelFirebaseUser
    }


initialModel : UCode.Model.SharedModelFirebaseUser -> Model
initialModel =
    Model Nothing Nothing Browser.queryId Browser.fragment [] RemoteData.Loading NoDialog


type Msg
    = SharedMsg UCode.Msg.Msg
    | Mdl (Material.Msg Msg)
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedInstrDesginer Types.Snapshot
    | AddedLesson Types.Snapshot
    | ChangedLesson Types.Snapshot
    | RemovedLesson Types.Snapshot
    | AddedActivity Data.Id Types.Snapshot
    | ChangedActivity Data.Id Types.Snapshot
    | RemovedActivity Data.Id Types.Snapshot
    | MoveActivity Data.Id Data.Id Int
    | MovedActivity (Result Firebase.Errors.Error ())
    | MoveLesson Data.Id Int
    | MovedLesson (Result Firebase.Errors.Error ())
    | EditLesson Data.Id Lesson.Lesson
    | NameInEditLessonForm String String
    | UpdateLesson String String
    | UpdatedLesson (Result Firebase.Errors.Error ())
    | NewLesson
    | NameInAddLessonForm String
    | CreateLesson String Int
    | CreatedLesson (Result Firebase.Errors.Error ())
    | DeleteActivity Data.Id Data.Id Activity.Activity
    | DeleteLesson Data.Id Lesson.Lesson
    | ConfirmDeleteLesson Data.Id
    | ConfirmDeleteActivity Data.Id Data.Id
    | Deleted (Result Firebase.Errors.Error ())
    | CancelDelete
    | OpenActivityPage String String Int


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedInstrDesginer snapshot ->
            { model
                | instrDesigner = RemoteData.Success (InstrDesigner.fromSnapshot snapshot)
            }
                ! []

        AddedLesson snapshot ->
            ( Lesson.recordWithAddedLessonSnapshotSorted model snapshot
            , Data.foldMaybe Cmd.none (View.scrollIfFragmentEndsWith model.fragment) (Snapshot.key snapshot)
            )

        ChangedLesson snapshot ->
            Lesson.recordWithChangedLessonSnapshotSorted model snapshot ! []

        RemovedLesson snapshot ->
            Lesson.recordWithRemovedLessonSnapshot model snapshot ! []

        AddedActivity lessonId snapshot ->
            Lesson.recordWithAddedLessonActivitySnapshotSorted model lessonId snapshot ! []

        ChangedActivity lessonId snapshot ->
            Lesson.recordWithChangedLessonActivitySnapshotSorted model lessonId snapshot ! []

        RemovedActivity lessonId snapshot ->
            Lesson.recordWithRemovedLessonActivitySnapshot model lessonId snapshot ! []

        MoveActivity lessonId activityId number ->
            ( model, UCode.Firebase.foldFirebaseDb (Activity.saveNumber lessonId activityId MovedActivity number) model.sharedModel.firebaseApp )

        MovedActivity _ ->
            model ! []

        MoveLesson lessonId number ->
            ( model, UCode.Firebase.foldFirebaseDb (Lesson.saveNumber lessonId MovedLesson number) model.sharedModel.firebaseApp )

        MovedLesson _ ->
            model ! []

        EditLesson lessonId lesson ->
            { model | dialog = EditLessonForm lessonId lesson.name } ! []

        NameInEditLessonForm id name ->
            { model | dialog = EditLessonForm id name } ! []

        UpdateLesson id name ->
            ( model, UCode.Firebase.foldFirebaseDb (Lesson.saveName id UpdatedLesson name) model.sharedModel.firebaseApp )

        UpdatedLesson _ ->
            model ! []

        NewLesson ->
            { model | dialog = AddLessonForm "" (List.length model.lessons + 1) } ! []

        NameInAddLessonForm name ->
            { model | dialog = AddLessonForm name (List.length model.lessons + 1) } ! []

        CreateLesson name number ->
            ( model, Lesson.createMaybe CreatedLesson name number Browser.queryId model.sharedModel.firebaseApp )

        CreatedLesson _ ->
            model ! []

        DeleteActivity lessonId activityId activity ->
            { model | dialog = ActivityDeleteConfirmation lessonId activityId activity } ! []

        DeleteLesson lessonId lesson ->
            { model | dialog = LessonDeleteConfirmation lessonId lesson } ! []

        ConfirmDeleteLesson lessonId ->
            ( model, Lesson.deleteMaybe Deleted lessonId model.sharedModel.firebaseApp )

        ConfirmDeleteActivity lessonId activityId ->
            ( model, Activity.deleteMaybe Deleted lessonId activityId model.sharedModel.firebaseApp )

        CancelDelete ->
            model ! []

        Deleted _ ->
            model ! []

        OpenActivityPage activityType lessonId number ->
            if activityType == "submission_instruction" then
                ( model, Navigation.load ("/edit/" ++ activityType ++ ".html?lesson=" ++ lessonId ++ "&number=" ++ (toString number)) )
            else
                ( model, Navigation.load ("/new/" ++ activityType ++ ".html?id=" ++ lessonId ++ "&number=" ++ (toString number)) )

        SharedMsg msg_ ->
            UCode.Model.update SharedMsg msg_ model

        Mdl msg_ ->
            Tuple.mapFirst (\sharedModel -> { model | sharedModel = sharedModel }) <|
                Material.update Mdl msg_ model.sharedModel


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Grid.grid []
        [ Heading.viewChapterEditHeading model
        , View.fullWidthCell
            [ h1 []
                [ text "Lessons "
                , View.buttonMini model SharedMsg NewLesson False True [ 0 ] [ Icon.i "add" ]
                ]
            , viewLessons model
            ]
        ]
    , dialog model
    ]


viewLessons : Model -> Html Msg
viewLessons model =
    case model.instrDesigner of
        RemoteData.Failure err ->
            p [] [ text "An error occurred, please try reloading." ]

        RemoteData.Success Nothing ->
            p [] [ text "We couldn't find you as an Instructional Designer, ask a UCode boss for help." ]

        RemoteData.Success (Just instrDesigner) ->
            if instrDesigner.active then
                ol [ class "lessons" ] <|
                    List.indexedMap (viewLesson model) model.lessons
            else
                p [] [ text "You are not an active Instructional Designer, ask a UCode boss for help." ]

        _ ->
            View.spinner


addActivityMenuItems : Data.Id -> Int -> List (Menu.Item Msg)
addActivityMenuItems lessonId number =
    List.map
        (\activity ->
            View.menuItem
                (OpenActivityPage activity lessonId number)
                (Activity.iconFromActivityType activity)
                ("Add " ++ (Activity.nameFromActivityType activity))
        )
        [ "video", "instruction", "quiz", "exercises", "exam", "project_step" ]
        ++ [ View.menuItemAndDivider
                (OpenActivityPage "submission_instruction" lessonId number)
                (Activity.iconFromActivityType "submission_instruction")
                ("Add " ++ (Activity.nameFromActivityType "submission_instruction"))
           ]


viewLesson : Model -> Int -> ( Data.Id, Lesson.LessonActivitiesWithIds ) -> Html Msg
viewLesson model index ( lessonId, { lesson, activities } ) =
    li
        [ class "lesson"
        , value (toString lesson.number)
        ]
        [ h4
            [ id ("lesson_" ++ lessonId) ]
            [ text lesson.name
            , text " "
            , Menu.render Mdl
                [ 0, index ]
                model.sharedModel.mdl
                [ Menu.ripple, Options.cs "menu-button" ]
                (addActivityMenuItems lessonId (List.length activities + 1)
                    ++ [ View.menuItemOpensDialog
                            (EditLesson lessonId lesson)
                            "edit"
                            ("Edit " ++ lesson.name)
                            False
                       , View.menuItemOpensDialog
                            (DeleteLesson lessonId lesson)
                            "delete"
                            ("Delete " ++ lesson.name)
                            (List.length activities > 0)
                       ]
                )
            , text " "
            , View.buttonMini model
                SharedMsg
                (MoveLesson lessonId (lesson.number - 1))
                False
                False
                [ 1, index ]
                [ Icon.view "arrow_upward" [ Icon.size18 ] ]
            , text " "
            , View.buttonMini model
                SharedMsg
                (MoveLesson lessonId (lesson.number + 1))
                False
                False
                [ 2, index ]
                [ Icon.view "arrow_downward" [ Icon.size18 ] ]
            ]
        , ol [ class "activities" ] <|
            List.indexedMap (viewActivity model lessonId index) activities
        ]


viewActivity : Model -> Data.Id -> Int -> Int -> ( Data.Id, Activity.Activity ) -> Html Msg
viewActivity model lessonId lessonIndex index ( activityId, activity ) =
    li
        [ class "activity"
        , value (toString activity.number)
        ]
        [ h5
            [ id ("activity_" ++ activityId) ]
            [ Activity.activityIconUnicode activity.activityType
            , a
                [ href (activity.activityType ++ ".html?id=" ++ activity.activityId ++ "&lesson=" ++ lessonId) ]
                [ text (Activity.nameFromActivityType activity.activityType) ]
            , text " "
            , Menu.render Mdl
                [ 0, index, lessonIndex ]
                model.sharedModel.mdl
                [ Menu.ripple, Options.cs "menu-button" ]
                [ View.menuItemOpensDialog
                    (DeleteActivity lessonId activityId activity)
                    "delete"
                    ("Delete " ++ (Activity.nameFromActivityType activity.activityType))
                    False
                ]
            , text " "
            , View.buttonMini model
                SharedMsg
                (MoveActivity lessonId activityId (activity.number - 1))
                False
                False
                [ 1, index, lessonIndex ]
                [ Icon.view "arrow_upward" [ Icon.size18 ] ]
            , text " "
            , View.buttonMini model
                SharedMsg
                (MoveActivity lessonId activityId (activity.number + 1))
                False
                False
                [ 2, index, lessonIndex ]
                [ Icon.view "arrow_downward" [ Icon.size18 ] ]
            ]
        ]


dialog : Model -> Html Msg
dialog model =
    case model.dialog of
        NoDialog ->
            Dialog.view [] []

        LessonDeleteConfirmation lessonId lesson ->
            Dialog.view
                []
                [ Dialog.title [] [ text "Confirmation" ]
                , Dialog.content []
                    [ p []
                        [ text ("Are you sure you want to delete " ++ lesson.name ++ "?")
                        ]
                    ]
                , Dialog.actions []
                    [ Button.render Mdl
                        [ 1 ]
                        model.sharedModel.mdl
                        [ Dialog.closeOn "click"
                        , Options.onClick (ConfirmDeleteLesson lessonId)
                        ]
                        [ text ("Delete " ++ lesson.name) ]
                    , Button.render Mdl
                        [ 2 ]
                        model.sharedModel.mdl
                        [ Dialog.closeOn "click"
                        , Options.onClick CancelDelete
                        ]
                        [ text "Cancel"
                        ]
                    ]
                ]

        ActivityDeleteConfirmation lessonId activityId activity ->
            Dialog.view
                []
                [ Dialog.title [] [ text "Confirmation" ]
                , Dialog.content []
                    [ p []
                        [ text ("Are you sure you want to delete the " ++ (Activity.nameFromActivityType activity.activityType) ++ "?")
                        ]
                    ]
                , Dialog.actions []
                    [ Button.render Mdl
                        [ 1 ]
                        model.sharedModel.mdl
                        [ Dialog.closeOn "click"
                        , Options.onClick (ConfirmDeleteActivity lessonId activityId)
                        ]
                        [ text ("Delete " ++ activity.activityType) ]
                    , Button.render Mdl
                        [ 2 ]
                        model.sharedModel.mdl
                        [ Dialog.closeOn "click"
                        , Options.onClick CancelDelete
                        ]
                        [ text "Cancel"
                        ]
                    ]
                ]

        AddLessonForm name number ->
            Dialog.view
                []
                [ Dialog.title [] [ text "Add Lesson" ]
                , Dialog.content []
                    [ Textfield.render Mdl
                        [ 3 ]
                        model.sharedModel.mdl
                        [ Textfield.label "Name"
                        , Textfield.floatingLabel
                        , Textfield.text_
                        , Textfield.value name
                        , Textfield.autofocus
                        , Options.onInput NameInAddLessonForm
                        ]
                        []
                    ]
                , Dialog.actions []
                    [ Button.render Mdl
                        [ 1 ]
                        model.sharedModel.mdl
                        [ Dialog.closeOn "click"
                        , Button.disabled
                            |> Options.when (String.isEmpty name)
                        , Options.onClick (CreateLesson name number)
                        ]
                        [ text "Create" ]
                    , Button.render Mdl
                        [ 2 ]
                        model.sharedModel.mdl
                        [ Dialog.closeOn "click"
                        ]
                        [ text "Cancel"
                        ]
                    ]
                ]

        EditLessonForm lessonId name ->
            Dialog.view
                []
                [ Dialog.title [] [ text "Edit Lesson" ]
                , Dialog.content []
                    [ Textfield.render Mdl
                        [ 3 ]
                        model.sharedModel.mdl
                        [ Textfield.label "Name"
                        , Textfield.floatingLabel
                        , Textfield.text_
                        , Textfield.value name
                        , Textfield.autofocus
                        , Options.onInput (NameInEditLessonForm lessonId)
                        ]
                        []
                    ]
                , Dialog.actions []
                    [ Button.render Mdl
                        [ 1 ]
                        model.sharedModel.mdl
                        [ Dialog.closeOn "click"
                        , Button.disabled
                            |> Options.when (String.isEmpty name)
                        , Options.onClick (UpdateLesson lessonId name)
                        ]
                        [ text "Update" ]
                    , Button.render Mdl
                        [ 2 ]
                        model.sharedModel.mdl
                        [ Dialog.closeOn "click"
                        ]
                        [ text "Cancel"
                        ]
                    ]
                ]


lessonSubs : Model -> UCode.Firebase.FirebaseApp -> ( Data.Id, Lesson.LessonActivitiesWithIds ) -> Sub Msg
lessonSubs model firebase ( lessonId, _ ) =
    UCode.Firebase.objectsSubscriptions ("activities/" ++ lessonId) firebase.db (AddedActivity lessonId) (ChangedActivity lessonId) (RemovedActivity lessonId)


firebaseSubs : Model -> UCode.Firebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ Heading.chapterBreadcrumbsSub model ChangedChapter ChangedMilestone firebase
        , InstrDesigner.sub firebase ChangedInstrDesginer model.sharedModel.user.uid
        , UCode.Firebase.objectsByIdSubscriptions "lessons" "chapterId" firebase AddedLesson ChangedLesson RemovedLesson model.chapterId
        , Sub.batch (List.map (lessonSubs model firebase) model.lessons)
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , Data.foldMaybe Sub.none (firebaseSubs model) model.sharedModel.firebaseApp
        ]
