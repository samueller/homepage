module Page.Exercises exposing (main)

import Dict
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Html exposing (..)
import Html.Attributes exposing (..)
import Json.Decode as Decode
import Json.Encode as Encode
import Material.Button as Button
import Material.Dialog as Dialog
import Material.Options as Options
import Navigation
import RemoteData exposing (RemoteData)
import Types.Activity as Activity
import Types.Chapter as Chapter
import Types.Instructor as Instructor
import Types.Lesson as Lesson
import Types.Lti as Lti
import Types.Milestone as Milestone
import UCode.Browser as Browser
import UCode.Data as Data
import UCode.Firebase as UFirebase
import UCode.Model as UModel
import UCode.Msg
import UCode.Sub as USub
import UCode.Users as Users
import UCode.View as View
import Util.Heading as Heading
import View.Button
import View.Dialog


main : Program UModel.FirebaseUser Model Msg
main =
    Html.programWithFlags
        { init = Users.initWithFirebaseUser SharedMsg initialModel
        , view = View.viewWithDialog SharedMsg view
        , update = update
        , subscriptions = subscriptions
        }


type Dialog
    = DialogConfirmNextExercise


type alias Model =
    { milestone : Maybe Milestone.Milestone
    , chapter : Maybe Chapter.Chapter
    , lesson : Maybe Lesson.Lesson
    , lessonId : Data.Id
    , lessonResult : Maybe Lesson.Result
    , activityId : Data.Id
    , activity : Maybe Activity.Activity
    , nextActivityId : Maybe Data.Id
    , nextActivity : Maybe Activity.Activity
    , nextLessonId : Maybe Data.Id
    , nextLesson : Maybe Lesson.Lesson
    , nextLessonActivityId : Maybe Data.Id
    , nextLessonActivity : Maybe Activity.Activity
    , id : Data.Id
    , number : Int
    , exercise : Maybe Lti.Exercise
    , nextExercise : RemoteData.RemoteData String (Maybe Lti.Exercise)
    , ltiId : Maybe String
    , lti : Maybe Lti.Lti
    , ltiOutcome : RemoteData.RemoteData String (Maybe Lti.Outcome)
    , exercises : List ( Data.Id, ( Lti.Exercise, RemoteData.RemoteData String (Maybe Lti.Outcome) ) )
    , outcomes : Maybe (Dict.Dict Data.Id Lti.Outcome)
    , isInstructor : RemoteData String Bool
    , dialog : Maybe Dialog
    , sharedModel : UModel.SharedModelFirebaseUser
    }


initialModel : UModel.SharedModelFirebaseUser -> Model
initialModel sharedModel =
    { milestone = Nothing
    , chapter = Nothing
    , lesson = Nothing
    , lessonId = Browser.queryParam "lesson"
    , lessonResult = Nothing
    , activityId = Browser.queryParam "activity"
    , activity = Nothing
    , nextActivityId = Nothing
    , nextActivity = Nothing
    , nextLessonId = Nothing
    , nextLesson = Nothing
    , nextLessonActivityId = Nothing
    , nextLessonActivity = Nothing
    , id = Browser.queryId
    , number = Browser.intQueryParam "number"
    , exercise = Nothing
    , nextExercise = RemoteData.Loading
    , ltiId = Nothing
    , lti = Nothing
    , ltiOutcome = RemoteData.Loading
    , exercises = []
    , outcomes = Nothing
    , isInstructor = RemoteData.Loading
    , dialog = Nothing
    , sharedModel = sharedModel
    }


type
    Msg
    -- UI
    = SharedMsg UCode.Msg.Msg
    | NextExercise
    | ConfirmNextExercise
    | CloseDialog
      -- DATA
    | ChangedMilestone Types.Snapshot
    | ChangedChapter Types.Snapshot
    | ChangedLesson Types.Snapshot
    | ChangedLessonResult Types.Snapshot
    | ChangedActivity Types.Snapshot
    | ChangedNextActivity Types.Snapshot
    | ChangedNextLesson Types.Snapshot
    | ChangedNextLessonActivity Types.Snapshot
    | ChangedExercise Types.Snapshot
    | ChangedNextExercise Types.Snapshot
    | ChangedLti Types.Snapshot
    | ChangedOutcome Types.Snapshot
    | AddedExerciseOfSet Types.Snapshot
    | ChangedExerciseOfSet Types.Snapshot
    | RemovedExerciseOfSet Types.Snapshot
    | ChangedOutcomes Types.Snapshot
    | ChangedIsInstructor (Result String Bool)


outcomesDecoder : Decode.Decoder (Dict.Dict Data.Id Lti.Outcome)
outcomesDecoder =
    Decode.dict Lti.outcomeDecoder


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        NextExercise ->
            case RemoteData.toMaybe model.nextExercise of
                Just (Just nextExercise) ->
                    model
                        ! [ Navigation.load <|
                                Lti.exercisesUrlWithNumber
                                    model.lessonId
                                    model.activityId
                                    model.id
                                    nextExercise.number
                          ]

                _ ->
                    model ! []

        ConfirmNextExercise ->
            { model | dialog = Just DialogConfirmNextExercise } ! []

        CloseDialog ->
            { model | dialog = Nothing } ! []

        ChangedLesson snapshot ->
            Lesson.recordWithJustLessonSnapshot model snapshot ! []

        ChangedMilestone snapshot ->
            Milestone.recordWithJustMilestoneSnapshot model snapshot ! []

        ChangedChapter snapshot ->
            Chapter.recordWithJustChapterSnapshot model snapshot ! []

        ChangedLessonResult snapshot ->
            Lesson.recordMaybeLessonResultSnapshot model snapshot ! []

        ChangedActivity snapshot ->
            case Decode.decodeValue Activity.decoder (Snapshot.value snapshot) of
                Ok activity ->
                    { model | activity = Just activity } ! []

                Err _ ->
                    { model | activity = Nothing } ! []

        ChangedNextActivity snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Activity.decoder) (Snapshot.value snapshot) of
                Ok (( activityId, activity ) :: _) ->
                    { model
                        | nextActivityId = Just activityId
                        , nextActivity = Just activity
                    }
                        ! []

                _ ->
                    { model
                        | nextActivityId = Nothing
                        , nextActivity = Nothing
                    }
                        ! []

        ChangedNextLesson snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Decode.int) (Snapshot.value snapshot) of
                Ok (( lessonId, number ) :: _) ->
                    { model | nextLessonId = Just lessonId } ! []

                _ ->
                    { model | nextLessonId = Nothing } ! []

        ChangedNextLessonActivity snapshot ->
            case Decode.decodeValue (Decode.keyValuePairs Activity.decoder) (Snapshot.value snapshot) of
                Ok (( activityId, activity ) :: _) ->
                    { model
                        | nextLessonActivityId = Just activityId
                        , nextLessonActivity = Just activity
                    }
                        ! []

                _ ->
                    { model
                        | nextLessonActivityId = Nothing
                        , nextLessonActivity = Nothing
                    }
                        ! []

        ChangedExercise snapshot ->
            Lti.recordWithMaybeFirstExerciseAndIdSnapshot model snapshot ! []

        ChangedNextExercise snapshot ->
            { model
                | nextExercise =
                    Data.foldResult (RemoteData.Success Nothing)
                        (RemoteData.Success << Maybe.map Tuple.second << List.head)
                    <|
                        Decode.decodeValue (Decode.keyValuePairs Lti.exerciseDecoder) <|
                            Snapshot.value snapshot
            }
                ! []

        ChangedLti snapshot ->
            Lti.recordWithMaybeLtiSnapshot model snapshot ! []

        ChangedOutcome snapshot ->
            Data.recordUpdatedFromSnapshotValueOrElse
                model
                (\_ outcome -> { model | ltiOutcome = RemoteData.Success (Just outcome) })
                (\() -> { model | ltiOutcome = RemoteData.Success Nothing })
                Lti.outcomeDecoder
                snapshot
                ! []

        AddedExerciseOfSet snapshot ->
            Data.recordUpdatedFromSnapshot model
                (\model id exercise ->
                    { model
                        | exercises =
                            List.sortBy (.number << Tuple.first << Tuple.second)
                                (( id, ( exercise, RemoteData.Loading ) ) :: model.exercises)
                    }
                )
                Lti.exerciseDecoder
                snapshot
                ! []

        ChangedExerciseOfSet snapshot ->
            Data.recordUpdatedFromSnapshot model
                (\model id exercise ->
                    { model
                        | exercises =
                            List.sortBy (.number << Tuple.first << Tuple.second)
                                (Data.idListUpdated id
                                    (\( _, outcome ) -> ( exercise, outcome ))
                                    model.exercises
                                )
                    }
                )
                Lti.exerciseDecoder
                snapshot
                ! []

        RemovedExerciseOfSet snapshot ->
            { model
                | exercises =
                    Data.idListRemovedSnapshot model.exercises snapshot
            }
                ! []

        ChangedOutcomes snapshot ->
            Data.recordUpdatedFromSnapshotValueOrElse model
                (\model outcomes ->
                    { model | outcomes = Just outcomes }
                )
                (\() ->
                    { model | outcomes = Just Dict.empty }
                )
                outcomesDecoder
                snapshot
                ! []

        ChangedIsInstructor result ->
            { model | isInstructor = RemoteData.fromResult result } ! []

        SharedMsg msg_ ->
            UModel.update SharedMsg msg_ model


nextLink : Model -> Maybe ( String, String )
nextLink model =
    case ( model.nextActivityId, model.nextActivity, model.nextLessonId, model.nextLessonActivityId, model.nextLessonActivity ) of
        ( Just nextActivityId, Just nextActivity, _, _, _ ) ->
            Just ( "Next Activity", Activity.href nextActivity nextActivityId model.lessonId )

        ( _, _, Just nextLessonId, Just nextActivityId, Just nextActivity ) ->
            Just ( "Next Lesson", Activity.href nextActivity nextActivityId nextLessonId )

        _ ->
            Nothing


viewAnswerKeyButton : Model -> String -> Html Msg
viewAnswerKeyButton model ltiUrl =
    case model.isInstructor of
        RemoteData.NotAsked ->
            text ""

        RemoteData.Loading ->
            text ""

        RemoteData.Failure error ->
            text <| "Error while checking your permissions: " ++ error

        RemoteData.Success True ->
            a
                [ href <| "https://www.codereview.com/exercise_solution.html?url=" ++ ltiUrl
                , target "_blank"
                ]
                [ Button.render (UCode.Msg.Mdl >> SharedMsg)
                    [ 3 ]
                    model.sharedModel.mdl
                    [ Button.raised, Button.primary ]
                    [ text "View Answer Key" ]
                ]

        RemoteData.Success False ->
            text ""


viewLti : Model -> List (Html Msg)
viewLti model =
    case ( model.exercise, model.ltiId, model.lti, model.ltiOutcome ) of
        ( Just exercise, Just ltiId, Just lti, RemoteData.Success maybeOutcome ) ->
            [ viewAnswerKeyButton model lti.url
            , iframe
                [ src <|
                    "lti.html?url="
                        ++ lti.url
                        ++ "&key="
                        ++ lti.key
                        ++ "&lti="
                        ++ ltiId
                        ++ "&user="
                        ++ model.sharedModel.user.uid
                        ++ "&activity="
                        ++ model.id
                        ++ "&kind=exercise"
                , style
                    [ ( "margin-top", "10px" )
                    , ( "flex-grow", "1" )
                    , ( "min-height", "400px" )
                    ]
                , class "lti"
                ]
                []
            ]

        _ ->
            [ View.spinner ]


nextActivityButtonText : Model -> Maybe String -> String
nextActivityButtonText model =
    Maybe.withDefault
        (if Data.isJust model.lessonResult then
            "Solve exercise"

         else
            "Finish other activities"
        )


viewNextActivityButton : Model -> Maybe ( String, String ) -> () -> Html Msg
viewNextActivityButton model link () =
    View.buttonLink
        model
        SharedMsg
        (Maybe.map Tuple.second link)
        [ 0 ]
        [ text (nextActivityButtonText model (Maybe.map Tuple.first link)) ]


viewNextExerciseButton : Model -> Lti.Exercise -> Html Msg
viewNextExerciseButton model nextExercise =
    RemoteData.withDefault View.spinner <|
        RemoteData.map
            (\ltiOutcome ->
                let
                    passedExercise =
                        Data.foldMaybe 0 .score ltiOutcome >= 95

                    button =
                        View.Button.raised SharedMsg [ 1 ] model
                in
                if passedExercise then
                    button [] NextExercise "Next exercise"

                else
                    button [ Dialog.openOn "click" ] ConfirmNextExercise "Skip exercise"
            )
            model.ltiOutcome


viewPreviousButton : Model -> Html Msg
viewPreviousButton model =
    View.buttonLink
        model
        SharedMsg
        (Data.applyMaybe
            (\() ->
                Lti.exercisesUrlWithNumber model.lessonId model.activityId model.id (model.number - 1)
            )
            (model.number > 1)
        )
        [ 0 ]
        [ text "Previous" ]


viewNextExerciseOrActivityButton : Model -> Maybe Lti.Exercise -> Html Msg
viewNextExerciseOrActivityButton model nextExercise =
    Data.forkMaybe
        (viewNextActivityButton model (nextLink model))
        (viewNextExerciseButton model)
        nextExercise


viewActivityActions : Model -> Html Msg
viewActivityActions model =
    View.activityActions
        [ viewPreviousButton model
        , RemoteData.withDefault View.spinner <|
            RemoteData.map (viewNextExerciseOrActivityButton model) model.nextExercise
        ]


scoreFromRemoteOutcome : RemoteData.RemoteData String (Maybe Lti.Outcome) -> Float
scoreFromRemoteOutcome outcome =
    case outcome of
        RemoteData.Success (Just outcome) ->
            outcome.score

        _ ->
            0


viewExerciseOfSet : Model -> Dict.Dict Data.Id Lti.Outcome -> ( Data.Id, ( Lti.Exercise, RemoteData.RemoteData String (Maybe Lti.Outcome) ) ) -> Html Msg
viewExerciseOfSet model outcomes ( exerciseId, ( exercise, outcome ) ) =
    if exercise.number == model.number then
        div
            [ class "exercise active"
            , value (toString exercise.number)
            , href ("/exercises.html?id=" ++ model.id ++ "&activity=" ++ model.activityId ++ "&lesson=" ++ model.lessonId ++ "&number=" ++ toString exercise.number)
            ]
            [ Activity.starsHtml (Data.foldMaybe 0 .score (Dict.get exerciseId outcomes))
            , text " "
            , em [] [ text exercise.name ]
            ]

    else
        a
            [ class "exercise"
            , value (toString exercise.number)
            , href ("/exercises.html?id=" ++ model.id ++ "&activity=" ++ model.activityId ++ "&lesson=" ++ model.lessonId ++ "&number=" ++ toString exercise.number)
            ]
            [ Activity.starsHtml (Data.foldMaybe 0 .score (Dict.get exerciseId outcomes))
            , text " "
            , span [] [ text exercise.name ]
            ]


viewExerciseSet : Model -> List (Html Msg)
viewExerciseSet model =
    case model.outcomes of
        Just outcomes ->
            [ div [ class "exercises" ] <|
                List.map (viewExerciseOfSet model outcomes) model.exercises
            ]

        Nothing ->
            [ View.spinner ]


viewBody : Model -> List (Html Msg)
viewBody model =
    [ Html.node "style" [] [ text ".mdl-layout__content { display: flex; }" ]
    , Options.div
        [ Options.css "display" "flex"
        , Options.css "flex-grow" "1"
        , Options.css "flex-direction" "column"
        , Options.css "margin" "10px"
        , Options.css "min-height" "-webkit-min-content"
        ]
        [ Heading.viewActivityHeadingHtml model ""
        , div [] <| viewExerciseSet model
        , Options.div
            [ Options.css "flex-grow" "1"
            , Options.css "display" "flex"
            , Options.css "flex-direction" "column"
            , Options.css "display" "flex"
            , Options.css "flex-shrink" "0"
            ]
            (viewLti model)
        , viewActivityActions model
        ]
    ]


viewDialog : Model -> Dialog -> Html Msg
viewDialog model dialog =
    case dialog of
        DialogConfirmNextExercise ->
            View.Dialog.confirm
                model
                SharedMsg
                [ 0 ]
                "Skip exercise?"
                [ text "Are you sure you want to skip the exercise?" ]
                "Skip"
                "Cancel"
                NextExercise
                CloseDialog


view : Model -> ( List (Html Msg), Html Msg )
view model =
    ( viewBody model
    , model.dialog
        |> Maybe.map (viewDialog model)
        |> Maybe.withDefault View.Dialog.empty
    )


activitySubs : Model -> UFirebase.FirebaseApp -> Activity.Activity -> Sub Msg
activitySubs model firebase activity =
    UFirebase.valuesByChildSubscription ChangedNextActivity ("activities/" ++ model.lessonId) "number" firebase (Encode.int (activity.number + 1))


nextLessonActivitySubs : Model -> UFirebase.FirebaseApp -> Data.Id -> Sub Msg
nextLessonActivitySubs model firebase nextLessonId =
    UFirebase.valuesByChildSubscription ChangedNextLessonActivity ("activities/" ++ nextLessonId) "number" firebase (Encode.int 1)


nextLessonSubs : Model -> UFirebase.FirebaseApp -> Lesson.Result -> Lesson.Lesson -> Sub Msg
nextLessonSubs model firebase lessonResult lesson =
    UFirebase.valuesByChildValueSubscription ChangedNextLesson ("lessonNumbers/" ++ lesson.chapterId) firebase (Encode.int (lesson.number + 1))


ltiSubs : Model -> UFirebase.FirebaseApp -> Data.Id -> Sub Msg
ltiSubs model firebase ltiId =
    Sub.batch
        [ UFirebase.idSubscription "ltis" firebase ChangedLti ltiId
        , UFirebase.idSubscription ("exerciseSetResults/" ++ model.sharedModel.user.uid ++ "/" ++ model.id) firebase ChangedOutcome ltiId
        ]


firebaseSubs : Model -> UFirebase.FirebaseApp -> Sub Msg
firebaseSubs model firebase =
    Sub.batch
        [ UFirebase.idSubscription ("lessonResults/" ++ model.sharedModel.user.uid) firebase ChangedLessonResult model.lessonId
        , UFirebase.idSubscription ("activities/" ++ model.lessonId) firebase ChangedActivity model.activityId
        , USub.foldMaybe (activitySubs model firebase) model.activity
        , USub.foldMaybe (nextLessonActivitySubs model firebase) model.nextLessonId
        , USub.fold2Maybes (nextLessonSubs model firebase) model.lessonResult model.lesson
        , USub.foldMaybe (ltiSubs model firebase) model.ltiId
        , UFirebase.valuesByChildSubscription ChangedExercise ("exerciseSets/" ++ model.id) "number" firebase (Encode.int model.number)
        , UFirebase.valuesByChildSubscription ChangedNextExercise ("exerciseSets/" ++ model.id) "number" firebase (Encode.int (model.number + 1))
        , UFirebase.objectsSubscriptions ("exerciseSets/" ++ model.id) firebase.db AddedExerciseOfSet ChangedExerciseOfSet RemovedExerciseOfSet
        , UFirebase.idSubscription ("exerciseSetResults/" ++ model.sharedModel.user.uid) firebase ChangedOutcomes model.id
        , Instructor.subIsInstructor model.sharedModel.user.uid ChangedIsInstructor firebase
        ]


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ View.materialSub model SharedMsg
        , Heading.activityBreadcrumbsSub model ChangedLesson ChangedChapter ChangedMilestone
        , USub.firebaseSubs model firebaseSubs
        ]
