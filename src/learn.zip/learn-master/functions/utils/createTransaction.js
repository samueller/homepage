const db = require('./db')

/**
 * Used to record UCoins given or taken from a user. Increments the user's ucoins,
 * the nextTransactionId, and inserts a transaction.
 * @param {boolean} recordUcoinsPath
 *   Some transactions store the ucoin value in the instance. Setting this to true
 *   will update the ucoin value in the transaction instance (which assumes the
 *   value was not set upon creation). This is used for transactions such as facebook
 *   likes, where the transaction is created clientside.
 */
module.exports = (userId, reason, reasonId, centerId, ucoins, recordUcoinsPath) => {
  return Promise.all([
    db.value('users', userId, 'ucoins'),
    db.value('ucoinTransactionHistory', userId, 'nextTransactionId')
  ])
    .then(([userUcoins, nextTransactionId]) => {
      userUcoins = userUcoins || 0
      nextTransactionId = nextTransactionId || 0

      const updates = {
        [`/users/${userId}/ucoins`]: userUcoins + ucoins,
        [`/ucoinTransactionHistory/${userId}/nextTransactionId`]:
          nextTransactionId + 1,
        [`/ucoinTransactionHistory/${userId}/transactions/${nextTransactionId}`]: {
          reason,
          reasonId,
          centerId: centerId || null,
          change: ucoins,
          timestamp: db.ServerValue.TIMESTAMP
        }
      }

      if (recordUcoinsPath) {
        updates[recordUcoinsPath] = ucoins
      }

      return db.ref().update(updates)
    })
}
