import moment from 'moment-timezone'

export const fakeTeamupSession = (id, endAgo, duration) => ({
  id: 'session-' + (id + 1),
  start_time: moment().subtract(endAgo + duration, 'minutes').format(),
  end_time: moment().subtract(endAgo, 'minutes').format(),
  utc_start: moment().subtract(endAgo + duration, 'minutes').utc().format()
})

export const fakeSessionAttendances = timings =>
  timings.map((timing, index) => ({ session: fakeTeamupSession(index, ...timing) }))
