const functions = require('firebase-functions')
const db = require('../utils/db')

const cacheByMilestone = (chapterId, before, after) => {
  const milestoneId = before ? before.milestoneId : after.milestoneId
  db.ref('chapterNumbers', milestoneId, chapterId)
    .set(after && after.number)
}

module.exports =
  functions.database.ref('chapters/{chapterId}')
    .onWrite((change, context) =>
      cacheByMilestone(
        context.params.chapterId,
        change.before.val(),
        change.after.val()
      )
    )

module.exports._test = { cacheByMilestone }
