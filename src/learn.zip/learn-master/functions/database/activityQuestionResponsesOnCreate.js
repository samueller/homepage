const functions = require('firebase-functions')
const db = require('../utils/db')
const average = require('../utils/average')

const scoreResponse = (id, response) =>
  db.valueOrReject('multRespOptions', id)
    .then(options => {
      const correct =
        Object.keys(options)
          .every(optionId =>
            options[optionId].correct === response.selections[optionId]
          )
      return correct ? 100 : 0
    })

const scoreResponses = responses =>
  Promise.all(
    Object.keys(responses)
      .map(responseId => scoreResponse(responseId, responses[responseId]))
  )

const scoreQuiz = ({ userId, activityId, quizId, responseId }) =>
  db.value('questionResponses', userId, quizId, responseId, 'multResp')
    .then(responses => {
      if (responses) {
        return scoreResponses(responses).then(average)
      } else {
        return 0
      }
    })
    .then(score => {
      db.ref('activityResults', userId, activityId)
        .set({ score, timestamp: db.ServerValue.TIMESTAMP })
    })

module.exports =
  functions.database.ref('activityQuestionResponses/{userId}/{activityId}/{quizId}/{responseId}')
    .onCreate((snapshot, context) => scoreQuiz(context.params))

module.exports._test = { scoreQuiz }
