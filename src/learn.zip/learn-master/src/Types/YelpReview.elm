module Types.YelpReview exposing (exists, create)

import Task exposing (Task)
import Json.Encode as Encode exposing (Value)
import UCode.Data exposing (Id)
import UCode.Model exposing (FirebaseUser)
import UCode.User as User
import Util.Firebase.Database as Db


encoder : FirebaseUser -> Value
encoder manager =
    Encode.object
        [ ( "recordedAt", Db.serverTime )
        , ( "recordedByUserId", Encode.string manager.uid )
        , ( "recordedByUserName", Encode.string manager.displayName )
        ]


exists : Id -> Task String Bool
exists userId =
    Db.exists [ "yelpReviews", userId ]


create : String -> FirebaseUser -> Task String ()
create userEmail manager =
    User.validateEmailNoDb userEmail
        |> Task.andThen
            (\user ->
                exists user.id
                    |> Task.mapError (\error -> "Failed to check if \"" ++ userEmail ++ "\" already got credit for a yelp review: " ++ error)
                    |> Task.andThen
                        (\hasReviewed ->
                            if hasReviewed then
                                Task.fail <| "\"" ++ userEmail ++ "\" has already gotten credit for a yelp review"
                            else
                                Task.succeed user
                        )
            )
        |> Task.andThen
            (\user ->
                Db.set [ "yelpReviews", user.id ] (encoder manager)
            )
