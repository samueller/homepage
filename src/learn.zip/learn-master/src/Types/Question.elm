module Types.Question exposing (..)

import Json.Encode as Encode
import Firebase.Database.Reference as Reference
import Firebase.Database.Types as Types
import UCode.Firebase


type alias Response =
    { id : String
    , content : String
    }


type alias Question =
    { id : String
    , question : String
    , responsesGood : List Response
    , responsesBad : List Response
    }


type alias WithQuestionFields r =
    { r
        | question : String
    }


fieldsEncoder : String -> Encode.Value
fieldsEncoder question =
    Encode.object
        [ ( "question", Encode.string question )
        ]


invalidFields : WithQuestionFields r -> Bool
invalidFields =
    String.isEmpty << .question


multRespQuestionSub : Types.Database -> (String -> Types.Snapshot -> msg) -> String -> Sub msg
multRespQuestionSub db changedMsg id =
    Reference.on "value" (UCode.Firebase.ref ("questions/multResp/" ++ id ++ "/question") db) (changedMsg id)
