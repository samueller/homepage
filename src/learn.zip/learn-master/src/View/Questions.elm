module View.Questions exposing (multipleChoice, multipleSelect, shortResponse)

{-| View helpers for displaying a "question", for example in a quiz or survey
-}

import Set exposing (Set)
import Html exposing (Html, div, text)
import Html.Attributes exposing (style, id)
import Material.Toggles as Toggles
import Material.Options as Options
import Material.Button as Button
import Material.Textfield as Textfield
import UCode.Model exposing (WithSharedModel)
import UCode.Msg
import Types.Instruction as Instruction


-- Extracting the common code from multipleChoiceOption and multipleResponseOption
-- would be great, but the type signature of such a function would be very long,
-- and might even be impossible to write out because many of the relevant types
-- are not exposed from Material.Toggles


multipleChoiceOption :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> Bool
    -> String
    -> Int
    -> ( String, msg )
    -> Html msg
multipleChoiceOption sharedMsg index model selected key subIndex ( content, onSelectMsg ) =
    Options.div
        [ Options.css "margin-bottom" "10px" ]
        [ Toggles.radio
            (sharedMsg << UCode.Msg.Mdl)
            (index ++ [ subIndex ])
            model.sharedModel.mdl
            [ Toggles.value selected
            , Toggles.group key
            , Toggles.ripple
            , Options.onToggle onSelectMsg
            ]
            [ text content ]
        ]


multipleResponseOption :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> Bool
    -> String
    -> Int
    -> ( String, msg )
    -> Html msg
multipleResponseOption sharedMsg index model selected key subIndex ( content, onSelectMsg ) =
    Options.div
        [ Options.css "margin-bottom" "10px" ]
        [ Toggles.checkbox
            (sharedMsg << UCode.Msg.Mdl)
            (index ++ [ subIndex ])
            model.sharedModel.mdl
            [ Toggles.value selected
            , Toggles.group key
            , Toggles.ripple
            , Options.onToggle onSelectMsg
            ]
            [ text content ]
        ]


viewPreviousNextButtons :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> Bool
    -> Maybe msg
    -> Maybe msg
    -> Html msg
viewPreviousNextButtons sharedMsg index model focused previousMsg nextMsg =
    let
        button : Int -> String -> Maybe msg -> Html msg
        button subIndex txt onClickMsg =
            Button.render
                (sharedMsg << UCode.Msg.Mdl)
                (index ++ [ subIndex ])
                model.sharedModel.mdl
                [ Button.raised
                , Button.primary
                , Button.ripple
                , case onClickMsg of
                    Just msg ->
                        Options.onClick msg

                    Nothing ->
                        Button.disabled
                ]
                [ text txt ]
    in
        if focused then
            div []
                [ button 0 "Previous" previousMsg
                , button 1 "Next" nextMsg
                ]
        else
            text ""


questionStyle : Bool -> Html.Attribute msg
questionStyle focused =
    style
        (if focused then
            []
         else
            [ ( "opacity", "0.2" ) ]
        )


{-| A question where one of several options may be chosen
-}
multipleChoice :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> String
    -> String
    -> List ( String, msg )
    -> Int
    -> Bool
    -> Maybe msg
    -> Maybe msg
    -> Html msg
multipleChoice sharedMsg index model title id_ options selectedOptionIndex focused previousMsg nextMsg =
    div
        [ questionStyle focused
        , id id_
        ]
        [ Instruction.div title
        , div [] <|
            List.indexedMap
                (\subIndex ->
                    multipleChoiceOption
                        sharedMsg
                        (index ++ [ 0 ])
                        model
                        (subIndex == selectedOptionIndex)
                        title
                        subIndex
                )
                options
        , viewPreviousNextButtons sharedMsg (index ++ [ 1 ]) model focused previousMsg nextMsg
        ]


{-| A question where one or more of several options may be chosen
-}
multipleSelect :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> String
    -> String
    -> List ( String, msg )
    -> Set Int
    -> Bool
    -> Maybe msg
    -> Maybe msg
    -> Html msg
multipleSelect sharedMsg index model title id_ options selectedOptionIndexes focused previousMsg nextMsg =
    div
        [ questionStyle focused
        , id id_
        ]
        [ Instruction.div title
        , div [] <|
            List.indexedMap
                (\subIndex ->
                    multipleResponseOption
                        sharedMsg
                        (index ++ [ 0 ])
                        model
                        (Set.member subIndex selectedOptionIndexes)
                        title
                        subIndex
                )
                options
        , viewPreviousNextButtons sharedMsg (index ++ [ 1 ]) model focused previousMsg nextMsg
        ]


shortResponse :
    (UCode.Msg.Msg -> msg)
    -> List Int
    -> WithSharedModel model a
    -> String
    -> String
    -> String
    -> (String -> msg)
    -> Bool
    -> Maybe msg
    -> Maybe msg
    -> Html msg
shortResponse sharedMsg index model question id_ input onInputMsg focused previousMsg nextMsg =
    div
        [ questionStyle focused
        , id id_
        ]
        [ Instruction.div question
        , Textfield.render
            (sharedMsg << UCode.Msg.Mdl)
            (index ++ [ 0 ])
            model.sharedModel.mdl
            [ Options.onInput onInputMsg
            , Textfield.value input
            ]
            []
        , viewPreviousNextButtons sharedMsg (index ++ [ 1 ]) model focused previousMsg nextMsg
        ]
