module Types.UcoinTransaction exposing (..)

import Task
import Json.Decode as Decode exposing (Decoder, Value)
import Json.Decode.Extra as Decode
import UCode.Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Types.FacebookLike
import Types.FacebookWorkshopShare
import Types.UcoinAdjustments
import Types.PrizePurchase
import Types.Referral
import Types.WorkshopReferral
import Types.Completion


type TransactionType
    = MilestoneCompletion Types.Completion.MilestoneCompletion
    | ChapterCompletion Types.Completion.ChapterCompletion
    | PrizePurchase Types.PrizePurchase.PrizePurchase
    | PrizeRefund Int Types.PrizePurchase.PrizePurchase
    | Referral Types.Referral.Referral
    | WorkshopReferral Types.WorkshopReferral.WorkshopReferral
    | FacebookLike Types.FacebookLike.FacebookLike
    | FacebookWorkshopShare Types.FacebookWorkshopShare.FacebookWorkshopShare
    | Adjustment Types.UcoinAdjustments.UcoinAdjustment
    | SurveyCompletion
    | UtypeCompletion
    | TwitterFollow
    | YelpReview
    | ParentTestimonial
    | StudentTestimonial


type TransactionReason
    = ReasonMilestoneCompletion Id
    | ReasonChapterCompletion Id
    | ReasonPrizePurchase Id
    | ReasonPrizeRefund Id
    | ReasonReferral Id
    | ReasonWorkshopReferral Id
    | ReasonFacebookLike
    | ReasonFacebookWorkshopShare Id
    | ReasonAdjustment Id
    | ReasonSurveyCompletion
    | ReasonUtypeCompletion
    | ReasonTwitterFollow
    | ReasonYelpReview
    | ReasonParentTestimonial
    | ReasonStudentTestimonial


type alias Transaction =
    { id : Int
    , reason : TransactionReason
    , change : Int
    , timestamp : Int
    }


type alias History =
    { userId : Id
    , transactions : List Transaction
    }


reasonIdDecoder : Decoder String
reasonIdDecoder =
    Decode.field "reasonId" Decode.string


reasonDecoder : Decoder TransactionReason
reasonDecoder =
    Decode.field "reason" Decode.string
        |> Decode.andThen
            (\string ->
                case string of
                    "milestoneCompletions" ->
                        Decode.map ReasonMilestoneCompletion reasonIdDecoder

                    "chapterCompletions" ->
                        Decode.map ReasonChapterCompletion reasonIdDecoder

                    "prizePurchases" ->
                        Decode.map ReasonPrizePurchase reasonIdDecoder

                    "prizeRefund" ->
                        Decode.map ReasonPrizeRefund reasonIdDecoder

                    "referrals" ->
                        Decode.map ReasonReferral reasonIdDecoder

                    "workshopReferrals" ->
                        Decode.map ReasonWorkshopReferral reasonIdDecoder

                    "facebookLikes" ->
                        Decode.succeed ReasonFacebookLike

                    "ucoinAdjustments" ->
                        Decode.map ReasonAdjustment reasonIdDecoder

                    "exitSurveySubmissions" ->
                        Decode.succeed ReasonSurveyCompletion

                    "utypeCompletions" ->
                        Decode.succeed ReasonUtypeCompletion

                    "facebookEventShares" ->
                        Decode.map ReasonFacebookWorkshopShare reasonIdDecoder

                    "twitterFollows" ->
                        Decode.succeed ReasonTwitterFollow

                    "yelpReviews" ->
                        Decode.succeed ReasonYelpReview

                    "parentTestimonials" ->
                        Decode.succeed ReasonParentTestimonial

                    "studentTestimonials" ->
                        Decode.succeed ReasonStudentTestimonial

                    invalidReason ->
                        Decode.fail <| "Invalid transaction.reason: " ++ invalidReason
            )


transactionDecoder : Int -> Decoder Transaction
transactionDecoder id =
    Decode.map3 (Transaction id)
        reasonDecoder
        (Decode.field "change" Decode.int)
        (Decode.field "timestamp" Decode.int)


historyDecoder : Id -> Decoder History
historyDecoder userId =
    Decode.map (History userId)
        (Decode.field "transactions" (Decode.indexedList transactionDecoder))


getHistory : Id -> (Result String History -> msg) -> FirebaseApp -> Cmd msg
getHistory userId onFinish =
    UCode.Firebase.valueTask
        [ "ucoinTransactionHistory", userId ]
        (Decode.nullable (historyDecoder userId)
            |> Decode.map (Maybe.withDefault (History userId []))
        )
        >> Task.attempt onFinish


getDetailsByReason : Id -> TransactionReason -> (Result String TransactionType -> msg) -> FirebaseApp -> Cmd msg
getDetailsByReason userId transactionReason onFinish app =
    case transactionReason of
        ReasonMilestoneCompletion milestoneId ->
            Types.Completion.getMilestone
                userId
                milestoneId
                (Result.map MilestoneCompletion >> onFinish)
                app

        ReasonChapterCompletion chapterId ->
            Types.Completion.getChapter
                userId
                chapterId
                (Result.map ChapterCompletion >> onFinish)
                app

        ReasonPrizePurchase purchaseId ->
            Types.PrizePurchase.get
                userId
                purchaseId
                (Result.map PrizePurchase >> onFinish)
                app

        ReasonPrizeRefund purchaseId ->
            Types.PrizePurchase.get
                userId
                purchaseId
                (Result.andThen
                    (\purchase ->
                        case purchase.canceledAt of
                            Just canceledAt ->
                                Ok <| PrizeRefund canceledAt purchase

                            Nothing ->
                                Err "Purchase has not been canceled"
                    )
                    >> onFinish
                )
                app

        ReasonReferral referredUserId ->
            Types.Referral.get
                referredUserId
                (Result.map Referral >> onFinish)
                app

        ReasonWorkshopReferral eventBrightUserId ->
            Types.WorkshopReferral.get eventBrightUserId
                |> Task.map WorkshopReferral
                |> Task.attempt onFinish

        ReasonFacebookLike ->
            Types.FacebookLike.get
                userId
                (Result.map FacebookLike >> onFinish)
                app

        ReasonFacebookWorkshopShare eventId ->
            Types.FacebookWorkshopShare.get userId eventId
                |> Task.map FacebookWorkshopShare
                |> Task.attempt onFinish

        ReasonAdjustment adjustmentId ->
            Types.UcoinAdjustments.get
                userId
                adjustmentId
                (Result.map Adjustment >> onFinish)
                app

        ReasonSurveyCompletion ->
            Task.succeed SurveyCompletion |> Task.attempt onFinish

        ReasonUtypeCompletion ->
            Task.succeed UtypeCompletion |> Task.attempt onFinish

        ReasonTwitterFollow ->
            Task.succeed TwitterFollow |> Task.attempt onFinish

        ReasonYelpReview ->
            Task.succeed YelpReview |> Task.attempt onFinish

        ReasonParentTestimonial ->
            Task.succeed ParentTestimonial |> Task.attempt onFinish

        ReasonStudentTestimonial ->
            Task.succeed StudentTestimonial |> Task.attempt onFinish
