# Learn - UCode LMS

## Developing

1. Download code and dependencies

  ```shell
  $ git clone https://github.com/ucode/learn && cd learn
  $ elm-install
  $ cd functions && npm install
  ```

  *The `elm-install` command comes from elm-github-install (`npm i -g elm-github-install`)*

2. To server the code:

  In one terminal:
  ```shell
  $ ./dev.sh Dashboard # Argument is the module name of a page module, without the Page prefix
  ```

  In another terminal:
  ```shell
  $ firebase serve
  ```

3. Go to http://localhost:5000 in a browser. The dev script only builds the specified page, so you might need to build all the other pages first (see Building Elm Code below)

### Building Elm Code

```shell
$ ./make_all.sh
```

### Deploying

```shell
# Deploy a component like so:
$ firebase deploy --only functions
$ firebase deploy --only functions:http.lti,functions:database.activityOnCreate
$ firebase deploy --only hosting
$ firebase deploy --only database
```

Deploying everything at once with `firebase deploy` isn't recommended, sometimes a few Firebase functions will fail, so it's better to specify which components need deploying.

## Firebase Database Schema

```javascript
/* Users */
{ "users":
    { "$userId":
        { "name": string
        , "email": string
        , "birthDate": string
        , "ucoins": int // cached from other UCoin-related fields
        }
    }
, "students":
    { "$userId":
        { "centerId": string
        , "name": string // cached from user
        , "currentLessonId": string
        , "active": boolean
        , "teamupId": string
        , "notes": string // Maybe null
        }
    }
, "instrDesigners":
    { "$userId":
        { "active": boolean
        }
    }
, "instructorTeamupIds":
    { "$instructorTeamupId":
        { "userId": string
        , "name": string
        }
    }
, "admins":
    { "$userId": true
    }

/* UCoins and Prizes */
, "ucoinAdjustments":
    { "$userId":
        { "$ucoinAdjustmentId":
            { "reason": string // explains why the UCoins were given
            , "adjustedBy":
                { "userId": $userId
                , "userName": string // cached from user
                }
            , "adjustedAt": timestamp
            , "ucoins": int
            }
        }
    }
, "prizes":
    { "$prizeId":
        { "name": string
        , "imageUrl": string // Ex: https://i.imgur.com/abcd.jpg
        , "description": string
        , "price": int
        }
    }
, "prizePurchases":
    { "$userId":
        { "$purchaseId":
            { "prizeId": string
            , "prizeName": string // cached from prizes
            , "cost": int // This stays the same, even if the price changes in the future
            , "purchasedAt": timestamp
            , "validated": boolean // Database function confirms the student has enough UCoins
            , "ordered": timestamp // Date that an AD marked the purchase as "ordered"
            , "canceled": timestamp? // Date that an AD marked the purchase as "canceled"
                                     // Setting this automatically reverts the
                                     // related transaction
            }
        }
    }
, "ucoinTransactionHistory":
    { "$userId":
        { "nextTransactionId": int // This integer tracks the next transaction ID,
                                   // as well as the number of transactions for
                                   // this user. The first transaction is ID 0.
        , "transactions":
            { "$transactionId":
                { "reason": string // must be one of: milestoneCompletions,
                                   // chapterCompletions, prizePurchases, referrals,
                                   // facebookLikes, ucoinAdjustments, exitSurveySubmissions,
                                   // utypeCompletions, prizeRefund, facebookEventShares,
                                   // workshopReferrals, parentTestimonials,
                                   // studentTestimonials, twitterFollows
                , "centerId": string // Center ID -- used only for exitSurveySubmissions
                , "reasonId": string // ID of the related reason. Note that each
                                     // is stored in a different node/path
                , "change": int // positive or negative integer representing a
                                // delta of UCoins
                , "timestamp": int
                }
            }
        }
    }

/* UType */
, "utypeCompletions":
    { "$userId":
        { "completedAt": timestamp
        , "ucoins": int // The value of completing UType at the time of completion
        }
    }

/* Surveys */
, "exitSurveyQuestions":
    { "$exitSurveyQuestionId":
        { "question": string
        , "order": int
        , "options"?: // if not present, the question is short response
            { "$optionId":
                { "option": string
                , "order": int
                , "points": int // number of points awarded for this option -- higher is better
                }
            }
        }
    }
, "exitSurveySubmissions":
    { "$centerId":
        { "$userId":
            { "$teamupSessionId":
                { "timestamp": int
                , "instructorTeamupId": string
                , "currentLessonId": string
                , "responses":
                    { "$exitSurveyQuestionId":
                        { "optionId": string? // not present when the question is short response
                        , "text": string // the text of the option, or the user submitted text
                        , "questionText": string // the question, at the time it was answered
                        }
                    }
                }
            }
        }
    }

/* User invites */
, "instructorInvites":
    { "$id":
        { "email": string
        , "name": string
        , "birthDate": string // yyyy-mm-dd
        , "centerId": string
        , "timestamp": int
        , "teamupId": string
        , "inviter": string
        , "inviterId": string
        }
    }
, "studentInvites":
    { "$id":
        { "email": string
        , "name": string
        , "birthDate": string // yyyy-mm-dd
        , "centerId": string
        , "timestamp": int
        , "teamupId": string
        , "inviter": string
        , "inviterId": string
        }
    }

/* Marketing & Networking */
, "facebookLikes":
    { "$userId":
        { "likedBy": string // ID of the user that liked our page
        , "recordedAt": timestamp
        , "recordedBy":
            { "userId": $userId
            , "userName": string // cached from user
            }
        , "ucoins": int // The value of a like at the time of recording this like.
                            // Used to revoke coins in case the like is removed.
        }
    }
, "twitterFollows":
    { "$userId":
        { "followedBy": string // ID of the user that followed our page
        , "recordedAt": timestamp
        , "recordedByUserId": string
        , "recordedByUserName": string
        , "ucoins": int // The amount of UCoins awarded
        }
    }
, "yelpReviews":
    { "$userId":
        { "recordedAt": timestamp
        , "recordedByUserId": string
        , "recordedByUserName": string
        , "ucoins": int // The amount of UCoins awarded
        }
    }
, "studentTestimonials":
    { "$userId":
        { "$testimonialId":
            { "recordedAt": timestamp
            , "recordedByUserId": string
            , "recordedByUserName": string
            , "ucoins": int // The amount of UCoins awarded
            }
        }
    }
, "parentTestimonials":
    { "$userId":
        { "$testimonialId":
            { "recordedAt": timestamp
            , "recordedByUserId": string
            , "recordedByUserName": string
            , "ucoins": int // The amount of UCoins awarded
            }
        }
    }
, "facebookEventShares":
    { "$userId":
        { "$eventId": // Facebook event ID (from Facebook URL)
            { "sharedBy": string // ID of the user that shared the event
            , "recordedAt": timestamp
            , "recordedBy":
                { "userId": $userId
                , "userName": string // cached from user
                }
            , "ucoins": int // The value of a like at the time of recording
            }
        }
    }
, "referrals":
    { "$userId": // the student that signed up for UCode
        { "referredName": string // Cached name of the student that was referred
        , "referredBy": // the student(s) that recommended UCode to someone
            { "$userId": string // cached name of user
            }
        , "recordedAt": timestamp
        , "recordedBy":
            { "userId": $userId
            , "userName": string // cached from user
            }
        , "ucoins": int // The value of referring one student at the time of
                        // the referral. Used to recalculate each student's reward
                        // if a student is added or removed from the referral
        }
    }
, "workshopReferrals":
    { "$eventBrightUserId": // referred user
        { "referredBy": // the student(s) that recommended the event
              { "$userId": string // cached name
              }
        , "recordedAt": timestamp
        , "recordedBy":
            { "userId": $userId
            , "userName": string // cached from user
            }
        , "ucoins": int // The value of referring one student at the time of
                        // the referral. Used to recalculate each student's reward
                        // if a student is added or removed from the referral
        }
    }

/* Centers */
, "centers":
    { "$centerId":
        { "name": string
        , "shortName": string
        }
    }
, "managerCenters":
    { "$userId":
        { "$centerId": string } // cached center name
    }
, "instructorCenters": // cached from centerInstructors
    { "$userId":
        { "$centerId": string } // cached center name
    }
, "centerInstructors":
    { "$centerId":
        { "$userId": string } // cached instructor name
    }
, "pendingCenterPurchases": // prize purchases, per center, that need to be ordered
    { "$centerId":
        { "$purchaseId":
            { "userName": string
            , "userId": string
            , "prizeName": string
            }
        }
    }


/* Messaging and Notifications */
, "centerNotifications": // TODO not in the database
    { "submissions":
        { "new":
            { "$centerId":
                { "$userId":
                    { "$lessonId":
                        { "$submissionInstrId": string } // user name
                    }
                }
            }
        , "message":
            { "$centerId":
                { "$userId":
                    { "$lessonId":
                        { "$submissionInstrId": string } // user name
                    }
                }
            }
        }
    }
, "projectStepMessages":
    { "$userId": // student
        { "$projectStepId":
            { "$id":
                { "userId": string // sender
                , "name": string // cached user's name
                , "message": string
                , "timestamp": string
                }
            }
        }
    }
, "studentNotifications": // TODO not in the database
    { "submissions":
        { "result":
            { "$userId":
                { "$lessonId":
                    { "$submissionInstrId": number } // score
                }
            }
        , "message":
            { "$userId":
                { "$lessonId":
                    { "$submissionInstrId": string } // name
                }
            }
        }
    }

/* Curricula Definition */
, "milestones":
    { "$id":
        { "name": string
        , "number": int
        }
    }
, "chapters":
    { "$id":
        { "name": string
        , "number": string
        , "milestoneId": string
        }
    }
, "chapterNumbers":
    { "$milestoneId":
        { "$chapterId": int } // chapter number
    }
, "lessons":
    { "$id":
        { "name": string
        , "number": int
        , "chapterId": string
        }
    }
, "lessonNumbers":
    { "$chapterId":
        { "$lessonId": int } // lesson number
    }
, "activities":
    { "$lessonId":
        { "$id":
            { "activityId": string // id of lti, quiz, submission, instruction
            , "activityType": string // lti, quiz, submission, instruction
            , "number": int
            }
        }
    }
, "activityLessons":
    { "$activityId": "$lessonId" }
, "quizzes":
    { "$id":
        { "questionCount": int // how to deal with gaps?
        , "questions":
            { "$id":
                { "questionId": string // id of multResp, hotSpot, etc
                , "kind": string // multResp, hotSpot, etc
                , "number": int // same number = 1 of them randomly
                }
            }
        }
    }
, "questions":
    { "multResp":
        { "$id":
            { "question": string }
        }
    }
, "multRespOptions":
    { "$multRespId":
        { "$id":
            { "content": string
            , "feedback": string
            , "correct": boolean
            }
        }
    }
, "exerciseSets":
    { "$id":
        { "$ltiId":
            { "name": string
            , "number": int // same number means 1 of them randomly
            }
        }
    }
, "exerciseSetActivities":
    { "$exerciseSetId": "$activityId" }
, "exams":
    { "$id":
        { "time": int // time limit in seconds
        , "problems":
            { "name": string
            , "number": int // same number means 1 of them randomly
            , "weight": int
            , "kind": string // lti or multResp
            , "id": string
            }
        }
    }
, "ltis":
    { "$id":
        { "url": string
        , "key": string
        , "secret": string
        }
    }
, "videos":
    { "$id":
        { "type": string // youtube or ucode
        , "id": string // id of video from source, not Firebase
        , "content": string
        }
    }
, "instructions":
    { "$id":
        { "content": string
        }
    }
, "projectSteps":
    { "$id":
        { "instruction": string
        , "rubric": string
        }
    }
, "projectStepActivities":
    { "$projectStepId": "$activityId" }
, "projectStepSubmissionFields":
    { "$projectStepId":
        { "$id":
            { "name": string
            , "lines": int
            , "number": int
            }
        }
    }

/* Users' Curricula Results */
, "lessonResults":
    { "$userId":
        { "$lessonId":
            { "timestamp": int
            , "instructor"?: string // the student's instructor at the time, if available
            }
        }
    }
, "instructorLessonResults":
    { "$userId": // Instructor's uid
        { "$id":
            { "studentId": string // uid
            , "lessonId": string
            , "centerId": string // student's center
            , "timestamp": int
            }
        }
    }
, "activityResults":
    { "$userId":
        { "$activityId": // actual activity id, not quiz/lti/etc id
            { "score": number // percentage
            , "timestamp": int
            }
        }
    }
, "activityQuestionResponses":
    { "$userId":
        { "$activityId":
            { "$quizId":
                { "$responseId": true }
            }
        }
    }
, "questionResponses":
    { "$userId":
        { "$quizId":
            { "$id": // set of question responses
                { "timestamp": int
                , "multResp":
                    { "$multRespId":
                        { "passed": boolean // not used yet
                        , "selections":
                            { "$optionId": boolean }
                        }
                    }
                }
            }
        }
    }
, "exerciseSetResults":
    { "$userId":
        { "$exerciseSetId":
            { "$ltiId":
                { "score": number // percentage
                , "attempts": int
                , "timestamp": int
                }
            }
        }
    }
, "projectStepSubmissions":
    { "$userId":
        { "$projectStepId":
            { "fields":
                { "$field": string } // value
            , "timestamp": int
            }
        }
    }
, "chapterCompletions":
    { "$userId":
        { "$chapterId":
            { "numberAndName": string // Example: "3.1 Basics"
            , "completedAt": timestamp
            , "ucoins": int // The number of UCoins awarded for completing a
                            // chapter at the time this chapter was completed
            , "milestoneId": string
            }
        }
    }
, "milestoneCompletions":
    { "$userId":
        { "$milestoneId":
            { "numberAndName": string // Example: "1 JavaScript"
            , "completedAt": timestamp
            , "ucoins": int // The number of UCoins awarded for completing a
                            // milestone at the time this milestone was completed
            , "centerId": string // may be null if the user is not a student
            }
        }
    }
, "milestoneCompletionsByCenter": // cache for milestoneCompletions
    { "$centerId":
        { "$completionId": // This ID is only used in this node, for now
            { "userId": string
            , "milestoneId": string
            , "completedAt": timestamp
            }
        }
    }
}
