module Types.Lesson exposing (Lesson, LessonActivitiesWithIds, LessonWithActivities, LessonWithId, LessonWithMaybeId, Result, WithLesson, WithLessonId, WithLessons, WithLessonsActivitiesWithIds, WithLessonsDict, WithMaybeLesson, WithMaybeLessonResult, WithMaybeLessonWithId, WithResults, create, createMaybe, decoder, decoderMaybeId, decoderWithId, delete, deleteMaybe, fromSnapshot, get, getAll, lessonActivitiesWithAddedActivitySorted, lessonActivitiesWithChangedActivitySorted, lessonActivitiesWithChangedLesson, lessonActivitiesWithRemovedActivity, lessonDecoder, lessonEncoder, lessonWithActivitiesDecoder, lessonsActivitiesWithIdsSorted, listItemHeadingHtml, listItemHeadingHtmlFromResult, listItemHeadingLockedHtml, passedHtml, recordMaybeLessonResult, recordMaybeLessonResultSnapshot, recordWithAddedActivitySorted, recordWithAddedLessonActivitySnapshotSorted, recordWithAddedLessonSnapshotSorted, recordWithAddedLessonSorted, recordWithAddedResult, recordWithAddedResultSnapshot, recordWithChangedActivitySorted, recordWithChangedDictEntry, recordWithChangedLessonActivitySnapshotSorted, recordWithChangedLessonSnapshotSorted, recordWithChangedLessonSorted, recordWithJustLesson, recordWithJustLessonSnapshot, recordWithJustLessonWithId, recordWithJustLessonWithIdSnapshot, recordWithRemovedActivity, recordWithRemovedDictEntry, recordWithRemovedLesson, recordWithRemovedLessonActivitySnapshot, recordWithRemovedLessonSnapshot, resultDecoder, saveName, saveNumber, sub)

import Dict exposing (Dict)
import Firebase.Database.Snapshot as Snapshot
import Firebase.Database.Types as Types
import Firebase.Errors
import Html as Html
import Html.Attributes as Attributes
import Json.Decode as Decode exposing (Decoder)
import Json.Encode as Encode
import Task exposing (Task)
import Types.Activity as Activity
import UCode.Data as Data exposing (Id)
import UCode.Firebase



-- TYPES


type alias Lesson =
    { name : String
    , number : Int
    , chapterId : String
    }


type alias Result =
    { timestamp : Int
    }


type alias LessonWithId =
    { id : String
    , name : String
    , number : Int
    , chapterId : String
    }


type alias LessonWithMaybeId =
    { id : Maybe String
    , name : String
    , number : Int
    , chapterId : String
    }


type alias LessonWithActivities =
    { id : String
    , activities : List Activity.ActivityWithId
    , name : String
    , number : Int
    , chapterId : String
    }


type alias LessonActivitiesWithIds =
    { lesson : Lesson
    , activities : List ( Data.Id, Activity.Activity )
    }



-- RECORDS WITH LESSON TYPES


type alias WithLesson r =
    { r | lesson : LessonWithId }


type alias WithResults r =
    { r | lessonResults : Dict.Dict Data.Id Result }


type alias WithMaybeLesson r =
    { r | lesson : Maybe Lesson }


type alias WithMaybeLessonResult r =
    { r | lessonResult : Maybe Result }


type alias WithMaybeLessonWithId r =
    { r | lesson : Maybe LessonWithId }


type alias WithLessons r =
    { r | lessons : List ( Data.Id, Lesson ) }


type alias WithLessonsDict r =
    { r | lessons : Dict.Dict Data.Id Lesson }


type alias WithLessonsActivitiesWithIds r =
    { r | lessons : List ( Data.Id, LessonActivitiesWithIds ) }


type alias WithLessonId r =
    { r | lessonId : Data.Id }



-- DECODERS


decoder : Decoder Lesson
decoder =
    Decode.map3 Lesson
        (Decode.field "name" Decode.string)
        (Decode.field "number" Decode.int)
        (Decode.field "chapterId" Decode.string)


resultDecoder : Decoder Result
resultDecoder =
    Decode.map Result
        (Decode.field "timestamp" Decode.int)


decoderWithId : String -> Decoder LessonWithId
decoderWithId id =
    Decode.map3 (LessonWithId id)
        (Decode.field "name" Decode.string)
        (Decode.field "number" Decode.int)
        (Decode.field "chapterId" Decode.string)


decoderMaybeId : String -> Decoder LessonWithMaybeId
decoderMaybeId id =
    Decode.map3 (LessonWithMaybeId (Just id))
        (Decode.field "name" Decode.string)
        (Decode.field "number" Decode.int)
        (Decode.field "chapterId" Decode.string)


lessonDecoder : String -> Decoder LessonWithId
lessonDecoder =
    decoderWithId


lessonEncoder : String -> Int -> String -> Encode.Value
lessonEncoder name number chapterId =
    Encode.object
        [ ( "name", Encode.string name )
        , ( "number", Encode.int number )
        , ( "chapterId", Encode.string chapterId )
        ]


lessonWithActivitiesDecoder : String -> Decoder LessonWithActivities
lessonWithActivitiesDecoder id =
    Decode.map3 (LessonWithActivities id [])
        (Decode.field "name" Decode.string)
        (Decode.field "number" Decode.int)
        (Decode.field "chapterId" Decode.string)



-- UPDATE LESSON IN RECORD


recordWithJustLesson : WithMaybeLesson a -> Lesson -> WithMaybeLesson a
recordWithJustLesson record lesson =
    { record | lesson = Just lesson }


recordMaybeLessonResult : WithMaybeLessonResult a -> Result -> WithMaybeLessonResult a
recordMaybeLessonResult record result =
    { record | lessonResult = Just result }


recordWithJustLessonWithId : WithMaybeLessonWithId a -> LessonWithId -> WithMaybeLessonWithId a
recordWithJustLessonWithId record lesson =
    { record | lesson = Just lesson }


recordWithJustLessonSnapshot : WithMaybeLesson a -> Types.Snapshot -> WithMaybeLesson a
recordWithJustLessonSnapshot record =
    Data.recordWithSnapshotValue record (recordWithJustLesson record) decoder


recordMaybeLessonResultSnapshot : WithMaybeLessonResult a -> Types.Snapshot -> WithMaybeLessonResult a
recordMaybeLessonResultSnapshot record =
    Data.recordWithSnapshotValue record (recordMaybeLessonResult record) resultDecoder


recordWithJustLessonWithIdSnapshot : WithMaybeLessonWithId a -> Types.Snapshot -> WithMaybeLessonWithId a
recordWithJustLessonWithIdSnapshot record =
    Data.recordWithSnapshot record (recordWithJustLessonWithId record) decoderWithId


fromSnapshot : Types.Snapshot -> Maybe Lesson
fromSnapshot =
    Data.maybeFromSnapshot decoder


lessonsActivitiesWithIdsSorted : List ( Data.Id, LessonActivitiesWithIds ) -> List ( Data.Id, LessonActivitiesWithIds )
lessonsActivitiesWithIdsSorted =
    List.sortBy <|
        .number
            << .lesson
            << Tuple.second


recordWithAddedLessonSorted : WithLessonsActivitiesWithIds r -> Data.Id -> Lesson -> WithLessonsActivitiesWithIds r
recordWithAddedLessonSorted record id lesson =
    { record
        | lessons =
            lessonsActivitiesWithIdsSorted <|
                ( id, LessonActivitiesWithIds lesson [] )
                    :: record.lessons
    }


lessonActivitiesWithChangedLesson : Data.Id -> Lesson -> ( Data.Id, LessonActivitiesWithIds ) -> ( Data.Id, LessonActivitiesWithIds )
lessonActivitiesWithChangedLesson id lesson idAndLessonActivities =
    if id == Tuple.first idAndLessonActivities then
        Tuple.mapSecond
            (\lessonActivities -> { lessonActivities | lesson = lesson })
            idAndLessonActivities

    else
        idAndLessonActivities


recordWithChangedLessonSorted : WithLessonsActivitiesWithIds r -> Data.Id -> Lesson -> WithLessonsActivitiesWithIds r
recordWithChangedLessonSorted record id lesson =
    { record
        | lessons =
            lessonsActivitiesWithIdsSorted <|
                List.map (lessonActivitiesWithChangedLesson id lesson) record.lessons
    }


recordWithRemovedLesson : WithLessonsActivitiesWithIds r -> Data.Id -> WithLessonsActivitiesWithIds r
recordWithRemovedLesson record id =
    { record
        | lessons =
            List.filter
                ((/=) id << Tuple.first)
                record.lessons
    }


recordWithAddedLessonSnapshotSorted : WithLessonsActivitiesWithIds r -> Types.Snapshot -> WithLessonsActivitiesWithIds r
recordWithAddedLessonSnapshotSorted record snapshot =
    Data.recordUpdatedFromSnapshot record recordWithAddedLessonSorted decoder snapshot


recordWithChangedLessonSnapshotSorted : WithLessonsActivitiesWithIds r -> Types.Snapshot -> WithLessonsActivitiesWithIds r
recordWithChangedLessonSnapshotSorted record snapshot =
    Data.recordUpdatedFromSnapshot record recordWithChangedLessonSorted decoder snapshot


recordWithRemovedLessonSnapshot : WithLessonsActivitiesWithIds r -> Types.Snapshot -> WithLessonsActivitiesWithIds r
recordWithRemovedLessonSnapshot record snapshot =
    Data.recordUpdatedFromSnapshotKey record recordWithRemovedLesson snapshot


recordWithChangedDictEntry : WithLessonsDict r -> Data.Id -> Lesson -> WithLessonsDict r
recordWithChangedDictEntry record id lesson =
    { record | lessons = Dict.insert id lesson record.lessons }


recordWithRemovedDictEntry : WithLessonsDict r -> Types.Snapshot -> WithLessonsDict r
recordWithRemovedDictEntry record snapshot =
    { record | lessons = Data.dictWithRemovedElementFromSnapshot record.lessons snapshot }


lessonActivitiesWithAddedActivitySorted : Data.Id -> Activity.Activity -> LessonActivitiesWithIds -> LessonActivitiesWithIds
lessonActivitiesWithAddedActivitySorted activityId activity lessonActivities =
    { lessonActivities
        | activities =
            Data.idListSorted <|
                ( activityId, activity )
                    :: lessonActivities.activities
    }


lessonActivitiesWithChangedActivitySorted : Data.Id -> Activity.Activity -> LessonActivitiesWithIds -> LessonActivitiesWithIds
lessonActivitiesWithChangedActivitySorted activityId activity lessonActivities =
    { lessonActivities
        | activities =
            Data.idListSorted <|
                Data.idListReplaced activityId activity lessonActivities.activities
    }


lessonActivitiesWithRemovedActivity : Data.Id -> LessonActivitiesWithIds -> LessonActivitiesWithIds
lessonActivitiesWithRemovedActivity id lessonActivities =
    { lessonActivities
        | activities =
            List.filter ((/=) id << Tuple.first) lessonActivities.activities
    }


recordWithAddedActivitySorted : Data.Id -> WithLessonsActivitiesWithIds r -> Data.Id -> Activity.Activity -> WithLessonsActivitiesWithIds r
recordWithAddedActivitySorted lessonId record activityId activity =
    { record
        | lessons =
            Data.idListUpdated lessonId
                (lessonActivitiesWithAddedActivitySorted activityId activity)
                record.lessons
    }


recordWithChangedActivitySorted : Data.Id -> WithLessonsActivitiesWithIds r -> Data.Id -> Activity.Activity -> WithLessonsActivitiesWithIds r
recordWithChangedActivitySorted lessonId record activityId activity =
    { record
        | lessons =
            Data.idListUpdated lessonId
                (lessonActivitiesWithChangedActivitySorted activityId activity)
                record.lessons
    }


recordWithRemovedActivity : Data.Id -> WithLessonsActivitiesWithIds r -> Data.Id -> Activity.Activity -> WithLessonsActivitiesWithIds r
recordWithRemovedActivity lessonId record activityId activity =
    { record
        | lessons =
            Data.idListUpdated lessonId
                (lessonActivitiesWithRemovedActivity activityId)
                record.lessons
    }


recordWithAddedLessonActivitySnapshotSorted : WithLessonsActivitiesWithIds r -> Data.Id -> Types.Snapshot -> WithLessonsActivitiesWithIds r
recordWithAddedLessonActivitySnapshotSorted record lessonId snapshot =
    Data.recordUpdatedFromSnapshot record (recordWithAddedActivitySorted lessonId) Activity.decoder snapshot


recordWithChangedLessonActivitySnapshotSorted : WithLessonsActivitiesWithIds r -> Data.Id -> Types.Snapshot -> WithLessonsActivitiesWithIds r
recordWithChangedLessonActivitySnapshotSorted record lessonId snapshot =
    Data.recordUpdatedFromSnapshot record (recordWithChangedActivitySorted lessonId) Activity.decoder snapshot


recordWithRemovedLessonActivitySnapshot : WithLessonsActivitiesWithIds r -> Data.Id -> Types.Snapshot -> WithLessonsActivitiesWithIds r
recordWithRemovedLessonActivitySnapshot record lessonId snapshot =
    Data.recordUpdatedFromSnapshot record (recordWithRemovedActivity lessonId) Activity.decoder snapshot


recordWithAddedResult : WithResults r -> Data.Id -> Result -> WithResults r
recordWithAddedResult record lessonId result =
    { record | lessonResults = Dict.insert lessonId result record.lessonResults }


recordWithAddedResultSnapshot : WithResults r -> Types.Snapshot -> WithResults r
recordWithAddedResultSnapshot record snapshot =
    Data.recordUpdatedFromSnapshot
        record
        recordWithAddedResult
        resultDecoder
        snapshot



-- VIEW


passedHtml : Maybe Result -> Html.Html msg
passedHtml result =
    case result of
        Just result ->
            Html.span
                [ Attributes.title (Data.formatDate result.timestamp) ]
                [ Html.text ""
                ]

        Nothing ->
            Html.text ""


listItemHeadingHtmlFromResult : Data.Id -> String -> Int -> Html.Html msg -> Html.Html msg
listItemHeadingHtmlFromResult lessonId name index passedHtml =
    Html.div
        [ Attributes.id ("lesson_" ++ lessonId), Attributes.class "lesson__card-heading" ]
        [ passedHtml
        , Html.h3 [ Attributes.class "lesson__card-heading-1" ] [ Html.text ("Lesson " ++ toString (index + 1)) ]
        , Html.h4 [ Attributes.class "lesson__card-heading-2" ] [ Html.text name ]
        ]


listItemHeadingHtml : Data.Id -> String -> Int -> Maybe Result -> Html.Html msg
listItemHeadingHtml lessonId name index =
    listItemHeadingHtmlFromResult lessonId name index
        << passedHtml


listItemHeadingLockedHtml : Data.Id -> String -> Html.Html msg
listItemHeadingLockedHtml lessonId name =
    Html.h4
        [ Attributes.id ("lesson_" ++ lessonId) ]
        [ Html.text ("🔒 " ++ name) ]



-- REQUESTS


sub : UCode.Firebase.FirebaseApp -> (Types.Snapshot -> msg) -> String -> Sub msg
sub =
    UCode.Firebase.idSubscription "lessons"


get : Data.Id -> Types.Database -> Task String LessonWithId
get id =
    UCode.Firebase.onceTask ("lessons/" ++ id)
        >> Task.andThen
            (Snapshot.value
                >> Decode.decodeValue (decoderWithId id)
                >> Data.taskFromResult
            )


getAll : Types.Database -> Task String (List LessonWithId)
getAll =
    UCode.Firebase.onceTask "lessons"
        >> Task.andThen
            (Snapshot.value
                >> Decode.decodeValue (Data.indexedKeyValueDecoder lessonDecoder)
                >> Data.taskFromResult
            )


saveNumber : Data.Id -> (Result.Result Firebase.Errors.Error () -> msg) -> Int -> Types.Database -> Cmd msg
saveNumber lessonId =
    UCode.Firebase.saveInt ("lessons/" ++ lessonId ++ "/number")


saveName : Data.Id -> (Result.Result Firebase.Errors.Error () -> msg) -> String -> Types.Database -> Cmd msg
saveName lessonId =
    UCode.Firebase.saveString ("lessons/" ++ lessonId ++ "/name")


create : (Result.Result Firebase.Errors.Error () -> msg) -> String -> Int -> String -> Types.Database -> Cmd msg
create createdMsg name number chapterId =
    UCode.Firebase.pushValue "lessons" createdMsg <|
        lessonEncoder name number chapterId


createMaybe : (Result.Result Firebase.Errors.Error () -> msg) -> String -> Int -> String -> Maybe UCode.Firebase.FirebaseApp -> Cmd msg
createMaybe createdMsg name number chapterId =
    UCode.Firebase.foldFirebaseDb <|
        create createdMsg name number chapterId


delete : (Result.Result Firebase.Errors.Error () -> msg) -> Data.Id -> Types.Database -> Cmd msg
delete deletedMsg id =
    UCode.Firebase.removeNode ("lessons/" ++ id) deletedMsg


deleteMaybe : (Result.Result Firebase.Errors.Error () -> msg) -> Data.Id -> Maybe UCode.Firebase.FirebaseApp -> Cmd msg
deleteMaybe deletedMsg id =
    UCode.Firebase.removeNodeMaybe ("lessons/" ++ id) deletedMsg
