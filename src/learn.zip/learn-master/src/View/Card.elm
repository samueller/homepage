module View.Card exposing (basic, withMaxWidth)

import Html exposing (..)
import Material.Options exposing (css)
import Material.Card as Card
import Material.Elevation as Elevation
import Material.Color as Color


basic : String -> Html msg -> Html msg
basic title body =
    Card.view [ Elevation.e2, css "width" "auto" ]
        [ Card.title [ Card.border ] [ Card.head [] [ text title ] ]
        , Card.text [ Color.text Color.black ] [ body ]
        ]


withMaxWidth : String -> Int -> Html msg -> Html msg
withMaxWidth title maxWidth body =
    Card.view
        [ Elevation.e2
        , css "width" "auto"
        , css "max-width" (toString maxWidth ++ "px")
        , css "margin" "auto"
        ]
        [ Card.title [ Card.border ] [ Card.head [] [ text title ] ]
        , Card.text [ Color.text Color.black ] [ body ]
        ]
