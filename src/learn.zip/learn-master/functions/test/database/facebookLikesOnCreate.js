import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const facebookLikesOnCreate =
  proxyquire(
    '../../database/facebookLikesOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CREATE FACEBOOK LIKES TRANSACTION

test('createFacebookLikesTransaction creates a valid transaction', async t => {
  await facebookLikesOnCreate._test.createFacebookLikesTransaction(
    { userId: 'testUserId' }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'facebookLikes',
          change: 350,
          timestamp:
            ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})
