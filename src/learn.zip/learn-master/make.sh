elm-make src/Page/$1.elm --output public/elm/$1.js
