const logWithSeverity = severity => message => object => {
    console[severity](message, object)
    return object
}

exports.error = message =>
    logWithSeverity('error')(message)

exports.info = message =>
    logWithSeverity('info')(message)

exports.debug = message =>
    logWithSeverity('log')(message)
