var _ucode$learn$Native_Browser = function () {
    function queryParam(param) {
        return (new URLSearchParams(window.location.search)).get(param) || ''
    }

    function queryParamMaybe(param) {
        const result = queryParam(param)
        return result
            ? { ctor: 'Just', _0: result }
            : { ctor: 'Nothing' }
    }

    function fragment() {
        return window.location.hash.substring(1)
    }

    return {
        queryParam,
        queryParamMaybe,
        fragment
    }
}()