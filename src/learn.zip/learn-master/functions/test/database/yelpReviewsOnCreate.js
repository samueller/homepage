import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const yelpReviewsOnCreate =
  proxyquire(
    '../../database/yelpReviewsOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CREATE YELP REVIEW TRANSACTION

test('createYelpReviewTransaction creates a valid transaction', async t => {
  await yelpReviewsOnCreate._test.createYelpReviewTransaction(
    { userId: 'testUserId' }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'yelpReviews',
          change: 500,
          timestamp:
            ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})
