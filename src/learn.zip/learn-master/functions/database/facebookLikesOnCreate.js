const functions = require('firebase-functions')
const createTransaction = require('../utils/createTransaction')
const constants = require('../constants')

const createFacebookLikesTransaction = ({ userId }) =>
  createTransaction(
    userId,
    'facebookLikes',
    null,
    false,
    constants.UCOIN_VALUES.FACEBOOK_LIKE,
    `facebookLikes/${userId}/ucoins`
  )

module.exports =
  functions.database.ref('facebookLikes/{userId}')
    .onCreate((snap, context) =>
      createFacebookLikesTransaction(context.params)
    )

module.exports._test = { createFacebookLikesTransaction }
