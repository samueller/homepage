// eslint-disable-next-line no-unused-vars
const functions = require('firebase-functions')
const admin = require('firebase-admin')
admin.initializeApp()

const exportFunctionsOfType = functionType => {
  const path = require('path')
  const fs = require('fs')
  const files = fs.readdirSync(path.join(__dirname, functionType))
  if (!module.exports[functionType]) {
    module.exports[functionType] = {}
  }
  files.forEach(file => {
    const functionName = file.split('.')[0]
    module.exports[functionType][functionName] = require(`./${functionType}/${functionName}`)
  })
}

if (process.env.FUNCTION_NAME) {
  console.log('Exporting function ' + process.env.FUNCTION_NAME)
  const [ functionType, functionName ] = process.env.FUNCTION_NAME.split('-')
  if (!module.exports[functionType]) {
    module.exports[functionType] = {}
  }
  module.exports[functionType][functionName] =
    require(`./${functionType}/${functionName}`)
} else {
  console.log('Exporting all functions')
  exportFunctionsOfType('database')
  exportFunctionsOfType('http')
}
