module Types.PrizePurchase exposing (..)

import Task exposing (Task)
import Json.Decode as Decode exposing (Decoder, Value)
import Json.Encode as Encode
import UCode.Data as Data exposing (Id)
import UCode.Firebase exposing (FirebaseApp)
import Types.Prize exposing (Prize)


type alias PrizePurchase =
    { userId : Id
    , id : Id
    , prizeId : Id
    , prizeName : String
    , cost : Int
    , purchasedAt : Int
    , canceledAt : Maybe Int
    }


type alias PendingPurchase =
    { centerId : Id
    , purchaseId : Id
    , userName : String
    , userId : String
    , prizeName : String
    }


prizePurchaseDecoder : Id -> Id -> Decoder PrizePurchase
prizePurchaseDecoder userId prizePurchaseId =
    Decode.map5 (PrizePurchase userId prizePurchaseId)
        (Decode.field "prizeId" Decode.string)
        (Decode.field "prizeName" Decode.string)
        (Decode.field "cost" Decode.int)
        (Decode.field "purchasedAt" Decode.int)
        (Decode.maybe <| Decode.field "canceled" Decode.int)


purchaseEncoder : Prize -> Value
purchaseEncoder prize =
    Encode.object
        [ ( "prizeId", Encode.string prize.id )
        , ( "prizeName", Encode.string prize.name )
        , ( "cost", Encode.int prize.price )
        , ( "purchasedAt", UCode.Firebase.serverTime )
        ]


pendingPurchaseDecoder : Id -> Id -> Decoder PendingPurchase
pendingPurchaseDecoder centerId purchaseId =
    Decode.map3 (PendingPurchase centerId purchaseId)
        (Decode.field "userName" Decode.string)
        (Decode.field "userId" Decode.string)
        (Decode.field "prizeName" Decode.string)


create : Id -> Prize -> (Result String () -> msg) -> FirebaseApp -> Cmd msg
create userId prize onFinish =
    UCode.Firebase.pushTask
        [ "prizePurchases", userId ]
        (purchaseEncoder prize)
        >> Task.attempt onFinish


get : Id -> Id -> (Result String PrizePurchase -> msg) -> FirebaseApp -> Cmd msg
get userId prizePurchaseId onFinish =
    UCode.Firebase.valueTask
        [ "prizePurchases", userId, prizePurchaseId ]
        (prizePurchaseDecoder userId prizePurchaseId)
        >> Task.attempt onFinish


subPendingPurchasesForCenter : Id -> (Result String ( PendingPurchase, Bool ) -> msg) -> FirebaseApp -> Sub msg
subPendingPurchasesForCenter centerId =
    UCode.Firebase.subChildren
        [ "pendingCenterPurchases", centerId ]
        (pendingPurchaseDecoder centerId)


markAsPurchased : PendingPurchase -> FirebaseApp -> Task String ()
markAsPurchased pendingPurchase =
    UCode.Firebase.updateMulti
        []
        [ ( [ "pendingCenterPurchases", pendingPurchase.centerId, pendingPurchase.purchaseId ]
          , Encode.null
          )
        , ( [ "prizePurchases", pendingPurchase.userId, pendingPurchase.purchaseId, "ordered" ]
          , UCode.Firebase.serverTime
          )
        ]


markAsCanceled : PendingPurchase -> FirebaseApp -> Task String ()
markAsCanceled pendingPurchase =
    UCode.Firebase.setTask
        [ "prizePurchases"
        , pendingPurchase.userId
        , pendingPurchase.purchaseId
        , "canceled"
        ]
        UCode.Firebase.serverTime
