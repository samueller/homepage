import test from 'ava'
import proxyquire from 'proxyquire'
import { createAdminMock } from '../_test_utils'

const { mockdatabase, adminMock } = createAdminMock()

const parentTestimonialsOnCreate =
  proxyquire(
    '../../database/parentTestimonialsOnCreate',
    { 'firebase-admin': Object.assign({ '@global': true }, adminMock) }
  )

// CREATE PARENT TESTIMONIALS TRANSACTION

test('createParentTestimonialsTransaction creates a valid transaction', async t => {
  await parentTestimonialsOnCreate._test.createParentTestimonialsTransaction(
    { userId: 'testUserId', testimonialId: 'testimonial-12345' }
  )
  const { ucoinTransactionHistory } = mockdatabase.getData()
  t.deepEqual(
    ucoinTransactionHistory.testUserId,
    {
      nextTransactionId: 1,
      transactions: [
        {
          reason: 'parentTestimonials',
          reasonId: 'testimonial-12345',
          change: 500,
          timestamp:
            ucoinTransactionHistory.testUserId.transactions[0].timestamp
        }
      ]
    }
  )
})
