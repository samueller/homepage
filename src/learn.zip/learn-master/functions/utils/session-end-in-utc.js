module.exports = session => {
  const sessionDuration = (new Date(session.end_time)) - (new Date(session.start_time))
  return (new Date(session.utc_start).getTime()) + sessionDuration
}
