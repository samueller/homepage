const functions = require('firebase-functions')
const db = require('../utils/db')
const createTransaction = require('../utils/createTransaction')

const cacheByCenter = ({ userId, milestoneId }, val) =>
  val.centerId
    && db.ref('milestoneCompletionsByCenter', val.centerId)
      .push({
        userId,
        milestoneId,
        completedAt: val.completedAt
      })

const createMilestoneCompletionTransaction = ({ userId, milestoneId }, val) =>
  createTransaction(
    userId,
    'milestoneCompletions',
    milestoneId,
    false,
    val.ucoins,
    false
  )

module.exports =
  functions.database.ref('milestoneCompletions/{userId}/{milestoneId}')
    .onCreate((snap, context) => [
      cacheByCenter(context.params, snap.val()),
      createMilestoneCompletionTransaction(context.params, snap.val())
    ])

module.exports._test = { cacheByCenter, createMilestoneCompletionTransaction }
